import sys
import os
import cv2
import numpy as np
from PyQt6.QtWidgets import (
    QApplication, QMainWindow, QWidget, QHBoxLayout, QVBoxLayout,
    QLabel, QPushButton, QListWidget, QSlider, QComboBox,
    QStackedWidget, QFileDialog, QGroupBox, QSizePolicy, QScrollArea
)
from PyQt6.QtCore import Qt, pyqtSignal
from PyQt6.QtGui import QPixmap, QImage

from processing.binarize_fn import binarize_custom, binarize_otsu, binarize_adaptive
from processing.color_space_fn import split_channels, COLOR_MODES
from processing.edge_detect_fn import canny, sobel, laplacian, scharr
from processing.intensity_transform_fn import gamma, log_transform, linear, histogram_eq, clahe
from processing.image_correction_fn import affine


def ndarray_to_qpixmap(image: np.ndarray) -> QPixmap:
    if image is None:
        return QPixmap()
    if len(image.shape) == 2:
        h, w = image.shape
        qimg = QImage(image.data, w, h, w, QImage.Format.Format_Grayscale8)
    else:
        h, w, ch = image.shape
        rgb = cv2.cvtColor(image, cv2.COLOR_BGR2RGB)
        qimg = QImage(rgb.data, w, h, w * ch, QImage.Format.Format_RGB888)
    return QPixmap.fromImage(qimg)


class LabeledSlider(QWidget):
    valueChanged = pyqtSignal(int)

    def __init__(self, label: str, min_val: int, max_val: int, default: int, display_fn=None):
        super().__init__()
        self._display_fn = display_fn or (lambda v: str(v))
        layout = QHBoxLayout(self)
        layout.setContentsMargins(0, 0, 0, 0)
        self._name_label = QLabel(label)
        self._name_label.setFixedWidth(120)
        self._slider = QSlider(Qt.Orientation.Horizontal)
        self._slider.setRange(min_val, max_val)
        self._slider.setValue(default)
        self._val_label = QLabel(self._display_fn(default))
        self._val_label.setFixedWidth(60)
        self._slider.valueChanged.connect(self._on_change)
        layout.addWidget(self._name_label)
        layout.addWidget(self._slider)
        layout.addWidget(self._val_label)

    def _on_change(self, v):
        self._val_label.setText(self._display_fn(v))
        self.valueChanged.emit(v)

    def value(self):
        return self._slider.value()


class BinarizePanel(QWidget):
    changed = pyqtSignal()

    def __init__(self):
        super().__init__()
        layout = QVBoxLayout(self)
        self._mode_combo = QComboBox()
        self._mode_combo.addItems(["自訂門檻", "Otsu 自動", "自適應"])
        layout.addWidget(QLabel("二值化模式："))
        layout.addWidget(self._mode_combo)
        self._threshold_slider = LabeledSlider("門檻值", 0, 255, 127)
        self._blocksize_slider = LabeledSlider("BlockSize", 0, 249, 4, lambda v: str(2*v+3))
        self._c_slider = LabeledSlider("C 值", 0, 100, 52, lambda v: str(v-50))
        layout.addWidget(self._threshold_slider)
        layout.addWidget(self._blocksize_slider)
        layout.addWidget(self._c_slider)
        layout.addStretch()
        self._mode_combo.currentIndexChanged.connect(self._update_visibility)
        self._mode_combo.currentIndexChanged.connect(lambda _: self.changed.emit())
        self._threshold_slider.valueChanged.connect(lambda _: self.changed.emit())
        self._blocksize_slider.valueChanged.connect(lambda _: self.changed.emit())
        self._c_slider.valueChanged.connect(lambda _: self.changed.emit())
        self._update_visibility(0)

    def _update_visibility(self, idx):
        self._threshold_slider.setVisible(idx == 0)
        self._blocksize_slider.setVisible(idx == 2)
        self._c_slider.setVisible(idx == 2)

    def apply(self, image: np.ndarray) -> np.ndarray:
        gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY) if len(image.shape) == 3 else image
        idx = self._mode_combo.currentIndex()
        if idx == 0:
            return binarize_custom(gray, self._threshold_slider.value())
        elif idx == 1:
            return binarize_otsu(gray)
        else:
            return binarize_adaptive(gray, self._blocksize_slider.value(), self._c_slider.value())

    def save(self, image: np.ndarray, image_path: str) -> str:
        result = self.apply(image)
        folder = os.path.join(os.path.dirname(image_path), "Binarized")
        os.makedirs(folder, exist_ok=True)
        modes = ["custom", "otsu", "adaptive"]
        out = os.path.join(folder, f"{os.path.splitext(os.path.basename(image_path))[0]}_{modes[self._mode_combo.currentIndex()]}.jpg")
        cv2.imwrite(out, result)
        return out


class ColorSpacePanel(QWidget):
    changed = pyqtSignal()

    def __init__(self):
        super().__init__()
        layout = QVBoxLayout(self)
        self._mode_combo = QComboBox()
        self._mode_combo.addItems(COLOR_MODES)
        self._channel_combo = QComboBox()
        layout.addWidget(QLabel("色彩空間："))
        layout.addWidget(self._mode_combo)
        layout.addWidget(QLabel("通道："))
        layout.addWidget(self._channel_combo)
        layout.addStretch()
        self._mode_combo.currentIndexChanged.connect(self._update_channels)
        self._mode_combo.currentIndexChanged.connect(lambda _: self.changed.emit())
        self._channel_combo.currentIndexChanged.connect(lambda _: self.changed.emit())
        self._update_channels(0)

    def _update_channels(self, idx):
        self._channel_combo.blockSignals(True)
        self._channel_combo.clear()
        mode = COLOR_MODES[idx]
        if mode == "GRAY":
            self._channel_combo.addItems(["Gray"])
        elif mode in ("BGR", "RGB"):
            self._channel_combo.addItems(["Ch0", "Ch1", "Ch2"])
        else:
            self._channel_combo.addItems(["Ch0", "Ch1", "Ch2"])
        self._channel_combo.blockSignals(False)

    def apply(self, image: np.ndarray) -> np.ndarray:
        channels = split_channels(image, self._mode_combo.currentIndex())
        ch_idx = min(self._channel_combo.currentIndex(), len(channels) - 1)
        return channels[ch_idx]

    def save(self, image: np.ndarray, image_path: str) -> str:
        result = self.apply(image)
        folder = os.path.join(os.path.dirname(image_path), "Color_Space_Channel")
        os.makedirs(folder, exist_ok=True)
        mode = COLOR_MODES[self._mode_combo.currentIndex()]
        ch = self._channel_combo.currentIndex()
        out = os.path.join(folder, f"{os.path.splitext(os.path.basename(image_path))[0]}_{mode}_ch{ch}.jpg")
        cv2.imwrite(out, result)
        return out


class EdgeDetectPanel(QWidget):
    changed = pyqtSignal()

    def __init__(self):
        super().__init__()
        layout = QVBoxLayout(self)
        self._method_combo = QComboBox()
        self._method_combo.addItems(["Canny", "Sobel", "Laplacian", "Scharr"])
        layout.addWidget(QLabel("偵測方法："))
        layout.addWidget(self._method_combo)
        self._low_slider = LabeledSlider("低門檻", 0, 255, 100)
        self._high_slider = LabeledSlider("高門檻", 0, 255, 200)
        self._ksize_slider = LabeledSlider("Kernel Size", 0, 14, 0, lambda v: str(2*v+3))
        layout.addWidget(self._low_slider)
        layout.addWidget(self._high_slider)
        layout.addWidget(self._ksize_slider)
        layout.addStretch()
        self._method_combo.currentIndexChanged.connect(self._update_visibility)
        self._method_combo.currentIndexChanged.connect(lambda _: self.changed.emit())
        self._low_slider.valueChanged.connect(lambda _: self.changed.emit())
        self._high_slider.valueChanged.connect(lambda _: self.changed.emit())
        self._ksize_slider.valueChanged.connect(lambda _: self.changed.emit())
        self._update_visibility(0)

    def _update_visibility(self, idx):
        self._low_slider.setVisible(idx == 0)
        self._high_slider.setVisible(idx == 0)
        self._ksize_slider.setVisible(idx == 1)

    def _to_gray(self, image):
        return cv2.cvtColor(image, cv2.COLOR_BGR2GRAY) if len(image.shape) == 3 else image

    def apply(self, image: np.ndarray) -> np.ndarray:
        gray = self._to_gray(image)
        idx = self._method_combo.currentIndex()
        if idx == 0:
            return canny(gray, self._low_slider.value(), self._high_slider.value())
        elif idx == 1:
            return sobel(gray, self._ksize_slider.value())
        elif idx == 2:
            return laplacian(gray)
        else:
            return scharr(gray)

    def save(self, image: np.ndarray, image_path: str) -> str:
        result = self.apply(image)
        folder = os.path.join(os.path.dirname(image_path), "Edge_Detected")
        os.makedirs(folder, exist_ok=True)
        methods = ["canny", "sobel", "laplacian", "scharr"]
        out = os.path.join(folder, f"{os.path.splitext(os.path.basename(image_path))[0]}_{methods[self._method_combo.currentIndex()]}.jpg")
        cv2.imwrite(out, result)
        return out


class IntensityPanel(QWidget):
    changed = pyqtSignal()

    def __init__(self):
        super().__init__()
        layout = QVBoxLayout(self)
        self._mode_combo = QComboBox()
        self._mode_combo.addItems(["Gamma", "對數轉換", "線性轉換", "直方圖等化", "CLAHE 自適應等化"])
        layout.addWidget(QLabel("轉換模式："))
        layout.addWidget(self._mode_combo)
        self._gamma_slider = LabeledSlider("Gamma", 1, 300, 100, lambda v: f"{v/100:.2f}")
        self._k_slider = LabeledSlider("k 值", 1, 50, 10, lambda v: f"{v/10:.1f}")
        self._a_slider = LabeledSlider("a 值", 50, 300, 100, lambda v: f"{v/100:.2f}")
        self._b_slider = LabeledSlider("b 值", 0, 200, 100, lambda v: str(v-100))
        self._clip_slider = LabeledSlider("clipLimit", 1, 40, 20, lambda v: f"{v/10:.1f}")
        for w in [self._gamma_slider, self._k_slider, self._a_slider, self._b_slider, self._clip_slider]:
            layout.addWidget(w)
        layout.addStretch()
        self._mode_combo.currentIndexChanged.connect(self._update_visibility)
        self._mode_combo.currentIndexChanged.connect(lambda _: self.changed.emit())
        for w in [self._gamma_slider, self._k_slider, self._a_slider, self._b_slider, self._clip_slider]:
            w.valueChanged.connect(lambda _: self.changed.emit())
        self._update_visibility(0)

    def _update_visibility(self, idx):
        self._gamma_slider.setVisible(idx == 0)
        self._k_slider.setVisible(idx == 1)
        self._a_slider.setVisible(idx == 2)
        self._b_slider.setVisible(idx == 2)
        self._clip_slider.setVisible(idx == 4)

    def _to_gray(self, image):
        return cv2.cvtColor(image, cv2.COLOR_BGR2GRAY) if len(image.shape) == 3 else image

    def apply(self, image: np.ndarray) -> np.ndarray:
        gray = self._to_gray(image)
        idx = self._mode_combo.currentIndex()
        if idx == 0:
            return gamma(gray, self._gamma_slider.value() / 100)
        elif idx == 1:
            return log_transform(gray, self._k_slider.value() / 10)
        elif idx == 2:
            return linear(gray, self._a_slider.value() / 100, self._b_slider.value() - 100)
        elif idx == 3:
            return histogram_eq(gray)
        else:
            return clahe(gray, self._clip_slider.value() / 10)

    def save(self, image: np.ndarray, image_path: str) -> str:
        result = self.apply(image)
        folder = os.path.join(os.path.dirname(image_path), "Intensity_Transform")
        os.makedirs(folder, exist_ok=True)
        modes = ["gamma", "log", "linear", "hist_eq", "clahe"]
        out = os.path.join(folder, f"{os.path.splitext(os.path.basename(image_path))[0]}_{modes[self._mode_combo.currentIndex()]}.jpg")
        cv2.imwrite(out, result)
        return out


class CorrectionPanel(QWidget):
    changed = pyqtSignal()

    def __init__(self):
        super().__init__()
        layout = QVBoxLayout(self)
        layout.addWidget(QLabel("仿射變換："))
        self._dx_slider = LabeledSlider("X 偏移", 0, 100, 30)
        self._dy_slider = LabeledSlider("Y 偏移", 0, 100, 30)
        layout.addWidget(self._dx_slider)
        layout.addWidget(self._dy_slider)
        layout.addStretch()
        self._dx_slider.valueChanged.connect(lambda _: self.changed.emit())
        self._dy_slider.valueChanged.connect(lambda _: self.changed.emit())

    def apply(self, image: np.ndarray) -> np.ndarray:
        return affine(image, self._dx_slider.value(), self._dy_slider.value())

    def save(self, image: np.ndarray, image_path: str) -> str:
        result = self.apply(image)
        folder = os.path.join(os.path.dirname(image_path), "Image_Correction")
        os.makedirs(folder, exist_ok=True)
        dx, dy = self._dx_slider.value(), self._dy_slider.value()
        out = os.path.join(folder, f"{os.path.splitext(os.path.basename(image_path))[0]}_affine_dx{dx}_dy{dy}.jpg")
        cv2.imwrite(out, result)
        return out


class MainWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("影像處理工具")
        self.resize(1100, 700)
        self._image: np.ndarray | None = None
        self._image_path: str = ""

        central = QWidget()
        self.setCentralWidget(central)
        root = QVBoxLayout(central)

        # 頂部工具列
        toolbar = QHBoxLayout()
        self._load_btn = QPushButton("📂 載入圖片")
        self._save_btn = QPushButton("💾 儲存結果")
        self._status_label = QLabel("尚未載入圖片")
        self._save_btn.setEnabled(False)
        self._load_btn.clicked.connect(self._load_image)
        self._save_btn.clicked.connect(self._save_result)
        toolbar.addWidget(self._load_btn)
        toolbar.addWidget(self._save_btn)
        toolbar.addWidget(self._status_label)
        toolbar.addStretch()
        root.addLayout(toolbar)

        # 主體：左側預覽 + 右側控制
        body = QHBoxLayout()
        root.addLayout(body)

        # 左側：圖片顯示
        self._preview = QLabel("請先載入圖片")
        self._preview.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self._preview.setMinimumSize(600, 500)
        self._preview.setStyleSheet("background:#1e1e1e; color:#888; border:1px solid #444;")
        self._preview.setSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Expanding)
        body.addWidget(self._preview, stretch=3)

        # 右側：方法選擇 + 參數面板
        right = QVBoxLayout()
        body.addLayout(right, stretch=1)

        method_group = QGroupBox("處理方法")
        mg_layout = QVBoxLayout(method_group)
        self._method_list = QListWidget()
        self._method_list.addItems(["色彩空間分離", "二值化", "邊緣偵測", "強度轉換", "影像校正"])
        self._method_list.setCurrentRow(0)
        mg_layout.addWidget(self._method_list)
        right.addWidget(method_group)

        param_group = QGroupBox("參數調整")
        pg_layout = QVBoxLayout(param_group)
        self._param_stack = QStackedWidget()
        self._color_panel = ColorSpacePanel()
        self._binarize_panel = BinarizePanel()
        self._edge_panel = EdgeDetectPanel()
        self._intensity_panel = IntensityPanel()
        self._correction_panel = CorrectionPanel()
        for p in [self._color_panel, self._binarize_panel, self._edge_panel,
                  self._intensity_panel, self._correction_panel]:
            self._param_stack.addWidget(p)
            p.changed.connect(self._update_preview)
        pg_layout.addWidget(self._param_stack)
        right.addWidget(param_group)

        self._method_list.currentRowChanged.connect(self._param_stack.setCurrentIndex)
        self._method_list.currentRowChanged.connect(lambda _: self._update_preview())

    def _load_image(self):
        path, _ = QFileDialog.getOpenFileName(
            self, "選擇圖片", "",
            "圖片檔案 (*.png *.jpg *.jpeg *.bmp)"
        )
        if not path:
            return
        img = cv2.imread(path)
        if img is None:
            self._status_label.setText("無法讀取圖片")
            return
        self._image = img
        self._image_path = path
        orig_folder = os.path.join(os.path.dirname(path), "Original Image")
        os.makedirs(orig_folder, exist_ok=True)
        cv2.imwrite(os.path.join(orig_folder, os.path.basename(path)), img)
        self._status_label.setText(f"已載入：{os.path.basename(path)}")
        self._save_btn.setEnabled(True)
        self._update_preview()

    def _current_panel(self):
        panels = [self._color_panel, self._binarize_panel, self._edge_panel,
                  self._intensity_panel, self._correction_panel]
        return panels[self._method_list.currentRow()]

    def _update_preview(self):
        if self._image is None:
            return
        try:
            result = self._current_panel().apply(self._image)
            pix = ndarray_to_qpixmap(result)
            scaled = pix.scaled(
                self._preview.width(), self._preview.height(),
                Qt.AspectRatioMode.KeepAspectRatio,
                Qt.TransformationMode.SmoothTransformation
            )
            self._preview.setPixmap(scaled)
        except Exception as e:
            self._status_label.setText(f"預覽錯誤：{e}")

    def _save_result(self):
        if self._image is None:
            return
        try:
            out = self._current_panel().save(self._image, self._image_path)
            self._status_label.setText(f"已儲存：{os.path.relpath(out, os.path.dirname(self._image_path))}")
        except Exception as e:
            self._status_label.setText(f"儲存錯誤：{e}")

    def resizeEvent(self, event):
        super().resizeEvent(event)
        self._update_preview()


def main():
    app = QApplication(sys.argv)
    app.setStyle("Fusion")
    win = MainWindow()
    win.show()
    sys.exit(app.exec())


if __name__ == "__main__":
    main()
