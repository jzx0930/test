import sys
import os
sys.path.insert(0, os.path.dirname(__file__))

import cv2
import numpy as np
import streamlit as st
from PIL import Image

from processing.binarize_fn import binarize_custom, binarize_otsu, binarize_adaptive
from processing.color_space_fn import split_channels, COLOR_MODES
from processing.edge_detect_fn import canny, sobel, laplacian, scharr
from processing.intensity_transform_fn import gamma, log_transform, linear, histogram_eq, clahe
from processing.image_correction_fn import affine


def pil_to_bgr(pil_img: Image.Image) -> np.ndarray:
    return cv2.cvtColor(np.array(pil_img.convert("RGB")), cv2.COLOR_RGB2BGR)


def bgr_to_pil(img: np.ndarray) -> Image.Image:
    if len(img.shape) == 2:
        return Image.fromarray(img)
    return Image.fromarray(cv2.cvtColor(img, cv2.COLOR_BGR2RGB))


def to_gray(image: np.ndarray) -> np.ndarray:
    return cv2.cvtColor(image, cv2.COLOR_BGR2GRAY) if len(image.shape) == 3 else image


st.set_page_config(page_title="影像處理工具", layout="wide")
st.title("影像處理工具")

uploaded = st.file_uploader("載入圖片", type=["png", "jpg", "jpeg", "bmp"])

if uploaded is None:
    st.info("請上傳一張圖片開始使用")
    st.stop()

pil_img = Image.open(uploaded)
image = pil_to_bgr(pil_img)

method = st.sidebar.radio(
    "處理方法",
    ["色彩空間分離", "二值化", "邊緣偵測", "強度轉換", "影像校正"]
)

st.sidebar.markdown("---")
st.sidebar.markdown("### 參數調整")

result = None

if method == "色彩空間分離":
    mode_idx = st.sidebar.selectbox("色彩空間", range(len(COLOR_MODES)), format_func=lambda i: COLOR_MODES[i])
    channels = split_channels(image, mode_idx)
    ch_idx = st.sidebar.selectbox("通道", range(len(channels)), format_func=lambda i: f"Ch{i}")
    result = channels[ch_idx]

elif method == "二值化":
    mode = st.sidebar.radio("模式", ["自訂門檻", "Otsu 自動", "自適應"])
    gray = to_gray(image)
    if mode == "自訂門檻":
        thresh = st.sidebar.slider("門檻值", 0, 255, 127)
        result = binarize_custom(gray, thresh)
    elif mode == "Otsu 自動":
        result = binarize_otsu(gray)
    else:
        bs = st.sidebar.slider("BlockSize（奇數）", 0, 249, 4, help="實際值 = 2n+3")
        c = st.sidebar.slider("C 值", 0, 100, 52, help="實際值 = n-50")
        result = binarize_adaptive(gray, bs, c)

elif method == "邊緣偵測":
    algo = st.sidebar.radio("算法", ["Canny", "Sobel", "Laplacian", "Scharr"])
    gray = to_gray(image)
    if algo == "Canny":
        low = st.sidebar.slider("低門檻", 0, 255, 100)
        high = st.sidebar.slider("高門檻", 0, 255, 200)
        result = canny(gray, low, high)
    elif algo == "Sobel":
        ks = st.sidebar.slider("Kernel Size", 0, 14, 0, help="實際值 = 2n+3")
        result = sobel(gray, ks)
    elif algo == "Laplacian":
        result = laplacian(gray)
    else:
        result = scharr(gray)

elif method == "強度轉換":
    mode = st.sidebar.radio("模式", ["Gamma", "對數轉換", "線性轉換", "直方圖等化", "CLAHE"])
    gray = to_gray(image)
    if mode == "Gamma":
        g = st.sidebar.slider("Gamma x100", 1, 300, 100, help="實際值 = n/100")
        result = gamma(gray, g / 100)
    elif mode == "對數轉換":
        k = st.sidebar.slider("k x10", 1, 50, 10, help="實際值 = n/10")
        result = log_transform(gray, k / 10)
    elif mode == "線性轉換":
        a = st.sidebar.slider("a x100", 50, 300, 100, help="實際值 = n/100")
        b = st.sidebar.slider("b 值", 0, 200, 100, help="實際值 = n-100")
        result = linear(gray, a / 100, b - 100)
    elif mode == "直方圖等化":
        result = histogram_eq(gray)
    else:
        cl = st.sidebar.slider("clipLimit x10", 1, 40, 20, help="實際值 = n/10")
        result = clahe(gray, cl / 10)

elif method == "影像校正":
    dx = st.sidebar.slider("X 偏移", 0, 100, 30)
    dy = st.sidebar.slider("Y 偏移", 0, 100, 30)
    result = affine(image, dx, dy)

# 顯示原圖與結果
col1, col2 = st.columns(2)
with col1:
    st.subheader("原圖")
    st.image(pil_img, use_container_width=True)
with col2:
    st.subheader("處理結果")
    if result is not None:
        st.image(bgr_to_pil(result), use_container_width=True)

# 下載按鈕
if result is not None:
    result_pil = bgr_to_pil(result)
    import io
    buf = io.BytesIO()
    result_pil.save(buf, format="PNG")
    st.download_button(
        label="下載結果",
        data=buf.getvalue(),
        file_name=f"result_{method}.png",
        mime="image/png"
    )
