# 影像處理工具 / Image Processing Tool

Python 影像處理專案，提供多種常見的影像處理功能。
支援**線上瀏覽器版**驗證功能、**本機桌面版**完整執行，以及**一鍵安裝工具**。

---

## 線上驗證（免安裝）

可直接在瀏覽器開啟以下連結，上傳圖片即可測試所有功能，不需要安裝任何軟體：

**https://250319pyimageprocessing-hmnuyuwm4rxzrojaydmyac.streamlit.app/**

---

## 功能列表

| 功能 | 說明 | 可調整參數 |
|------|------|-----------|
| 色彩空間分離 | 分離各色彩通道 | 色彩空間（BGR/HSV/Lab/YCrCb/HLS/LUV/XYZ/YUV/GRAY/RGB）、通道選擇 |
| 二值化 | 將影像轉為黑白 | 模式（自訂門檻/Otsu 自動/自適應）、門檻值、BlockSize、C 值 |
| 邊緣偵測 | 偵測影像輪廓邊緣 | 算法（Canny/Sobel/Laplacian/Scharr）、低門檻、高門檻、Kernel Size |
| 強度轉換 | 調整影像亮度與對比 | 模式（Gamma/對數/線性/直方圖等化/CLAHE）、各模式對應參數 |
| 影像校正 | 仿射幾何變換校正 | X 偏移、Y 偏移 |

---

## 執行版本比較

| | 線上版（Streamlit） | 桌面版（PyQt6） |
|---|---|---|
| 執行方式 | 瀏覽器，免安裝 | 本機安裝執行 |
| 即時預覽 | 有 | 有 |
| 滑桿互動 | 有 | 有 |
| 結果下載 | 有（下載按鈕） | 有（自動儲存到資料夾） |
| 適合用途 | 快速驗證功能 | 正式使用 |

---

## 本機執行（PyQt6 桌面版）

### 前置需求

請先安裝 **Python 3.10 以上**：https://www.python.org/downloads/

> 安裝時請務必勾選 **"Add Python to PATH"**

### 下載專案

點右上角 `Code` → `Download ZIP`，解壓縮後進入資料夾。

---

### 方法一：一鍵執行（推薦）

解壓縮後直接雙擊 `setup.bat`，腳本會自動：
- 檢查所有必要套件是否已安裝
- **已安裝**：跳過安裝，直接啟動程式
- **有缺套件**：自動安裝後再啟動程式

---

### 方法二：手動安裝

```bash
pip install PyQt6 opencv-python numpy
cd Image_Processing
python ui_main.py
```

---

## 建議工作流程

```
1. 開啟線上版 → 上傳圖片驗證功能是否符合需求
         ↓
2. 確認後，下載專案 ZIP 並解壓縮
         ↓
3. 雙擊 setup.bat → 自動檢查套件並啟動桌面版
```

---

## 專案結構

```
250319_Py_Image_Processing/
├── setup.bat                   # 一鍵安裝並啟動桌面版
├── requirements.txt            # 套件清單
└── Image_Processing/
    ├── ui_main.py              # PyQt6 桌面版主程式
    ├── streamlit_app.py        # Streamlit 線上/本機網頁版主程式
    ├── main.py                 # 原始命令列版主程式
    ├── binarize.py
    ├── color_space.py
    ├── edge_detect.py
    ├── image_correction.py
    ├── intensity_transform.py
    ├── modules/
    │   ├── image_selector.py
    │   ├── workflow_manager.py
    │   └── utils.py
    └── processing/             # 純函數模組（桌面版與網頁版共用）
        ├── binarize_fn.py
        ├── color_space_fn.py
        ├── edge_detect_fn.py
        ├── intensity_transform_fn.py
        └── image_correction_fn.py
```
