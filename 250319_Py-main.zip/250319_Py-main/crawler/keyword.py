# -*- coding: utf-8 -*-
"""
關鍵字比對：在頁面內文中尋找使用者輸入的關鍵字，
回傳含前後文的相關片段，供寫入 KeyWord.txt。
"""

# 單頁同一關鍵字最多記錄的片段數，避免某頁重複幾百次塞爆檔案
MAX_MATCHES_PER_PAGE = 20

# 片段往前後各取多少字元當前後文
CONTEXT_CHARS = 40


def parse_keywords(raw):
    """把使用者輸入的關鍵字字串拆成清單。逗號、頓號、分號都可當分隔。"""
    if not raw or not raw.strip():
        return []
    parts = []
    for sep in ("、", "；", ";"):
        raw = raw.replace(sep, ",")
    for kw in raw.split(","):
        kw = kw.strip()
        if kw and kw not in parts:
            parts.append(kw)
    return parts


def find_matches(text, keywords):
    """在 text 中找所有關鍵字，回傳去重後的相關片段清單（不分大小寫）。"""
    if not text or not keywords:
        return []
    low = text.lower()
    snippets = []
    seen = set()
    for kw in keywords:
        kw_low = kw.lower()
        start = 0
        found = 0
        while found < MAX_MATCHES_PER_PAGE:
            i = low.find(kw_low, start)
            if i < 0:
                break
            begin = max(0, i - CONTEXT_CHARS)
            end = min(len(text), i + len(kw) + CONTEXT_CHARS)
            snippet = " ".join(text[begin:end].split())  # 換行/連續空白壓成單一空格
            if snippet not in seen:
                seen.add(snippet)
                snippets.append(snippet)
                found += 1
            start = i + len(kw)
    return snippets
