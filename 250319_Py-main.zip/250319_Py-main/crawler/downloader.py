# -*- coding: utf-8 -*-
"""
下載頁面上的圖片與附件（PDF 等）到 output/assets/。

防錯設計：
- 檔名做 Windows/macOS/Linux 全平台消毒（移除不合法字元、限制長度、保留副檔名）
- 沒有副檔名時依回應的 Content-Type 補上
- 單檔失敗只記錄、不中斷
- 跳過 data:/mailto:/javascript: 等非可下載網址
"""

import hashlib
import mimetypes
import os
import re
from urllib.parse import unquote, urljoin, urlparse

import requests
from bs4 import BeautifulSoup

# 視為「附件」要下載的副檔名。
ASSET_EXTS = (
    ".pdf", ".doc", ".docx", ".xls", ".xlsx", ".ppt", ".pptx",
    ".zip", ".csv", ".txt",
)

# Windows 檔名不允許的字元 + 控制字元與空白
_BAD_CHARS = re.compile(r'[<>:"/\\|?*\x00-\x1f\s]+')


def _safe_name(url, content_type=""):
    """由網址產生全平台安全、唯一、不過長的檔名。"""
    parsed = urlparse(url)
    base = unquote(os.path.basename(parsed.path)) or "asset"
    base = _BAD_CHARS.sub("_", base).strip("._") or "asset"
    name, ext = os.path.splitext(base)
    if not ext and content_type:
        guessed = mimetypes.guess_extension(content_type.split(";")[0].strip())
        ext = guessed or ""
    digest = hashlib.md5(url.encode("utf-8")).hexdigest()[:8]
    return f"{digest}_{name[:60]}{ext[:10]}"


def collect_asset_urls(html, page_url):
    """從 HTML 找出圖片與附件的絕對網址。"""
    try:
        soup = BeautifulSoup(html, "lxml")
    except Exception:
        soup = BeautifulSoup(html, "html.parser")
    urls = set()

    for img in soup.find_all("img", src=True):
        src = img["src"].strip()
        # 內嵌圖片或非網址的 src 不是可下載的目標
        if src.startswith(("data:", "javascript:", "blob:")):
            continue
        urls.add(urljoin(page_url, src))

    for a in soup.find_all("a", href=True):
        href = a["href"].strip()
        if href.startswith(("data:", "javascript:", "mailto:", "tel:", "#")):
            continue
        absolute = urljoin(page_url, href)
        if absolute.lower().split("?")[0].endswith(ASSET_EXTS):
            urls.add(absolute)

    return {u for u in urls if u.startswith(("http://", "https://"))}


def download_one(url, assets_dir, headers, cookies, max_mb=25, already=None):
    """下載單一檔案。成功回傳檔名，略過/失敗回傳 None（失敗會丟例外給呼叫端記錄）。"""
    if already is not None:
        if url in already:
            return None
        already.add(url)

    os.makedirs(assets_dir, exist_ok=True)
    resp = requests.get(url, headers=headers, cookies=cookies,
                        timeout=30, stream=True)
    resp.raise_for_status()

    size = int(resp.headers.get("Content-Length", 0))
    limit = max_mb * 1024 * 1024
    if size and size > limit:
        print(f"      略過(過大 {size // 1024 // 1024}MB): {url}")
        return None

    name = _safe_name(url, resp.headers.get("Content-Type", ""))
    path = os.path.join(assets_dir, name)
    downloaded = 0
    try:
        with open(path, "wb") as f:
            for chunk in resp.iter_content(chunk_size=65536):
                downloaded += len(chunk)
                if downloaded > limit:
                    print(f"      中止(超過 {max_mb}MB): {url}")
                    break
                f.write(chunk)
    except Exception:
        # 寫到一半失敗的殘檔移除，避免留下壞檔
        try:
            os.remove(path)
        except OSError:
            pass
        raise
    return name


def download_assets(html, page_url, assets_dir, headers, cookies,
                    max_mb=25, already=None):
    """下載頁面上所有資產，回傳成功下載的檔名清單。單檔失敗不影響整體。"""
    if already is None:
        already = set()

    saved = []
    for url in collect_asset_urls(html, page_url):
        try:
            name = download_one(url, assets_dir, headers, cookies,
                                max_mb=max_mb, already=already)
            if name:
                saved.append(name)
        except Exception as exc:  # 單檔失敗不影響整體流程
            print(f"      下載失敗: {url} ({exc})")
    return saved
