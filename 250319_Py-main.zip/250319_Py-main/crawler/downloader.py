# -*- coding: utf-8 -*-
"""
下載頁面上的圖片與附件（PDF 等）到 output/assets/。
"""

import hashlib
import os
from urllib.parse import urljoin, urlparse

import requests
from bs4 import BeautifulSoup

# 視為「附件」要下載的副檔名。
ASSET_EXTS = (
    ".pdf", ".doc", ".docx", ".xls", ".xlsx", ".ppt", ".pptx",
    ".zip", ".csv", ".txt",
)


def _safe_name(url):
    parsed = urlparse(url)
    base = os.path.basename(parsed.path) or "asset"
    digest = hashlib.md5(url.encode("utf-8")).hexdigest()[:8]
    return f"{digest}_{base}"


def collect_asset_urls(html, page_url):
    """從 HTML 找出圖片與附件的絕對網址。"""
    soup = BeautifulSoup(html, "lxml")
    urls = set()

    for img in soup.find_all("img", src=True):
        src = img["src"]
        if src.startswith("data:"):  # 內嵌圖片不是可下載的網址
            continue
        urls.add(urljoin(page_url, src))

    for a in soup.find_all("a", href=True):
        href = urljoin(page_url, a["href"])
        if href.lower().split("?")[0].endswith(ASSET_EXTS):
            urls.add(href)

    return urls


def download_assets(html, page_url, assets_dir, headers, cookies,
                    max_mb=25, already=None):
    """下載資產，回傳這次成功下載的檔名清單。already 為已下載 URL 的集合（去重）。"""
    if already is None:
        already = set()
    os.makedirs(assets_dir, exist_ok=True)

    saved = []
    for url in collect_asset_urls(html, page_url):
        if url in already:
            continue
        already.add(url)
        try:
            resp = requests.get(
                url, headers=headers, cookies=cookies,
                timeout=30, stream=True,
            )
            resp.raise_for_status()

            size = int(resp.headers.get("Content-Length", 0))
            if size and size > max_mb * 1024 * 1024:
                print(f"      略過(過大 {size//1024//1024}MB): {url}")
                continue

            name = _safe_name(url)
            path = os.path.join(assets_dir, name)
            downloaded = 0
            limit = max_mb * 1024 * 1024
            with open(path, "wb") as f:
                for chunk in resp.iter_content(chunk_size=65536):
                    downloaded += len(chunk)
                    if downloaded > limit:
                        break
                    f.write(chunk)
            saved.append(name)
        except Exception as exc:  # 單檔失敗不影響整體流程
            print(f"      下載失敗: {url} ({exc})")

    return saved
