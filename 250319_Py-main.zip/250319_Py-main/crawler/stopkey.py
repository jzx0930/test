# -*- coding: utf-8 -*-
"""
ESC 停止鍵監聽。只用標準函式庫：
- Windows 用 msvcrt
- macOS / Linux 用 termios + select
在背景執行緒監聽，按下 ESC 後設定 stop_event，爬蟲主迴圈會看到並優雅停止。
"""

import sys
import threading

ESC = 27

stop_event = threading.Event()


def _listen_windows():
    import msvcrt
    while not stop_event.is_set():
        ch = msvcrt.getch()
        if ch in (b"\x1b",):
            stop_event.set()
            break


def _listen_unix():
    import select
    import termios
    import tty

    fd = sys.stdin.fileno()
    old = termios.tcgetattr(fd)
    try:
        tty.setcbreak(fd)
        while not stop_event.is_set():
            r, _, _ = select.select([sys.stdin], [], [], 0.2)
            if r:
                ch = sys.stdin.read(1)
                if ch and ord(ch) == ESC:
                    stop_event.set()
                    break
    finally:
        termios.tcsetattr(fd, termios.TCSADRAIN, old)


def start_listener():
    """啟動背景監聽執行緒。stdin 不是終端機時（如重新導向）不啟動。"""
    if sys.platform == "win32":
        target = _listen_windows
    else:
        if not sys.stdin.isatty():
            return
        target = _listen_unix

    t = threading.Thread(target=target, daemon=True)
    t.start()
    print("提示：抓取途中隨時按 ESC 鍵即可停止（已抓取的資料會保留）。\n")
