# -*- coding: utf-8 -*-
"""
從頁面 HTML 抽取內容：純文字、Markdown、以及結構化資料（標題/連結/表格）。
"""

from datetime import datetime, timezone
from urllib.parse import urljoin

import html2text
from bs4 import BeautifulSoup


def _build_markdown_converter():
    h = html2text.HTML2Text()
    h.ignore_images = False
    h.ignore_links = False
    h.body_width = 0  # 不要硬斷行
    return h


# 這些區塊是每頁重複的導覽/頁尾/彈窗雜訊，對閱讀內容沒有幫助，抽取前先移除。
NOISE_TAGS = ["script", "style", "noscript", "nav", "header", "footer", "aside", "iframe", "svg"]
NOISE_PATTERNS = ["cookie", "banner", "breadcrumb", "navbar", "menu", "sidebar", "popup", "modal"]


def _remove_noise(soup):
    for tag in soup(NOISE_TAGS):
        tag.decompose()
    for attr in ("class", "id"):
        for el in soup.find_all(attrs={attr: True}):
            if el.decomposed:  # 父元素已被移除，這個子元素是空殼
                continue
            value = " ".join(el.get(attr)) if isinstance(el.get(attr), list) else el.get(attr, "")
            if any(p in value.lower() for p in NOISE_PATTERNS):
                el.decompose()


def _soup(html):
    """lxml 解析失敗時退回內建解析器，確保任何 HTML 都能處理。"""
    try:
        return BeautifulSoup(html, "lxml")
    except Exception:
        return BeautifulSoup(html, "html.parser")


def extract(html, page_url):
    """回傳 (markdown_text, structured_dict)。"""
    soup = _soup(html)

    title = soup.title.get_text(strip=True) if soup.title else ""

    headings = []
    for level in range(1, 7):
        for tag in soup.find_all(f"h{level}"):
            text = tag.get_text(strip=True)
            if text:
                headings.append({"level": level, "text": text})

    links = []
    seen_links = set()
    for a in soup.find_all("a", href=True):
        href = urljoin(page_url, a["href"])
        if href not in seen_links:
            seen_links.add(href)
            links.append({"text": a.get_text(strip=True), "href": href})

    tables = []
    for table in soup.find_all("table"):
        rows = []
        for tr in table.find_all("tr"):
            cells = [c.get_text(strip=True) for c in tr.find_all(["th", "td"])]
            if cells:
                rows.append(cells)
        if rows:
            tables.append(rows)

    # 移除導覽/頁尾等雜訊後，主內容優先取 <main> 或 <article>
    _remove_noise(soup)
    main = soup.find("main") or soup.find("article") or soup.body or soup
    text = main.get_text(separator="\n", strip=True)
    try:
        markdown = _build_markdown_converter().handle(str(main))
    except Exception:
        markdown = text  # Markdown 轉換失敗就退回純文字，不可中斷流程

    # 沒有 <title> 的頁面用第一個標題或網址當標題
    if not title:
        title = headings[0]["text"] if headings else page_url

    structured = {
        "url": page_url,
        "title": title,
        "headings": headings,
        "links": links,
        "tables": tables,
        "text": text,
        "fetched_at": datetime.now(timezone.utc).isoformat(),
    }
    return markdown, structured
