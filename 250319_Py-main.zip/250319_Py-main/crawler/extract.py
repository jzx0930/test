# -*- coding: utf-8 -*-
"""
從頁面 HTML 抽取內容：純文字、Markdown、以及結構化資料（標題/連結/表格）。
"""

from datetime import datetime, timezone
from urllib.parse import urljoin

import html2text
from bs4 import BeautifulSoup


def _build_markdown_converter():
    h = html2text.HTML2Text()
    h.ignore_images = False
    h.ignore_links = False
    h.body_width = 0  # 不要硬斷行
    return h


def extract(html, page_url):
    """回傳 (markdown_text, structured_dict)。"""
    soup = BeautifulSoup(html, "lxml")

    title = soup.title.get_text(strip=True) if soup.title else ""

    headings = []
    for level in range(1, 7):
        for tag in soup.find_all(f"h{level}"):
            text = tag.get_text(strip=True)
            if text:
                headings.append({"level": level, "text": text})

    links = []
    seen_links = set()
    for a in soup.find_all("a", href=True):
        href = urljoin(page_url, a["href"])
        if href not in seen_links:
            seen_links.add(href)
            links.append({"text": a.get_text(strip=True), "href": href})

    tables = []
    for table in soup.find_all("table"):
        rows = []
        for tr in table.find_all("tr"):
            cells = [c.get_text(strip=True) for c in tr.find_all(["th", "td"])]
            if cells:
                rows.append(cells)
        if rows:
            tables.append(rows)

    # 純文字（移除 script/style）
    for tag in soup(["script", "style", "noscript"]):
        tag.decompose()
    text = soup.get_text(separator="\n", strip=True)

    markdown = _build_markdown_converter().handle(html)

    structured = {
        "url": page_url,
        "title": title,
        "headings": headings,
        "links": links,
        "tables": tables,
        "text": text,
        "fetched_at": datetime.now(timezone.utc).isoformat(),
    }
    return markdown, structured
