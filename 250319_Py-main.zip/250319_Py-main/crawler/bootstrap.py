# -*- coding: utf-8 -*-
"""
套件自動檢查與安裝。只用 Python 標準函式庫，因為這支程式可能在套件都還沒裝好時就被呼叫。
"""

import importlib.util
import os
import subprocess
import sys

# import 名稱 -> pip 安裝名稱
REQUIRED = {
    "playwright": "playwright",
    "bs4": "beautifulsoup4",
    "lxml": "lxml",
    "html2text": "html2text",
    "requests": "requests",
}

# 用來記錄 playwright 瀏覽器已安裝過，避免每次都重裝。
_READY_FLAG = os.path.join("output", ".playwright_ready")


def _is_installed(import_name):
    return importlib.util.find_spec(import_name) is not None


def _pip_install(pip_names):
    cmd = [sys.executable, "-m", "pip", "install", *pip_names]
    print("    執行:", " ".join(cmd))
    subprocess.run(cmd, check=True)


def _ensure_playwright_browser():
    """確保 Playwright 的 Chromium 瀏覽器二進位已安裝。"""
    if os.path.exists(_READY_FLAG):
        print("  - Playwright Chromium：先前已安裝，略過。")
        return
    print("  - 安裝 Playwright Chromium 瀏覽器（首次會花一點時間）...")
    subprocess.run(
        [sys.executable, "-m", "playwright", "install", "chromium"],
        check=True,
    )
    os.makedirs(os.path.dirname(_READY_FLAG), exist_ok=True)
    with open(_READY_FLAG, "w", encoding="utf-8") as f:
        f.write("ok")
    print("  - Playwright Chromium 安裝完成。")


def check_and_install():
    """檢查所有需要的套件，缺少就自動安裝，最後確保瀏覽器就緒。"""
    print("=" * 60)
    print("步驟 1/2：檢查 Python 套件")
    print("=" * 60)

    missing = []
    for import_name, pip_name in REQUIRED.items():
        if _is_installed(import_name):
            print(f"  [OK]   {import_name}")
        else:
            print(f"  [缺少] {import_name} -> 將安裝 {pip_name}")
            missing.append(pip_name)

    if missing:
        print("\n發現缺少套件，開始自動安裝...")
        _pip_install(missing)
        print("套件安裝完成。\n")
    else:
        print("\n所有套件都已安裝。\n")

    print("=" * 60)
    print("步驟 2/2：檢查 Playwright 瀏覽器")
    print("=" * 60)
    _ensure_playwright_browser()
    print()
