# -*- coding: utf-8 -*-
"""
啟動設定表單（tkinter，Python 內建，免安裝）。

使用者貼上網址、設定參數後按「開始抓取」：
- 表單不關閉，下方顯示進度條與目前頁面
- 爬蟲在背景執行緒執行，透過 queue 把進度安全地傳回 UI 執行緒
- 可按「停止」或 ESC 隨時中止，結束後可改參數再跑一次

對貼上的網址做防呆：
- 全形字元自動轉半形（中文輸入法常把 https：// 打成全形）
- 去除前後空白、引號、角括號
- 沒打 http(s):// 自動補 https://
"""

import json
import os
import queue
import threading
import time
import traceback
from urllib.parse import urlparse

from crawler.stopkey import stop_event

# 記住上一次的設定，下次打開自動帶入
SETTINGS_FILE = "last_settings.json"


def _load_last_settings():
    try:
        with open(SETTINGS_FILE, encoding="utf-8") as f:
            return json.load(f)
    except Exception:
        return {}


def _save_last_settings(d):
    try:
        with open(SETTINGS_FILE, "w", encoding="utf-8") as f:
            json.dump(d, f, ensure_ascii=False, indent=2)
    except Exception:
        pass


def clean_url(raw):
    """把使用者貼上的網址整理成可用的標準形式。"""
    s = "".join(
        chr(ord(c) - 0xFEE0) if 0xFF01 <= ord(c) <= 0xFF5E
        else (" " if c == "　" else c)
        for c in (raw or "")
    )
    s = s.strip().strip("'\"<>“”‘’ ").strip()
    if s and not s.lower().startswith(("http://", "https://")):
        s = "https://" + s.lstrip("/:")
    return s


def is_valid_url(url):
    try:
        p = urlparse(url)
    except ValueError:
        return False
    return p.scheme in ("http", "https") and "." in p.netloc


def show_form(config, crawl_func):
    """顯示設定表單並在背景執行 crawl_func(config, progress_cb)。
    視窗關閉時回傳。"""
    import tkinter as tk
    from tkinter import messagebox, ttk

    root = tk.Tk()
    root.title("網站資料抓取工具")
    root.resizable(False, False)

    frm = ttk.Frame(root, padding=16)
    frm.grid()

    entries = []

    def add_row(row, label, default, width=52):
        ttk.Label(frm, text=label).grid(row=row, column=0, sticky="w", pady=4)
        var = tk.StringVar(value=str(default))
        ent = ttk.Entry(frm, textvariable=var, width=width)
        ent.grid(row=row, column=1, sticky="w", pady=4, padx=(8, 0))
        entries.append(ent)
        return var

    last = _load_last_settings()

    url_var = add_row(0, "起始網址（貼上要爬的網站）",
                      last.get("url", config.START_URL))
    prefix_var = add_row(1, "只爬此前綴底下的頁面（選填）",
                         last.get("prefix", getattr(config, "URL_PREFIX", "")))
    pages_var = add_row(2, "最多抓幾頁",
                        last.get("pages", config.MAX_PAGES), width=10)
    depth_var = add_row(3, "連結展開深度",
                        last.get("depth", config.MAX_DEPTH), width=10)
    delay_var = add_row(4, "每頁延遲（秒）",
                        last.get("delay", config.REQUEST_DELAY), width=10)
    conc_var = add_row(5, "並行分頁數 1~3（越多越快、越易被擋）",
                       last.get("concurrency", getattr(config, "CONCURRENCY", 1)),
                       width=10)
    keyword_var = add_row(6, "關鍵字（留空＝不搜尋；多個用逗號分隔）",
                          last.get("keywords", getattr(config, "KEYWORDS", "")))

    headless_var = tk.BooleanVar(value=last.get("headless", config.HEADLESS))
    cb1 = ttk.Checkbutton(frm, text="無頭模式（不顯示瀏覽器視窗；被網站擋時可取消勾選）",
                          variable=headless_var)
    cb1.grid(row=7, column=0, columnspan=2, sticky="w", pady=4)

    assets_var = tk.BooleanVar(value=last.get("assets", config.DOWNLOAD_ASSETS))
    cb2 = ttk.Checkbutton(frm, text="下載圖片與 PDF 等附件", variable=assets_var)
    cb2.grid(row=8, column=0, columnspan=2, sticky="w", pady=4)

    resume_var = tk.BooleanVar(value=False)
    cb3 = ttk.Checkbutton(frm, text="接續上次中斷的進度（已抓過的頁面跳過）",
                          variable=resume_var)
    cb3.grid(row=9, column=0, columnspan=2, sticky="w", pady=4)
    entries.extend([cb1, cb2, cb3])

    btns = ttk.Frame(frm)
    btns.grid(row=10, column=0, columnspan=2, pady=(12, 4))
    start_btn = ttk.Button(btns, text="開始抓取")
    start_btn.grid(row=0, column=0, padx=6)
    stop_btn = ttk.Button(btns, text="停止", state="disabled",
                          command=stop_event.set)
    stop_btn.grid(row=0, column=1, padx=6)

    # ---- 進度區 ----
    bar = ttk.Progressbar(frm, length=480, mode="determinate")
    bar.grid(row=11, column=0, columnspan=2, sticky="w", pady=(8, 2))
    status_var = tk.StringVar(value="尚未開始。設定好後按「開始抓取」。")
    ttk.Label(frm, textvariable=status_var, foreground="#444",
              wraplength=480, justify="left").grid(
        row=12, column=0, columnspan=2, sticky="w")

    events = queue.Queue()
    state = {"running": False, "started_at": None, "base_count": 0}

    def eta_text(count, maximum):
        """以本輪平均每頁耗時估算剩餘時間。"""
        done = count - state["base_count"]
        if not state["started_at"] or done < 3:
            return ""
        per_page = (time.time() - state["started_at"]) / done
        remain = int(per_page * (maximum - count))
        if remain < 60:
            return f"｜預估剩餘 {remain} 秒"
        return f"｜預估剩餘 {remain // 60} 分 {remain % 60} 秒"

    def progress_cb(event):
        events.put(event)  # 由背景執行緒呼叫，只丟進 queue，不碰 UI

    def crawl_thread():
        try:
            crawl_func(config, progress_cb)
        except Exception:
            events.put({"type": "crash", "trace": traceback.format_exc()})

    def set_running(running):
        state["running"] = running
        for w in entries:
            w.configure(state="disabled" if running else "normal")
        start_btn.configure(state="disabled" if running else "normal")
        stop_btn.configure(state="normal" if running else "disabled")

    def poll_events():
        try:
            while True:
                ev = events.get_nowait()
                if ev["type"] == "page":
                    if state["base_count"] is None:  # 續爬時以第一筆事件校正起點
                        state["base_count"] = max(0, ev["count"] - 1)
                        state["started_at"] = time.time()
                    bar.configure(maximum=ev["max"], value=ev["count"])
                    status_var.set(f"進度 {ev['count']}/{ev['max']} 頁"
                                   f"{eta_text(ev['count'], ev['max'])}｜{ev['text']}")
                elif ev["type"] == "done":
                    bar.configure(value=bar["maximum"] if not ev["stopped"]
                                  else bar["value"])
                    msg = (f"{'已手動停止' if ev['stopped'] else '完成'}！"
                           f"共處理 {ev['count']} 頁")
                    if ev["errors"]:
                        msg += f"（{ev['errors']} 頁錯誤，見 errors.log）"
                    if ev.get("kw_hits") is not None:
                        msg += f"，關鍵字命中 {ev['kw_hits']} 處"
                    msg += f"。輸出位置：{ev['out']}"
                    status_var.set(msg)
                    set_running(False)
                elif ev["type"] == "crash":
                    status_var.set("發生錯誤，詳見彈出視窗。")
                    set_running(False)
                    messagebox.showerror("抓取失敗", ev["trace"][-1500:])
        except queue.Empty:
            pass
        root.after(200, poll_events)

    def on_start():
        url = clean_url(url_var.get())
        if not is_valid_url(url):
            messagebox.showerror(
                "網址錯誤",
                "請貼上完整網址，例如：https://www.example.com/\n"
                f"目前讀到的是：{url or '(空白)'}")
            return
        prefix = prefix_var.get().strip()
        if prefix:
            prefix = clean_url(prefix)
            if not is_valid_url(prefix):
                messagebox.showerror("前綴錯誤",
                                     "「只爬此前綴」需為完整網址開頭，例如：\n"
                                     "https://www.aerotech.com/products/")
                return
        try:
            pages = int(pages_var.get())
            depth = int(depth_var.get())
            delay = float(delay_var.get())
            conc = int(conc_var.get())
            if pages < 1 or depth < 0 or delay < 0 or not 1 <= conc <= 3:
                raise ValueError
        except ValueError:
            messagebox.showerror("參數錯誤",
                                 "頁數需為正整數、深度為 0 以上整數、延遲為非負數字、並行數為 1~3。")
            return

        config.START_URL = url
        config.ALLOWED_DOMAIN = ""  # 依新網址自動推導
        config.URL_PREFIX = prefix
        config.MAX_PAGES = pages
        config.MAX_DEPTH = depth
        config.REQUEST_DELAY = delay
        config.CONCURRENCY = conc
        config.HEADLESS = headless_var.get()
        config.DOWNLOAD_ASSETS = assets_var.get()
        config.KEYWORDS = keyword_var.get().strip()
        config.RESUME = resume_var.get()

        _save_last_settings({
            "url": url, "prefix": prefix, "pages": pages, "depth": depth,
            "delay": delay, "concurrency": conc,
            "keywords": config.KEYWORDS,
            "headless": config.HEADLESS, "assets": config.DOWNLOAD_ASSETS,
        })

        bar.configure(maximum=pages, value=0)
        status_var.set("啟動瀏覽器中…")
        state["started_at"] = None
        state["base_count"] = None  # 第一筆進度事件抵達時校正（支援續爬起點）
        set_running(True)
        threading.Thread(target=crawl_thread, daemon=True).start()

    start_btn.configure(command=on_start)
    root.bind("<Escape>", lambda e: stop_event.set())

    def on_close():
        if state["running"]:
            if not messagebox.askyesno("確認", "抓取仍在進行中，要停止並關閉嗎？\n（已抓取的資料會保留）"):
                return
            stop_event.set()
        root.destroy()

    root.protocol("WM_DELETE_WINDOW", on_close)

    ttk.Label(frm, foreground="#666",
              text="提示：抓取中可按「停止」或 ESC 鍵中止，已抓取的資料會保留。\n"
                   "結果輸出到 output/，其中 for_ai/ 資料夾就是要交給 AI 的全部內容。\n"
                   "有填關鍵字時，命中內容會以「相關內容-網頁連結」寫入 output/KeyWord.txt。"
              ).grid(row=13, column=0, columnspan=2, sticky="w", pady=(12, 0))

    root.eval("tk::PlaceWindow . center")
    poll_events()
    root.mainloop()
