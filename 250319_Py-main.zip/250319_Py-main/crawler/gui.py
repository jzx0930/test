# -*- coding: utf-8 -*-
"""
啟動設定表單（tkinter，Python 內建，免安裝）。
讓使用者貼上要爬的網址並調整參數，按「開始抓取」後回傳設定。

對貼上的網址做防呆：
- 全形字元自動轉半形（中文輸入法常把 https：// 打成全形）
- 去除前後空白、引號、角括號
- 沒打 http(s):// 自動補 https://
"""

from urllib.parse import urlparse


def clean_url(raw):
    """把使用者貼上的網址整理成可用的標準形式。"""
    s = "".join(
        chr(ord(c) - 0xFEE0) if 0xFF01 <= ord(c) <= 0xFF5E
        else (" " if c == "　" else c)
        for c in (raw or "")
    )
    s = s.strip().strip("'\"<>“”‘’ ").strip()
    if s and not s.lower().startswith(("http://", "https://")):
        s = "https://" + s.lstrip("/:")
    return s


def is_valid_url(url):
    try:
        p = urlparse(url)
    except ValueError:
        return False
    return p.scheme in ("http", "https") and "." in p.netloc


def show_form(config):
    """顯示設定表單。按「開始抓取」回傳 True 並把值寫回 config；關閉視窗回傳 False。"""
    import tkinter as tk
    from tkinter import messagebox, ttk

    result = {"start": False}

    root = tk.Tk()
    root.title("網站資料抓取工具 — 設定")
    root.resizable(False, False)

    frm = ttk.Frame(root, padding=16)
    frm.grid()

    def add_row(row, label, default, width=52):
        ttk.Label(frm, text=label).grid(row=row, column=0, sticky="w", pady=4)
        var = tk.StringVar(value=str(default))
        ttk.Entry(frm, textvariable=var, width=width).grid(
            row=row, column=1, sticky="w", pady=4, padx=(8, 0))
        return var

    url_var = add_row(0, "起始網址（貼上要爬的網站）", config.START_URL)
    pages_var = add_row(1, "最多抓幾頁", config.MAX_PAGES, width=10)
    depth_var = add_row(2, "連結展開深度", config.MAX_DEPTH, width=10)
    delay_var = add_row(3, "每頁延遲（秒）", config.REQUEST_DELAY, width=10)
    keyword_var = add_row(4, "關鍵字（留空＝不搜尋；多個用逗號分隔）",
                          getattr(config, "KEYWORDS", ""))

    headless_var = tk.BooleanVar(value=config.HEADLESS)
    ttk.Checkbutton(frm, text="無頭模式（不顯示瀏覽器視窗；被網站擋時可取消勾選）",
                    variable=headless_var).grid(row=5, column=0, columnspan=2,
                                                sticky="w", pady=4)

    assets_var = tk.BooleanVar(value=config.DOWNLOAD_ASSETS)
    ttk.Checkbutton(frm, text="下載圖片與 PDF 等附件",
                    variable=assets_var).grid(row=6, column=0, columnspan=2,
                                              sticky="w", pady=4)

    def on_start():
        url = clean_url(url_var.get())
        if not is_valid_url(url):
            messagebox.showerror(
                "網址錯誤",
                "請貼上完整網址，例如：https://www.example.com/\n"
                f"目前讀到的是：{url or '(空白)'}")
            return
        try:
            pages = int(pages_var.get())
            depth = int(depth_var.get())
            delay = float(delay_var.get())
            if pages < 1 or depth < 0 or delay < 0:
                raise ValueError
        except ValueError:
            messagebox.showerror("參數錯誤", "頁數需為正整數、深度為 0 以上整數、延遲為非負數字。")
            return

        config.START_URL = url
        config.ALLOWED_DOMAIN = ""  # 依新網址自動推導
        config.MAX_PAGES = pages
        config.MAX_DEPTH = depth
        config.REQUEST_DELAY = delay
        config.HEADLESS = headless_var.get()
        config.DOWNLOAD_ASSETS = assets_var.get()
        config.KEYWORDS = keyword_var.get().strip()
        result["start"] = True
        root.destroy()

    btns = ttk.Frame(frm)
    btns.grid(row=7, column=0, columnspan=2, pady=(12, 0))
    ttk.Button(btns, text="開始抓取", command=on_start).grid(row=0, column=0, padx=6)
    ttk.Button(btns, text="取消", command=root.destroy).grid(row=0, column=1, padx=6)

    ttk.Label(frm, foreground="#666",
              text="提示：抓取開始後，在黑色視窗按 ESC 可隨時停止。\n"
                   "結果會輸出到 output/，其中 for_ai/ 資料夾就是要交給 AI 的全部內容。\n"
                   "有填關鍵字時，命中內容會以「相關內容-網頁連結」寫入 output/KeyWord.txt。"
              ).grid(row=8, column=0, columnspan=2, sticky="w", pady=(12, 0))

    root.eval("tk::PlaceWindow . center")
    root.mainloop()
    return result["start"]
