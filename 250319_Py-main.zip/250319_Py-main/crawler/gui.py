# -*- coding: utf-8 -*-
"""
啟動設定表單（tkinter，Python 內建，免安裝）。
讓使用者貼上要爬的網址並調整參數，按「開始抓取」後回傳設定。
"""

import tkinter as tk
from tkinter import messagebox, ttk


def show_form(config):
    """顯示設定表單。按「開始抓取」回傳 True 並把值寫回 config；關閉視窗回傳 False。"""
    result = {"start": False}

    root = tk.Tk()
    root.title("網站資料抓取工具 — 設定")
    root.resizable(False, False)

    frm = ttk.Frame(root, padding=16)
    frm.grid()

    def add_row(row, label, default, width=52):
        ttk.Label(frm, text=label).grid(row=row, column=0, sticky="w", pady=4)
        var = tk.StringVar(value=str(default))
        ttk.Entry(frm, textvariable=var, width=width).grid(
            row=row, column=1, sticky="w", pady=4, padx=(8, 0))
        return var

    url_var = add_row(0, "起始網址（貼上要爬的網站）", config.START_URL)
    pages_var = add_row(1, "最多抓幾頁", config.MAX_PAGES, width=10)
    depth_var = add_row(2, "連結展開深度", config.MAX_DEPTH, width=10)
    delay_var = add_row(3, "每頁延遲（秒）", config.REQUEST_DELAY, width=10)

    headless_var = tk.BooleanVar(value=config.HEADLESS)
    ttk.Checkbutton(frm, text="無頭模式（不顯示瀏覽器視窗；被網站擋時可取消勾選）",
                    variable=headless_var).grid(row=4, column=0, columnspan=2,
                                                sticky="w", pady=4)

    assets_var = tk.BooleanVar(value=config.DOWNLOAD_ASSETS)
    ttk.Checkbutton(frm, text="下載圖片與 PDF 等附件",
                    variable=assets_var).grid(row=5, column=0, columnspan=2,
                                              sticky="w", pady=4)

    def on_start():
        url = url_var.get().strip()
        if not url.startswith(("http://", "https://")):
            messagebox.showerror("網址錯誤", "請輸入 http:// 或 https:// 開頭的完整網址。")
            return
        try:
            pages = int(pages_var.get())
            depth = int(depth_var.get())
            delay = float(delay_var.get())
            if pages < 1 or depth < 0 or delay < 0:
                raise ValueError
        except ValueError:
            messagebox.showerror("參數錯誤", "頁數/深度需為正整數，延遲需為非負數字。")
            return

        config.START_URL = url
        config.ALLOWED_DOMAIN = ""  # 依新網址自動推導
        config.MAX_PAGES = pages
        config.MAX_DEPTH = depth
        config.REQUEST_DELAY = delay
        config.HEADLESS = headless_var.get()
        config.DOWNLOAD_ASSETS = assets_var.get()
        result["start"] = True
        root.destroy()

    btns = ttk.Frame(frm)
    btns.grid(row=6, column=0, columnspan=2, pady=(12, 0))
    ttk.Button(btns, text="開始抓取", command=on_start).grid(row=0, column=0, padx=6)
    ttk.Button(btns, text="取消", command=root.destroy).grid(row=0, column=1, padx=6)

    ttk.Label(frm, foreground="#666",
              text="提示：抓取開始後，在黑色視窗按 ESC 可隨時停止。\n"
                   "結果會輸出到 output/，其中 for_ai/ 資料夾就是要交給 AI 的全部內容。"
              ).grid(row=7, column=0, columnspan=2, sticky="w", pady=(12, 0))

    root.eval("tk::PlaceWindow . center")
    root.mainloop()
    return result["start"]
