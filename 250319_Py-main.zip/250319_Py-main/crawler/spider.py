# -*- coding: utf-8 -*-
"""
Playwright BFS 爬蟲主體：從起始網址逐頁展開同網域連結並抓取內容。
"""

import csv
import hashlib
import json
import os
import re
import time
from collections import deque
from datetime import datetime, timezone
from urllib.parse import urljoin, urldefrag, urlparse

from playwright.sync_api import sync_playwright

from crawler import extract, downloader


def _domain_of(url):
    return urlparse(url).netloc


def _safe_filename(url):
    """把網址轉成安全、唯一的檔名（不含副檔名）。"""
    parsed = urlparse(url)
    slug = (parsed.netloc + parsed.path).strip("/")
    slug = re.sub(r"[^A-Za-z0-9._-]+", "_", slug) or "index"
    slug = slug[:80]
    digest = hashlib.md5(url.encode("utf-8")).hexdigest()[:10]
    return f"{slug}_{digest}"


def _same_domain(url, allowed):
    return _domain_of(url) == allowed


def _collect_links(page, base_url):
    """從目前頁面收集所有 <a href> 的絕對網址（去除片段）。"""
    hrefs = page.eval_on_selector_all(
        "a[href]", "els => els.map(e => e.getAttribute('href'))"
    )
    links = []
    for h in hrefs:
        if not h:
            continue
        absolute, _ = urldefrag(urljoin(base_url, h))
        if absolute.startswith(("http://", "https://")):
            links.append(absolute)
    return links


def run(config):
    out = config.OUTPUT_DIR
    dirs = {k: os.path.join(out, k) for k in ("html", "markdown", "data", "assets")}
    for d in dirs.values():
        os.makedirs(d, exist_ok=True)

    allowed = config.ALLOWED_DOMAIN or _domain_of(config.START_URL)
    index_path = os.path.join(out, "index.csv")
    downloaded_assets = set()

    print("=" * 60)
    print("開始抓取")
    print("=" * 60)
    print(f"起始網址 : {config.START_URL}")
    print(f"允許網域 : {allowed}")
    print(f"上限     : {config.MAX_PAGES} 頁 / 深度 {config.MAX_DEPTH}")
    print(f"輸出目錄 : {os.path.abspath(out)}")
    print()

    visited = set()
    queue = deque([(config.START_URL, 0)])
    count = 0

    with open(index_path, "w", newline="", encoding="utf-8-sig") as idx_f:
        writer = csv.writer(idx_f)
        writer.writerow(["url", "title", "depth", "filename", "status", "fetched_at"])

        with sync_playwright() as p:
            browser = p.chromium.launch(headless=config.HEADLESS)
            context = browser.new_context(
                user_agent=config.USER_AGENT,
                locale=config.LOCALE,
                viewport=config.VIEWPORT,
            )
            page = context.new_page()

            while queue and count < config.MAX_PAGES:
                url, depth = queue.popleft()
                if url in visited or depth > config.MAX_DEPTH:
                    continue
                visited.add(url)

                status = "ok"
                title = ""
                fname = _safe_filename(url)
                html = None

                for attempt in range(config.MAX_RETRIES + 1):
                    try:
                        page.goto(url, timeout=config.PAGE_TIMEOUT_MS,
                                  wait_until="domcontentloaded")
                        try:
                            page.wait_for_load_state(
                                "networkidle", timeout=config.PAGE_TIMEOUT_MS)
                        except Exception:
                            pass  # networkidle 逾時不算致命
                        html = page.content()
                        break
                    except Exception as exc:
                        status = f"error: {exc}"
                        if attempt < config.MAX_RETRIES:
                            time.sleep(config.REQUEST_DELAY)

                count += 1
                if html is None:
                    print(f"[{count}] 失敗 d{depth} {url}")
                    writer.writerow([url, "", depth, fname, status,
                                     datetime.now(timezone.utc).isoformat()])
                    idx_f.flush()
                    continue

                # 存原始 HTML
                with open(os.path.join(dirs["html"], fname + ".html"),
                          "w", encoding="utf-8") as f:
                    f.write(html)

                # 抽取 markdown + 結構化資料
                markdown, structured = extract.extract(html, url)
                title = structured.get("title", "")

                with open(os.path.join(dirs["markdown"], fname + ".md"),
                          "w", encoding="utf-8") as f:
                    f.write(markdown)
                with open(os.path.join(dirs["data"], fname + ".json"),
                          "w", encoding="utf-8") as f:
                    json.dump(structured, f, ensure_ascii=False, indent=2)

                # 下載資產
                if config.DOWNLOAD_ASSETS:
                    cookies = {c["name"]: c["value"] for c in context.cookies()}
                    downloader.download_assets(
                        html, url, dirs["assets"],
                        headers={"User-Agent": config.USER_AGENT},
                        cookies=cookies,
                        max_mb=config.MAX_ASSET_MB,
                        already=downloaded_assets,
                    )

                print(f"[{count}] OK d{depth} {title[:50]!r} {url}")
                writer.writerow([url, title, depth, fname, status,
                                 structured["fetched_at"]])
                idx_f.flush()

                # 展開同網域連結
                if depth < config.MAX_DEPTH:
                    for link in _collect_links(page, url):
                        if link not in visited and _same_domain(link, allowed):
                            queue.append((link, depth + 1))

                time.sleep(config.REQUEST_DELAY)

            browser.close()

    print()
    print("=" * 60)
    print(f"完成！共處理 {count} 頁。索引檔：{os.path.abspath(index_path)}")
    print("=" * 60)
