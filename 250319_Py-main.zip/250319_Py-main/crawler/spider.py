# -*- coding: utf-8 -*-
"""
Playwright BFS 爬蟲主體：從起始網址逐頁展開同網站連結並抓取內容。

防錯設計：
- 任何一頁處理失敗都不會中斷整次抓取，錯誤細節寫入 output/errors.log
- 起始網址被重新導向到其他網域時，自動改用導向後的網域
- PDF/圖片等二進位連結不當頁面開，交給下載器
- 瀏覽器中途崩潰會自動重啟續爬
- 網址正規化（去除 #fragment、utm 追蹤參數、大小寫、預設埠）避免重複抓
"""

import csv
import hashlib
import json
import os
import re
import shutil
import time
import traceback
from collections import deque
from datetime import datetime, timezone
from urllib.parse import parse_qsl, urldefrag, urlencode, urljoin, urlparse, urlunparse

from playwright.sync_api import sync_playwright

from crawler import extract, downloader, keyword
from crawler.stopkey import stop_event, start_listener

# 這些副檔名不當成網頁瀏覽，直接交給下載器處理
BINARY_EXTS = (
    ".pdf", ".doc", ".docx", ".xls", ".xlsx", ".ppt", ".pptx",
    ".zip", ".rar", ".7z", ".gz", ".tar",
    ".jpg", ".jpeg", ".png", ".gif", ".webp", ".svg", ".ico", ".bmp",
    ".mp3", ".mp4", ".avi", ".mov", ".wmv", ".webm",
    ".exe", ".msi", ".dmg", ".apk", ".csv", ".txt", ".json", ".xml",
)

# 網址裡的追蹤參數，去掉以免同一頁被當成不同網址重複抓
TRACKING_PARAMS = ("utm_", "fbclid", "gclid", "yclid", "mc_cid", "mc_eid", "igshid")


def _normalize_url(url):
    """網址正規化：去 fragment/追蹤參數、小寫主機、去預設埠與尾端斜線。"""
    url, _ = urldefrag((url or "").strip())
    p = urlparse(url)
    scheme = p.scheme.lower()
    netloc = p.netloc.lower()
    if scheme == "http" and netloc.endswith(":80"):
        netloc = netloc[:-3]
    if scheme == "https" and netloc.endswith(":443"):
        netloc = netloc[:-4]
    query = urlencode([
        (k, v) for k, v in parse_qsl(p.query, keep_blank_values=True)
        if not any(k.lower().startswith(t) for t in TRACKING_PARAMS)
    ])
    path = p.path or "/"
    if path != "/" and path.endswith("/"):
        path = path[:-1]
    return urlunparse((scheme, netloc, path, p.params, query, ""))


def _site_key(url_or_netloc):
    """取網站識別鍵：主機名小寫、去掉開頭 www.，讓 www 與裸網域視為同站。"""
    netloc = urlparse(url_or_netloc).netloc if "//" in (url_or_netloc or "") else (url_or_netloc or "")
    netloc = netloc.lower().split(":")[0]
    return netloc[4:] if netloc.startswith("www.") else netloc


def _same_site(url, allowed_key):
    return _site_key(url) == allowed_key


def _is_binary_url(url):
    path = urlparse(url).path.lower()
    return path.endswith(BINARY_EXTS)


def _safe_filename(url):
    """把網址轉成 Windows/macOS/Linux 都安全且唯一的檔名（不含副檔名）。"""
    parsed = urlparse(url)
    slug = (parsed.netloc + parsed.path).strip("/")
    slug = re.sub(r"[^A-Za-z0-9._-]+", "_", slug) or "index"
    slug = slug[:80].rstrip("._")
    digest = hashlib.md5(url.encode("utf-8")).hexdigest()[:10]
    return f"{slug}_{digest}"


def _collect_links(page, base_url):
    """收集目前頁面所有 <a href> 的正規化絕對網址。失敗回傳空清單。"""
    try:
        hrefs = page.eval_on_selector_all(
            "a[href]", "els => els.map(e => e.getAttribute('href'))")
    except Exception:
        return []
    links = []
    for h in hrefs:
        if not h:
            continue
        h = h.strip()
        if h.lower().startswith(("javascript:", "mailto:", "tel:", "data:", "#")):
            continue
        try:
            absolute = _normalize_url(urljoin(base_url, h))
        except ValueError:
            continue
        if absolute.startswith(("http://", "https://")):
            links.append(absolute)
    return links


def _new_browser(p, config):
    browser = p.chromium.launch(headless=config.HEADLESS)
    context = browser.new_context(
        user_agent=config.USER_AGENT,
        locale=config.LOCALE,
        viewport=config.VIEWPORT,
        ignore_https_errors=True,
    )
    page = context.new_page()
    return browser, context, page


def _is_browser_dead(exc):
    msg = str(exc).lower()
    return any(s in msg for s in ("closed", "crashed", "disconnected"))


def _fetch(page, url, config):
    """載入一頁。回傳 (html, final_url, status_text)。

    status_text：'ok' / 'http_404' 等 / 'download'（觸發了檔案下載）/ 'error: ...'
    html 為 None 代表沒拿到網頁內容。
    """
    last_error = "error: unknown"
    for attempt in range(config.MAX_RETRIES + 1):
        try:
            resp = page.goto(url, timeout=config.PAGE_TIMEOUT_MS,
                             wait_until="domcontentloaded")
            try:
                page.wait_for_load_state("networkidle",
                                         timeout=config.PAGE_TIMEOUT_MS)
            except Exception:
                pass  # networkidle 逾時不算致命

            content_type = ""
            status = 200
            if resp is not None:
                status = resp.status
                content_type = (resp.headers or {}).get("content-type", "")

            # 不是 HTML（例如直接連到 JSON/檔案）→ 交給下載器
            if content_type and "html" not in content_type.lower():
                return None, page.url, "download"

            html = page.content()
            status_text = "ok" if status < 400 else f"http_{status}"
            return html, page.url, status_text
        except Exception as exc:
            msg = str(exc)
            # 連結觸發了檔案下載（Playwright 無法當頁面開）
            if "Download is starting" in msg or "ERR_ABORTED" in msg:
                return None, url, "download"
            if _is_browser_dead(exc):
                raise  # 讓外層重啟瀏覽器
            last_error = f"error: {msg.splitlines()[0][:200]}"
            if attempt < config.MAX_RETRIES and not stop_event.is_set():
                time.sleep(config.REQUEST_DELAY)
    return None, url, last_error


def run(config):
    out = config.OUTPUT_DIR
    dirs = {k: os.path.join(out, k) for k in ("html", "markdown", "data", "assets")}
    for d in dirs.values():
        os.makedirs(d, exist_ok=True)

    start_url = _normalize_url(config.START_URL)
    allowed = _site_key(config.ALLOWED_DOMAIN or start_url)
    index_path = os.path.join(out, "index.csv")
    errors_path = os.path.join(out, "errors.log")
    # for_ai/：要交給 AI 閱讀的東西全部集中在這個資料夾
    for_ai_dir = os.path.join(out, "for_ai")
    os.makedirs(for_ai_dir, exist_ok=True)
    for_ai_path = os.path.join(for_ai_dir, "site_content.md")
    downloaded_assets = set()

    # 關鍵字搜尋：欄位有內容才啟用
    keywords = keyword.parse_keywords(getattr(config, "KEYWORDS", ""))
    keyword_path = os.path.join(out, "KeyWord.txt")
    kw_f = None
    kw_hits = 0
    if keywords:
        kw_f = open(keyword_path, "w", encoding="utf-8")
        kw_f.write(f"關鍵字：{', '.join(keywords)}\n"
                   f"格式：相關內容-網頁連結\n"
                   + "=" * 50 + "\n")

    # index.csv 若被 Excel 開著會鎖住，先檢查再開始，避免抓完才發現寫不進去
    try:
        idx_f = open(index_path, "w", newline="", encoding="utf-8-sig")
    except PermissionError:
        print(f"無法寫入 {os.path.abspath(index_path)}：檔案似乎被其他程式（如 Excel）開啟中。")
        print("請先關閉該檔案再重新執行。")
        return

    err_f = open(errors_path, "w", encoding="utf-8")

    print("=" * 60)
    print("開始抓取")
    print("=" * 60)
    print(f"起始網址 : {start_url}")
    print(f"允許網站 : {allowed}（含 www 與各子網域路徑差異的正規化）")
    print(f"上限     : {config.MAX_PAGES} 頁 / 深度 {config.MAX_DEPTH}")
    print(f"輸出目錄 : {os.path.abspath(out)}")
    print()

    start_listener()

    ai_f = open(for_ai_path, "w", encoding="utf-8")
    ai_f.write(f"# 網站抓取彙整:{allowed}\n\n"
               f"起始網址:{start_url}\n"
               f"抓取時間:{datetime.now(timezone.utc).isoformat()}\n\n"
               "以下每一頁以 `===== PAGE =====` 分隔，含網址、標題與去除導覽雜訊後的內文。\n")

    visited = set()
    queue = deque([(start_url, 0)])
    count = 0
    error_count = 0
    stopped = False
    domain_adjusted = config.ALLOWED_DOMAIN != ""  # 使用者自己指定的就不自動調整

    def log_error(url, note=""):
        nonlocal error_count
        error_count += 1
        err_f.write(f"\n[{datetime.now(timezone.utc).isoformat()}] {url}\n")
        if note:
            err_f.write(note + "\n")
        err_f.write(traceback.format_exc())
        err_f.flush()

    writer = csv.writer(idx_f)
    writer.writerow(["url", "final_url", "title", "depth", "filename",
                     "status", "fetched_at"])

    with sync_playwright() as p:
        browser, context, page = _new_browser(p, config)
        try:
            while queue and count < config.MAX_PAGES:
                if stop_event.is_set():
                    stopped = True
                    break
                url, depth = queue.popleft()
                if url in visited or depth > config.MAX_DEPTH:
                    continue
                visited.add(url)
                fname = _safe_filename(url)
                now = datetime.now(timezone.utc).isoformat()

                # 二進位/檔案連結：不開頁面，直接下載
                if _is_binary_url(url):
                    count += 1
                    if config.DOWNLOAD_ASSETS:
                        try:
                            saved = downloader.download_one(
                                url, dirs["assets"],
                                headers={"User-Agent": config.USER_AGENT},
                                cookies={}, max_mb=config.MAX_ASSET_MB,
                                already=downloaded_assets)
                            status = "asset" if saved else "asset_skipped"
                        except Exception:
                            status = "asset_failed"
                            log_error(url)
                        print(f"[{count}] {status} d{depth} {url}")
                        writer.writerow([url, url, "", depth, "", status, now])
                        idx_f.flush()
                    continue

                # ---- 載入頁面（瀏覽器若死掉自動重啟一次）----
                try:
                    try:
                        html, final_url, status = _fetch(page, url, config)
                    except Exception as exc:
                        if not _is_browser_dead(exc):
                            raise
                        print("    （瀏覽器中斷，重新啟動續爬...）")
                        try:
                            browser.close()
                        except Exception:
                            pass
                        browser, context, page = _new_browser(p, config)
                        html, final_url, status = _fetch(page, url, config)
                except Exception:
                    count += 1
                    log_error(url)
                    print(f"[{count}] 失敗 d{depth} {url}（詳見 errors.log）")
                    writer.writerow([url, url, "", depth, fname, "error", now])
                    idx_f.flush()
                    continue

                count += 1

                # 觸發下載的連結 → 交給下載器
                if status == "download":
                    if config.DOWNLOAD_ASSETS:
                        try:
                            cookies = {c["name"]: c["value"]
                                       for c in context.cookies()}
                            downloader.download_one(
                                url, dirs["assets"],
                                headers={"User-Agent": config.USER_AGENT},
                                cookies=cookies, max_mb=config.MAX_ASSET_MB,
                                already=downloaded_assets)
                        except Exception:
                            log_error(url)
                    print(f"[{count}] asset d{depth} {url}")
                    writer.writerow([url, final_url, "", depth, "", "asset", now])
                    idx_f.flush()
                    continue

                if html is None:
                    print(f"[{count}] 失敗 d{depth} {url} -> {status}")
                    writer.writerow([url, final_url, "", depth, fname, status, now])
                    idx_f.flush()
                    continue

                # 起始頁被導向到其他網域（如 example.com -> www.example.com 以外的站）
                # 時，第一頁自動改用導向後的網域，否則一頁都抓不到
                if not domain_adjusted:
                    domain_adjusted = True
                    final_key = _site_key(final_url)
                    if final_key and final_key != allowed:
                        print(f"    （起始網址導向到 {final_key}，改用此網域）")
                        allowed = final_key

                # ---- 解析與存檔：任何錯誤都不可中斷整體 ----
                title = ""
                try:
                    with open(os.path.join(dirs["html"], fname + ".html"),
                              "w", encoding="utf-8") as f:
                        f.write(html)

                    markdown, structured = extract.extract(html, final_url)
                    title = structured.get("title", "") or ""

                    with open(os.path.join(dirs["markdown"], fname + ".md"),
                              "w", encoding="utf-8") as f:
                        f.write(markdown)
                    with open(os.path.join(dirs["data"], fname + ".json"),
                              "w", encoding="utf-8") as f:
                        json.dump(structured, f, ensure_ascii=False, indent=2)

                    ai_f.write(f"\n\n===== PAGE =====\n"
                               f"URL: {final_url}\n"
                               f"TITLE: {title}\n"
                               f"DEPTH: {depth}\n\n"
                               f"{markdown.strip()}\n")
                    ai_f.flush()

                    # 關鍵字比對：標題 + 內文，命中就寫入 KeyWord.txt
                    if kw_f is not None:
                        snippets = keyword.find_matches(
                            title + "\n" + structured.get("text", ""), keywords)
                        for s in snippets:
                            kw_f.write(f"{s}-{final_url}\n")
                        if snippets:
                            kw_hits += len(snippets)
                            kw_f.flush()
                            print(f"      關鍵字命中 {len(snippets)} 處")
                except Exception:
                    status = "parse_error"
                    log_error(url, "解析/存檔失敗（原始 HTML 已保留）")

                # ---- 下載頁面上的圖片/附件：失敗不影響流程 ----
                if config.DOWNLOAD_ASSETS:
                    try:
                        cookies = {c["name"]: c["value"]
                                   for c in context.cookies()}
                        downloader.download_assets(
                            html, final_url, dirs["assets"],
                            headers={"User-Agent": config.USER_AGENT},
                            cookies=cookies, max_mb=config.MAX_ASSET_MB,
                            already=downloaded_assets)
                    except Exception:
                        log_error(url, "附件下載失敗")

                print(f"[{count}] {status.upper()} d{depth} {title[:50]!r} {final_url}")
                writer.writerow([url, final_url, title, depth, fname, status, now])
                idx_f.flush()

                # ---- 展開同站連結 ----
                if depth < config.MAX_DEPTH:
                    for link in _collect_links(page, final_url):
                        if link not in visited and _same_site(link, allowed):
                            queue.append((link, depth + 1))

                time.sleep(config.REQUEST_DELAY)
        finally:
            try:
                browser.close()
            except Exception:
                pass
            ai_f.close()
            idx_f.close()
            err_f.close()
            if kw_f is not None:
                kw_f.close()

    # 索引也複製一份進 for_ai/，讓這個資料夾自成完整可交付的內容
    try:
        shutil.copyfile(index_path, os.path.join(for_ai_dir, "index.csv"))
        if keywords and os.path.exists(keyword_path):
            shutil.copyfile(keyword_path,
                            os.path.join(for_ai_dir, "KeyWord.txt"))
    except Exception:
        pass

    print()
    print("=" * 60)
    if stopped:
        print(f"已按 ESC 停止。共處理 {count} 頁，資料已保留。")
    else:
        print(f"完成！共處理 {count} 頁。")
    if error_count:
        print(f"其中 {error_count} 頁有錯誤，細節見：{os.path.abspath(errors_path)}")
    if keywords:
        print(f"關鍵字命中 {kw_hits} 處：{os.path.abspath(keyword_path)}")
    print(f"索引檔：{os.path.abspath(index_path)}")
    print(f"要給 AI 的資料夾：{os.path.abspath(for_ai_dir)}")
    print("=" * 60)
