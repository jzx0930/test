# -*- coding: utf-8 -*-
"""
Playwright BFS 爬蟲主體：從起始網址逐頁展開同網站連結並抓取內容。

特性：
- 可多工作者並行抓取（config.CONCURRENCY，每個工作者一個獨立瀏覽器）
- 續爬：進度存在 output/.crawl_state.json，中斷後可接續（config.RESUME）
- 路徑前綴過濾：只爬 config.URL_PREFIX 開頭的頁面
- for_ai/site_content.md 超過 config.AI_FILE_MB 自動分割
- 任何一頁失敗都不中斷整體，錯誤寫入 output/errors.log
- 起始網址被導向其他網域時自動跟隨；www 與裸網域視為同站
- PDF/圖片等二進位連結交給下載器；瀏覽器崩潰自動重啟
"""

import csv
import hashlib
import json
import os
import re
import shutil
import threading
import time
import traceback
from collections import deque
from datetime import datetime, timezone
from urllib.parse import parse_qsl, urldefrag, urlencode, urljoin, urlparse, urlunparse

from playwright.sync_api import sync_playwright

from crawler import extract, downloader, keyword
from crawler.stopkey import stop_event, start_listener

# 這些副檔名不當成網頁瀏覽，直接交給下載器處理
BINARY_EXTS = (
    ".pdf", ".doc", ".docx", ".xls", ".xlsx", ".ppt", ".pptx",
    ".zip", ".rar", ".7z", ".gz", ".tar",
    ".jpg", ".jpeg", ".png", ".gif", ".webp", ".svg", ".ico", ".bmp",
    ".mp3", ".mp4", ".avi", ".mov", ".wmv", ".webm",
    ".exe", ".msi", ".dmg", ".apk", ".csv", ".txt", ".json", ".xml",
)

# 網址裡的追蹤參數，去掉以免同一頁被當成不同網址重複抓
TRACKING_PARAMS = ("utm_", "fbclid", "gclid", "yclid", "mc_cid", "mc_eid", "igshid")

STATE_FILE = ".crawl_state.json"


def _normalize_url(url):
    """網址正規化：去 fragment/追蹤參數、小寫主機、去預設埠與尾端斜線。"""
    url, _ = urldefrag((url or "").strip())
    p = urlparse(url)
    scheme = p.scheme.lower()
    netloc = p.netloc.lower()
    if scheme == "http" and netloc.endswith(":80"):
        netloc = netloc[:-3]
    if scheme == "https" and netloc.endswith(":443"):
        netloc = netloc[:-4]
    query = urlencode([
        (k, v) for k, v in parse_qsl(p.query, keep_blank_values=True)
        if not any(k.lower().startswith(t) for t in TRACKING_PARAMS)
    ])
    path = p.path or "/"
    if path != "/" and path.endswith("/"):
        path = path[:-1]
    return urlunparse((scheme, netloc, path, p.params, query, ""))


def _site_key(url_or_netloc):
    """取網站識別鍵：主機名小寫、去掉開頭 www.，讓 www 與裸網域視為同站。"""
    netloc = urlparse(url_or_netloc).netloc if "//" in (url_or_netloc or "") else (url_or_netloc or "")
    netloc = netloc.lower().split(":")[0]
    return netloc[4:] if netloc.startswith("www.") else netloc


def _same_site(url, allowed_key):
    return _site_key(url) == allowed_key


def _is_binary_url(url):
    path = urlparse(url).path.lower()
    return path.endswith(BINARY_EXTS)


def _safe_filename(url):
    """把網址轉成 Windows/macOS/Linux 都安全且唯一的檔名（不含副檔名）。"""
    parsed = urlparse(url)
    slug = (parsed.netloc + parsed.path).strip("/")
    slug = re.sub(r"[^A-Za-z0-9._-]+", "_", slug) or "index"
    slug = slug[:80].rstrip("._")
    digest = hashlib.md5(url.encode("utf-8")).hexdigest()[:10]
    return f"{slug}_{digest}"


def _collect_links(page, base_url):
    """收集目前頁面所有 <a href> 的正規化絕對網址。失敗回傳空清單。"""
    try:
        hrefs = page.eval_on_selector_all(
            "a[href]", "els => els.map(e => e.getAttribute('href'))")
    except Exception:
        return []
    links = []
    for h in hrefs:
        if not h:
            continue
        h = h.strip()
        if h.lower().startswith(("javascript:", "mailto:", "tel:", "data:", "#")):
            continue
        try:
            absolute = _normalize_url(urljoin(base_url, h))
        except ValueError:
            continue
        if absolute.startswith(("http://", "https://")):
            links.append(absolute)
    return links


def _new_browser(p, config):
    browser = p.chromium.launch(headless=config.HEADLESS)
    context = browser.new_context(
        user_agent=config.USER_AGENT,
        locale=config.LOCALE,
        viewport=config.VIEWPORT,
        ignore_https_errors=True,
    )
    page = context.new_page()
    return browser, context, page


def _is_browser_dead(exc):
    msg = str(exc).lower()
    return any(s in msg for s in ("closed", "crashed", "disconnected"))


def _fetch(page, url, config):
    """載入一頁。回傳 (html, final_url, status_text)。

    status_text：'ok' / 'http_404' 等 / 'download'（觸發了檔案下載）/ 'error: ...'
    html 為 None 代表沒拿到網頁內容。
    """
    last_error = "error: unknown"
    for attempt in range(config.MAX_RETRIES + 1):
        try:
            resp = page.goto(url, timeout=config.PAGE_TIMEOUT_MS,
                             wait_until="domcontentloaded")
            try:
                page.wait_for_load_state("networkidle",
                                         timeout=config.PAGE_TIMEOUT_MS)
            except Exception:
                pass  # networkidle 逾時不算致命

            content_type = ""
            status = 200
            if resp is not None:
                status = resp.status
                content_type = (resp.headers or {}).get("content-type", "")

            if content_type and "html" not in content_type.lower():
                return None, page.url, "download"

            html = page.content()
            status_text = "ok" if status < 400 else f"http_{status}"
            return html, page.url, status_text
        except Exception as exc:
            msg = str(exc)
            if "Download is starting" in msg or "ERR_ABORTED" in msg:
                return None, url, "download"
            if _is_browser_dead(exc):
                raise  # 讓外層重啟瀏覽器
            last_error = f"error: {msg.splitlines()[0][:200]}"
            if attempt < config.MAX_RETRIES and not stop_event.is_set():
                time.sleep(config.REQUEST_DELAY)
    return None, url, last_error


class _AiWriter:
    """for_ai 合併檔寫入器：超過大小上限自動分割成 site_content_2.md、_3.md..."""

    def __init__(self, dir_path, header, limit_mb, resume):
        self.dir = dir_path
        self.header = header
        self.limit = int(limit_mb * 1024 * 1024)
        self.part = 1
        if resume:
            while os.path.exists(self._path(self.part + 1)):
                self.part += 1
        path = self._path(self.part)
        if resume and os.path.exists(path):
            self.size = os.path.getsize(path)
            self.f = open(path, "a", encoding="utf-8")
        else:
            self.f = open(path, "w", encoding="utf-8")
            self.f.write(header)
            self.size = len(header.encode("utf-8"))

    def _path(self, part):
        name = "site_content.md" if part == 1 else f"site_content_{part}.md"
        return os.path.join(self.dir, name)

    def write(self, text):
        data = text.encode("utf-8")
        if self.size + len(data) > self.limit and self.size > len(self.header.encode("utf-8")):
            self.f.close()
            self.part += 1
            self.f = open(self._path(self.part), "w", encoding="utf-8")
            cont = self.header + f"\n（接續第 {self.part} 份）\n"
            self.f.write(cont)
            self.size = len(cont.encode("utf-8"))
        self.f.write(text)
        self.f.flush()
        self.size += len(data)

    def close(self):
        try:
            self.f.close()
        except Exception:
            pass


def _load_state(out, start_url):
    """讀取續爬狀態。不存在或起始網址不同則回傳 None。"""
    path = os.path.join(out, STATE_FILE)
    if not os.path.exists(path):
        return None
    try:
        with open(path, encoding="utf-8") as f:
            state = json.load(f)
        if state.get("start_url") != start_url:
            print("（上次的進度是別的網址，改為重新開始）")
            return None
        return state
    except Exception:
        return None


def run(config, progress_cb=None):
    """執行抓取。progress_cb 為選用的進度回呼（給 GUI 用）。"""
    def notify(event):
        if progress_cb is not None:
            try:
                progress_cb(event)
            except Exception:
                pass  # GUI 回呼出錯不可影響抓取

    out = config.OUTPUT_DIR
    dirs = {k: os.path.join(out, k) for k in ("html", "markdown", "data", "assets")}
    for d in dirs.values():
        os.makedirs(d, exist_ok=True)

    start_url = _normalize_url(config.START_URL)
    allowed = _site_key(config.ALLOWED_DOMAIN or start_url)
    url_prefix = _normalize_url(config.URL_PREFIX) if getattr(config, "URL_PREFIX", "") else ""
    concurrency = max(1, min(int(getattr(config, "CONCURRENCY", 1)), 3))
    index_path = os.path.join(out, "index.csv")
    errors_path = os.path.join(out, "errors.log")
    state_path = os.path.join(out, STATE_FILE)
    for_ai_dir = os.path.join(out, "for_ai")
    os.makedirs(for_ai_dir, exist_ok=True)

    # ---- 續爬狀態 ----
    state = _load_state(out, start_url) if getattr(config, "RESUME", False) else None
    resuming = state is not None

    # ---- 共享狀態（多工作者用，全部以 lock 保護）----
    lock = threading.RLock()
    visited = set(state["visited"]) if resuming else set()
    queue = deque([tuple(x) for x in state["queue"]] if resuming else [(start_url, 0)])
    shared = {
        "count": state["count"] if resuming else 0,
        "in_progress": 0,
        "errors": 0,
        "kw_hits": state.get("kw_hits", 0) if resuming else 0,
        "stopped": False,
        "allowed": allowed,
        "domain_adjusted": resuming or config.ALLOWED_DOMAIN != "",
        "downloaded_assets": set(),
    }

    # index.csv 若被 Excel 開著會鎖住，先檢查再開始
    file_mode = "a" if resuming else "w"
    try:
        idx_f = open(index_path, file_mode, newline="", encoding="utf-8-sig")
    except PermissionError:
        print(f"無法寫入 {os.path.abspath(index_path)}：檔案似乎被其他程式（如 Excel）開啟中。")
        print("請先關閉該檔案再重新執行。")
        return
    writer = csv.writer(idx_f)
    if not resuming:
        writer.writerow(["url", "final_url", "title", "depth", "filename",
                         "status", "fetched_at"])

    err_f = open(errors_path, file_mode, encoding="utf-8")

    keywords = keyword.parse_keywords(getattr(config, "KEYWORDS", ""))
    keyword_path = os.path.join(out, "KeyWord.txt")
    kw_f = None
    if keywords:
        kw_f = open(keyword_path, file_mode, encoding="utf-8")
        if not resuming:
            kw_f.write(f"關鍵字：{', '.join(keywords)}\n"
                       f"格式：相關內容-網頁連結\n" + "=" * 50 + "\n")

    ai_header = (f"# 網站抓取彙整:{allowed}\n\n"
                 f"起始網址:{start_url}\n"
                 f"抓取時間:{datetime.now(timezone.utc).isoformat()}\n\n"
                 "以下每一頁以 `===== PAGE =====` 分隔，含網址、標題與去除導覽雜訊後的內文。\n")
    ai_writer = _AiWriter(for_ai_dir, ai_header,
                          getattr(config, "AI_FILE_MB", 20), resuming)

    print("=" * 60)
    print("開始抓取" + ("（接續上次進度）" if resuming else ""))
    print("=" * 60)
    print(f"起始網址 : {start_url}")
    print(f"允許網站 : {shared['allowed']}")
    if url_prefix:
        print(f"路徑限制 : 只爬 {url_prefix} 開頭的頁面")
    print(f"上限     : {config.MAX_PAGES} 頁 / 深度 {config.MAX_DEPTH} / 並行 {concurrency}")
    if resuming:
        print(f"已抓進度 : {shared['count']} 頁，待爬佇列 {len(queue)} 條")
    print(f"輸出目錄 : {os.path.abspath(out)}")
    print()

    stop_event.clear()
    start_listener()

    def log_error(url, note=""):
        with lock:
            shared["errors"] += 1
            err_f.write(f"\n[{datetime.now(timezone.utc).isoformat()}] {url}\n")
            if note:
                err_f.write(note + "\n")
            err_f.write(traceback.format_exc())
            err_f.flush()

    def save_state():
        # 進度落地，供中斷後續爬（已在 lock 內呼叫）
        try:
            with open(state_path, "w", encoding="utf-8") as f:
                json.dump({"start_url": start_url,
                           "visited": sorted(visited),
                           "queue": list(queue),
                           "count": shared["count"],
                           "kw_hits": shared["kw_hits"]}, f, ensure_ascii=False)
        except Exception:
            pass

    def allow_link(link):
        if not _same_site(link, shared["allowed"]):
            return False
        return not url_prefix or link.startswith(url_prefix)

    def write_row(row):
        writer.writerow(row)
        idx_f.flush()

    def process_page(page, context, url, depth, config):
        """抓取並處理一頁（在工作者執行緒內）。檔案/狀態寫入都在 lock 內。"""
        fname = _safe_filename(url)
        now = datetime.now(timezone.utc).isoformat()
        html, final_url, status = _fetch(page, url, config)

        with lock:
            shared["count"] += 1
            my_num = shared["count"]

        if status == "download":
            if config.DOWNLOAD_ASSETS:
                try:
                    cookies = {c["name"]: c["value"] for c in context.cookies()}
                    with lock:
                        already = shared["downloaded_assets"]
                    downloader.download_one(
                        url, dirs["assets"],
                        headers={"User-Agent": config.USER_AGENT},
                        cookies=cookies, max_mb=config.MAX_ASSET_MB,
                        already=already)
                except Exception:
                    log_error(url)
            print(f"[{my_num}] asset d{depth} {url}")
            with lock:
                write_row([url, final_url, "", depth, "", "asset", now])
                save_state()
            notify({"type": "page", "count": my_num,
                    "max": config.MAX_PAGES, "text": f"附件 {url}"})
            return

        if html is None:
            print(f"[{my_num}] 失敗 d{depth} {url} -> {status}")
            with lock:
                write_row([url, final_url, "", depth, fname, status, now])
                save_state()
            notify({"type": "page", "count": my_num,
                    "max": config.MAX_PAGES, "text": f"失敗({status}) {url}"})
            return

        # 起始頁被導向到其他網域時，自動改用導向後的網域
        with lock:
            if not shared["domain_adjusted"]:
                shared["domain_adjusted"] = True
                final_key = _site_key(final_url)
                if final_key and final_key != shared["allowed"]:
                    print(f"    （起始網址導向到 {final_key}，改用此網域）")
                    shared["allowed"] = final_key

        # ---- 解析與存檔：任何錯誤都不可中斷整體 ----
        title = ""
        try:
            with open(os.path.join(dirs["html"], fname + ".html"),
                      "w", encoding="utf-8") as f:
                f.write(html)

            markdown, structured = extract.extract(html, final_url)
            title = structured.get("title", "") or ""

            with open(os.path.join(dirs["markdown"], fname + ".md"),
                      "w", encoding="utf-8") as f:
                f.write(markdown)
            with open(os.path.join(dirs["data"], fname + ".json"),
                      "w", encoding="utf-8") as f:
                json.dump(structured, f, ensure_ascii=False, indent=2)

            with lock:
                ai_writer.write(f"\n\n===== PAGE =====\n"
                                f"URL: {final_url}\n"
                                f"TITLE: {title}\n"
                                f"DEPTH: {depth}\n\n"
                                f"{markdown.strip()}\n")

                if kw_f is not None:
                    snippets = keyword.find_matches(
                        title + "\n" + structured.get("text", ""), keywords)
                    for s in snippets:
                        kw_f.write(f"{s}-{final_url}\n")
                    if snippets:
                        shared["kw_hits"] += len(snippets)
                        kw_f.flush()
                        print(f"      關鍵字命中 {len(snippets)} 處")
        except Exception:
            status = "parse_error"
            log_error(url, "解析/存檔失敗（原始 HTML 已保留）")

        if config.DOWNLOAD_ASSETS:
            try:
                cookies = {c["name"]: c["value"] for c in context.cookies()}
                with lock:
                    already = shared["downloaded_assets"]
                downloader.download_assets(
                    html, final_url, dirs["assets"],
                    headers={"User-Agent": config.USER_AGENT},
                    cookies=cookies, max_mb=config.MAX_ASSET_MB,
                    already=already)
            except Exception:
                log_error(url, "附件下載失敗")

        print(f"[{my_num}] {status.upper()} d{depth} {title[:50]!r} {final_url}")

        with lock:
            write_row([url, final_url, title, depth, fname, status, now])
            if depth < config.MAX_DEPTH:
                for link in _collect_links(page, final_url):
                    if link not in visited and allow_link(link):
                        queue.append((link, depth + 1))
            save_state()
        notify({"type": "page", "count": my_num,
                "max": config.MAX_PAGES, "text": title[:60] or final_url})

    def worker(worker_id):
        try:
            with sync_playwright() as p:
                browser, context, page = _new_browser(p, config)
                try:
                    while not stop_event.is_set():
                        task = None
                        with lock:
                            if shared["count"] + shared["in_progress"] >= config.MAX_PAGES:
                                break
                            while queue:
                                url, depth = queue.popleft()
                                if url in visited or depth > config.MAX_DEPTH:
                                    continue
                                visited.add(url)
                                task = (url, depth)
                                break
                            if task is None:
                                if shared["in_progress"] == 0:
                                    break  # 佇列空且沒人在跑 → 結束
                            else:
                                shared["in_progress"] += 1
                        if task is None:
                            time.sleep(0.2)  # 等其他工作者展開新連結
                            continue

                        url, depth = task
                        try:
                            # 二進位連結不開頁面，直接下載
                            if _is_binary_url(url):
                                now = datetime.now(timezone.utc).isoformat()
                                with lock:
                                    shared["count"] += 1
                                    my_num = shared["count"]
                                status = "asset_skipped"
                                if config.DOWNLOAD_ASSETS:
                                    try:
                                        with lock:
                                            already = shared["downloaded_assets"]
                                        saved = downloader.download_one(
                                            url, dirs["assets"],
                                            headers={"User-Agent": config.USER_AGENT},
                                            cookies={}, max_mb=config.MAX_ASSET_MB,
                                            already=already)
                                        status = "asset" if saved else "asset_skipped"
                                    except Exception:
                                        status = "asset_failed"
                                        log_error(url)
                                print(f"[{my_num}] {status} d{depth} {url}")
                                with lock:
                                    write_row([url, url, "", depth, "", status, now])
                                    save_state()
                                notify({"type": "page", "count": my_num,
                                        "max": config.MAX_PAGES, "text": f"附件 {url}"})
                            else:
                                try:
                                    process_page(page, context, url, depth, config)
                                except Exception as exc:
                                    if not _is_browser_dead(exc):
                                        raise
                                    print(f"    （工作者{worker_id} 瀏覽器中斷，重新啟動續爬...）")
                                    try:
                                        browser.close()
                                    except Exception:
                                        pass
                                    browser, context, page = _new_browser(p, config)
                                    process_page(page, context, url, depth, config)
                        except Exception:
                            with lock:
                                shared["count"] += 1
                                my_num = shared["count"]
                            log_error(url)
                            print(f"[{my_num}] 失敗 d{depth} {url}（詳見 errors.log）")
                            with lock:
                                write_row([url, url, "", depth, _safe_filename(url),
                                           "error",
                                           datetime.now(timezone.utc).isoformat()])
                                save_state()
                            notify({"type": "page", "count": my_num,
                                    "max": config.MAX_PAGES, "text": f"失敗 {url}"})
                        finally:
                            with lock:
                                shared["in_progress"] -= 1
                        time.sleep(config.REQUEST_DELAY)
                finally:
                    try:
                        browser.close()
                    except Exception:
                        pass
        except Exception:
            log_error(f"(工作者{worker_id})", "工作者異常結束")

    threads = [threading.Thread(target=worker, args=(i + 1,), daemon=True)
               for i in range(concurrency)]
    for t in threads:
        t.start()
    for t in threads:
        t.join()

    if stop_event.is_set():
        shared["stopped"] = True

    ai_writer.close()
    idx_f.close()
    err_f.close()
    if kw_f is not None:
        kw_f.close()

    # 完整跑完才清掉續爬狀態；中途停止則保留供下次接續
    if not shared["stopped"] and not queue:
        try:
            os.remove(state_path)
        except OSError:
            pass

    # 索引/關鍵字也複製進 for_ai/，讓這個資料夾自成完整可交付的內容
    try:
        shutil.copyfile(index_path, os.path.join(for_ai_dir, "index.csv"))
        if keywords and os.path.exists(keyword_path):
            shutil.copyfile(keyword_path, os.path.join(for_ai_dir, "KeyWord.txt"))
    except Exception:
        pass

    count = shared["count"]
    print()
    print("=" * 60)
    if shared["stopped"]:
        print(f"已停止。共處理 {count} 頁，資料已保留，下次可勾選「接續上次進度」續爬。")
    else:
        print(f"完成！共處理 {count} 頁。")
    if shared["errors"]:
        print(f"其中 {shared['errors']} 頁有錯誤，細節見：{os.path.abspath(errors_path)}")
    if keywords:
        print(f"關鍵字命中 {shared['kw_hits']} 處：{os.path.abspath(keyword_path)}")
    print(f"索引檔：{os.path.abspath(index_path)}")
    print(f"要給 AI 的資料夾：{os.path.abspath(for_ai_dir)}")
    print("=" * 60)
    notify({"type": "done", "count": count, "stopped": shared["stopped"],
            "errors": shared["errors"],
            "kw_hits": shared["kw_hits"] if keywords else None,
            "out": os.path.abspath(out)})
