# -*- coding: utf-8 -*-
"""
抓取設定檔。要改抓哪個網站、抓多少頁，主要改這裡就好。
"""

# 起始網址：爬蟲從這一頁開始，往同網域內的連結逐頁展開。
START_URL = "https://www.aerotech.com/"

# 只跟「這個網域」底下的連結。留空字串 "" 代表自動用 START_URL 的網域。
# 例如想限制更窄，可填 "www.aerotech.com"。
ALLOWED_DOMAIN = ""

# 最多抓幾頁（避免無限爬整個站）。先小量測試可改成 3。
MAX_PAGES = 200

# 連結展開的最大深度（START_URL 為第 0 層）。
MAX_DEPTH = 4

# 每抓一頁後等待幾秒（禮貌延遲，降低被偵測/封鎖機率）。
REQUEST_DELAY = 1.0

# 是否用無頭模式。設 False 會跳出實際瀏覽器視窗，較不容易被當成機器人。
HEADLESS = True

# 每頁載入逾時（毫秒）。
PAGE_TIMEOUT_MS = 30000

# 單頁載入失敗時的重試次數。
MAX_RETRIES = 2

# 是否下載頁面上的圖片 / PDF 等附件。
DOWNLOAD_ASSETS = True

# 附件單檔大小上限（MB），超過就略過。
MAX_ASSET_MB = 25

# 關鍵字搜尋（留空 = 不啟用）。可填多個，用逗號分隔，例如 "linear stage, encoder"。
# 有填時，每頁內文若出現關鍵字，會把相關片段與網址寫入 output/KeyWord.txt。
KEYWORDS = ""

# 只爬網址開頭符合此前綴的頁面（留空 = 整站）。
# 例如 "https://www.aerotech.com/products/" 就只爬產品區。起始網址不受限制。
URL_PREFIX = ""

# 同時開幾個瀏覽器分頁並行抓取（1~3）。越多越快，但被網站封鎖的風險也越高。
CONCURRENCY = 1

# 是否接續上次中斷的進度（已抓過的頁面跳過，從上次的待爬清單繼續）。
RESUME = False

# for_ai/site_content.md 單檔大小上限（MB），超過自動分割成 site_content_2.md...
AI_FILE_MB = 20

# 輸出資料夾。
OUTPUT_DIR = "output"

# 偽裝用的瀏覽器 User-Agent。
USER_AGENT = (
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
    "(KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36"
)

# 瀏覽器語系與視窗大小。
LOCALE = "en-US"
VIEWPORT = {"width": 1366, "height": 900}
