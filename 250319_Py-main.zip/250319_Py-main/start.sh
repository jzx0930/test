#!/usr/bin/env bash
# macOS / Linux 一鍵啟動：會自動檢查/安裝套件並開始抓取。
cd "$(dirname "$0")" || exit 1

if command -v python3 >/dev/null 2>&1; then
    python3 run.py
elif command -v python >/dev/null 2>&1; then
    python run.py
else
    echo "找不到 Python，請先安裝 Python 3。"
    exit 1
fi
