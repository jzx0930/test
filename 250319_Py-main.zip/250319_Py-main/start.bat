@echo off
REM One-click launcher: checks/installs packages then starts the crawler.
cd /d "%~dp0"

py --version
if %errorlevel%==0 (
    py run.py
    goto end
)

python --version
if %errorlevel%==0 (
    python run.py
    goto end
)

echo Python not found. Please install Python 3 and check "Add Python to PATH".
echo Download: https://www.python.org/downloads/

:end
echo.
pause
