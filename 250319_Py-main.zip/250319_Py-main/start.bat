@echo off
REM Windows 一鍵啟動：雙擊此檔即可。會自動檢查/安裝套件並開始抓取。
chcp 65001 >nul
cd /d "%~dp0"

where py >nul 2>nul
if %errorlevel%==0 (
    py run.py
    goto end
)

where python >nul 2>nul
if %errorlevel%==0 (
    python run.py
    goto end
)

echo 找不到 Python，請先安裝 Python 3 並勾選「Add Python to PATH」。
echo 下載： https://www.python.org/downloads/

:end
echo.
pause
