# 網站資料抓取工具

從指定網站的起始網址開始，自動沿著同網域的連結逐頁抓取，把每一頁存成
**原始 HTML、Markdown、結構化 JSON**，並下載頁面上的**圖片與附件**，最後產生一份
全站索引 `index.csv`。

底層用 Playwright 真實 Chromium 瀏覽器執行，較能處理需要 JavaScript 渲染的頁面，
也較不容易被當成單純的爬蟲機器人。

## 一鍵啟動

啟動時會**自動檢查所需套件，缺少就自動安裝**，並確保 Playwright 瀏覽器就緒，然後開始抓取。

- **Windows**：雙擊 `start.bat`
- **macOS / Linux**：`bash start.sh`
- **任何平台**：`python run.py`

> 第一次執行會安裝套件與 Chromium 瀏覽器，需要幾分鐘，請耐心等候。

## 設定

要抓哪個網站、抓多少頁，改 `config.py`：

| 設定 | 說明 |
| --- | --- |
| `START_URL` | 起始網址（預設 `https://www.aerotech.com/`） |
| `ALLOWED_DOMAIN` | 限制只抓哪個網域，留空自動用起始網址的網域 |
| `MAX_PAGES` | 最多抓幾頁（先測試可設 `3`） |
| `MAX_DEPTH` | 連結展開最大深度 |
| `REQUEST_DELAY` | 每頁之間的延遲秒數（禮貌延遲） |
| `HEADLESS` | 設 `False` 會顯示瀏覽器視窗，較不易被偵測 |
| `DOWNLOAD_ASSETS` | 是否下載圖片/附件 |

## 輸出

執行後產生在 `output/`：

```
output/
├── html/        每頁原始 HTML
├── markdown/    每頁 Markdown
├── data/        每頁結構化 JSON（標題/連結/表格/純文字）
├── assets/      下載的圖片與附件
└── index.csv    全站頁面索引
```

## 注意

- 部分網站會偵測或阻擋自動存取；本工具用真實瀏覽器 + 可關閉無頭模式 + 禮貌延遲盡量降低被擋的機會，但無法保證一定成功。
- 請僅抓取你有權存取的公開資料，並遵守該網站的使用條款。
- 預設有頁數上限以免無限爬整個站，可在 `config.py` 自行調整。
