# -*- coding: utf-8 -*-
"""
一鍵入口：
1. 檢查所需 Python 套件，缺少就自動安裝。
2. 確保 Playwright 瀏覽器已安裝。
3. 啟動爬蟲開始抓取。

直接執行：  python run.py
"""

import os
import sys

# 確保不論從哪個目錄執行，都能 import 到本專案的 crawler 套件。
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))


def main():
    print("\n網站資料抓取工具 — 一鍵啟動\n")

    # 步驟一/二：檢查並安裝套件與瀏覽器（只用標準函式庫，可在套件未裝時呼叫）
    from crawler import bootstrap
    bootstrap.check_and_install()

    # 套件就緒後才 import 爬蟲（它依賴第三方套件）
    import config
    from crawler import spider

    # 顯示設定視窗（含進度條），爬蟲由視窗控制啟動/停止；
    # 沒有圖形環境時退回用 config.py 的設定直接在終端機執行
    try:
        from crawler import gui
    except Exception as exc:
        gui = None
        print(f"（無法載入設定視窗，改用 config.py 的設定：{exc}）")

    try:
        if gui is not None:
            try:
                gui.show_form(config, spider.run)
            except Exception as exc:
                # 視窗開不起來（無圖形環境等）就退回終端機模式
                print(f"（無法開啟設定視窗，改用 config.py 的設定：{exc}）")
                spider.run(config)
        else:
            spider.run(config)
    except KeyboardInterrupt:
        print("\n已手動中止。已抓取的內容保留在輸出目錄。")
        sys.exit(130)


if __name__ == "__main__":
    try:
        main()
    except KeyboardInterrupt:
        print("\n已手動中止。")
    except Exception:
        # 任何未預期錯誤都完整印出，方便截圖回報，不要讓視窗無聲關閉
        import traceback
        print("\n發生未預期的錯誤，請把以下訊息截圖回報：\n")
        traceback.print_exc()
        sys.exit(1)
