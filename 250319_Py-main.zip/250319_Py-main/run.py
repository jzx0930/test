# -*- coding: utf-8 -*-
"""
一鍵入口：
1. 檢查所需 Python 套件，缺少就自動安裝。
2. 確保 Playwright 瀏覽器已安裝。
3. 啟動爬蟲開始抓取。

直接執行：  python run.py
"""

import os
import sys

# 確保不論從哪個目錄執行，都能 import 到本專案的 crawler 套件。
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))


def main():
    print("\n網站資料抓取工具 — 一鍵啟動\n")

    # 步驟一/二：檢查並安裝套件與瀏覽器（只用標準函式庫，可在套件未裝時呼叫）
    from crawler import bootstrap
    bootstrap.check_and_install()

    # 套件就緒後才 import 爬蟲（它依賴第三方套件）
    import config
    from crawler import spider

    try:
        spider.run(config)
    except KeyboardInterrupt:
        print("\n已手動中止。已抓取的內容保留在輸出目錄。")
        sys.exit(130)


if __name__ == "__main__":
    main()
