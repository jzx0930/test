﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Threading;
using System.Diagnostics;
using libplctag;
using Sres.Net.EEIP;
using LaserProcess_LCH;


namespace LCSBM
{
    public class EthernetIP_Connect
    {
        Tag _TagData;
        EEIPClient eeipClient;
        Stopwatch tactT = new Stopwatch();

        /// <summary>
        /// 資料更新成功
        /// </summary>
        public bool DataUpdataOk = false;

        // ICE2-8IOL-G65L-V1D 的典型 Tag 路徑（依 Web Server 或 EDS 確認）
        // 常見 PDI 映射：Input Assembly Instance 通常在 Tag 名稱如 "InputAssembly" 或 Symbolic "PDI[port]"
        // 先用 Web Server[](http://裝置IP) 確認 Tag 名稱或 Assembly Instance
        public EthernetIP_Connect(string ip)
        {
            //_TagData = new Tag()
            //{
            //    Gateway = ip,               // 你的 ICE2 IP
            //    //Path = "1,0",                           // 通常背板 + 槽位 (Generic Adapter 模式設 1,0)
            //    PlcType = PlcType.ControlLogix,                 // ICE2 不是 Logix，但 libplctag 常用 PLC5 或 LGX 模擬 Explicit
            //    Protocol = Protocol.ab_eip,             // 或用 CpuType.LGX + Symbolic Tag，如果裝置支援
            //    Name = "PDI",                 // 常見名稱，或 "PDI" / "ProcessDataInput"
            //    ElementSize = 4,                        // 假設 32-bit 資料，實際依端口 PDI 大小調整（e.g. 2 bytes/port）
            //    ElementCount = 1,                       // 一次讀 1 個元素，或更多
            //    Timeout = TimeSpan.FromSeconds(5)
            //};

            eeipClient = new EEIPClient();
            eeipClient.IPAddress = ip;
            eeipClient.RegisterSession();

            eeipClient.O_T_InstanceID = 117;
            eeipClient.T_O_InstanceID = 101;
            eeipClient.ConfigurationAssemblyInstanceID = 1;   // 常見為 1
            //eeipClient.O_T_Length = 8;//4;                       // 輸出長度（bytes）
            //eeipClient.T_O_Length = 16;//12;                       // 輸入長度（bytes）

            eeipClient.O_T_Length = 12;                       // 輸出長度（bytes）
            eeipClient.T_O_Length = 24;                       // 輸入長度（bytes）


            // 關鍵調整：使用最簡單的 RealTimeFormat 和 ConnectionType
            eeipClient.O_T_RealTimeFormat = RealTimeFormat.Modeless;   // Modeless 最寬鬆，不加額外 header
            eeipClient.T_O_RealTimeFormat = RealTimeFormat.Modeless;

            eeipClient.O_T_ConnectionType = ConnectionType.Point_to_Point;   // 先用單播，避免 multicast path 問題
            eeipClient.T_O_ConnectionType = ConnectionType.Point_to_Point;

            eeipClient.O_T_Priority = Priority.Scheduled;            
            eeipClient.T_O_Priority = Priority.Scheduled;

            eeipClient.RequestedPacketRate_O_T = 15000; //10ms
            eeipClient.RequestedPacketRate_T_O = 15000;
           
            //eeipClient.i = 20000;       // 20 ms，先用較寬鬆的 RPI 測試

            // 明確關閉一些可能產生額外 segment 的選項
            eeipClient.O_T_OwnerRedundant = false;
            eeipClient.T_O_OwnerRedundant = false;
            eeipClient.O_T_VariableLength = false;
            eeipClient.T_O_VariableLength = false;

            // 嘗試 Forward Open
            try
            {
                eeipClient.ForwardOpen();
                Console.WriteLine("Class 1 連線成功！");
            }
            catch (Sres.Net.EEIP.CIPException ex)
            {
                Console.WriteLine("ForwardOpen 失敗: " + ex.Message);
                //Console.WriteLine("General Status: " + ex.GeneralStatusCode);
                //Console.WriteLine("Additional Status: " + ex.AdditionalStatusCode);
            }
        }


        public bool Festo_GetPressure(ref double P05, ref ushort valve, ref double P10)
        {
            double NPdata = 0, NVdata = 0;
            bool finish = false;
            //Read the Inputs Transfered form Target -> Originator
            //Console.WriteLine("State of first Input byte: " + eeipClient.T_O_IOData[8]);
            //Console.WriteLine("State of second Input byte: " + eeipClient.T_O_IOData[9]);

            ////write the Outputs Transfered form Originator -> Target
            //eeipClient.O_T_IOData[0] = (byte)(eeipClient.O_T_IOData[0] + 1);
            //eeipClient.O_T_IOData[1] = (byte)(eeipClient.O_T_IOData[1] - 1);
            //eeipClient.O_T_IOData[2] = 1;
            //eeipClient.O_T_IOData[3] = 8;
            try
            {                
              //  Console.WriteLine($);
                ushort festo1 = BitConverter.ToUInt16(eeipClient.T_O_IOData, 4);
                ushort festo3 = BitConverter.ToUInt16(eeipClient.T_O_IOData, 20);
                valve = BitConverter.ToUInt16(eeipClient.T_O_IOData, 12);
                if (valve >= 65535)
                    valve = 0;
                uint Pdata = festo1;                
                NPdata = Pdata >> 2;
                P05 = NPdata * 0.003051944088;
                int Vdata = festo3;
                NVdata = Vdata >> 2;
                P10 = NVdata * 0.0061038881768;
                byte[] dummy = eeipClient.GetAttributeSingle(0x01, 1, 1);  // Class 0x01, Instance 1, Attribute 1 (Vendor ID)
                //Console.WriteLine("dummy " + dummy[0].ToString());
                finish = true;

                if (!DataUpdataOk)
                    DataUpdataOk = true;
            }
            catch (CIPException ex)
            {
                Console.WriteLine("CIP " + ex.ToString());
                MainForm.Instance?.writeError("Festo_GetPressure CIP Exception:", $"{ex}");   // ✅
                // Form1.Error_Log.Add($"[Festo_GetPressure CIP Exception]: {ex.ToString()}");
            }
            catch (Exception ex)
			{
                Console.WriteLine(ex.ToString());
                MainForm.Instance?.writeError("Festo_GetPressure Exception:", $"{ex}");   // ✅

               // Form1.Error_Log.Add($"[Festo_GetPressure Exception]: {ex.ToString()}");
                ForwardOpen();
            }


             return finish;
        }

        public void ForwardOpen()
		{            
            eeipClient.ForwardClose();            
            eeipClient.UnRegisterSession();           
            Thread.Sleep(20);
            eeipClient.RegisterSession();           
            eeipClient.ForwardOpen();
            Console.WriteLine("[ForwardOpen]: " + DateTime.Now);
            MainForm.Instance?.writeError("ForwardOpen", $"ForwardOpen");   // ✅

           // Form1.Error_Log.Add("[ForwardOpen]");
        }

        public void WriteData()
        {
            //while (true)
            {
                //eeipClient.O_T_IOData[0] = (byte)(eeipClient.O_T_IOData[0] + 1);
                //eeipClient.O_T_IOData[1] = (byte)(eeipClient.O_T_IOData[1] - 1);
                //eeipClient.O_T_IOData[2] = 1;
                //eeipClient.O_T_IOData[3] = 8;

                eeipClient.O_T_IOData[0] = 5;


                System.Threading.Thread.Sleep(500);

            }
        }

        public void Close()
		{
            eeipClient.ForwardClose();
            eeipClient.UnRegisterSession();
            
            
		}

    }
}
