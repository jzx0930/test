﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Module_Interface;

namespace LaserProcess_LCH
{
    public partial class MainForm
    {
        //DI
        private const string _monitorEmergencyStop = "急停(EStop)";
        private const string _monitorSystemPower = "動力電源(SystemPower)";
        private const string _monitorCDAPressure = "廠源正壓(CDAPressure)";
        //private const string _monitorClampPressure = "減震器正壓(ClampPressure)";
        private const string _monitorChuckVacuum = "載台真空(ChuckVacuum)";
        private const string _monitorDoorSafety = "維修門檢(DoorSafety)";
        private const string _monitorDoorLock = "電子門鎖(DoorLock)";
        private const string _monitorDustCollect = "集塵機(DustCollector)";
        //private const string _monitorScannerWaterFlowHi = "ScannerWaterFlowHi";
        //private const string _monitorScannerWaterFlowLo = "ScannerWaterFlowLo";
        private const string _monitorN2Pressure = "氮氣壓力(N2Pressure)";
        private const string _monitorScannerWater = "振鏡冷水機(ScannerWater)";
        private const string _monitorScannerWaterF = "振鏡冷水機流量(ScannerWaterF)";
        private const string _monitorScannerWaterT = "振鏡冷水機溫度(ScannerWaterT)";
        //private const string _monitorWaterLeakage = "LeakageSensor";
        private const string _monitorDustcoverOpenStop = "Powermeter防塵蓋開(DustcoverOpenStop)";
        private const string _monitorDustcoverCloseStop = "Powermeter防塵蓋關(DustcoverCloseStop)";

        //DO
        private const string _controlRedLight = "紅燈(RedLight)";
        private const string _controlYellowLight = "黃燈(YellowLight)";
        private const string _controlGreenLight = "綠燈(GreenLight)";
        private const string _controlBuzzer = "警報音(Buzzer)";
        //private const string _controlDisableChuckVacuum = "DisableChuckVacuum";
        private const string _controlDoorLock = "電子門鎖開關(DoorLock)";
        private const string _controlDustCollect = "集塵機開關(DustCollector)";
        private const string _controlProcessGasSwitch = "氮氣磁閥開關(ProcessGasSwitch)";
        private const string _controlDustcover = "Powermeter吹正壓(Dustcover)";
        private const string _controlDustcoverVacuum = "Powermeter防塵蓋開合(DustcoverVacuum)";


        private UInt64 _IOCard_LastDIState;
        private UInt64 _IOCard_DIState;
        private const UInt64 _IOCard_InitialDIState = 3119; // = 1111 0100 0011 0000
        /// <summary>
        /// 初始化 IO 控制模組的輸出狀態，
        /// 包含燈號、蜂鳴器、門鎖、集塵器等設備的初始 DO 設定。
        /// </summary>
        /// <remarks>
        /// 此方法在系統啟動階段執行，僅當 IO 卡模組處於 <see cref="SteadyState.Ready"/> 狀態時才進行初始化，
        /// 主要用途為設定各項數位輸出（DO）設備的預設狀態，確保系統進入穩定、安全的初始條件。
        ///
        /// 初始化內容包括：
        /// <list type="bullet">
        ///   <item>紅燈、黃燈、綠燈：預設全部開啟（true），表示系統啟動中</item>
        ///   <item>蜂鳴器、門鎖、集塵器：預設關閉（false），避免誤觸</item>
        ///   <item>製程氣體開關、集塵罩、真空吸附：依安全邏輯設定初始值</item>
        /// </list>
        ///
        /// 同時建立 <see cref="_lastLEDLight"/> 狀態物件，記錄 LED 燈號的邏輯狀態（預設皆為 false），
        /// 並透過 <see cref="writeEvent"/> 方法記錄初始化完成事件以供系統日誌追蹤。
        ///
        /// 此方法為 IO 控制模組的啟動入口，確保所有外部設備在系統啟動時處於可控且安全的狀態。
        /// </remarks>

        private void IOControl_Initialize()
        {
            // Skip the initialization if IOCard didn't enable
            if (!_IOCard.GetState().Equals(SteadyState.Ready))
                return;

            // Initialize DO setting
            _IOCard.writeDO(_IOCard._doDic[_controlRedLight], true);
            _IOCard.writeDO(_IOCard._doDic[_controlYellowLight], true);
            _IOCard.writeDO(_IOCard._doDic[_controlGreenLight], true);
            _IOCard.writeDO(_IOCard._doDic[_controlBuzzer], false);
            _IOCard.writeDO(_IOCard._doDic[_controlDoorLock], false);
            _IOCard.writeDO(_IOCard._doDic[_controlDustCollect], false);
            //_IOCard.writeDO(_IOCard._doDic[_controlDisableChuckVacuum], true);
            _IOCard.writeDO(_IOCard._doDic[_controlProcessGasSwitch], false);
            _IOCard.writeDO(_IOCard._doDic[_controlDustcover], true);
            _IOCard.writeDO(_IOCard._doDic[_controlDustcoverVacuum], false);

            //  Initialize LEDLight
            _lastLEDLight = new LEDLight();
            _lastLEDLight.Red = false;
            _lastLEDLight.Yellow = false;
            _lastLEDLight.Green = false;

            // Write Event Log
            writeEvent("MainForm.IOControl", "IOControl initialized!");
        }

        #region Private Method

        private void controlDO(string controlName, bool enable)
        {
            int channel = _IOCard._doDic[controlName];
            _IOCard.writeDO(channel, enable);
        }

        private bool getChannelBool(int channel, UInt64 diState)
        {
            bool result = false;
            UInt64 mask = 1;
            mask <<= channel;
            UInt64 state = diState & mask;
            if (state == 1)
                result = true;
            return result;
        }

        #endregion

        #region GUI Control Method

        private delegate void dUpdatePnlWithBool(Panel panel, bool enable);
        private void UpdateDIPnlBackColor(Panel panel, bool flag)
        {
            if (panel.InvokeRequired)
            {
                var func = new dUpdatePnlWithBool(UpdateDIPnlBackColor);
                panel.Invoke(func, panel, flag);
            }
            else
            {
                if (flag)
                    //panel.BackColor = Color.LightGreen;
                    panel.BackColor = Color.Green;
                else
                    //panel.BackColor = Color.DarkGreen;
                    panel.BackColor = Color.DarkGray;
            }
        }

        #endregion

        #region Event Handler

        private void HandleDIInterrupt(object sender, int channelInterrupt, UInt64 diState)
        {
            _IOCard_DIState = diState;
            string diName = _IOCard._diDic[channelInterrupt];
            bool enable = getChannelBool(channelInterrupt, diState);
            if (diName == _monitorEmergencyStop)
            {
                if (enable)
                {
                    writeEvent("IOCard", "EmergencyStop Tripped.");
                    writeError("MainForm.IOControl", "EmergencyStop Tripped.");
                    setEmergencyStopLock();
                }
                else
                {
                    writeEvent("IOCard", "EmergencyStop Released.");
                }
            }
            if (diName == _monitorChuckVacuum)
            {
                if (enable)
                {
                    writeEvent("IOCard", "Chuck Activated.");
                }
                else
                {
                    writeEvent("IOCard", "Chuck Deactivated.");
                }
                UpdateDIPnlBackColor(pnl_AutoMode_Chuck_Status, enable);
            }
            if (diName == _monitorDoorLock)
            {
                if (enable)
                {
                    writeEvent("IOCard", "DoorLock Activated.");
                }
                else
                {
                    writeEvent("IOCard", "DoorLock Activated.");
                }
                UpdateDIPnlBackColor(pnl_AutoMode_LockDoor_Status, enable);
            }
        }

        #endregion
    }
}
