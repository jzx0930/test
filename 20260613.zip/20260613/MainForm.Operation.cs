﻿using System;

using System.IO;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;
using ConfocalLaser_Interface;
using Aerotech.A3200.Status;
using System.Diagnostics;
using NCScriptParser_Interface;
using static NCScriptParser_Interface.NCScriptParser;
using System.Text.RegularExpressions;

namespace LaserProcess_LCH
{
    public partial class MainForm
    {
        private void operation_setting_Click(object sender, EventArgs e)
        {
            #region 抽屜
           
                // ⭐ 只在開啟時指定方向（這邊可根據不同按鈕傳入不同方向）
                currentDirection = DrawerDirection.Bottom;

                InitDrawerPosition();         // 移到起始位置
                gb__operation_setting.Visible = true;
                StartDrawerSlideIn();
          
          
            #endregion 

            btn_AutoMode_SelectFile.Enabled = false;
            _NCParser.operation_setting_flag = false;
            gb__operation_setting.Visible = true;
            operation_setting.Visible = false;
            operation_closed.Visible = true;
            lb_operation_setting5.BackColor = Color.LightCoral;
            lb_operation_setting5.Text = "未設置完成";


            int W = 380, H = 280;
            listBox_operation_setting1.MinimumSize = new Size(150, 250);
            listBox_operation_setting1.Size = new Size(W, H);
            listBox_operation_setting1.MaximumSize = new Size(600, 800);
            listBox_operation_setting1.AutoSize = false;
            listBox_operation_setting2.MinimumSize = new Size(150, 250);
            listBox_operation_setting2.Size = new Size(W, H);
            listBox_operation_setting2.MaximumSize = new Size(600, 800);
            listBox_operation_setting2.AutoSize = false;
            //[BM:自訂Log紀錄內容-指定起始加工位置-開始設定]
            if (_AutoProcessLog_flag)
                writeEventLog_Automatic_processing($"指定加工起始項目", $"開始設定");
        }

        private void operation_closed_Click(object sender, EventArgs e)
        {
            #region 抽屜
            StartDrawerSlideOut();       // 用之前記錄的 currentDirection 回縮
            #endregion

            btn_AutoMode_SelectFile.Enabled = true;
            _NCParser.operation_setting_flag = false;
           // gb__operation_setting.Visible = false;

            listBox_operation_setting1.Items.Clear();
            listBox_operation_setting2.Items.Clear();
            txt_AutoMode_operation_setting_LotMumber.Text = "";
            listBox_operation_setting1.Enabled = true;
            operation_setting.Visible = true;
            operation_closed.Visible = false;
            lb_operation_setting5.BackColor = Color.LightCoral;
            lb_operation_setting5.Text = "未設置完成";
            //[BM:自訂Log紀錄內容-指定起始加工位置-取消設定]
            if (_AutoProcessLog_flag)
                writeEventLog_Automatic_processing($"指定加工起始項目", $"取消設定");
        }

        private void btn_AutoMode_operation_setting_SelectFile_Click(object sender, EventArgs e)
        {
            //[BM:自訂Log紀錄內容-指定起始加工位置-選擇加工檔]
            if (_AutoProcessLog_flag)
                writeEventLog_Automatic_processing($"指定加工起始項目", $"選擇加工檔");

            writeEvent("UserEvent", "Select Process File.");

            chk_Distance.Checked = false;
            OpenFileDialog_NC.InitialDirectory = _NCParser._InitialDirectory;
            OpenFileDialog_NC.DefaultExt = "mlproj";
            OpenFileDialog_NC.Filter = "project files (*.mlproj)|*.mlproj";
            if (OpenFileDialog_NC.ShowDialog() == DialogResult.OK)
            {
                operation_setting_rest.Visible = true;
                try
                {

                    string fileName = OpenFileDialog_NC.FileName;
                    int index1 = fileName.LastIndexOf('\\');
                    int index2 = fileName.LastIndexOf('.');

                    char[] projectDir = new char[index1];
                    // Get project directory
                    fileName.CopyTo(0, projectDir, 0, projectDir.Length);
                    _NCParser._ProjectDirectory = new string(projectDir);
                    _NCParser._InitialDirectory = new string(projectDir);
                    //[BM:刀具檔讀取通解]//=================================================
                    if (_isSysSimulated)
                    {
                        _ConfigSystem._JobxFolderPath = "C:\\Users\\250319\\Desktop\\job\\LCH_job";//10f電腦自看測試用
                    }
                    string fileName_UDorLD = fileName.Substring(0, index1); // 取得資料夾名稱
                    string patternLD = @"LD\d+(-\d+)?"; // LD + 數字，檢查 "-" 後是否為數字
                    string patternUD = @"UD\d+(-\d+)?"; // UD + 數字，檢查 "-" 後是否為數字

                    Match matchLD = Regex.Match(fileName_UDorLD, patternLD);
                    Match matchUD = Regex.Match(fileName_UDorLD, patternUD);

                    List<string> extractedKeywords = new List<string>();

                    if (matchLD.Success)
                    {
                        extractedKeywords.Add(matchLD.Value); // 加入匹配的 LD 結果
                    }
                    if (matchUD.Success)
                    {
                        extractedKeywords.Add(matchUD.Value); // 加入匹配的 UD 結果
                    }

                    if (extractedKeywords.Count == 0)
                    {
                        MessageBox.Show("確認Case資料夾名稱內具有單一層之名稱");
                        writeError("NC檔轉檔失敗", "轉檔名稱:" + _NCParser._NCName);
                        return;
                    }
                    else if (extractedKeywords.Count > 1)
                    {
                        MessageBox.Show("確認Case資料夾名稱內只有單一層之名稱");
                        writeError("NC檔轉檔失敗", "轉檔名稱:" + _NCParser._NCName);
                        return;
                    }

                    else
                    {
                        if (_isSysSimulated)
                        {
                            _ConfigSystem._JobxFolderPath = Path.Combine(_ConfigSystem._JobxFolderPath, extractedKeywords[0]);
                            _ConfigSystem.WriteIntoIniFile();
                        }
                        else
                        {
                            _ConfigSystem._JobxFolderPath = Path.Combine(_ConfigSystem._JobxFolderPath1, extractedKeywords[0]);
                            _ConfigSystem.WriteIntoIniFile();
                        }
                        string source = Path.Combine(C_Path, "Warmup_File"); // 來源資料夾
                        string destination = _ConfigSystem._JobxFolderPath; // 目標資料夾
                        bool missingFiles = false; // 用於追蹤是否有缺少的檔案
                        List<string> missingFileList = new List<string>(); // 儲存缺少的檔案清單
                        int w = 300, h = 100;//提醒視窗尺寸長寬
                        if (!Directory.Exists(destination))
                        {
                            System.Windows.Forms.Form customMessageBox = new System.Windows.Forms.Form();
                            customMessageBox.Text = "資料夾缺失!!";
                            customMessageBox.Size = new Size(w, h);
                            customMessageBox.FormBorderStyle = FormBorderStyle.FixedDialog; // 固定視窗大小
                            customMessageBox.TopMost = true; // 確保視窗顯示在最前方
                            customMessageBox.Icon = SystemIcons.Warning; // 使用內建警告圖示
                            customMessageBox.StartPosition = FormStartPosition.CenterScreen; // 讓視窗顯示在螢幕中央
                            customMessageBox.MinimumSize = new Size(w, w); // 強制視窗不會小於這個大小
                            RichTextBox richTextBox = new RichTextBox();
                            richTextBox.Dock = DockStyle.Fill;
                            richTextBox.ReadOnly = true;
                            richTextBox.BackColor = Color.White;
                            richTextBox.Font = new Font("微軟正黑體", 12);
                            richTextBox.ForeColor = Color.FromArgb(85, 85, 85);
                            richTextBox.Text = $"LCH_job 資料夾內不存在名為：\n{extractedKeywords[0]}\n之資料夾請手動建立。";
                            // 文字置中 (適用於 `RichTextBox` 需要使用 RTF 設定)
                            richTextBox.SelectAll();
                            richTextBox.SelectionAlignment = HorizontalAlignment.Center;
                            // 確保 extractedKeywords[0] 顯示為紅色
                            int keywordPosition = richTextBox.Text.IndexOf(extractedKeywords[0]);
                            if (keywordPosition >= 0)
                            {
                                richTextBox.Select(keywordPosition, extractedKeywords[0].Length);
                                richTextBox.SelectionColor = Color.Red;
                                richTextBox.SelectionLength = 0;
                            }
                            customMessageBox.Controls.Add(richTextBox);
                            customMessageBox.ShowDialog();
                            return;
                        }

                        // 檢查來源資料夾內的所有檔案是否存在於目標資料夾
                        foreach (string file1 in Directory.GetFiles(source))
                        {
                            string destFile = Path.Combine(destination, Path.GetFileName(file1)); // 取得目標完整路徑

                            if (!File.Exists(destFile)) // 如果目標資料夾內沒有該檔案
                            {
                                missingFiles = true;
                                missingFileList.Add(Path.GetFileName(file1)); // 只存檔案名稱
                            }
                        }

                        if (missingFiles)
                        {
                            string missingFilesText = string.Join("\r", missingFileList); // 將缺少的檔案合併成一個字串
                            System.Windows.Forms.Form customMessageBox = new System.Windows.Forms.Form();
                            customMessageBox.Text = "檔案缺失提醒!!";
                            customMessageBox.Size = new Size(w + 600, h + 600);
                            customMessageBox.FormBorderStyle = FormBorderStyle.FixedDialog; // 固定視窗大小
                            customMessageBox.TopMost = true; // 確保視窗顯示在最前方
                            customMessageBox.Icon = SystemIcons.Warning; // 使用內建警告圖示
                            customMessageBox.StartPosition = FormStartPosition.CenterScreen;  //讓視窗顯示在螢幕中央
                            customMessageBox.MinimumSize = new Size(w, w); // 強制視窗不會小於這個大小
                            RichTextBox richTextBox = new RichTextBox();
                            richTextBox.Dock = DockStyle.Fill;
                            richTextBox.ReadOnly = true;
                            richTextBox.BackColor = Color.White;
                            richTextBox.Font = new Font("微軟正黑體", 12);
                            richTextBox.ForeColor = Color.FromArgb(85, 85, 85);
                            richTextBox.Text = $"{extractedKeywords[0]} 資料夾內缺少以下暖機檔案：\n{missingFilesText}\n請手動建立。"; // 文字置中 (適用於 `RichTextBox` 需要使用 RTF 設定)
                            richTextBox.SelectAll();
                            richTextBox.SelectionAlignment = HorizontalAlignment.Center;
                            richTextBox.DeselectAll(); // 取消所有選取狀態
                            customMessageBox.Controls.Add(richTextBox);
                            customMessageBox.ShowDialog();
                            return;
                        }
                    }
                    //=================================================
                    char[] file = new char[fileName.Length - index1 - 1 - OpenFileDialog_NC.DefaultExt.Length - 1];
                    // Get NC file name
                    fileName.CopyTo(index1 + 1, file, 0, file.Length);
                    _NCParser._NCName = new string(file);

                    // Display NC file name
                    txt_AutoMode_operation_setting_LotMumber.Text = _NCParser._NCName;

                    // Reset step status
                    _stepFlags[(int)Step.s1] = false;
                    updatePnlStepState(pnl_AutoMode_LoadFile_Status, StepState.inactive);
                    updatePnlStepState(pnl_AutoMode_MoveZ_Status, StepState.inactive);
                    updatePnlStepState(pnl_AutoMode_OrgPoint_Status, StepState.inactive);
                    //[BM:不放開吸附功能，狀態顯示不會放開(所有程式只有UI介面的取消吸附才可以解除吸附)]
                    //updatePnlStepState(pnl_AutoMode_Chuck_Status, StepState.inactive);

                    //解析NC檔為 研發手動NC檔模式 chk_RD_NCfile.Checked
                    _NCParser.RD_NCfile = chk_RD_NCfile.Checked;

                    // Load file and parse parameters
                    _NCParser.ParseData_operation_setting();

                    listBox_operation_setting1.Items.Clear();  //清空 ListBox
                    for (int t = 0; t < _NCParser._Op_Execute.Length; t++)
                    {
                        listBox_operation_setting1.Items.Add($"第{t}加工項目名稱為:{_NCParser._Op_Note[t]}狀態為{_NCParser._Op_Execute[t]}");
                    }
                    listBox_operation_setting1.TopIndex = listBox_operation_setting1.Items.Count - 1;

                   operation_setting_progress.Animation = 1000;
                    operation_setting_progress.Value = 0.5f; // 用來限制進度值不超出 0~1 範圍;


                    if (_isSysSimulated)
                    {
                      
                        return;
                    }
                       

                    _NCParser.WriteIntoIniFile();  // Write InitialDirectory back to the.ini file

                    _formNCParser = new FormNCParser(_NCParser);  // Do Data Parsing

					//if (_isSysSimulated)
                    //{
                    //    btn_AutoMode_ViewFile.Enabled = true;
                    //    btn_AutoMode_ViewFile.Visible = true;
                    //    _FormNCScriptparser = new NCScriptparser.Form();
                    //    _FormNCScriptparser.Show();
                    //    return;
                    //}

                    // Start Step Check Timer with checkAutoModeProgress
                    autoMode_StartStepWithTimer(Step.s1);

                    // No need to check
                    _stepTimers[(int)Step.s1].Set();

                    // Update GUI Control
                    btn_AutoMode_ViewFile.Enabled = true;
                    updatePnlStepState(pnl_AutoMode_LoadFile_Status, StepState.OK);

                    // Enable Load button
					//btn_AutoMode_LoadFile.Enabled = true;

                    //MES LOG批號記錄
                    _CHPT_MES.Batch_Number = txt_AutoMode_LotMumber.Text;
                    _CHPT_MES.Serial_Number = txt_AutoMode_LotMumber.Text;
                    _CHPT_MES.Product_Name = _NCParser._NCName;
                    _CHPT_MES.Laser_Process_File = fileName;
                    _CHPT_MES.Laser_Pos_File = fileName;


                    //Write Event
                    writeEvent("UserEvent", "加工轉檔路徑： " + OpenFileDialog_NC.FileName);

                    // Write Process
                    writeProcess("Step1", "檔案已選擇載入");

                    //[BM:自訂Log紀錄內容-指定起始加工位置-檔案載入成功]
                    if (_AutoProcessLog_flag)
                        writeEventLog_Automatic_processing($"指定加工起始項目", $"檔案載入成功");

                }
                catch (Exception ex)  // 捕捉所有異常
                {
                    MessageBox.Show($"錯誤訊息: {ex.Message}", "Error！！"); // 顯示具體的錯誤訊息
                    writeError("NC檔轉檔失敗", $"轉檔名稱： {_NCParser._NCName}\n錯誤詳細: {ex.Message}");  // 記錄錯誤日誌
                    //[BM:自訂Log紀錄內容-指定起始加工位置-NC檔轉檔失敗]
                    if (_AutoProcessLog_flag)
                        writeEventLog_Automatic_processing($"指定加工起始項目", $"NC檔轉檔失敗:{ex}");

                    return;
                }
            }
        }

        private void operation_setting_rest_Click(object sender, EventArgs e)
        {
            operation_setting_rest.Visible = false;
            _NCParser.operation_setting_flag = false;
            listBox_operation_setting1.Items.Clear();
            listBox_operation_setting2.Items.Clear();
            txt_AutoMode_operation_setting_LotMumber.Text = "";
            listBox_operation_setting1.Enabled = true;
            lb_operation_setting5.BackColor = Color.LightCoral;
            lb_operation_setting5.Text = "未設置完成";
            //[BM:自訂Log紀錄內容-指定起始加工位置-重置按鈕已按下]
            if (_AutoProcessLog_flag)
                writeEventLog_Automatic_processing($"指定加工起始項目", $"重置按鈕已按下");

			operation_setting_progress.Animation = 200;
            operation_setting_progress.Value = Math.Max(0f, Math.Min(1f, 0)); // 用來限制進度值不超出 0~1 範圍;

        }
        private void listBox_operation_setting1_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (listBox_operation_setting1.SelectedIndex != -1) // 確保有選擇項目
            {
                //[BM:自訂Log紀錄內容-指定起始加工位置-開始指定加工起始項目]
                if (_AutoProcessLog_flag)
                    writeEventLog_Automatic_processing($"指定加工起始項目", $"開始指定加工起始項目");

                int number = 0;
                string edge = _NCParser._Op_Note[_NCParser._Op_Note.Length - 1];
                string others = _NCParser._Op_Note[_NCParser._Op_Note.Length - 2];
                string LAM_GH = _NCParser._Op_Note[_NCParser._Op_Note.Length - 3];
                string GH = _NCParser._Op_Note[_NCParser._Op_Note.Length - 4];
                string OpreationLable = "";
                Match match = Regex.Match(listBox_operation_setting1.SelectedItem.ToString(), @"\d+"); // 提取第一組數字
                if (match.Success)
                {
                    number = Convert.ToInt32(match.Value);
                }
                DialogResult result = MessageBox.Show($"是否指定第: {number} 項為啟始加工項", "確認選擇", MessageBoxButtons.OKCancel);
 				if (_AutoProcessLog_flag)
                    writeEventLog_Automatic_processing("指定加工啟始位置", $"起始項目為{number}{_NCParser._Op_Note[number]}");

                if (result == DialogResult.OK)
                {
                    #region 指定起始加工位置
                    if (number >= 0 && number < _NCParser._Op_Execute2.Length)
                    {
                        for (int i = 0; i < number; i++)
                        {
                            _NCParser._Op_Execute2[i] = false;
                        }
                    }
                    else
                    {
                        MessageBox.Show("輸入的數字超出範圍，請重新輸入");
                    }

                    for (int t = 0; t < _NCParser._Op_Execute.Length; t++)
                    {
                        if (_NCParser._Op_Execute2[t] == true)
                            listBox_operation_setting2.Items.Add($"第{t}加工項目名稱為:{_NCParser._Op_Note[t]}狀態為{_NCParser._Op_Execute2[t]}");
                    }
                    listBox_operation_setting2.TopIndex = listBox_operation_setting2.Items.Count - 1;
                    listBox_operation_setting1.Enabled = false;

                    _NCParser._Op_Execute = (bool[])_NCParser._Op_Execute2.Clone();
                    _NCParser.operation_setting_flag = true;
                    _NCParser.ParseData_operation_setting();
                    #endregion

                    #region 專案 LCH新增指定步驟加工功能 開發測試工具
                    if (_isSysSimulated)
                    {
                        #region 將微孔以外的工序印在txt中 設計時可視化_NCParser._QueueCmds內容
                        string filePath = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, $"xuan", "Operation", $"任務排程內容.txt");
                        using (StreamWriter writer = new StreamWriter(filePath, false)) // false 代表覆寫舊檔案
                        {
                            foreach (var cmd in _NCParser._QueueCmds)
                            {
                                // 格式化每條命令資訊
                                string listItem = string.Format("Arguments: {0}, CmdModule: {1}, Command: {2}, Else: {3}",
                                    cmd.Arguments, cmd.CmdModule, cmd.Command, cmd.Else);

                                // 寫入到 txt 檔案
                                writer.WriteLine(listItem);
                            }
                        }
                        #endregion

                        #region 裁切_NCParser._QueueCmds內的命令
                        if (listBox_operation_setting1.SelectedItem != null)
                        {
                            string selectedText = listBox_operation_setting1.SelectedItem.ToString();
                            if (selectedText.Contains($"{GH}"))
                            {
                                OpreationLable = $"//--------- Operation {number} ----------";
                            }
                            if (selectedText.Contains($"{LAM_GH}"))
                            {
                                OpreationLable = $"//--------- Operation {number} ----------";
                            }
                            if (selectedText.Contains($"{others}"))
                            {
                                OpreationLable = $"//--------- Operation {number} ----------";
                            }
                            if (selectedText.Contains($"{edge}"))
                            {
                                OpreationLable = $"//--------- Operation {number} ----------";
                            }
                        }
                        if (OpreationLable != "")
                        {
                            List<string> argumentList = new List<string>();//// 創建一個 List 來存儲 Arguments
                            foreach (var cmd in _NCParser._QueueCmds)
                            {
                                string listItem = string.Format("{0}", cmd.Arguments);
                                argumentList.Add(listItem);
                            }

                            int index = argumentList.IndexOf(OpreationLable);
                            if (index != -1)
                            {
                                RemoveQueueCmds(index - 1);
                            }
                            else
                            {
                                MessageBox.Show($"{OpreationLable}不在 argumentList 中，請重置嘗試");
                                return;
                            }
                        }
                        #endregion
                    }
                    #endregion

                    lb_operation_setting5.BackColor = Color.LightGreen;
                    lb_operation_setting5.Text = "已設置完成!!  請繼續STEP2";

                    //[BM:自訂Log紀錄內容-指定起始加工位置-設定完成]
                    if (_AutoProcessLog_flag)
                        writeEventLog_Automatic_processing($"指定加工起始項目", $"設定完成");

                    operation_setting_progress.Value = Math.Max(0f, Math.Min(1f, 100)); // 用來限制進度值不超出 0~1 範圍;
                }
                else if (result == DialogResult.Cancel)
                {
                    MessageBox.Show("請從新選擇起始加工位置");
                }
            }
        }

        #region 專案 LCH新增指定步驟加工功能 開發測試工具
        private void button2_Click(object sender, EventArgs e)//
        {


            RemoveQueueCmds(3); // 刪除索引 3 到 0 的所有元素

        }
        /// <summary>
        /// 刪除 _QueueCmds 從指定索引到 0 的所有元素
        /// </summary>
        /// <param name="index">要刪除的起始索引</param>
        private void RemoveQueueCmds(int index)
        {
            // 先將 Queue 轉換為 List 以便索引訪問
            List<QueueCmd> cmdList = _NCParser._QueueCmds.ToList();

            // 確保索引範圍有效
            if (index >= 0 && index < cmdList.Count)
            {
                // 移除 index 位置到 0 的所有元素
                cmdList.RemoveRange(0, index + 1);

                // 轉換回 Queue
                _NCParser._QueueCmds = new Queue<QueueCmd>(cmdList);
            }

            string filePath = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, $"xuan", "Operation", $"微孔命令以外指令裁剪後.txt");
            using (StreamWriter writer = new StreamWriter(filePath, false)) // false 代表覆寫舊檔案
            {
                foreach (var cmd in _NCParser._QueueCmds)
                {
                    // 格式化每條命令資訊
                    string listItem = string.Format("Arguments: {0}, CmdModule: {1}, Command: {2}, Else: {3}",
                        cmd.Arguments, cmd.CmdModule, cmd.Command, cmd.Else);

                    // 寫入到 txt 檔案
                    writer.WriteLine(listItem);
                }
            }
        }
        #endregion

 	    #region 抽屜
        enum DrawerDirection { Left, Right, Top, Bottom }
        System.Windows.Forms.Timer drawerTimer = new System.Windows.Forms.Timer();
        bool slidingIn = true;
        bool drawerVisible = false;
        DrawerDirection currentDirection = DrawerDirection.Top;
        Point originalPanelPosition;
        private void InitDrawerPosition()
        {
            switch (currentDirection)
            {
                case DrawerDirection.Left:
                    gb__operation_setting.Location = new Point(-gb__operation_setting.Width, originalPanelPosition.Y);
                    break;
                case DrawerDirection.Right:
                    gb__operation_setting.Location = new Point(this.Width, originalPanelPosition.Y);
                    break;
                case DrawerDirection.Top:
                    gb__operation_setting.Location = new Point(originalPanelPosition.X, -gb__operation_setting.Height);
                    break;
                case DrawerDirection.Bottom:
                    gb__operation_setting.Location = new Point(originalPanelPosition.X, this.Height);
                    break;
            }
        }
        private void StartDrawerSlideIn()
        {
            slidingIn = true;
            drawerTimer.Interval = 1;
            drawerTimer.Tick += SlideDrawer;
            drawerTimer.Start();
        }
        private void StartDrawerSlideOut()
        {
            slidingIn = false;
            drawerTimer.Interval = 1;
            drawerTimer.Tick += SlideDrawer;
            drawerTimer.Start();
        }
        private void SlideDrawer(object sender, EventArgs e)
        {
            int step = 20;

            switch (currentDirection)
            {
                case DrawerDirection.Left:
                    if (slidingIn)
                    {
                        if (gb__operation_setting.Left < originalPanelPosition.X)
                            gb__operation_setting.Left += step;
                        else
                            FinishSlide(originalPanelPosition.X, originalPanelPosition.Y);
                    }
                    else
                    {
                        if (gb__operation_setting.Left > -gb__operation_setting.Width)
                            gb__operation_setting.Left -= step;
                        else
                            FinishSlide(-gb__operation_setting.Width, gb__operation_setting.Top, true);
                    }
                    break;

                case DrawerDirection.Right:
                    if (slidingIn)
                    {
                        if (gb__operation_setting.Left > originalPanelPosition.X)
                            gb__operation_setting.Left -= step;
                        else
                            FinishSlide(originalPanelPosition.X, originalPanelPosition.Y);
                    }
                    else
                    {
                        if (gb__operation_setting.Left < this.Width)
                            gb__operation_setting.Left += step;
                        else
                            FinishSlide(this.Width, gb__operation_setting.Top, true);
                    }
                    break;

                case DrawerDirection.Top:
                    if (slidingIn)
                    {
                        if (gb__operation_setting.Top < originalPanelPosition.Y)
                            gb__operation_setting.Top += step;
                        else
                            FinishSlide(originalPanelPosition.X, originalPanelPosition.Y);
                    }
                    else
                    {
                        if (gb__operation_setting.Top > -gb__operation_setting.Height)
                            gb__operation_setting.Top -= step;
                        else
                            FinishSlide(gb__operation_setting.Left, -gb__operation_setting.Height, true);
                    }
                    break;

                case DrawerDirection.Bottom:
                    if (slidingIn)
                    {
                        if (gb__operation_setting.Top > originalPanelPosition.Y)
                            gb__operation_setting.Top -= step;
                        else
                            FinishSlide(originalPanelPosition.X, originalPanelPosition.Y);
                    }
                    else
                    {
                        if (gb__operation_setting.Top < this.Height)
                            gb__operation_setting.Top += step;
                        else
                            FinishSlide(gb__operation_setting.Left, this.Height, true);
                    }
                    break;
            }
        }
        private void FinishSlide(int x, int y, bool hide = false)
        {
            gb__operation_setting.Location = new Point(x, y);
            drawerTimer.Stop();
            drawerTimer.Tick -= SlideDrawer;
            if (hide) gb__operation_setting.Visible = false;
        }
		#endregion

    }
}
