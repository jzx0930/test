﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LaserProcess_LCH
{
    class ConfigProcess : Module_Interface.Module
    {
        private Dictionary<string, string> _iniDic;

        public double _Compensate_DistanceZ;
        public double _Speed_Fast;
        public double _Speed_Feature;
        public double _Speed_GuideHole;
        public double _Speed_LamGH;
        public double _Speed_Others;
        public bool _IsAutoProcessSuspend;
        public int _Suspend_IntervalTime;
        public int _Suspend_TimeToWait;
        public bool _IsAutoProcessHold;
        public int _Hold_IntervalTime;
        public int _Hold_TimeToWait;
        public bool _IsAutoProcessWarmup;
        public int _Warmup_TimeToWait;
        public bool _IsAutoLaserSleep;
        public int _LaserSleep_Count;
        public int _LaserSleep_Time;
        public double _Power_Feature;
        public double _Power_GuideHole;
        public int _Power_LamGH;
        public int _Power_Others;
        public int _Power_DeviationThreshold;
        public string _Sample_JobName;
        public int _Sample_CutLoop;
        public double _Sample_CutLength;
        public double _Sample_CutWidth;
        public double _Sample_OffsetX;
        public double _Sample_OffsetY;
        public LaserParam _LaserParam_Convert;
        public MotionParam _MotionParam_Convert;
        public bool _IsAutoProcessCheckJobx;
        /// <summary>
        /// 配置檔中是否啟用，測高加工前、後比對功能
        /// </summary>
        public bool _IsThickComparison;
        /// <summary>
        /// 加工厚度比對所允許的最大高度誤差範圍，來源為 <see cref="_ConfigProcess._ThickComparison"/> 設定值。
        /// </summary>
        /// <remarks>
        /// 用於判斷 <see cref="_ThickComparison"/> 是否落在容許的正負範圍內：
        /// 超出此範圍視為加工厚度異常，並可能導致急停保護。
        /// </remarks>
        public double _ThickComparison;
        public double _Check_ThickLaserX;
        public double _Check_ThickLaserY;
        public double _Check_ThickLaserZ;

        private static char _seperator = ',';

        public struct LaserParam
        {
            public double Gain;
            public double Offset;
        }

        public struct MotionParam
        {
            public double Gain;
            public double Offset;
        }

        public ConfigProcess(string name) : base(name)
        {
            // Update _iniDic and private parameters
            _iniDic = this.GetIniDic();
            this.UpdatePublicParams();
        }

        ~ConfigProcess()
        {
            Destruction();
        }

        private void Destruction()
        {
            // Write back ini file
            this.WriteIniFile(_iniDic);
        }

        public void UpdatePublicParams()
        {
            try
            {
                _Compensate_DistanceZ = double.Parse(_iniDic["Compensate_DistanceZ"]);
                _Speed_Fast = double.Parse(_iniDic["Speed_Fast"]);
                _Speed_Feature = double.Parse(_iniDic["Speed_Feature"]);
                _Speed_GuideHole = double.Parse(_iniDic["Speed_GuideHole"]);
                _Speed_LamGH = double.Parse(_iniDic["Speed_LamGH"]);
                _Speed_Others = double.Parse(_iniDic["Speed_Others"]);
                _IsAutoProcessSuspend = Convert.ToBoolean(_iniDic["IsAutoProcessSuspend"]);
                _Suspend_IntervalTime = int.Parse(_iniDic["Suspend_IntervalTime"]);
                _Suspend_TimeToWait = int.Parse(_iniDic["Suspend_TimeToWait"]);
                _IsAutoProcessHold = Convert.ToBoolean(_iniDic["IsAutoProcessHold"]);
                _Hold_IntervalTime = int.Parse(_iniDic["Hold_IntervalTime"]);
                _Hold_TimeToWait = int.Parse(_iniDic["Hold_TimeToWait"]);
                _IsAutoProcessWarmup = Convert.ToBoolean(_iniDic["IsAutoProcessWarmup"]);
                _Warmup_TimeToWait = int.Parse(_iniDic["Warmup_TimeToWait"]);
                _IsAutoLaserSleep = Convert.ToBoolean(_iniDic["IsAutoLaserSleep"]);
                _LaserSleep_Count = int.Parse(_iniDic["LaserSleep_Count"]);
                _LaserSleep_Time = int.Parse(_iniDic["LaserSleep_Time"]);
                _Power_Feature = double.Parse(_iniDic["Power_Feature"]);
                _Power_GuideHole = double.Parse(_iniDic["Power_GuideHole"]);
                _Power_LamGH = int.Parse(_iniDic["Power_LamGH"]);
                _Power_Others = int.Parse(_iniDic["Power_Others"]);
                _Power_DeviationThreshold = int.Parse(_iniDic["Power_DeviationThreshold"]);
                _Sample_JobName = _iniDic["Sample_JobName"];
                _Sample_CutLoop = int.Parse(_iniDic["Sample_CutLoop"]);
                _Sample_CutLength = double.Parse(_iniDic["Sample_CutLength"]);
                _Sample_CutWidth = double.Parse(_iniDic["Sample_CutWidth"]);
                _Sample_OffsetX = double.Parse(_iniDic["Sample_OffsetX"]);
                _Sample_OffsetY = double.Parse(_iniDic["Sample_OffsetY"]);
                _LaserParam_Convert = parseStringToLaserParam(_iniDic["LaserParam_Convert"]);
                _MotionParam_Convert = parseStringToMotionParam(_iniDic["MotionParam_Convert"]);
                _IsAutoProcessCheckJobx = Convert.ToBoolean(_iniDic["IsAutoProcessCheckJobx"]);
                _IsThickComparison = Convert.ToBoolean(_iniDic["IsThickComparison"]);
                _ThickComparison = double.Parse(_iniDic["ThickComparison"]);
                _Check_ThickLaserX = double.Parse(_iniDic["Check_ThickLaserX"]);
                _Check_ThickLaserY = double.Parse(_iniDic["Check_ThickLaserY"]);
                _Check_ThickLaserZ = double.Parse(_iniDic["Check_ThickLaserZ"]);


            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public void WriteIntoIniFile()
        {
            try
            {
                // Update dictionary list
                _iniDic["Compensate_DistanceZ"] = _Compensate_DistanceZ.ToString();
                _iniDic["Speed_Fast"] = _Speed_Fast.ToString();
                _iniDic["Speed_Feature"] = _Speed_Feature.ToString();
                _iniDic["Speed_GuideHole"] = _Speed_GuideHole.ToString();
                _iniDic["Speed_LamGH"] = _Speed_LamGH.ToString();
                _iniDic["Speed_Others"] = _Speed_Others.ToString();
                _iniDic["IsAutoProcessSuspend"] = parseBoolToString(_IsAutoProcessSuspend);
                _iniDic["Suspend_IntervalTime"] = _Suspend_IntervalTime.ToString();
                _iniDic["Suspend_TimeToWait"] = _Suspend_TimeToWait.ToString();
                _iniDic["IsAutoProcessHold"] = parseBoolToString(_IsAutoProcessHold);
                _iniDic["Hold_IntervalTime"] = _Hold_IntervalTime.ToString();
                _iniDic["Hold_TimeToWait"] = _Hold_TimeToWait.ToString();
                _iniDic["IsAutoProcessWarmup"] = parseBoolToString(_IsAutoProcessWarmup);
                _iniDic["Warmup_TimeToWait"] = _Warmup_TimeToWait.ToString();
                _iniDic["IsAutoLaserSleep"] = parseBoolToString(_IsAutoLaserSleep);
                _iniDic["LaserSleep_Count"] = _LaserSleep_Count.ToString();
                _iniDic["LaserSleep_Time"] = _LaserSleep_Time.ToString();
                _iniDic["Power_Feature"] = _Power_Feature.ToString();
                _iniDic["Power_GuideHole"] = _Power_GuideHole.ToString();
                _iniDic["Power_LamGH"] = _Power_LamGH.ToString();
                _iniDic["Power_Others"] = _Power_Others.ToString();
                _iniDic["Power_DeviationThreshold"] = _Power_DeviationThreshold.ToString();
                _iniDic["Sample_JobName"] = _Sample_JobName.ToString();
                _iniDic["Sample_CutLoop"] = _Sample_CutLoop.ToString();
                _iniDic["Sample_CutLength"] = _Sample_CutLength.ToString();
                _iniDic["Sample_CutWidth"] = _Sample_CutWidth.ToString();
                _iniDic["Sample_OffsetX"] = _Sample_OffsetX.ToString();
                _iniDic["Sample_OffsetY"] = _Sample_OffsetY.ToString();
                _iniDic["LaserParam_Convert"] = parseTwoDoubleToString(_LaserParam_Convert.Gain, _LaserParam_Convert.Offset, _seperator);
                _iniDic["MotionParam_Convert"] = parseTwoDoubleToString(_MotionParam_Convert.Gain, _MotionParam_Convert.Offset, _seperator);
                _iniDic["IsAutoProcessCheckJobx"] = parseBoolToString(_IsAutoProcessCheckJobx);
                _iniDic["IsThickComparison"] = parseBoolToString(_IsThickComparison);
                _iniDic["ThickComparison"] = _ThickComparison.ToString();
                _iniDic["Check_ThickLaserX"] = _Check_ThickLaserX.ToString();
                _iniDic["Check_ThickLaserY"] = _Check_ThickLaserY.ToString();
                _iniDic["Check_ThickLaserZ"] = _Check_ThickLaserZ.ToString();

                // Write back ini file
                this.WriteIniFile(_iniDic);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        #region Private Static Method
        private static string parseBoolToString(bool enable)
        {
            if (enable)
                return "True";
            else
                return "False";
        }

        private static string parseTwoDoubleToString(double double1, double double2, char seperator)
        {
            return string.Format("{0}{2}{1}", double1, double2, seperator);
        }

        private static void parseStringToTwoSubString(string data, char seperator, out string string1, out string string2)
        {
            int index = data.IndexOf(seperator);
            if (index != -1)
            {
                char[] char1 = new char[index];
                data.CopyTo(0, char1, 0, index);
                char[] char2 = new char[data.Length - index - 1];
                data.CopyTo(index + 1, char2, 0, data.Length - index - 1);
                string1 = new string(char1).Trim();
                string2 = new string(char2).Trim();
            }
            else
            {
                throw new Exception("Fail to parseStringToTwoSubString.\n" + data);
            }
        }

        private static LaserParam parseStringToLaserParam(string data)
        {
            string sGain, sOffset;
            parseStringToTwoSubString(data, _seperator, out sGain, out sOffset);
            return new LaserParam { Gain = double.Parse(sGain), Offset = double.Parse(sOffset)};
        }

        private static MotionParam parseStringToMotionParam(string data)
        {
            string sGain, sOffset;
            parseStringToTwoSubString(data, _seperator, out sGain, out sOffset);
            return new MotionParam { Gain = double.Parse(sGain), Offset = double.Parse(sOffset) };
        }
        #endregion
    }
}
