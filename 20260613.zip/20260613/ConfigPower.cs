﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LaserProcess_LCH
{/// <summary>
/// 百分比對應mW配置
/// </summary>
    class ConfigPower : Module_Interface.Module
    {
        private Dictionary<string, string> _iniDic;
        private static char _seperator = ',';


        public Dictionary<int, double> _Power_Dict = new Dictionary<int, double>();

        public ConfigPower(string name) : base(name)
        {
            // Update _iniDic and private parameters
            _iniDic = this.GetIniDic();
            this.UpdatePublicParams();
        }

        ~ConfigPower()
        {
            Destruction();
        }

        private void Destruction()
        {
            // Write back ini file
            this.WriteIniFile(_iniDic);
        }

        public void UpdatePublicParams()
        {
            try
            {
                _Power_Dict.Clear(); // 清空舊資料

                for (int i = 1; i <= 20; i++)
                {
                    int percent = i * 5; // 5, 10, 15, ... 100
                    string key = "Percent_" + percent.ToString();

                    if (_iniDic.ContainsKey(key))
                    {
                        double value = double.Parse(_iniDic[key]);
                        _Power_Dict[percent] = value;
                    }
                }


                /*_Position_Processing = parseStringToPosition(_iniDic["Position_Processing"]);
                _Position_Camera = parseStringToPosition(_iniDic["Position_Camera"]);
                _Position_ConfocalLaser = parseStringToPosition(_iniDic["Position_ConfocalLaser"]);
                _Position_FeedIn = parseStringToPosition(_iniDic["Position_FeedIn"]);
                _Position_FeedOut = parseStringToPosition(_iniDic["Position_FeedOut"]);
                _Position_Reserved1 = parseStringToPosition(_iniDic["Position_Reserved1"]);
                _Position_Reserved2 = parseStringToPosition(_iniDic["Position_Reserved2"]);
                _Position_Reserved3 = parseStringToPosition(_iniDic["Position_Reserved3"]);
                _Position_PowerMonitor = parseStringToPosition(_iniDic["Position_PowerMonitor"]);

                _RelPosition_Laser2Camera = parseStringToRelPosition(_iniDic["RelativePosition_Laser2Camera"]);
                _RelPosition_Laser2ConfocalLaser = parseStringToRelPosition(_iniDic["RelativePosition_Laser2ConfocalLaser"]);

                _Height_Equip = parseStringToHeight(_iniDic["Height_Equip"]);

                _SWLimit_X = parseStringToSafetyThreshold(_iniDic["SafetyThreshold_SWLimit_X"]);
                _SWLimit_Y = parseStringToSafetyThreshold(_iniDic["SafetyThreshold_SWLimit_Y"]);
                _SWLimit_Z = parseStringToSafetyThreshold(_iniDic["SafetyThreshold_SWLimit_Z"]);

                _ProcessLimit_X = parseStringToSafetyThreshold(_iniDic["SafetyThreshold_ProcessLimit_X"]);
                _ProcessLimit_Y = parseStringToSafetyThreshold(_iniDic["SafetyThreshold_ProcessLimit_Y"]);
                _ProcessLimit_Z = parseStringToSafetyThreshold(_iniDic["SafetyThreshold_ProcessLimit_Z"]);

                _Velocity_Default = parseStringToVelocity(_iniDic["Velocity_Default"]);

                _PowerCalibration = parseStringToPowerCalibration(_iniDic["PowerCalibration"]);
                _RotationCalibration = parseStringToRotationCalibration(_iniDic["RotationCalibration"]);

                _PositionX = parseStringToPositionX(_iniDic["Position_SetOrg_X"]);
                _PositionY = parseStringToPositionY(_iniDic["Position_SetOrg_Y"]);
                _OrgPoint = parseStringToOrgPoint(_iniDic["Position_OrgPoint"]);*/
            }
            catch (Exception ex)
            {
                Console.WriteLine("UpdatePublicParams error: " + ex.Message);
            }
        }

        /* private Position parseStringToPosition(string data)
         {
             string sX, sY, sZ;
             parseStringToThreeSubString(data, _seperator, out sX, out sY, out sZ);
             return new Position { X = double.Parse(sX), Y = double.Parse(sY), Z = double.Parse(sZ) };
         }

         private RelPosition parseStringToRelPosition(string data)
         {
             string sX, sY;
             parseStringToTwoSubString(data, _seperator, out sX, out sY);
             return new RelPosition { X = double.Parse(sX), Y = double.Parse(sY) };
         }

         private SafetyThreshold parseStringToSafetyThreshold(string data)
         {
             string sLow, sHigh;
             parseStringToTwoSubString(data, _seperator, out sLow, out sHigh);
             return new SafetyThreshold { Low = double.Parse(sLow), High = double.Parse(sHigh) };
         }

         private PowerCalibration parseStringToPowerCalibration(string data)
         {
             string sGain, sOffset, sCutoff;
             parseStringToThreeSubString(data, _seperator, out sGain, out sOffset, out sCutoff);
             return new PowerCalibration { Gain = double.Parse(sGain), Offset = double.Parse(sOffset), Cutoff = double.Parse(sCutoff) };
         }

         private RotationCalibration parseStringToRotationCalibration(string data)
         {
             string sGain, sOffset;
             parseStringToTwoSubString(data, _seperator, out sGain, out sOffset);
             return new RotationCalibration { Gain = double.Parse(sGain), Offset = double.Parse(sOffset) };
         }

         private PositionX parseStringToPositionX(string data)
         {
             string sLeft, sRight;
             parseStringToTwoSubString(data, _seperator, out sLeft, out sRight);
             return new PositionX { Left = double.Parse(sLeft), Right = double.Parse(sRight) };
         }

         private PositionY parseStringToPositionY(string data)
         {
             string sDown, sUp;
             parseStringToTwoSubString(data, _seperator, out sDown, out sUp);
             return new PositionY { Down = double.Parse(sDown), Up = double.Parse(sUp) };
         }

         private OrgPoint parseStringToOrgPoint(string data)
         {
             string sX, sY;
             parseStringToTwoSubString(data, _seperator, out sX, out sY);
             return new OrgPoint { X = double.Parse(sX), Y = double.Parse(sY) };
         }

         private Height parseStringToHeight(string data)
         {
             string sLaser, sCamera, sConfocalLaser;
             parseStringToThreeSubString(data, _seperator, out sLaser, out sCamera, out sConfocalLaser);
             return new Height { Laser = double.Parse(sLaser), Camera = double.Parse(sCamera), ConfocalLaser = double.Parse(sConfocalLaser) };
         }

         private Velocity parseStringToVelocity(string data)
         {
             string sX, sY, sZ;
             parseStringToThreeSubString(data, _seperator, out sX, out sY, out sZ);
             return new Velocity { X = double.Parse(sX), Y = double.Parse(sY), Z = double.Parse(sZ) };
         }
        */
        /*public void WriteIntoIniFile()
        {
            try
            {
                // Update dictionary list
                _iniDic["Position_Processing"] = parseThreeDoubleToString(_Position_Processing.X, _Position_Processing.Y, _Position_Processing.Z, _seperator);
                _iniDic["Position_Camera"] = parseThreeDoubleToString(_Position_Camera.X, _Position_Camera.Y, _Position_Camera.Z, _seperator);
                _iniDic["Position_ConfocalLaser"] = parseThreeDoubleToString(_Position_ConfocalLaser.X, _Position_ConfocalLaser.Y, _Position_ConfocalLaser.Z, _seperator);
                _iniDic["Position_FeedIn"] = parseThreeDoubleToString(_Position_FeedIn.X, _Position_FeedIn.Y, _Position_FeedIn.Z, _seperator);
                _iniDic["Position_FeedOut"] = parseThreeDoubleToString(_Position_FeedOut.X, _Position_FeedOut.Y, _Position_FeedOut.Z, _seperator);
                _iniDic["Position_Reserved1"] = parseThreeDoubleToString(_Position_Reserved1.X, _Position_Reserved1.Y, _Position_Reserved1.Z, _seperator);
                _iniDic["Position_Reserved2"] = parseThreeDoubleToString(_Position_Reserved2.X, _Position_Reserved2.Y, _Position_Reserved2.Z, _seperator);
                _iniDic["Position_Reserved3"] = parseThreeDoubleToString(_Position_Reserved3.X, _Position_Reserved3.Y, _Position_Reserved3.Z, _seperator);
                _iniDic["Position_PowerMonitor"] = parseThreeDoubleToString(_Position_PowerMonitor.X, _Position_PowerMonitor.Y, _Position_PowerMonitor.Z, _seperator);

                _iniDic["RelativePosition_Laser2Camera"] = parseTwoDoubleToString(_RelPosition_Laser2Camera.X, _RelPosition_Laser2Camera.Y, _seperator);
                _iniDic["RelativePosition_Laser2ConfocalLaser"] = parseTwoDoubleToString(_RelPosition_Laser2ConfocalLaser.X, _RelPosition_Laser2ConfocalLaser.Y, _seperator);

                _iniDic["Height_Equip"] = parseThreeDoubleToString(_Height_Equip.Laser, _Height_Equip.Camera, _Height_Equip.ConfocalLaser, _seperator);

                _iniDic["SafetyThreshold_SWLimit_X"] = parseTwoDoubleToString(_SWLimit_X.Low, _SWLimit_X.High, _seperator);
                _iniDic["SafetyThreshold_SWLimit_Y"] = parseTwoDoubleToString(_SWLimit_Y.Low, _SWLimit_Y.High, _seperator);
                _iniDic["SafetyThreshold_SWLimit_Z"] = parseTwoDoubleToString(_SWLimit_Z.Low, _SWLimit_Z.High, _seperator);

                _iniDic["SafetyThreshold_ProcessLimit_X "] = parseTwoDoubleToString(_ProcessLimit_X.Low, _ProcessLimit_X.High, _seperator);
                _iniDic["SafetyThreshold_ProcessLimit_Y"] = parseTwoDoubleToString(_ProcessLimit_Y.Low, _ProcessLimit_Y.High, _seperator);
                _iniDic["SafetyThreshold_ProcessLimit_Z"] = parseTwoDoubleToString(_ProcessLimit_Z.Low, _ProcessLimit_Z.High, _seperator);

                _iniDic["Velocity_Default"] = parseThreeDoubleToString(_Velocity_Default.X, _Velocity_Default.Y, _Velocity_Default.Z, _seperator);

                _iniDic["PowerCalibration"] = parseThreeDoubleToString(_PowerCalibration.Gain, _PowerCalibration.Offset, _PowerCalibration.Cutoff, _seperator);
                _iniDic["RotationCalibration"] = parseTwoDoubleToString(_RotationCalibration.Gain, _RotationCalibration.Offset, _seperator);

                _iniDic["Position_SetOrg_X"] = parseTwoDoubleToString(_PositionX.Left, _PositionX.Right, _seperator);
                _iniDic["Position_SetOrg_Y"] = parseTwoDoubleToString(_PositionY.Down, _PositionY.Up, _seperator);
                _iniDic["Position_OrgPoint"] = parseTwoDoubleToString(_OrgPoint.X, _OrgPoint.Y, _seperator);
                // Write back ini file
                this.WriteIniFile(_iniDic);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        #region Private Static Method
        private static string parseTwoDoubleToString(double double1, double double2, char seperator)
        {
            return string.Format("{0}{2}{1}", double1, double2, seperator);
        }

        private static string parseThreeDoubleToString(double double1, double double2, double double3, char seperator)
        {
            return string.Format("{0}{3}{1}{3}{2}", double1, double2, double3, seperator);
        }

        private static void parseStringToTwoSubString(string data, char seperator, out string string1, out string string2)
        {
            int index = data.IndexOf(seperator);
            if (index != -1)
            {
                char[] char1 = new char[index];
                data.CopyTo(0, char1, 0, index);
                char[] char2 = new char[data.Length - index - 1];
                data.CopyTo(index + 1, char2, 0, data.Length - index - 1);
                string1 = new string(char1).Trim();
                string2 = new string(char2).Trim();
            }
            else
            {
                throw new Exception("Fail to parseStringToTwoSubString.\n" + data);
            }
        }

        private static void parseStringToThreeSubString(string data, char seperator, out string string1, out string string2, out string string3)
        {
            int index = data.IndexOf(seperator);
            if (index != -1)
            {
                char[] char1 = new char[index];
                data.CopyTo(0, char1, 0, index);
                char[] residue = new char[data.Length - index - 1];
                data.CopyTo(index + 1, residue, 0, data.Length - index - 1);
                string sResidue = new string(residue).Trim();
                index = sResidue.IndexOf(',');
                if (index != -1)
                {
                    char[] char2 = new char[index];
                    sResidue.CopyTo(0, char2, 0, index);
                    char[] char3 = new char[sResidue.Length - index - 1];
                    sResidue.CopyTo(index + 1, char3, 0, sResidue.Length - index - 1);
                    string1 = new string(char1).Trim();
                    string2 = new string(char2).Trim();
                    string3 = new string(char3).Trim();
                }
                else
                {
                    throw new Exception("Fail to parseStringToThreeSubString.\n" + data);
                }
            }
            else
            {
                throw new Exception("Fail to parseStringToThreeSubString.\n" + data);
            }
        }
        #endregion*/
    }

}
