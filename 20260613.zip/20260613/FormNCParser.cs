﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using NCScriptParser_Interface;

namespace LaserProcess_LCH
{
    public partial class FormNCParser : Form
    {
        public NCScriptParser_Interface.NCScriptParser data;
        private bool _isInitialized = false;

        public FormNCParser(NCScriptParser parser)
        {
            InitializeComponent();

            data = parser;
        }

        private void FormNCParser_Load(object sender, EventArgs e)
        {
            txt_ProjectFolder.Text = data._ProjectDirectory;
            txt_NCFileName.Text = data._NCName;
            lbl_NCFile.Text = data._NCName + ".nc";

            // Display DrillDataSet.csv
            int count = data._DDS_FileHeader.Length;
            DataGridViewTextBoxColumn[] dataGridViewCols = new DataGridViewTextBoxColumn[count];
            for (int i = 0; i < count; i++)
            {
                dataGridViewCols[i] = new DataGridViewTextBoxColumn();
                dataGridViewCols[i].HeaderText = data._DDS_FileHeader[i];
                dataGridView_DDS.Columns.Add(dataGridViewCols[i]);
            }

            for (int i = 0; i < data._DDS_RowCount; i++)
            {
                object[] values1 = { i + 1, data._DDS_LoadData[i], data._DDS_FilePath[i], data._DDS_ArrayName[i], data._DDS_NbrOfFeature[i], data._DDS_ZProbe[i], data._DDS_ZprobePositionX[i], data._DDS_ZprobePositionY[i], data._DDS_ScanheadFilePath[i], data._DDS_LaserPower[i], data._DDS_LaserDivider[i] };
                dataGridView_DDS.Rows.Add(values1);
            }

            // Update FeatureSelection ComboBox
            foreach (var name in data._DDS_ArrayName)
            {
                cmb_FeatureSelection.Items.Add(name);
            }
            cmb_FeatureSelection.Text = data._DDS_ArrayName[0];
            
            // Display Feature.csv
            count = 3;
            dataGridViewCols = new DataGridViewTextBoxColumn[count];
            string[] headerNames2 = { "Index", "PositionX", "PositionY" };
            int[] columnWidth2 = { 60, 120, 120 };
            for (int i = 0; i < count; i++)
            {
                dataGridViewCols[i] = new DataGridViewTextBoxColumn();
                dataGridViewCols[i].HeaderText = headerNames2[i];
                dataGridViewCols[i].Width = columnWidth2[i];
                dataGridView_Feature.Columns.Add(dataGridViewCols[i]);
            }
            count = 4;
            dataGridViewCols = new DataGridViewTextBoxColumn[count];
            headerNames2 = new string[] { "Index", "PositionX", "PositionY", "Type" };
            columnWidth2 = new int[] { 60, 120, 120, 60 };
            for (int i = 0; i < count; i++)
            {
                dataGridViewCols[i] = new DataGridViewTextBoxColumn();
                dataGridViewCols[i].HeaderText = headerNames2[i];
                dataGridViewCols[i].Width = columnWidth2[i];
                dataGridView_NewFeature.Columns.Add(dataGridViewCols[i]);
            }

            int currentIndex = 0;
            txt_NumberOfFeature.Text = data._DDS_NbrOfFeature[currentIndex].ToString();
            for (int i = 0; i < data._DDS_NbrOfFeature[currentIndex]; i++)
            {
                object[] values2 = { i + 1, data._DrillFeatures[currentIndex, i].X, data._DrillFeatures[currentIndex, i].Y };
                dataGridView_Feature.Rows.Add(values2);
            }
            for (int i = 0; i < data._NewDrillFeatures.Length; i++)
            {
                object[] values2 = { i + 1, data._NewDrillFeatures[i].X, data._NewDrillFeatures[i].Y, data._NewDrillFeatures[i].Type };
                dataGridView_NewFeature.Rows.Add(values2);
            }

            // Display NC Code
            txt_NCCode.Text = data._NCCode;
            txt_NCCode_HashCode.Text = string.Format("0x{0:X8}", data._NC_HashCode);

            // Display DrillDataSet.csv
            count = data._Op_FileHeader.Length;
            dataGridViewCols = new DataGridViewTextBoxColumn[count];
            for (int i = 0; i < count; i++)
            {
                dataGridViewCols[i] = new DataGridViewTextBoxColumn();
                dataGridViewCols[i].HeaderText = data._Op_FileHeader[i];
                dataGridView_Op.Columns.Add(dataGridViewCols[i]);
            }

            for (int i = 0; i < data._Op_RowCount; i++)
            {
                object[] values3 = { i + 1, data._Op_Execute[i], data._Op_Status[i], data._Op_LaserParamSet[i], data._Op_MotionParamSet[i], data._Op_Offset[i], data._Op_CutRepeat[i], data._Op_Probe[i] };
                dataGridView_Op.Rows.Add(values3);
            }

            // Display GuideHole.Positions
            txt_NbrOfGuideHole.Text = data._GuideHole_NbrOfData.ToString();
            string[] col6 = { "Index", "ProcessPosition", "StartCP", "LoopCP", "EndCP" };
            int[] columnWidth6 = { 60, 150, 200, 200, 200 };
            count = col6.Length;
            dataGridViewCols = new DataGridViewTextBoxColumn[count];
            for (int i = 0; i < count; i++)
            {
                dataGridViewCols[i] = new DataGridViewTextBoxColumn();
                dataGridViewCols[i].HeaderText = col6[i];
                dataGridViewCols[i].Width = columnWidth6[i];
                dataGridView_GuideHole.Columns.Add(dataGridViewCols[i]);
            }
            count = data._GuideHole_NbrOfData;
            for (int i = 0; i < count; i++)
            {
                string processPos = string.Format("X{0} Y{1}", data._GuideHole_DrillPositionData[i].ProcessPosition.X, data._GuideHole_DrillPositionData[i].ProcessPosition.Y);
                string startCP = string.Format("X{0} Y{1} I{2} J{3}", data._GuideHole_DrillPositionData[i].StartCP.X, data._GuideHole_DrillPositionData[i].StartCP.Y, data._GuideHole_DrillPositionData[i].StartCP.I, data._GuideHole_DrillPositionData[i].StartCP.J);
                string loopCP = string.Format("X{0} Y{1} I{2} J{3}", data._GuideHole_DrillPositionData[i].LoopCP.X, data._GuideHole_DrillPositionData[i].LoopCP.Y, data._GuideHole_DrillPositionData[i].LoopCP.I, data._GuideHole_DrillPositionData[i].LoopCP.J);
                string endCP = string.Format("X{0} Y{1} I{2} J{3}", data._GuideHole_DrillPositionData[i].EndCP.X, data._GuideHole_DrillPositionData[i].EndCP.Y, data._GuideHole_DrillPositionData[i].EndCP.I, data._GuideHole_DrillPositionData[i].EndCP.J);
                object[] values4 = { i + 1, processPos, startCP, loopCP, endCP };
                dataGridView_GuideHole.Rows.Add(values4);
            }

            // Display LamGH.Positions
            txt_NbrOfLamGH.Text = data._LamGH_NbrOfData.ToString();
            string[] col7 = { "Index", "FirstPosition", "SecondPosition", "ProcessPosition", "StartCP", "LoopPosition", "EndCP" };
            int[] columnWidth7 = { 60, 120, 120, 120, 200, 120, 200 };
            count = col7.Length;
            dataGridViewCols = new DataGridViewTextBoxColumn[count];
            for (int i = 0; i < count; i++)
            {
                dataGridViewCols[i] = new DataGridViewTextBoxColumn();
                dataGridViewCols[i].HeaderText = col7[i];
                dataGridViewCols[i].Width = columnWidth7[i];
                dataGridView_LamGH.Columns.Add(dataGridViewCols[i]);
            }
            count = data._LamGH_NbrOfData;
            if (count > 0)
            {
                // Update CutSelection ComboBox
                for (int i = 0; i < data._LamGH_NbrOfData; i++)
                {
                    cmb_LamGHSelection.Items.Add(i + 1);
                }
                cmb_LamGHSelection.Text = "1";

                // Update First Page of LamGH.Position
                //FirstPosition(1) + SecondPosition(1) + ProcessPosition(1) + StartCP(1) + LoopPosition(N) + EndCP(1)
                int index_LamGH = 1;
                currentIndex = 0;
                string sFirstPosition_LamGH = string.Format("X{0} Y{1}", data._LamGH_PositionData[currentIndex].FirstPosition.X, data._LamGH_PositionData[currentIndex].FirstPosition.Y);
                object[] oFirstPosition_LamGH = { index_LamGH++, sFirstPosition_LamGH };
                dataGridView_LamGH.Rows.Add(oFirstPosition_LamGH);
                string sSecondPosition_LamGH = string.Format("X{0} Y{1}", data._LamGH_PositionData[currentIndex].SecondPosition.X, data._LamGH_PositionData[currentIndex].SecondPosition.Y);
                object[] oSecondPosition_LamGH = { index_LamGH++, "", sSecondPosition_LamGH };
                dataGridView_LamGH.Rows.Add(oSecondPosition_LamGH);
                string sProcessPosition_LamGH = string.Format("X{0} Y{1}", data._LamGH_PositionData[currentIndex].ProcessPosition.X, data._LamGH_PositionData[currentIndex].ProcessPosition.Y);
                object[] oProcessPosition_LamGH = { index_LamGH++, "", "", sProcessPosition_LamGH };
                dataGridView_LamGH.Rows.Add(oProcessPosition_LamGH);
                string sStartCP_LamGH = string.Format("X{0} Y{1} I{2} J{3}", data._LamGH_PositionData[currentIndex].StartCP.X, data._LamGH_PositionData[currentIndex].StartCP.Y, data._LamGH_PositionData[currentIndex].StartCP.I, data._LamGH_PositionData[currentIndex].StartCP.J);
                object[] oStartCP_LamGH = { index_LamGH++, "", "", "", sStartCP_LamGH };
                dataGridView_LamGH.Rows.Add(oStartCP_LamGH);
                for (int i = 0; i < data._LamGH_PositionData[currentIndex].LoopPosition.Length; i++)
                {
                    string sLoopPosition = string.Format("X{0} Y{1}", data._LamGH_PositionData[currentIndex].LoopPosition[i].X, data._LamGH_PositionData[currentIndex].LoopPosition[i].Y);
                    object[] oLoopPosition = { index_LamGH++, "", "", "", "", sLoopPosition };
                    dataGridView_LamGH.Rows.Add(oLoopPosition);
                }
                string sEndCP_LamGH = string.Format("X{0} Y{1} I{2} J{3}", data._LamGH_PositionData[currentIndex].EndCP.X, data._LamGH_PositionData[currentIndex].EndCP.Y, data._LamGH_PositionData[currentIndex].EndCP.I, data._LamGH_PositionData[currentIndex].EndCP.J);
                object[] oEndCP_LamGH = { index_LamGH++, "", "", "", "", "", sEndCP_LamGH };
                dataGridView_LamGH.Rows.Add(oEndCP_LamGH);
            }

            // Display Others.Positions.Cut
            txt_NbrOfOthers_Cut.Text = data._Others_NbrOfData_Cut.ToString();
            string[] col7_1 = { "Index", "FirstPosition", "ProcessPosition", "StartCP", "LoopPosition", "EndCP" };
            int[] columnWidth7_1 = { 60, 120, 120, 200, 120, 200 };
            count = col7_1.Length;
            dataGridViewCols = new DataGridViewTextBoxColumn[count];
            for (int i = 0; i < count; i++)
            {
                dataGridViewCols[i] = new DataGridViewTextBoxColumn();
                dataGridViewCols[i].HeaderText = col7_1[i];
                dataGridViewCols[i].Width = columnWidth7_1[i];
                dataGridView_Others_Cut.Columns.Add(dataGridViewCols[i]);
            }

            count = data._Others_NbrOfData_Cut;
            if (count > 0)
            {
                // Update CutSelection ComboBox
                for (int i = 0; i < data._Others_NbrOfData_Cut; i++)
                {
                    cmb_CutSelection.Items.Add(i + 1);
                }
                cmb_CutSelection.Text = "1";

                // Update First Page of Others.Positions.Cut
                //FirstPosition(1) + ProcessPosition(1) + StartCP(1) + LoopPosition(N) + EndCP(1)
                int index_Others = 1;
                currentIndex = 0;
                string sFirstPosition_Others = string.Format("X{0} Y{1}", data._Others_CutPositionData[currentIndex].FirstPosition.X, data._Others_CutPositionData[currentIndex].FirstPosition.Y);
                object[] oFirstPosition_Others = { index_Others++, sFirstPosition_Others };
                dataGridView_Others_Cut.Rows.Add(oFirstPosition_Others);
                string sProcessPosition_Others = string.Format("X{0} Y{1}", data._Others_CutPositionData[currentIndex].ProcessPosition.X, data._Others_CutPositionData[currentIndex].ProcessPosition.Y);
                object[] oProcessPosition_Others = { index_Others++, "", sProcessPosition_Others };
                dataGridView_Others_Cut.Rows.Add(oProcessPosition_Others);
                string sStartCP_Others = string.Format("X{0} Y{1} I{2} J{3}", data._Others_CutPositionData[currentIndex].StartCP.X, data._Others_CutPositionData[currentIndex].StartCP.Y, data._Others_CutPositionData[currentIndex].StartCP.I, data._Others_CutPositionData[currentIndex].StartCP.J);
                object[] oStartCP_Others = { index_Others++, "", "", sStartCP_Others };
                dataGridView_Others_Cut.Rows.Add(oStartCP_Others);
                for (int i = 0; i < data._Others_CutPositionData[currentIndex].LoopPosition.Length; i++)
                {
                    string sLoopPosition = string.Format("X{0} Y{1}", data._Others_CutPositionData[currentIndex].LoopPosition[i].X, data._Others_CutPositionData[currentIndex].LoopPosition[i].Y);
                    object[] oLoopPosition = { index_Others++, "", "", "", sLoopPosition };
                    dataGridView_Others_Cut.Rows.Add(oLoopPosition);
                }
                string sEndCP_Others = string.Format("X{0} Y{1} I{2} J{3}", data._Others_CutPositionData[currentIndex].EndCP.X, data._Others_CutPositionData[currentIndex].EndCP.Y, data._Others_CutPositionData[currentIndex].EndCP.I, data._Others_CutPositionData[currentIndex].EndCP.J);
                object[] oEndCP_Others = { index_Others++, "", "", "", "", sEndCP_Others };
                dataGridView_Others_Cut.Rows.Add(oEndCP_Others);
            }

            // Display Others.Positions.Drill
            txt_NbrOfOthers_Drill.Text = data._Others_NbrOfData_Drill.ToString();
            string[] col7_2 = { "Index", "ProcessPosition", "StartCP", "LoopCP", "EndCP" };
            int[] columnWidth7_2 = { 60, 150, 200, 200, 200 };
            count = col7_2.Length;
            dataGridViewCols = new DataGridViewTextBoxColumn[count];
            for (int i = 0; i < count; i++)
            {
                dataGridViewCols[i] = new DataGridViewTextBoxColumn();
                dataGridViewCols[i].HeaderText = col7_2[i];
                dataGridViewCols[i].Width = columnWidth7_2[i];
                dataGridView_Others_Drill.Columns.Add(dataGridViewCols[i]);
            }
            count = data._Others_NbrOfData_Drill;
            for (int i = 0; i < count; i++)
            {
                string processPos = string.Format("X{0} Y{1}", data._Others_DrillPositionData[i].ProcessPosition.X, data._Others_DrillPositionData[i].ProcessPosition.Y);
                string startCP = string.Format("X{0} Y{1} I{2} J{3}", data._Others_DrillPositionData[i].StartCP.X, data._Others_DrillPositionData[i].StartCP.Y, data._Others_DrillPositionData[i].StartCP.I, data._Others_DrillPositionData[i].StartCP.J);
                string loopCP = string.Format("X{0} Y{1} I{2} J{3}", data._Others_DrillPositionData[i].LoopCP.X, data._Others_DrillPositionData[i].LoopCP.Y, data._Others_DrillPositionData[i].LoopCP.I, data._Others_DrillPositionData[i].LoopCP.J);
                string endCP = string.Format("X{0} Y{1} I{2} J{3}", data._Others_DrillPositionData[i].EndCP.X, data._Others_DrillPositionData[i].EndCP.Y, data._Others_DrillPositionData[i].EndCP.I, data._Others_DrillPositionData[i].EndCP.J);
                object[] values5 = { i + 1, processPos, startCP, loopCP, endCP };
                dataGridView_Others_Drill.Rows.Add(values5);
            }

            // Display Edge.Positions
            txt_NbrOfEdge.Text = data._Edge_NbrOfData.ToString();
            string[] col8 = { "Index", "FirstPosition", "ProcessPosition", "StartCP", "LoopPosition", "EndCP" };
            int[] columnWidth8 = { 60, 120, 120, 200, 120, 200 };
            count = col8.Length;
            dataGridViewCols = new DataGridViewTextBoxColumn[count];
            for (int i = 0; i < count; i++)
            {
                dataGridViewCols[i] = new DataGridViewTextBoxColumn();
                dataGridViewCols[i].HeaderText = col8[i];
                dataGridViewCols[i].Width = columnWidth8[i];
                dataGridView_Edge.Columns.Add(dataGridViewCols[i]);
            }
            //FirstPosition(1) + ProcessPosition(1) + StartCP(1) + LoopPosition(N) + EndCP(1)
            int index = 1;
            string sFirstPosition = string.Format("X{0} Y{1}", data._Edge_PositionData.FirstPosition.X, data._Edge_PositionData.FirstPosition.Y);
            object[] oFirstPosition = new object[] { index++, sFirstPosition };
            dataGridView_Edge.Rows.Add(oFirstPosition);
            string sProcessPosition = string.Format("X{0} Y{1}", data._Edge_PositionData.ProcessPosition.X, data._Edge_PositionData.ProcessPosition.Y);
            object[] oProcessPosition = new object[] { index++, "", sProcessPosition };
            dataGridView_Edge.Rows.Add(oProcessPosition);
            string sStartCP = string.Format("X{0} Y{1} I{2} J{3}", data._Edge_PositionData.StartCP.X, data._Edge_PositionData.StartCP.Y, data._Edge_PositionData.StartCP.I, data._Edge_PositionData.StartCP.J );
            object[] oStartCP = new object[] { index++, "", "", sStartCP };
            dataGridView_Edge.Rows.Add(oStartCP);
            for (int i = 0; i < data._Edge_PositionData.LoopPosition.Length; i++)
            {
                string sLoopPosition = string.Format("X{0} Y{1}", data._Edge_PositionData.LoopPosition[i].X, data._Edge_PositionData.LoopPosition[i].Y);
                object[] oLoopPosition = { index++, "", "", "", sLoopPosition };
                dataGridView_Edge.Rows.Add(oLoopPosition);
            }
            string sEndCP = string.Format("X{0} Y{1} I{2} J{3}", data._Edge_PositionData.EndCP.X, data._Edge_PositionData.EndCP.Y, data._Edge_PositionData.EndCP.I, data._Edge_PositionData.EndCP.J);
            object[] oEndCP = new object[] { index++, "", "", "", "", sEndCP };
            dataGridView_Edge.Rows.Add(oEndCP);

            // Display MotionParam
            // CutSpeed & Fastspeed
            count = 3;
            dataGridViewCols = new DataGridViewTextBoxColumn[count];
            string[] col9 = { "Index", "CutSpeed", "FastSpeed" };
            for (int i = 0; i < count; i++)
            {
                dataGridViewCols[i] = new DataGridViewTextBoxColumn();
                dataGridViewCols[i].HeaderText = col9[i];
                dataGridView_MP.Columns.Add(dataGridViewCols[i]);
            }

            for (int i = 0; i < data._MP_RowCount; i++)
            {
                object[] values9 = { i + 1,  data._MP_CutSpeed[i], data._MP_FastSpeed[i] };
                dataGridView_MP.Rows.Add(values9);
            }

            // Display LaserParam
            // Divider, PowerPct, PulseWidth
            count = 4;
            dataGridViewCols = new DataGridViewTextBoxColumn[count];
            string[] col10 = { "Index", "Divider", "Powerpct", "PulseWidth" };
            for (int i = 0; i < count; i++)
            {
                dataGridViewCols[i] = new DataGridViewTextBoxColumn();
                dataGridViewCols[i].HeaderText = col10[i];
                dataGridView_LP.Columns.Add(dataGridViewCols[i]);
            }

            for (int i = 0;  i < data._LP_RowCount; i++)
            {
                object[] values10 = { i + 1, data._LP_Divider[i], data._LP_PowerPct[i], data._LP_PulseWidth[i] };
                dataGridView_LP.Rows.Add(values10);
            }

            // Change the initialization flag
            _isInitialized = true;
        }

        #region GUI Event Method

        private void cmb_FeatureSelection_SelectedValueChanged(object sender, EventArgs e)
        {
            if (!_isInitialized)
                return;

            // Display Feature.csv
            dataGridView_Feature.Rows.Clear();

            int currentIndex = cmb_FeatureSelection.SelectedIndex;
            txt_NumberOfFeature.Text = data._DDS_NbrOfFeature[currentIndex].ToString();
            for (int i = 0; i < data._DDS_NbrOfFeature[currentIndex]; i++)
            {
                object[] values2 = { i + 1, data._DrillFeatures[currentIndex, i].X, data._DrillFeatures[currentIndex, i].Y };
                dataGridView_Feature.Rows.Add(values2);
            }
        }

        private void cmb_CutSelection_SelectedValueChanged(object sender, EventArgs e)
        {
            if (!_isInitialized)
                return;

            // Display Others.Cut
            dataGridView_Others_Cut.Rows.Clear();

            int currentIndex = cmb_CutSelection.SelectedIndex;

            //FirstPosition(1) + ProcessPosition(1) + StartCP(1) + LoopPosition(N) + EndCP(1)
            int index = 1;
            string sFirstPosition = string.Format("X{0} Y{1}", data._Others_CutPositionData[currentIndex].FirstPosition.X, data._Others_CutPositionData[currentIndex].FirstPosition.Y);
            object[] oFirstPosition = { index++, sFirstPosition };
            dataGridView_Others_Cut.Rows.Add(oFirstPosition);
            string sProcessPosition = string.Format("X{0} Y{1}", data._Others_CutPositionData[currentIndex].ProcessPosition.X, data._Others_CutPositionData[currentIndex].ProcessPosition.Y);
            object[] oProcessPosition = { index++, "", sProcessPosition };
            dataGridView_Others_Cut.Rows.Add(oProcessPosition);
            string sStartCP = string.Format("X{0} Y{1} I{2} J{3}", data._Others_CutPositionData[currentIndex].StartCP.X, data._Others_CutPositionData[currentIndex].StartCP.Y, data._Others_CutPositionData[currentIndex].StartCP.I, data._Others_CutPositionData[currentIndex].StartCP.J);
            object[] oStartCP = { index++, "", "", sStartCP };
            dataGridView_Others_Cut.Rows.Add(oStartCP);
            for (int i = 0; i < data._Others_CutPositionData[currentIndex].LoopPosition.Length; i++)
            {
                string sLoopPosition = string.Format("X{0} Y{1}", data._Others_CutPositionData[currentIndex].LoopPosition[i].X, data._Others_CutPositionData[currentIndex].LoopPosition[i].Y);
                object[] oLoopPosition = { index++, "", "", "", sLoopPosition };
                dataGridView_Others_Cut.Rows.Add(oLoopPosition);
            }
            string sEndCP = string.Format("X{0} Y{1} I{2} J{3}", data._Others_CutPositionData[currentIndex].EndCP.X, data._Others_CutPositionData[currentIndex].EndCP.Y, data._Others_CutPositionData[currentIndex].EndCP.I, data._Others_CutPositionData[currentIndex].EndCP.J);
            object[] oEndCP = { index++, "", "", "", "", sEndCP };
            dataGridView_Others_Cut.Rows.Add(oEndCP);
        }

        private void cmb_LamGHSelection_SelectedValueChanged(object sender, EventArgs e)
        {
            if (!_isInitialized)
                return;

            // Display Others.Cut
            dataGridView_LamGH.Rows.Clear();

            int currentIndex = cmb_LamGHSelection.SelectedIndex;

            //FirstPosition(1) + SecondPosition(1) + ProcessPosition(1) + StartCP(1) + LoopPosition(N) + EndCP(1)
            int index_LamGH = 1;
            string sFirstPosition_LamGH = string.Format("X{0} Y{1}", data._LamGH_PositionData[currentIndex].FirstPosition.X, data._LamGH_PositionData[currentIndex].FirstPosition.Y);
            object[] oFirstPosition_LamGH = { index_LamGH++, sFirstPosition_LamGH };
            dataGridView_LamGH.Rows.Add(oFirstPosition_LamGH);
            string sSecondPosition_LamGH = string.Format("X{0} Y{1}", data._LamGH_PositionData[currentIndex].SecondPosition.X, data._LamGH_PositionData[currentIndex].SecondPosition.Y);
            object[] oSecondPosition_LamGH = { index_LamGH++, "", sSecondPosition_LamGH };
            dataGridView_LamGH.Rows.Add(oSecondPosition_LamGH);
            string sProcessPosition_LamGH = string.Format("X{0} Y{1}", data._LamGH_PositionData[currentIndex].ProcessPosition.X, data._LamGH_PositionData[currentIndex].ProcessPosition.Y);
            object[] oProcessPosition_LamGH = { index_LamGH++, "", "", sProcessPosition_LamGH };
            dataGridView_LamGH.Rows.Add(oProcessPosition_LamGH);
            string sStartCP_LamGH = string.Format("X{0} Y{1} I{2} J{3}", data._LamGH_PositionData[currentIndex].StartCP.X, data._LamGH_PositionData[currentIndex].StartCP.Y, data._LamGH_PositionData[currentIndex].StartCP.I, data._LamGH_PositionData[currentIndex].StartCP.J);
            object[] oStartCP_LamGH = { index_LamGH++, "", "", "", sStartCP_LamGH };
            dataGridView_LamGH.Rows.Add(oStartCP_LamGH);
            for (int i = 0; i < data._LamGH_PositionData[currentIndex].LoopPosition.Length; i++)
            {
                string sLoopPosition = string.Format("X{0} Y{1}", data._LamGH_PositionData[currentIndex].LoopPosition[i].X, data._LamGH_PositionData[currentIndex].LoopPosition[i].Y);
                object[] oLoopPosition = { index_LamGH++, "", "", "", "", sLoopPosition };
                dataGridView_LamGH.Rows.Add(oLoopPosition);
            }
            string sEndCP_LamGH = string.Format("X{0} Y{1} I{2} J{3}", data._LamGH_PositionData[currentIndex].EndCP.X, data._LamGH_PositionData[currentIndex].EndCP.Y, data._LamGH_PositionData[currentIndex].EndCP.I, data._LamGH_PositionData[currentIndex].EndCP.J);
            object[] oEndCP_LamGH = { index_LamGH++, "", "", "", "", "", sEndCP_LamGH };
            dataGridView_LamGH.Rows.Add(oEndCP_LamGH);
        }

        #endregion
    }
}
