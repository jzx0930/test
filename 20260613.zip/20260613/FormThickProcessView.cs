﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace LaserProcess_LCH
{
    public partial class FormThickProcessView : Form
    {
        private double[] _compensatePositionX;
        private double[] _compensatePositionY;
        private double[] _compensatePositionHeight;
        private int[] _columnWidths = { 50, 100, 100, 100 };
        private string[] _columnHeaders = { "#", "位置.X(mm)", "位置.Y(mm)", "量測相對高度(um)"};


        public FormThickProcessView(Tuple<double[], double[], double[]> data)
        {
            InitializeComponent();

            _compensatePositionX = data.Item1;
            _compensatePositionY = data.Item2;
            _compensatePositionHeight = data.Item3;
        }
        
        private void FormThickProcessView_Load(object sender, EventArgs e)
        {
            // Initialize the DataGridView header
            dataGridViewHeaderInitialize(dataGridView, _columnWidths, _columnHeaders);

            double compensateOffset = 115;

            // Add the data into DataGridView
            for (int i = 0; i < _compensatePositionHeight.Length; i++)
            {
                double height = (_compensatePositionHeight[i] + -_compensatePositionHeight.Average()) * 1000;
                string sHeight = string.Format("{0:0.#}", height);
                object[] values = { i + 1, _compensatePositionX[i], _compensatePositionY[i], sHeight };

                dataGridView.Rows.Add(values);
            }
        }

        private void dataGridViewHeaderInitialize(DataGridView dataGridView, int[] columnWidths, string[] columnHeaders)
        {
            int count = columnWidths.Length;
            DataGridViewTextBoxColumn[] dataGridViewCols = new DataGridViewTextBoxColumn[count];
            for (int i = 0; i < count; i++)
            {
                dataGridViewCols[i] = new DataGridViewTextBoxColumn();
                dataGridViewCols[i].HeaderText = columnHeaders[i];
                dataGridViewCols[i].Width = columnWidths[i];

                Action<DataGridView, DataGridViewColumn> del = (graph, col) => graph.Columns.Add(col);
                this.Invoke(del, dataGridView, dataGridViewCols[i]);
            }
        }
    }
}
