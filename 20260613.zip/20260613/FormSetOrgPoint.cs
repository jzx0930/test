﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace LaserProcess_LCH
{
    public partial class FormSetOrgPoint : Form
    {
        public delegate void settingUpdateNotifier(object sender, EventArgs e);
        public event settingUpdateNotifier confirmChecked;
        public delegate void settingNotifier(object sender, TupleEventArgs data);
        public event settingNotifier confirmCheck;
        private MainForm _mainFormRef;
        private double pos_X_Left;
        private double pos_X_Right;
        private double pos_Y_Up;
        private double pos_Y_Down;
        private double pos_X_Center;
        private double pos_Y_Center;

        public FormSetOrgPoint(MainForm mainForm)
        {
            InitializeComponent();

            _mainFormRef = mainForm;
        }

        private void FormSetOrgPoint_Load(object sender, EventArgs e)
        {
            // Parse data
            pos_X_Left = _mainFormRef._offset_X_Left;
            pos_X_Right = _mainFormRef._offset_X_Right;
            pos_Y_Up = _mainFormRef._offset_Y_Up;
            pos_Y_Down = _mainFormRef._offset_Y_Down;
            pos_X_Center = _mainFormRef._offset_Center_X;
            pos_Y_Center = _mainFormRef._offset_Center_Y;

            // Update UI
            txt_PositionX_Left.Text = pos_X_Left.ToString("F3");
            txt_PositionX_Right.Text = pos_X_Right.ToString("F3");
            txt_PositionY_Down.Text = pos_Y_Down.ToString("F3");
            txt_PositionY_Up.Text = pos_Y_Up.ToString("F3");
            txt_PositionX_Center.Text = pos_X_Center.ToString("F3");
            txt_PositionY_Center.Text = pos_Y_Center.ToString("F3");
        }

        #region GUI Methods

        private void btn_Set_PositionX_Left_Click(object sender, EventArgs e)
        {
            // Update the position from PositionFeedback
            pos_X_Left = _mainFormRef._positionFeedback[(int)MainForm.MotionAxis.X];
            txt_PositionX_Left.Text = pos_X_Left.ToString("F3");

            if (pos_X_Left != 0 && pos_X_Right != 0)
            {
                pos_X_Center = (pos_X_Left + pos_X_Right) / 2;
                txt_PositionX_Center.Text = pos_X_Center.ToString("F3");
            }
        }

        private void btn_Set_PositionX_Right_Click(object sender, EventArgs e)
        {
            // Update the position from PositionFeedback
            pos_X_Right = _mainFormRef._positionFeedback[(int)MainForm.MotionAxis.X];
            txt_PositionX_Right.Text = pos_X_Right.ToString("F3");

            if (pos_X_Left != 0 && pos_X_Right != 0)
            {
                pos_X_Center = (pos_X_Left + pos_X_Right) / 2;
                txt_PositionX_Center.Text = pos_X_Center.ToString("F3");
            }
        }

        private void btn_Set_PositionY_Down_Click(object sender, EventArgs e)
        {
            // Update the position from PositionFeedback
            pos_Y_Down = _mainFormRef._positionFeedback[(int)MainForm.MotionAxis.Y];
            txt_PositionY_Down.Text = pos_Y_Down.ToString("F3");

            if (pos_Y_Down != 0 && pos_Y_Up != 0)
            {
                pos_Y_Center = (pos_Y_Down + pos_Y_Up) / 2;
                txt_PositionY_Center.Text = pos_Y_Center.ToString("F3");
            }
        }

        private void btn_Set_PositionY_Up_Click(object sender, EventArgs e)
        {
            // Update the position from PositionFeedback
            pos_Y_Up = _mainFormRef._positionFeedback[(int)MainForm.MotionAxis.Y];
            txt_PositionY_Up.Text = pos_Y_Up.ToString("F3");

            if (pos_Y_Down != 0 && pos_Y_Up != 0)
            {
                pos_Y_Center = (pos_Y_Down + pos_Y_Up) / 2;
                txt_PositionY_Center.Text = pos_Y_Center.ToString("F3");
            }
        }

        private void btn_Confirm_Click(object sender, EventArgs e)
        {
            // Update the setting
            _mainFormRef._offset_X_Left = pos_X_Left;
            _mainFormRef._offset_X_Right = pos_X_Right;
            _mainFormRef._offset_Y_Up = pos_Y_Up;
            _mainFormRef._offset_Y_Down = pos_Y_Down;
            _mainFormRef._offset_Center_X = pos_X_Center;
            _mainFormRef._offset_Center_Y = pos_Y_Center;

            // Send the notifier
            //confirmChecked?.Invoke(this, null);
            TupleEventArgs eventArgs = new TupleEventArgs(Tuple.Create(pos_X_Left, pos_X_Right, pos_Y_Up, pos_Y_Down, pos_X_Center, pos_Y_Center));
            confirmCheck?.Invoke(this, eventArgs);

            this.Close();
        }

        private void btn_Cancel_Click(object sender, EventArgs e)
        {
            // Quit without setting
            this.Close();
        }

        #endregion
    }

    public class TupleEventArgs : EventArgs
    {
        public Tuple<double, double, double, double, double, double> Data { get; set; }
        public TupleEventArgs(Tuple<double, double, double, double, double, double> data)
        {
            Data = data;
        }
    }
}
