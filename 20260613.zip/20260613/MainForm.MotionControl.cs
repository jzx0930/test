﻿using System;
using System.Windows.Forms;
using Aerotech.A3200;
using Aerotech.A3200.Exceptions;
using Aerotech.A3200.Status;
using Aerotech.A3200.Variables;
using Aerotech.A3200.Tasks;
using Aerotech.A3200.Information;
using Aerotech.Common;
using Aerotech.Common.Collections;
using System.Drawing;
using System.Linq;
using System.Threading;
using System.ComponentModel;
using Module_Interface;
using ConfocalLaser_Interface;

namespace LaserProcess_LCH
{
    public partial class MainForm
    {
        public enum MotionAxis //Base on LC2 design
        {
            X,
            Y,
            Z
        }
        private enum MainState
        {
            Disconnect,
            Connect,
            OK,
            NO,
            Progress
        };
        private enum SyncMotionType
        {
            Default,
            RapidMove,
            RapidMoveTo
        }
        private struct SyncMotionObject
        {
            public SyncMotionType Type;
            public object Object;
        }
        private struct RapidMoveObject
        {
            public int[] AxisIndexes;
            public double[] Distances;
            public double[] Speeds;
        }
        private struct RapidMoveToObject
        {
            public double X;
            public double Y;
            public double Z;
            public double FeedSpeed;
        }
        private static string[] sMotionSpeed = { "1", "5", "10", "20", "50" };

        private MotionAxis[] _MotionAxisAll;
        private int[] _iMotionAxisAll;
        private Controller _MC_Controller;  //MC stands for MotionControl

        private bool[] _isSWTripped, _isHoming, _isHomed, _isEnabled, _isInPosition, _isLimitP, _isLimitN;
        /// <summary>
        ///目前軸的即時回饋位置（實際值）
        /// </summary>
        public double[] _positionFeedback;
        public double[] _positionCommand;
        private bool _areSWTripped, _areHomed, _areEnabled, _areInPosition;
        private bool _isSWHiTripped = false;
        private bool _isSWLoTripped = false;
        private const double _fallBackDistance = 5; //Unit: mm

        /// <summary>
        /// Initialize MotionControl variables
        /// Homing all
        /// Set safety interlock
        /// for following application
        /// </summary>
        /// /// <summary>
        /// 初始化運動控制模組的變數與狀態，
        /// 包含軸狀態陣列建立、速度選項設定、伺服啟用與軟體原點清除等流程。
        /// </summary>
        /// <remarks>
        /// 此方法在系統啟動階段執行，為運動控制模組建立必要的狀態陣列與 UI 控制項內容，
        /// 並根據系統是否為模擬模式與設定檔 <see cref="_ConfigSystem._ConnectSetting.MotionControl"/> 決定是否執行連線與啟用伺服。
        ///
        /// 初始化內容包括：
        /// <list type="bullet">
        ///   <item>更新主狀態圖示為 <c>Disconnect</c>，表示尚未連線</item>
        ///   <item>建立 X/Y/Z 軸的狀態陣列（如是否 Homing、是否啟用、是否到位等）</item>
        ///   <item>將預設速度選項加入 UI ComboBox，並設定初始值</item>
        ///   <item>若為模擬模式（<c>_isSysSimulated</c>），則跳過硬體初始化</item>
        ///   <item>若設定允許，則自動執行 <c>btn_Connect_Click</c> 進行模組連線</item>
        ///   <item>啟用所有軸的伺服（Servo On）</item>
        ///   <item>執行 G82 指令以清除軟體原點</item>
        /// </list>
        ///
        /// 最後透過 <see cref="writeEvent"/> 方法記錄初始化完成事件，
        /// 此方法為運動控制模組進入操作階段前的必要準備流程。
        /// </remarks>

        private void MotionControl_Initialize()
        {
            // Update Motion Main Status
            updateMainStatusImage(MainState.Disconnect);

            _MotionAxisAll = new MotionAxis[] { MotionAxis.X, MotionAxis.Y, MotionAxis.Z };
            _iMotionAxisAll = new int[] { (int)MotionAxis.X, (int)MotionAxis.Y, (int)MotionAxis.Z };
            _isSWTripped = new bool[_MotionAxisAll.Length];
            _isHoming = new bool[_MotionAxisAll.Length];
            _isHomed = new bool[_MotionAxisAll.Length];
            _isEnabled = new bool[_MotionAxisAll.Length];
            _isInPosition = new bool[_MotionAxisAll.Length];
            _isLimitP = new bool[_MotionAxisAll.Length];
            _isLimitN = new bool[_MotionAxisAll.Length];
            _positionCommand = new double[_MotionAxisAll.Length];
            _positionFeedback = new double[_MotionAxisAll.Length];
            _areSWTripped = false;
            _areHomed = false;
            _areEnabled = false;
            _areInPosition = false;

            foreach (var motionSpeed in sMotionSpeed)
            {
                UpdateCmbAddItem(cmb_Motion_Speed_X, motionSpeed);
                UpdateCmbAddItem(cmb_Motion_Speed_Y, motionSpeed);
                UpdateCmbAddItem(cmb_Motion_Speed_Z, motionSpeed);
            }

            updateControlTxtWithString(cmb_Motion_Speed_X, sMotionSpeed[2]);
            updateControlTxtWithString(cmb_Motion_Speed_Y, sMotionSpeed[2]);
            updateControlTxtWithString(cmb_Motion_Speed_Z, sMotionSpeed[2]);

            //Skip if isSimulated
            if (_isSysSimulated)
                return;

            // Do auto-connection if ConnectSetting enable
            if (_ConfigSystem._ConnectSetting.MotionControl)
                btn_Connect_Click("Initialization", null);

            // Enable Servo On
            foreach (var axisIndex in _iMotionAxisAll)
            {
                // Do AxesEnable
                _MotionControl.AxesEnable(axisIndex, true);
            }

            // Clear Software origin
            string code = "G82";
            executeGCode(code);

            // Write Event Log
            writeEvent("MainForm.MotionControl", "MotionControl initialized!");
        }
        /// <summary>
        /// 停用運動控制模組，
        /// 在系統非模擬模式且模組處於就緒狀態時執行斷線操作。
        /// </summary>
        /// <remarks>
        /// 此方法在系統解除初始化或關閉階段執行，
        /// 用於釋放運動控制模組的資源並安全中斷與控制器的連線。
        ///
        /// 執行邏輯如下：
        /// <list type="bullet">
        ///   <item>若系統為模擬模式（<c>_isSysSimulated</c>），則跳過斷線流程</item>
        ///   <item>若運動控制模組狀態為 <see cref="SteadyState.Ready"/>，表示已連線且可操作，則呼叫 <c>btn_Disconnect_Click</c> 執行斷線</item>
        /// </list>
        ///
        /// 此方法確保在系統關閉前，運動控制模組能正確釋放資源與中斷通訊，
        /// 避免殘留連線或未釋放的控制權造成設備異常。
        /// </remarks>

        private void MotionControl_Deinitialize()
        {
            //Skip if isSimulated
            if (_isSysSimulated)
                return;

            if (_MotionControl.GetState().Equals(SteadyState.Ready))
                this.btn_Disconnect_Click(this, null);
        }

        #region GUI Control Method

        private delegate void dEnableGUIMotionControls(bool enable);
        /// <summary>
        /// Enable Motion Controls
        /// </summary>
        private void EnableGUIMotionControls(bool enable)
        {
            if (group_AxisStatus.InvokeRequired)
            {
                var func = new dEnableGUIMotionControls(EnableGUIMotionControls);
                this.Invoke(func, enable);
            }
            else
            {
                this.group_AxisStatus.Enabled = enable;
                this.group_PositionSpeed.Enabled = enable;
                this.group_Movement.Enabled = enable;
                this.group_MoveTo.Enabled = enable;
                this.group_ManualMode.Enabled = enable;
                this.group_AutoMode_Step1.Enabled = enable;
                this.group_AutoMode_Step3.Enabled = enable;
                this.group_AutoMode_Step4.Enabled = enable;
                this.group_AutoMode_Step2.Enabled = enable;
                this.group_AutoMode_Step5.Enabled = enable;
                this.group_AutoMode_Step6.Enabled = enable;
                this.btn_AutoMode_Process_Start.Enabled = enable;
                //[BM:即停-即停後 流程重置也被禁用]
                this.btn_AutoMode_Reset.Enabled = enable;

                //小樣微孔
                this.group_SampleMatrix_Step1.Enabled = enable;
                this.group_SampleMatrix_Step2.Enabled = enable;
                this.group_SampleMatrix_Step3.Enabled = enable;
                this.group_SampleMatrix_Step4.Enabled = enable;
                this.group_SampleMatrix_Step5.Enabled = enable;
                this.group_SampleMatrix_Step6.Enabled = enable;
                //this.group_SampleMatrix_Step7.Enabled = enable;
                //小樣GH
                this.group_GHSampleMatrix_Step1.Enabled = enable;
                this.group_GHSampleMatrix_Step2.Enabled = enable;
                this.group_GHSampleMatrix_Step3.Enabled = enable;
                this.group_GHSampleMatrix_Step4.Enabled = enable;
                this.group_GHSampleMatrix_Step5.Enabled = enable;
                this.group_GHSampleMatrix_Step6.Enabled = enable;
                //this.group_GHSampleMatrix_Step7.Enabled = enable;


            }
        }

        private void UpdateDiagPacket(NewDiagPacketArrivedEventArgs e)
        {
            //Invoke GUI update
            this.Invoke(new dUpdateMotionControlGUI(UpdateMotionControlGUI));

            // Check SW Limits only after all homed
            if (_areHomed)
            {
                foreach (int motionAxis in _iMotionAxisAll)
                {
                    // Only Homing can be executed during SW Limits tripped
                    if (!_isHoming[motionAxis] && !_isSWTripped[motionAxis])
                    {
                        try
                        {
                            checkSWLimits(motionAxis, _positionFeedback[motionAxis]);
                        }
                        catch (Exception ex)
                        {
                            abortMotion(_iMotionAxisAll);

                            if (_isSWHiTripped || _isSWLoTripped)
                            {
                                // Fallback to specified distance
                                double position = _positionFeedback[motionAxis];
                                double distance = _fallBackDistance;
                                if (_isSWHiTripped)
                                {
                                    distance = -1 * distance;
                                }
                                double speed = 10;
                                switch (motionAxis)
                                {
                                    case (int)MotionAxis.X:
                                        speed = _ConfigEquip._Velocity_Default.X;
                                        break;
                                    case (int)MotionAxis.Y:
                                        speed = _ConfigEquip._Velocity_Default.Y;
                                        break;
                                    case (int)MotionAxis.Z:
                                        speed = _ConfigEquip._Velocity_Default.Z;
                                        break;
                                    default:
                                        throw new Exception("Unknown motionAxis!");
                                }
                                
                                // Without delay, MoveAbs was skipped?
                                Thread.Sleep(100);
                                _MotionControl.MoveAbs(motionAxis, position + distance, speed);

                                // Wait in position
                                int[] axisIndexes = { motionAxis };
                                waitMotionDone(axisIndexes, 10000);
                                _isSWLoTripped = false;
                                _isSWHiTripped = false;
                            }
                            
                            _isSWTripped[motionAxis] = true;

                            // Write Error
                            writeError("MainForm.MotionControl", "SoftwareLimits interlock tripped, trigger Abort." + ex);
                            setSafetyInterlock();

                        }
                    }
                }
            }
        }

        private delegate void dUpdateMotionControlGUI();
        private void UpdateMotionControlGUI()
        {
            // Update GUI Controls
            // Update Homing
            UpdateHomingColor(btn_Motion_Homing_X, _isHoming[(int)MotionAxis.X]);
            UpdateHomingColor(btn_Motion_Homing_Y, _isHoming[(int)MotionAxis.Y]);
            UpdateHomingColor(btn_Motion_Homing_Z, _isHoming[(int)MotionAxis.Z]);
            // Update Homed
            UpdateHomedTxtText(txt_Motion_MotorStatus_X, _isHomed[(int)MotionAxis.X]);
            UpdateHomedTxtText(txt_Motion_MotorStatus_Y, _isHomed[(int)MotionAxis.Y]);
            UpdateHomedTxtText(txt_Motion_MotorStatus_Z, _isHomed[(int)MotionAxis.Z]);
            // Update Servo Enabled
            UpdateEnableTxtBackColorChkChecked(txt_Motion_MotorStatus_X, chk_Motion_Enable_X, _isEnabled[(int)MotionAxis.X]);
            UpdateEnableTxtBackColorChkChecked(txt_Motion_MotorStatus_Y, chk_Motion_Enable_Y, _isEnabled[(int)MotionAxis.Y]);
            UpdateEnableTxtBackColorChkChecked(txt_Motion_MotorStatus_Z, chk_Motion_Enable_Z, _isEnabled[(int)MotionAxis.Z]);
            // Update InPosition
            UpdateInPositionPnlBackColorLblText(pnl_Motion_Status_X, lbl_Motion_Status_X, _isInPosition[(int)MotionAxis.X], _isEnabled[(int)MotionAxis.X]);
            UpdateInPositionPnlBackColorLblText(pnl_Motion_Status_Y, lbl_Motion_Status_Y, _isInPosition[(int)MotionAxis.Y], _isEnabled[(int)MotionAxis.Y]);
            UpdateInPositionPnlBackColorLblText(pnl_Motion_Status_Z, lbl_Motion_Status_Z, _isInPosition[(int)MotionAxis.Z], _isEnabled[(int)MotionAxis.Z]);
            // Update Limit Positive & Negative
            UpdateLimitPnlBackColor(pnl_Motion_LimitN_X, _isLimitN[(int)MotionAxis.X]);
            UpdateLimitPnlBackColor(pnl_Motion_LimitN_Y, _isLimitN[(int)MotionAxis.Y]);
            UpdateLimitPnlBackColor(pnl_Motion_LimitN_Z, _isLimitN[(int)MotionAxis.Z]);
            UpdateLimitPnlBackColor(pnl_Motion_LimitP_X, _isLimitP[(int)MotionAxis.X]);
            UpdateLimitPnlBackColor(pnl_Motion_LimitP_Y, _isLimitP[(int)MotionAxis.Y]);
            UpdateLimitPnlBackColor(pnl_Motion_LimitP_Z, _isLimitP[(int)MotionAxis.Z]);
            // Update Positions
            txt_Motion_CmdPosition_X.Text = _positionCommand[(int)MotionAxis.X].ToString("F3");
            txt_Motion_CmdPosition_Y.Text = _positionCommand[(int)MotionAxis.Y].ToString("F3");
            txt_Motion_CmdPosition_Z.Text = _positionCommand[(int)MotionAxis.Z].ToString("F3");
            txt_Motion_Position_X.Text = _positionFeedback[(int)MotionAxis.X].ToString("F3");
            txt_Motion_Position_Y.Text = _positionFeedback[(int)MotionAxis.Y].ToString("F3");
            txt_Motion_Position_Z.Text = _positionFeedback[(int)MotionAxis.Z].ToString("F3");
        }

        private void UpdateHomingColor(Button button, bool flag)
        {
            if (flag)
                button.BackColor = Color.LawnGreen;
            else
                button.BackColor = Color.Silver;
        }

        private void UpdateHomedTxtText(TextBox textBox, bool flag)
        {
            if (flag)
                textBox.Text = "Home";
            else
                textBox.Text = "";
        }

        private void UpdateEnableTxtBackColorChkChecked(TextBox textBox, CheckBox checkBox, bool flag)
        {
            if (flag)
                textBox.BackColor = Color.Green;
            else
                textBox.BackColor = Color.Red;

            // Unregister the event handler before changing its CheckedState
            // Do register after the change completed.
            checkBox.CheckStateChanged -= this.chk_Motion_Enable_CheckedChanged;
            checkBox.Checked = flag;
            checkBox.CheckStateChanged += this.chk_Motion_Enable_CheckedChanged;
        }

        private void UpdateInPositionPnlBackColorLblText(Panel panel, Label label, bool flag, bool enable)
        {
            if (flag)
            {
                panel.BackColor = Color.Green;
                label.Text = "待機中";
            }
            else
            {
                panel.BackColor = Color.Red;
                if (enable)
                    label.Text = "移動中";
                else
                    label.Text = "OFF";
            }
        }

        private void UpdateLimitPnlBackColor(Panel panel, bool flag)
        {
            if (flag)
                panel.BackColor = Color.Red;
            else
                panel.BackColor = Color.Gray;
        }

        private delegate void dUpdateCmbWithString(ComboBox comboBox, string item);
        private void UpdateCmbAddItem(ComboBox comboBox, string item)
        {
            if (comboBox.InvokeRequired)
            {
                var func = new dUpdateCmbWithString(UpdateCmbAddItem);
                comboBox.Invoke(func, comboBox, item);
            }
            else
            {
                comboBox.Items.Add(item);
            }
        }

        private delegate void dUpdateMainStatusImage(MainState state);
        private void updateMainStatusImage(MainState state)
        {
            if (pnl_Motion_Main_Status.InvokeRequired)
            {
                var func = new dUpdateMainStatusImage(updateMainStatusImage);
                pnl_Motion_Main_Status.Invoke(func, state);
            }
            else
            {
                string path = C_Path + "\\images\\" + state + ".png";
                Image temp = Image.FromFile(path);
                Bitmap bitmap = Module_Interface.ImageHandler.ResizeImage(temp, pnl_Motion_Main_Status.Width, pnl_Motion_Main_Status.Height);
                pnl_Motion_Main_Status.BackgroundImage = bitmap;
            }
        }

        #endregion

        #region GUI Event Method

        private void btn_Connect_Click(object sender, EventArgs e)
        {
            pn_LCNcontrol.Visible = false;

            //Write Event
            writeEvent("UserEvent", "MotionControl Connect");

            //Skip if isSimulated
            if (_isSysSimulated)
                return;

            _MotionControl.Connect();

            _MotionControl.Initialize();

            // Consign controller after connection
            _MC_Controller = _MotionControl.GetController();

            // register task state and diagPackect arrived events
            //_MC_Controller.ControlCenter.TaskStates.NewTaskStatesArrived += new EventHandler<NewTaskStatesArrivedEventArgs>(TaskStates_NewTaskStatesArrived);
            _MC_Controller.ControlCenter.Diagnostics.NewDiagPacketArrived += new EventHandler<NewDiagPacketArrivedEventArgs>(Diagnostics_NewDiagPacketArrived);

            // Set the G code mode to Absolute mode
            string code = "G90";
            executeGCode(code);

            // Enable GUI Controls
            //EnableGUIMotionControls(true);

            // Disable UI control
            enableUIGroup(true);

            // Update Motion Main Status
            updateMainStatusImage(MainState.Connect);
        }

        private void btn_Disconnect_Click(object sender, EventArgs e)
        {
            //Write Event
            writeEvent("UserEvent", "MotionControl Disconnect");

            //Skip if isSimulated
            if (_isSysSimulated)
                return;

            // Unregister task state and diagPackect arrived events
            _MC_Controller.ControlCenter.Diagnostics.NewDiagPacketArrived -= new EventHandler<NewDiagPacketArrivedEventArgs>(Diagnostics_NewDiagPacketArrived);

            _MotionControl.Deinitialize();

            _MotionControl.Close();

            // Disable GUI Controls
            //EnableGUIMotionControls(false);

            // Disable UI control
            enableUIGroup(false);

            // Update Motion Main Status
            updateMainStatusImage(MainState.Disconnect);
        }

        private void btn_Motion_Servo_ALL_Click(object sender, EventArgs e)
        {
            bool enable = !_areEnabled;

            //Write Event
            if (enable)
                writeEvent("UserEvent", "ServoOn All");
            else
                writeEvent("UserEvent", "ServoOff All");

            //Skip if isSimulated
            if (_isSysSimulated)
                return;

            try
            {
                foreach (var axisIndex in _iMotionAxisAll)
                {
                    // Do AxesEnable
                    _MotionControl.AxesEnable(axisIndex, enable);
                }
            }
            catch (Exception ex)
            {
                if (enable)
                    writeError("MainForm.MotionControl", "Axes Enable failed!" + ex);
                else
                    writeError("MainForm.MotionControl", "Axes disable failed!" + ex);
                updateControlTxtWithString(txt_Motion_ErrorMsg, ex.ToString());
                setEquipmentFailLock();

                return;
            }
        }

        private void btn_Motion_Home_ALL_Click(object sender, EventArgs e)
        {
            //Write Event
            writeEvent("UserEvent", "Homing All");

            //Skip if isSimulated
            if (_isSysSimulated)
                return;

            try
            {
                // Homing all
                _MotionControl.Homing(_iMotionAxisAll);
            }
            catch (Exception ex)
            {
                writeError("MainForm.MotionControl", "Homing failed!" + ex);
                updateControlTxtWithString(txt_Motion_ErrorMsg, ex.ToString());
                return;
            }
        }

        private void btn_Motion_Stop_ALL_Click(object sender, EventArgs e)
        {
            //Write Event
            writeEvent("UserEvent", "Stop All");

            //Skip if isSimulated
            if (_isSysSimulated)
                return;

            try
            {
                abortMotion(_iMotionAxisAll);
            }
            catch (Exception ex)
            {
                writeError("MainForm.MotionControl", "Abort failed!" + ex);
                updateControlTxtWithString(txt_Motion_ErrorMsg, ex.ToString());
                return;
            }
        }

        private void btn_Motion_Acknowledge_ALL_Click(object sender, EventArgs e)
        {
            //Write Event
            writeEvent("UserEvent", "Acknowledge All");

            //Skip if isSimulated
            if (_isSysSimulated)
                return;

            try
            {
                updateControlTxtWithString(txt_Motion_ErrorMsg, "");
                _MotionControl.AcknowledgeAll();
            }
            catch (Exception ex)
            {
                writeError("MainForm.MotionControl", "AcknowledgeAll failed!" + ex);
                updateControlTxtWithString(txt_Motion_ErrorMsg, ex.ToString());
                return;
            }
        }

        private void btn_Motion_Homing_Click(object sender, EventArgs e)
        {
            // Update axisIndex depends on Control.Name of the sender
            Button button = (Button)sender;
            int axisIndex;
            string msg = "";
            switch (button.Name)
            {
                case "btn_Motion_Homing_X":
                    axisIndex = (int)MotionAxis.X;
                    _isHoming[(int)MotionAxis.X] = true;
                    msg = "Homing X";
                    break;
                case "btn_Motion_Homing_Y":
                    axisIndex = (int)MotionAxis.Y;
                    _isHoming[(int)MotionAxis.Y] = true;
                    msg = "Homing Y";
                    break;
                case "btn_Motion_Homing_Z":
                    axisIndex = (int)MotionAxis.Z;
                    _isHoming[(int)MotionAxis.Z] = true;
                    msg = "Homing Z";
                    break;
                default:
                    MessageBox.Show("Unknown btn_Motion_Homing_Click." + Environment.NewLine + button.Name);
                    return;
            }

            //Write Event
            writeEvent("UserEvent", msg);

            //Skip if isSimulated
            if (_isSysSimulated)
                return;

            try
            {
                // Do Homing
                _MotionControl.Homing(axisIndex);
            }
            catch (Exception ex)
            {
                writeError("MainForm.MotionControl", "Homing failed!" + ex);
                updateControlTxtWithString(txt_Motion_ErrorMsg, ex.ToString());
                return;
            }
        }

        private void btn_Motion_Move_Click(object sender, EventArgs e)
        {
            int[] axisIndexXYZ = { (int)MotionAxis.X, (int)MotionAxis.Y, (int)MotionAxis.Z };
            if (waitMotionDone(axisIndexXYZ, 1000))
            {

                // Check user selection
                if (!rdo_Motion_MoveAbs.Checked && !rdo_Motion_MoveRel.Checked)
                    return;

                // Update axisIndex depends on Control.Name of the sender
                Button button = (Button)sender;
                int axisIndex = 0;
                double position = 0;
                double speed = 0;
                try
                {
                    switch (button.Name)
                    {
                        case "btn_Motion_MoveP_X":
                            axisIndex = (int)MotionAxis.X;
                            position = double.Parse(txt_Motion_Distance_X.Text);
                            speed = double.Parse(cmb_Motion_Speed_X.Text);
                            break;
                        case "btn_Motion_MoveP_Y":
                            axisIndex = (int)MotionAxis.Y;
                            position = double.Parse(txt_Motion_Distance_Y.Text);
                            speed = double.Parse(cmb_Motion_Speed_Y.Text);
                            break;
                        case "btn_Motion_MoveP_Z":
                            axisIndex = (int)MotionAxis.Z;
                            position = double.Parse(txt_Motion_Distance_Z.Text);
                            speed = double.Parse(cmb_Motion_Speed_Z.Text);
                            break;
                        case "btn_Motion_MoveN_X":
                            axisIndex = (int)MotionAxis.X;
                            position = -1 * double.Parse(txt_Motion_Distance_X.Text);
                            speed = double.Parse(cmb_Motion_Speed_X.Text);
                            break;
                        case "btn_Motion_MoveN_Y":
                            axisIndex = (int)MotionAxis.Y;
                            position = -1 * double.Parse(txt_Motion_Distance_Y.Text);
                            speed = double.Parse(cmb_Motion_Speed_Y.Text);
                            break;
                        case "btn_Motion_MoveN_Z":
                            axisIndex = (int)MotionAxis.Z;
                            position = -1 * double.Parse(txt_Motion_Distance_Z.Text);
                            speed = double.Parse(cmb_Motion_Speed_Z.Text);
                            break;
                        default:
                            MessageBox.Show("Unknown btn_Motion_Move_Click." + Environment.NewLine + button.Name);
                            return;
                    }
                }
                catch (FormatException)
                {
                    MessageBox.Show("請輸入合理之數值!");
                    return;
                }
                catch (Exception ex)
                {
                    writeError("MainForm.MotionControl", "Motion Move failed!" + ex);
                    return;
                }

                //Write Event
                string msg = "";
                if (rdo_Motion_MoveAbs.Checked)
                    msg = string.Format("Axis.{0} MoveAbs({1},{2})", (MotionAxis)axisIndex, position, speed);
                if (rdo_Motion_MoveRel.Checked)
                    msg = string.Format("Axis.{0} MoveRel({1},{2})", (MotionAxis)axisIndex, position, speed);
                writeEvent("UserEvent", msg);

                //Skip if isSimulated
                if (_isSysSimulated)
                    return;


                try
                {
                    // Do Motion Movement based on Radio Checkbox
                    if (rdo_Motion_MoveAbs.Checked)
                        this.moveAbs(axisIndex, position, speed);
                    if (rdo_Motion_MoveRel.Checked)
                        this.moveRel(axisIndex, position, speed);
                }
                catch (Exception ex)
                {
                    writeError("MainForm.MotionControl", "Motion Move failed!" + ex);
                    updateControlTxtWithString(txt_Motion_ErrorMsg, ex.ToString());
                    return;
                }
            }
        }

        private void btn_Motion_Move_MouseDown(object sender, MouseEventArgs e)
        {
            //if (myController != null)
            //{
            //    try
            //    {
            //        // register task state and diagPackect arrived events
            //        //this.myController.ControlCenter.TaskStates.NewTaskStatesArrived += new EventHandler<NewTaskStatesArrivedEventArgs>(TaskStates_NewTaskStatesArrived);
            //        this.myController.ControlCenter.Diagnostics.NewDiagPacketArrived -= new EventHandler<NewDiagPacketArrivedEventArgs>(Diagnostics_NewDiagPacketArrived);
            //        Controller.Disconnect();
            //        btn_connect.Enabled = true;
            //        btn_disconnect.Enabled = false;
            //        //  _AxisStatus.Abort();


                    
            //        //LCH連線
            //        _MotionControl.Connect();

            //        _MotionControl.Initialize();

            //        // Consign controller after connection
            //        _MC_Controller = _MotionControl.GetController();

            //        // register task state and diagPackect arrived events
            //        //_MC_Controller.ControlCenter.TaskStates.NewTaskStatesArrived += new EventHandler<NewTaskStatesArrivedEventArgs>(TaskStates_NewTaskStatesArrived);
            //        _MC_Controller.ControlCenter.Diagnostics.NewDiagPacketArrived += new EventHandler<NewDiagPacketArrivedEventArgs>(Diagnostics_NewDiagPacketArrived);

            //        // Set the G code mode to Absolute mode
            //        string code = "G90";
            //        executeGCode(code);

            //        // Enable GUI Controls
            //        //EnableGUIMotionControls(true);

            //        // Disable UI control
            //        //  enableUIGroup(true);

            //        // Update Motion Main Status
            //        updateMainStatusImage(MainState.Connect);

            //    }
            //    catch (A3200Exception exception)
            //    {
            //        txt_Motion_ErrorMsg.Text = exception.Message;
            //    }
            //}

            // Check user selection
            if (!rdo_Motion_Jog.Checked)
                return;

            // Update axisIndex depends on Control.Name of the sender
            Button button = (Button)sender;
            int axisIndex = 0;
            double velocity = 0;
            try
            {
                switch (button.Name)
                {
                    case "btn_Motion_MoveP_X":
                        axisIndex = (int)MotionAxis.X;
                        velocity = double.Parse(cmb_Motion_Speed_X.Text);
                        break;
                    case "btn_Motion_MoveP_Y":
                        axisIndex = (int)MotionAxis.Y;
                        velocity = double.Parse(cmb_Motion_Speed_Y.Text);
                        break;
                    case "btn_Motion_MoveP_Z":
                        axisIndex = (int)MotionAxis.Z;
                        velocity = double.Parse(cmb_Motion_Speed_Z.Text);
                        break;
                    case "btn_Motion_MoveN_X":
                        axisIndex = (int)MotionAxis.X;
                        velocity = -1 * double.Parse(cmb_Motion_Speed_X.Text);
                        break;
                    case "btn_Motion_MoveN_Y":
                        axisIndex = (int)MotionAxis.Y;
                        velocity = -1 * double.Parse(cmb_Motion_Speed_Y.Text);
                        break;
                    case "btn_Motion_MoveN_Z":
                        axisIndex = (int)MotionAxis.Z;
                        velocity = -1 * double.Parse(cmb_Motion_Speed_Z.Text);
                        break;
                    default:
                        MessageBox.Show("Unknown btn_Motion_Move_MouseDown." + Environment.NewLine + button.Name);
                        return;
                }
            }
            catch (FormatException)
            {
                MessageBox.Show("請輸入合理之數值!");
                return;
            }
            catch (Exception ex)
            {
                writeError("MainForm.MotionControl", "Free Run failed!" + ex);
                updateControlTxtWithString(txt_Motion_ErrorMsg, ex.ToString());
                return;
            }

            //Write Event
            string msg = string.Format("Axis.{0} FreeRun({1})", (MotionAxis)axisIndex, velocity);
            writeEvent("UserEvent", msg);
            
            //Skip if isSimulated
            if (_isSysSimulated)
                return;

            try
            {
                // Do Motion Movement based on Radio Checkbox
                if (rdo_Motion_Jog.Checked)
                    moveJog(axisIndex, velocity);
            }
            catch (Exception ex)
            {
                writeError("MainForm.MotionControl", "Free Run failed!" + ex);
                updateControlTxtWithString(txt_Motion_ErrorMsg, ex.ToString());
                return;
            }
        }

        private void btn_Motion_Move_MouseUp(object sender, MouseEventArgs e)
        {
            //if (myController != null)
            //{
            //    try
            //    {
            //        // register task state and diagPackect arrived events
            //        //this.myController.ControlCenter.TaskStates.NewTaskStatesArrived += new EventHandler<NewTaskStatesArrivedEventArgs>(TaskStates_NewTaskStatesArrived);
            //        this.myController.ControlCenter.Diagnostics.NewDiagPacketArrived -= new EventHandler<NewDiagPacketArrivedEventArgs>(Diagnostics_NewDiagPacketArrived);
            //        Controller.Disconnect();
            //        btn_connect.Enabled = true;
            //        btn_disconnect.Enabled = false;
            //        //  _AxisStatus.Abort();

            //        //LCH連線
            //        _MotionControl.Connect();

            //        _MotionControl.Initialize();

            //        // Consign controller after connection
            //        _MC_Controller = _MotionControl.GetController();

            //        // register task state and diagPackect arrived events
            //        //_MC_Controller.ControlCenter.TaskStates.NewTaskStatesArrived += new EventHandler<NewTaskStatesArrivedEventArgs>(TaskStates_NewTaskStatesArrived);
            //        _MC_Controller.ControlCenter.Diagnostics.NewDiagPacketArrived += new EventHandler<NewDiagPacketArrivedEventArgs>(Diagnostics_NewDiagPacketArrived);

            //        // Set the G code mode to Absolute mode
            //        string code = "G90";
            //        executeGCode(code);

            //        // Enable GUI Controls
            //        //EnableGUIMotionControls(true);

            //        // Disable UI control
            //        //  enableUIGroup(true);

            //        // Update Motion Main Status
            //        updateMainStatusImage(MainState.Connect);

            //    }
            //    catch (A3200Exception exception)
            //    {
            //        txt_Motion_ErrorMsg.Text = exception.Message;
            //    }
            //}

            // Check user selection
            if (!rdo_Motion_Jog.Checked)
                return;

            // Update axisIndex depends on Control.Name of the sender
            Button button = (Button)sender;
            int axisIndex;
            switch (button.Name)
            {
                case "btn_Motion_MoveP_X":
                    axisIndex = (int)MotionAxis.X;
                    break;
                case "btn_Motion_MoveP_Y":
                    axisIndex = (int)MotionAxis.Y;
                    break;
                case "btn_Motion_MoveP_Z":
                    axisIndex = (int)MotionAxis.Z;
                    break;
                case "btn_Motion_MoveN_X":
                    axisIndex = (int)MotionAxis.X;
                    break;
                case "btn_Motion_MoveN_Y":
                    axisIndex = (int)MotionAxis.Y;
                    break;
                case "btn_Motion_MoveN_Z":
                    axisIndex = (int)MotionAxis.Z;
                    break;
                default:
                    MessageBox.Show("Unknown btn_Motion_Move_MouseUp." + Environment.NewLine + button.Name);
                    return;
            }

            //Write Event
            string msg = string.Format("Axis.{0} FreeRunStop()", (MotionAxis)axisIndex);
            writeEvent("UserEvent", msg);
            
            //Skip if isSimulated
            if (_isSysSimulated)
                return;

            try
            {
                // Do Motion Movement based on Radio Checkbox
                if (rdo_Motion_Jog.Checked)
                    _MotionControl.FreeRunStop(axisIndex);
            }
            catch (Exception ex)
            {
                writeError("MainForm.MotionControl", "Free Run Stop failed!" + ex);
                updateControlTxtWithString(txt_Motion_ErrorMsg, ex.ToString());
                return;
            }
        }

        private delegate void dMotionMoveTo(object sender, EventArgs e);
        private void btn_Motion_MoveTo_Click(object sender, EventArgs e)
        {
            // Update axisIndex depends on Control.Name of the sender
            Button button = (Button)sender;
            int[] axisIndexes = new int[] { (int)MotionAxis.X, (int)MotionAxis.Y };
            double[] distances;
            double[] speeds = new double[] { _ConfigEquip._Velocity_Default.X, _ConfigEquip._Velocity_Default.Y };
            string position1 = "";
            string position2 = "";
            switch (button.Name)
            {
                case "btn_Motion_Move_Laser2Camera":
                    distances = new double[] { _ConfigEquip._RelPosition_Laser2Camera.X, _ConfigEquip._RelPosition_Laser2Camera.Y };
                    position1 = "Laser";
                    position2 = "Camera";
                    break;
                case "btn_Motion_Move_Camera2Laser":
                    distances = new double[] { -_ConfigEquip._RelPosition_Laser2Camera.X, -_ConfigEquip._RelPosition_Laser2Camera.Y };
                    position1 = "Camera";
                    position2 = "Laser";
                    break;
                case "btn_Motion_Move_Laser2ConfocalLaser":
                    distances = new double[] { _ConfigEquip._RelPosition_Laser2ConfocalLaser.X, _ConfigEquip._RelPosition_Laser2ConfocalLaser.Y };
                    position1 = "Laser";
                    position2 = "ConfocalLaser";
                    break;
                case "btn_Motion_Move_ConfocalLaser2Laser":
                    distances = new double[] { -_ConfigEquip._RelPosition_Laser2ConfocalLaser.X, -_ConfigEquip._RelPosition_Laser2ConfocalLaser.Y };
                    position1 = "ConfocalLaser";
                    position2 = "Laser";
                    break;
                case "btn_Motion_Move_ConfocalLaser2Camera":
                    distances = new double[] { _ConfigEquip._RelPosition_Laser2Camera.X - _ConfigEquip._RelPosition_Laser2ConfocalLaser.X, _ConfigEquip._RelPosition_Laser2Camera.Y - _ConfigEquip._RelPosition_Laser2ConfocalLaser.Y };
                    position1 = "ConfocalLaser";
                    position2 = "Camera";
                    break;
                case "btn_Motion_Move_Camera2ConfocalLaser":
                    distances = new double[] { _ConfigEquip._RelPosition_Laser2ConfocalLaser.X - _ConfigEquip._RelPosition_Laser2Camera.X, _ConfigEquip._RelPosition_Laser2ConfocalLaser.Y - _ConfigEquip._RelPosition_Laser2Camera.Y };
                    position1 = "Camera";
                    position2 = "ConfocalLaser";
                    break;
                default:
                    MessageBox.Show("Unknown btn_Motion_MoveTo_Click." + Environment.NewLine + button.Name);
                    return;
            }

            //Write Event
            string msg = string.Format("Move from {0} to {1}", position1, position2);
            writeEvent("UserEvent", msg);

            //Skip if isSimulated
            if (_isSysSimulated)
                return;

            // Disable GUI Controls
            //EnableGUIMotionControls(false);

            // Disable UI control
            enableUIGroup(false);

            // Call BackgroundWorker to do asynchronous operation
            if (!BW_SyncMotion.IsBusy)
            {
                // Package
                RapidMoveObject rapidMoveObject = new RapidMoveObject();
                rapidMoveObject.AxisIndexes = axisIndexes;
                rapidMoveObject.Distances = distances;
                rapidMoveObject.Speeds = speeds;
                SyncMotionObject syncMotionObject = new SyncMotionObject();
                syncMotionObject.Type = SyncMotionType.RapidMove;
                syncMotionObject.Object = rapidMoveObject;

                // Start the asynchronous operation.
                BW_SyncMotion.RunWorkerAsync(syncMotionObject);
            }
            else
            {
                MessageBox.Show("IsBusy");
            }
        }

        private void chk_Motion_Enable_CheckedChanged(object sender, EventArgs e)
        {
            // Update axisIndex depends on Control.Name of the sender
            CheckBox checkBox = (CheckBox)sender;
            int axisIndex;
            bool enable = checkBox.Checked;
            switch (checkBox.Name)
            {
                case "chk_Motion_Enable_X":
                    axisIndex = (int)MotionAxis.X;
                    break;
                case "chk_Motion_Enable_Y":
                    axisIndex = (int)MotionAxis.Y;
                    break;
                case "chk_Motion_Enable_Z":
                    axisIndex = (int)MotionAxis.Z;
                    break;
                default:
                    MessageBox.Show("Unknown chk_Motion_Enable_CheckedChanged." + Environment.NewLine + checkBox.Name);
                    return;
            }

            string msg;
            //Write Event
            if (enable)
                msg = string.Format("Axis.{0} enable", (MotionAxis)axisIndex);
            else
                msg = string.Format("Axis.{0} disable", (MotionAxis)axisIndex);
            writeEvent("UserEvent", msg);

            //Skip if isSimulated
            if (_isSysSimulated)
                return;

            try
            {
                // Do AxesEnable
                _MotionControl.AxesEnable(axisIndex, enable);
            }
            catch (Exception ex)
            {
                writeError("MainForm.MotionControl", "Axes Enable failed!" + ex);
                updateControlTxtWithString(txt_Motion_ErrorMsg, ex.ToString());
                setEquipmentFailLock();
                return;
            }
        }

        private void btn_ConfigProcess_Compensate_Click(object sender, EventArgs e)
        {
            _isConfocalLaserBusy = true;
            ConfocalLaser.evalResult result = _ConfocalLaser.Trigger(1, out _ConfocalLaser_Output, 0);
            _isConfocalLaserBusy = false;
            if (_ConfocalLaser_Output < -99999)
            {
                // Write Event
                writeEvent("UserEvent", "Out of Compensate zone.");
                MessageBox.Show("請先移動Z軸至測高計量測範圍!", "Error！！");
            }
            else
            {
                double currentDistance = -1 * _ConfocalLaser_Output * 0.001; //Since confocal laser result unit: um
                double distance = currentDistance + _ConfigProcess._Compensate_DistanceZ;
                // Write Event
                writeEvent("UserEvent", "Compensate Z distance.");

                // Since MotionAxis Z direction is reversed
                distance = -1 * distance;
                moveRel((int)MotionAxis.Z, distance, _ConfigEquip._Velocity_Default.Z);
            }
        }

        #endregion

        #region Private Method

        private void moveAbs(int axisIndex, double position, double speed)
        {
            // Check enable
            if (!_isEnabled[axisIndex])
                throw new Exception("Axis isn't enabled yet." + Environment.NewLine + "Axis = " + (MotionAxis)axisIndex);
            // Check inposition
            //if (!_isInPosition[axisIndex])
                //throw new Exception("Axis isn't inposition yet." + Environment.NewLine + "Axis = " + (MotionAxis)axisIndex);
            // Check homed
            if (!_isHomed[axisIndex])
                throw new Exception("Axis isn't homed yet." + Environment.NewLine + "Axis = " + (MotionAxis)axisIndex);
            // Check software limits
            if (_isSWTripped[axisIndex])
                throw new Exception("Axis is already SW Limits tripped." + Environment.NewLine + "Axis = " + (MotionAxis)axisIndex);
            checkSWLimits(axisIndex, position);
            
            try
            {
                _MotionControl.MoveAbs(axisIndex, position, speed);
            }
            catch (Exception ex)
            {
                writeError("MainForm.MotionControl", "MoveAbs failed!" + ex);
                updateControlTxtWithString(txt_Motion_ErrorMsg, ex.ToString());
                return;
            }

            // Write Data log
            writeDataQueue("Motion", string.Format("Axis.{0} Move to {1} with Speed {2}", (MotionAxis)axisIndex, position, speed));
        }

        private void moveRel(int axisIndex, double distance, double speed)
        {
            // Check enable
            if (!_isEnabled[axisIndex])
                throw new Exception("Axis isn't enabled yet." + Environment.NewLine + "Axis = " + (MotionAxis)axisIndex);
            // Check inposition
            //if (!_isInPosition[axisIndex])
                //throw new Exception("Axis isn't inposition yet." + Environment.NewLine + "Axis = " + (MotionAxis)axisIndex);
            // Check homed
            if (!_isHomed[axisIndex])
                throw new Exception("Axis isn't homed yet." + Environment.NewLine + "Axis = " + (MotionAxis)axisIndex);
            // Check software limits
            if (_isSWTripped[axisIndex])
                throw new Exception("Axis is already SW Limits tripped." + Environment.NewLine + "Axis = " + (MotionAxis)axisIndex);
            double currentPosition = _positionFeedback[axisIndex];
            double targetPosition = currentPosition + distance;
            checkSWLimits(axisIndex, targetPosition);

            try
            {
                _MotionControl.MoveRel(axisIndex, distance, speed);
            }
            catch (Exception ex)
            {
                writeError("MainForm.MotionControl", "MoveRel failed!" + ex);
                updateControlTxtWithString(txt_Motion_ErrorMsg, ex.ToString());
                return;
            }

            // Write Data log
            writeDataQueue("Motion", string.Format("Axis.{0} Relative move to {1} with Speed {2}", (MotionAxis)axisIndex, distance, speed));
        }

        private void moveJog(int axisIndex, double velocity)
        {
            // Check enable
            if (!_isEnabled[axisIndex])
                throw new Exception("Axis isn't enabled yet." + Environment.NewLine + "Axis = " + (MotionAxis)axisIndex);
            // Check inposition
            //if (!_isInPosition[axisIndex])
                //throw new Exception("Axis isn't inposition yet." + Environment.NewLine + "Axis = " + (MotionAxis)axisIndex);
            // Check homed
            if (!_isHomed[axisIndex])
                throw new Exception("Axis isn't homed yet." + Environment.NewLine + "Axis = " + (MotionAxis)axisIndex);
            // Check software limits
            if (_isSWTripped[axisIndex])
                throw new Exception("Axis is already SW Limits tripped." + Environment.NewLine + "Axis = " + (MotionAxis)axisIndex);
            double currentPosition = _positionFeedback[axisIndex];
            checkSWLimits(axisIndex, currentPosition);

            try
            {
                _MotionControl.FreeRun(axisIndex, velocity);
            }
            catch (Exception ex)
            {
                writeError("MainForm.MotionControl", "FreeRun failed!" + ex);
                updateControlTxtWithString(txt_Motion_ErrorMsg, ex.ToString());
                return;
            }

            // Write Data Log
            writeDataQueue("Motion", string.Format("Axis.{0} Jogging with Speed {1}", (MotionAxis)axisIndex, velocity));
        }

        private void rapidMove(int[] axisIndexes, double[] distances, double[] speeds)
        {
            for (int i = 0; i < axisIndexes.Length; i++)
            {
                int axisIndex = axisIndexes[i];
                double distance = distances[i];
                // Check enable
                if (!_isEnabled[axisIndex])
                    throw new Exception("Axis isn't enabled yet." + Environment.NewLine + "Axis = " + (MotionAxis)axisIndex);
                // Check inposition
                //if (!_isInPosition[axisIndex])
                    //throw new Exception("Axis isn't inposition yet." + Environment.NewLine + "Axis = " + (MotionAxis)axisIndex);
                // Check homed
                if (!_isHomed[axisIndex])
                    throw new Exception("Axis isn't homed yet." + Environment.NewLine + "Axis = " + (MotionAxis)axisIndex);
                // Check software limits
                if (_isSWTripped[axisIndex])
                    throw new Exception("Axis is already SW Limits tripped." + Environment.NewLine + "Axis = " + (MotionAxis)axisIndex);
                double currentPosition = _positionFeedback[axisIndex];
                double targetPosition = currentPosition + distance;
                checkSWLimits(axisIndex, targetPosition);
            }

            try
            {
                _MotionControl.RapidMove(axisIndexes, distances, speeds);
            }
            catch (Exception ex)
            {
                writeError("MainForm.MotionControl", "RapidMove failed!" + ex);
                updateControlTxtWithString(txt_Motion_ErrorMsg, ex.ToString());
                return;
            }

            string msg = "";
            for (int i = 0; i < axisIndexes.Length; i++)
            {
                msg += string.Format("Axis.{0} Rapid move {1} with Speed {2};", (MotionAxis)axisIndexes[i], distances[i], speeds[i]);
            }

            // Write Data Log
            writeDataQueue("Motion", msg);
        }

        private void rapidMoveTo(double X, double Y, double Z, double FeedSpeed = 0)
        {
            int[] axisIndexes = { (int)MotionAxis.X, (int)MotionAxis.Y, (int)MotionAxis.Z };
            for (int i = 0; i < axisIndexes.Length; i++)
            {
                int axisIndex = axisIndexes[i];
                // Check enable
                if (!_isEnabled[axisIndex])
                    throw new Exception("Axis isn't enabled yet." + Environment.NewLine + "Axis = " + (MotionAxis)axisIndex);
                // Check inposition
                //if (!_isInPosition[axisIndex])
                //throw new Exception("Axis isn't inposition yet." + Environment.NewLine + "Axis = " + (MotionAxis)axisIndex);
                // Check homed
                if (!_isHomed[axisIndex])
                    throw new Exception("Axis isn't homed yet." + Environment.NewLine + "Axis = " + (MotionAxis)axisIndex);
                // Check software limits
                if (_isSWTripped[axisIndex])
                    throw new Exception("Axis is already SW Limits tripped." + Environment.NewLine + "Axis = " + (MotionAxis)axisIndex);
            }
            checkSWLimits((int)MotionAxis.X, X);
            checkSWLimits((int)MotionAxis.Y, Y);
            checkSWLimits((int)MotionAxis.Z, Z);

            string code;
            if (FeedSpeed == 0)
                code = string.Format("G00 X{0} Y{1} Z{2}", X, Y, Z);
            else
                code = string.Format("G00 X{0} Y{1} Z{2} F{3}", X, Y, Z, FeedSpeed);

            executeGCode(code);

            // Write Data log
            //writeDataQueue("Motion", "Rapid Move To = " + code);
        }
        /// <summary>
        /// 絕對位置控制軸到點位
        /// </summary>
        /// <param name="PointName"></param>
        /// <param name="X"></param>
        /// <param name="Y"></param>
        /// <param name="Z"></param>
        /// <param name="FeedSpeed"></param>
        private void moveTo(string PointName, double X, double Y, double Z, double FeedSpeed = 0)
        {
            //Skip if isSimulated
            if (_isSysSimulated)
                return;

            // Disable GUI Controls
            //EnableGUIMotionControls(false);

            // Disable UI control
            enableUIGroup(false);

            // Call BackgroundWorker to do asynchronous operation
            if (!BW_SyncMotion.IsBusy)
            {
                // Package
                RapidMoveToObject rapidMoveToObject = new RapidMoveToObject();
                rapidMoveToObject.X = X;
                rapidMoveToObject.Y = Y;
                rapidMoveToObject.Z = Z;
                rapidMoveToObject.FeedSpeed = FeedSpeed;
                SyncMotionObject syncMotionObject = new SyncMotionObject();
                syncMotionObject.Type = SyncMotionType.RapidMoveTo;
                syncMotionObject.Object = rapidMoveToObject;

                // Start the asynchronous operation.
                BW_SyncMotion.RunWorkerAsync(syncMotionObject);
            }
        }

        private void linearMove(double X, double Y, double FeedSpeed = 0)
        {
            int[] axisIndexes = { (int)MotionAxis.X, (int)MotionAxis.Y };
            for (int i = 0; i < axisIndexes.Length; i++)
            {
                int axisIndex = axisIndexes[i];
                // Check enable
                if (!_isEnabled[axisIndex])
                    throw new Exception("Axis isn't enabled yet." + Environment.NewLine + "Axis = " + (MotionAxis)axisIndex);
                // Check inposition
                //if (!_isInPosition[axisIndex])
                //throw new Exception("Axis isn't inposition yet." + Environment.NewLine + "Axis = " + (MotionAxis)axisIndex);
                // Check homed
                if (!_isHomed[axisIndex])
                    throw new Exception("Axis isn't homed yet." + Environment.NewLine + "Axis = " + (MotionAxis)axisIndex);
                // Check software limits
                if (_isSWTripped[axisIndex])
                    throw new Exception("Axis is already SW Limits tripped." + Environment.NewLine + "Axis = " + (MotionAxis)axisIndex);
            }
            checkSWLimits((int)MotionAxis.X, X);
            checkSWLimits((int)MotionAxis.Y, Y);

            string code;
            if (FeedSpeed == 0)
                code = string.Format("G01 X{0} Y{1}", X, Y);
            else
                code = string.Format("G01 X{0} Y{1} F{2}", X, Y, FeedSpeed);

            executeGCode(code);

            // Write Data log
            //writeDataQueue("Motion", "linearMove = " + code);
        }

        private void abortMotion(int[] axisIndexes)
        {
            try
            {
                _MotionControl.Abort(axisIndexes);
            }
            catch (Exception ex)
            {
                writeError("MainForm.MotionControl", "AbortMotion failed!" + ex);
                updateControlTxtWithString(txt_Motion_ErrorMsg, ex.ToString());
                return;
            }

            // Write Data log
            writeDataQueue("Motion", "Motion abort");
        }

        private void ccwMove(double X, double Y, double I, double J, double FeedSpeed = 0)
        {
            int[] axisIndexes = { (int)MotionAxis.X, (int)MotionAxis.Y };
            for (int i = 0; i < axisIndexes.Length; i++)
            {
                int axisIndex = axisIndexes[i];
                // Check enable
                if (!_isEnabled[axisIndex])
                    throw new Exception("Axis isn't enabled yet." + Environment.NewLine + "Axis = " + (MotionAxis)axisIndex);
                // Check inposition
                //if (!_isInPosition[axisIndex])
                    //throw new Exception("Axis isn't inposition yet." + Environment.NewLine + "Axis = " + (MotionAxis)axisIndex);
                // Check homed
                if (!_isHomed[axisIndex])
                    throw new Exception("Axis isn't homed yet." + Environment.NewLine + "Axis = " + (MotionAxis)axisIndex);
                // Check software limits
                if (_isSWTripped[axisIndex])
                    throw new Exception("Axis is already SW Limits tripped." + Environment.NewLine + "Axis = " + (MotionAxis)axisIndex);
            }

            string code;
            if (FeedSpeed == 0)
                code = string.Format("G03 X{0} Y{1} I{2} J{3}", X, Y, I, J);
            else
                code = string.Format("G03 X{0} Y{1} I{2} J{3} F{4}", X, Y, I, J, FeedSpeed);
            executeGCode(code);

            // Write Data log
            //writeDataQueue("Motion", "ccwMove = " + code);
        }

        private bool waitMotionDone(int[] axisIndexes, int timeout)
        {
            bool result = false;

            try
            {
                result = _MotionControl.WaitMotionDone(axisIndexes, timeout);
            }
            catch (Exception ex)
            {
                writeError("MainForm.MotionControl", "WaitMotionDone failed!" + ex);
                updateControlTxtWithString(txt_Motion_ErrorMsg, ex.ToString());
                return result;
            }

            return result;
        }

        private void executeGCode(string code)
        {
            try
            {
                //[BM:G-code-輸入G-code]
                _MotionControl.ExecuteGCode(code);
            }
            catch (Exception ex)
            {
                writeError("MainForm.MotionControl", "ExecuteGCode failed!" + ";Code: " + code + Environment.NewLine + ex );
                updateControlTxtWithString(txt_Motion_ErrorMsg, ex.ToString());
                return;
            }

            // Write Data log
            writeDataQueue("Motion", "ExecuteGCode = " + code);
        }

        private void checkSWLimits(int axisIndex, double position)
        {
            //switch (axisIndex)
            //{
            //    case (int)MotionAxis.X:
            //        if (position < _ConfigEquip._SWLimit_X.Low)
            //        {
            //            _isSWLoTripped = true;
            //            throw new Exception(string.Format("Software Limit Low check failed." + Environment.NewLine + "Axis.{0} Target position = {1}", (MotionAxis)axisIndex, position));
            //        }
            //        else if (position > _ConfigEquip._SWLimit_X.High)
            //        {
            //            _isSWHiTripped = true;
            //            throw new Exception(string.Format("Software Limit High check failed." + Environment.NewLine + "Axis.{0} Target position = {1}", (MotionAxis)axisIndex, position));
            //        }
            //        break;
            //    case (int)MotionAxis.Y:
            //        if (position < _ConfigEquip._SWLimit_Y.Low)
            //        {
            //            _isSWLoTripped = true;
            //            throw new Exception(string.Format("Software Limit Low check failed." + Environment.NewLine + "Axis.{0} Target position = {1}", (MotionAxis)axisIndex, position));
            //        }
            //        else if (position > _ConfigEquip._SWLimit_Y.High)
            //        {
            //            _isSWHiTripped = true;
            //            throw new Exception(string.Format("Software Limit High check failed." + Environment.NewLine + "Axis.{0} Target position = {1}", (MotionAxis)axisIndex, position));
            //        }
            //        break;
            //    case (int)MotionAxis.Z:
            //        if (position < _ConfigEquip._SWLimit_Z.Low)
            //        {
            //            _isSWLoTripped = true;
            //            throw new Exception(string.Format("Software Limit Low check failed." + Environment.NewLine + "Axis.{0} Target position = {1}", (MotionAxis)axisIndex, position));
            //        }
            //        else if (position > _ConfigEquip._SWLimit_Z.High)
            //        {
            //            _isSWHiTripped = true;
            //            throw new Exception(string.Format("Software Limit High check failed." + Environment.NewLine + "Axis.{0} Target position = {1}", (MotionAxis)axisIndex, position));
            //        }
            //        break;
            //    default:
            //        throw new Exception("Unexpected axisIndex." + Environment.NewLine + "Axis = " + axisIndex);
            //}
        }

        private void checkProcessLimits()
        {
            int motionAxis = (int)MotionAxis.X;
            if (_positionFeedback[motionAxis] < _ConfigEquip._ProcessLimit_X.Low)
                throw new Exception(string.Format("Process Limit Low check failed." + Environment.NewLine + "Axis.{0} position = {1}", (MotionAxis)motionAxis, _positionFeedback[motionAxis]));
            if (_positionFeedback[motionAxis] > _ConfigEquip._ProcessLimit_X.High)
                throw new Exception(string.Format("Process Limit High check failed." + Environment.NewLine + "Axis.{0} position = {1}", (MotionAxis)motionAxis, _positionFeedback[motionAxis]));
            motionAxis = (int)MotionAxis.Y;
            if (_positionFeedback[motionAxis] < _ConfigEquip._ProcessLimit_Y.Low)
                throw new Exception(string.Format("Process Limit Low check failed." + Environment.NewLine + "Axis.{0} position = {1}", (MotionAxis)motionAxis, _positionFeedback[motionAxis]));
            if (_positionFeedback[motionAxis] > _ConfigEquip._ProcessLimit_Y.High)
                throw new Exception(string.Format("Process Limit High check failed." + Environment.NewLine + "Axis.{0} position = {1}", (MotionAxis)motionAxis, _positionFeedback[motionAxis]));
            motionAxis = (int)MotionAxis.Z;
            if (_positionFeedback[motionAxis] < _ConfigEquip._ProcessLimit_Z.Low)
                throw new Exception(string.Format("Process Limit Low check failed." + Environment.NewLine + "Axis.{0} position = {1}", (MotionAxis)motionAxis, _positionFeedback[motionAxis]));
            if (_positionFeedback[motionAxis] > _ConfigEquip._ProcessLimit_Z.High)
                throw new Exception(string.Format("Process Limit High check failed." + Environment.NewLine + "Axis.{0} position = {1}", (MotionAxis)motionAxis, _positionFeedback[motionAxis]));
        }

        private static bool areAllTrue(bool[] array)
        {
            foreach (bool element in array)
            {
                if (!element)
                    return false;
            }
            return true;
        }

        private void waitInPosition()
        {
            int count = 0;
            int countLimit = 100;
            while (!_areInPosition)
            {
                Thread.Sleep(100);
                count++;
                if (count >= countLimit)
                    throw new Exception("Time-out(10s) in waitInPosition.");
            }
        }

        #endregion

        #region Event Handler

        /*
        /// <summary>
        /// Handle task state arrived event. Invoke SetTaskState to process data
        /// </summary>
        private void TaskStates_NewTaskStatesArrived(object sender, NewTaskStatesArrivedEventArgs e)
        {
            try
            {
                //URL: http://msdn.microsoft.com/en-us/library/ms171728.aspx
                //How to: Make Thread-Safe Calls to Windows Forms Controls
                this.Invoke(new Action<NewTaskStatesArrivedEventArgs>(SetTaskState), e);
            }
            catch
            {
            }
        }
        */

        /// <summary>
        /// Handle DiagPacket (axis state in it) arrived event. Invoke SetAxisState to process data
        /// </summary>
        private void Diagnostics_NewDiagPacketArrived(object sender, NewDiagPacketArrivedEventArgs e)
        {
            try
            {
                // Update private variables from EventArgs
                foreach (int motionAxis in _iMotionAxisAll)
                {
                    _isHoming[motionAxis] = e.Data[motionAxis].AxisStatus.Homing;
                    _isHomed[motionAxis] = e.Data[motionAxis].AxisStatus.Homed;
                    _isEnabled[motionAxis] = e.Data[motionAxis].DriveStatus.Enabled;
                    _isInPosition[motionAxis] = e.Data[motionAxis].DriveStatus.InPosition;
                    _isLimitP[motionAxis] = e.Data[motionAxis].AxisFault.CcwSoftwareLimitFault;
                    _isLimitN[motionAxis] = e.Data[motionAxis].AxisFault.CwSoftwareLimitFault;
                    _positionCommand[motionAxis] = e.Data[motionAxis].PositionCommand;
                    _positionFeedback[motionAxis] = e.Data[motionAxis].PositionFeedback;
                }
                _areInPosition = areAllTrue(_isInPosition);
                _areSWTripped = areAllTrue(_isSWTripped);

                //[BM: LCH二切功能-增加變數值]
                Home = _areHomed = areAllTrue(_isHomed);
                En = _areEnabled = areAllTrue(_isEnabled);
                //[BM: LCH二切功能-增加變數值]
                Motion_X = e.Data[0].DriveStatus.InPosition;
                Motion_Y = e.Data[1].DriveStatus.InPosition;
                Motion_Z = e.Data[2].DriveStatus.InPosition;

                //URL: http://msdn.microsoft.com/en-us/library/ms171728.aspx
                //How to: Make Thread-Safe Calls to Windows Forms Controls
                this.Invoke(new Action<NewDiagPacketArrivedEventArgs>(UpdateDiagPacket), e);
            }
            catch (Exception ex)
            {
                writeError("MainForm.MotionControl", "Diagnostics_NewDiagPacketArrived failed!" + ex);
                updateControlTxtWithString(txt_Motion_ErrorMsg, ex.ToString());
                setEquipmentFailLock();
                return;
            }
        }

        #endregion

        #region BackgroundWorker

        private void BW_SyncMotion_DoWork(object sender, DoWorkEventArgs e)
        {
            SyncMotionObject motionObject = (SyncMotionObject)e.Argument;
            SyncMotionType motionType = motionObject.Type;

            switch (motionType)
            {
                case SyncMotionType.RapidMove:
                    RapidMoveObject rapidMoveObject = (RapidMoveObject)motionObject.Object;
                    try
                    {
                        // Set Positioning to Relative Mode
                        string code = "G91";
                        executeGCode(code);

                        // Do Motion Movement to specified target position
                        this.rapidMove(rapidMoveObject.AxisIndexes, rapidMoveObject.Distances, rapidMoveObject.Speeds);
                    }
                    catch (Exception ex)
                    {
                        writeError("MainForm.MotionControl", "Rapid Move Failed!" + ex);
                        updateControlTxtWithString(txt_Motion_ErrorMsg, ex.ToString());
                        return;
                    }
                    break;
                case SyncMotionType.RapidMoveTo:
                    RapidMoveToObject rapidMoveToObject = (RapidMoveToObject)motionObject.Object;
                    try
                    {
                        // Set Positioning to Absolute Mode
                        string code = "G90";
                        executeGCode(code);

                        // Do Motion Movement to specified target position
                        this.rapidMoveTo(rapidMoveToObject.X, rapidMoveToObject.Y, rapidMoveToObject.Z, rapidMoveToObject.FeedSpeed);
                    }
                    catch (Exception ex)
                    {
                        writeError("MainForm.MotionControl", string.Format("Rapid Move To Failed!" + ex));
                        updateControlTxtWithString(txt_Motion_ErrorMsg, ex.ToString());
                        return;
                    }
                    break;
                default:
                    throw new Exception("Unknown SyncMotionType!");
                    break;
            }
            // Disable UI control
            enableUIGroup(false);
        }

        private void BW_SyncMotion_RunWorkerCompleted(object sender, RunWorkerCompletedEventArgs e)
        {
            // Disable UI control
            enableUIGroup(true);
        }

        #endregion
    }
}
