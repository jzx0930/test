﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Net.Sockets;
using NModbus;


namespace LCSBM
{
	public class P_F_IO_Link
	{
		private TcpClient _tcpClient;
		private ModbusFactory _factory;
		private IModbusMaster _master;
		private byte _slaveID  = 1;

		private object _sendLock = new object();
	

		public bool Connected
		{
		 
			//get
			//{			 
			//	return _tcpClient?.Connected ?? false;
			//}
			get => _tcpClient?.Connected??false;
		 
		}

		protected P_F_IO_Link(string ip, int port, byte slaveID)
		{
			try
			{
				_tcpClient = new TcpClient(ip, port);
				_tcpClient.ReceiveTimeout = 3000;
				_tcpClient.SendTimeout = 3000;
				_factory = new ModbusFactory();
				_master = _factory.CreateMaster(_tcpClient);
				int ss = _master.Transport.ReadTimeout;
				_slaveID = slaveID;
			 
			}
			catch (Exception ex)
			{
				 
			}
		}

		public void Disconnect()
        {
			_tcpClient.Close();
        }

		/// <summary>
		/// 讀取 register  03
		/// </summary>		
		/// <param name="startAddr"></param>
		/// <param name="regNum"></param>
		protected ushort[] ReadHoldingReg(ushort startAddr, ushort regNum)
		{
			lock(_sendLock)
				return _master.ReadHoldingRegisters(_slaveID, startAddr, regNum);
		}

		/// <summary>
		/// 讀取 register  03
		/// </summary>		
		/// <param name="startAddr"></param>
		/// <param name="regNum"></param>
		protected Task<ushort[]> ReadHoldingRegistersAsync(ushort startAddr, ushort regNum)
        {
			return _master.ReadHoldingRegistersAsync(_slaveID, startAddr, regNum);
		}

		/// <summary>
		/// 寫入 register  06
		/// </summary>
		/// <param name="startAddr"></param>
		/// <param name="regNum"></param>
		protected void WriteHoldingReg( ushort startAddr, ushort value)
		{
			lock (_sendLock)
				_master.WriteSingleRegister(_slaveID, startAddr, value);
		}

		/// <summary>
		/// 讀取 coil  01
		/// </summary>	
		/// <param name="startAddr"></param>
		/// <param name="regNum"></param>
		protected bool[] ReadCoils(ushort startAddr, ushort coilNum)
		{
			lock (_sendLock)
				return _master.ReadCoils(_slaveID, startAddr, coilNum);
		}

		/// <summary>
		/// 寫入 coil  05
		/// </summary>
		/// <param name="startAddr"></param>
		/// <param name="regNum"></param>
		protected void WriteHoldingReg(ushort startAddr, bool value)
		{
			lock (_sendLock)
				_master.WriteSingleCoil(_slaveID, startAddr, value);
		}


		 

	}
}
