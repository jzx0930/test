﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LCSBM
{
    public class FESTO_SPAN : P_F_IO_Link
    {

        public FESTO_SPAN (string ip, int port, byte slaveID) : base(ip, port, slaveID)
        { 
        }

        /// <summary>
        /// 壓力表頭  壓力值 單位(KPa)
        /// </summary>
        /// <returns></returns>
        public async Task<double> ASYN_P05_GetPressure(ushort portNo)
        {
            ushort addr = (ushort)((int)portNo * 1000 + 2);
            ushort[] value = await ReadHoldingRegistersAsync(addr, 1);
            uint Pdata = value[0];            
            double NPdata = Pdata >> 2;
            NPdata = NPdata * 0.003051944088;
    
            return NPdata;
        }

        public double P05_GetPressure(ushort portNo)
        {
            ushort addr = (ushort)((int)portNo * 1000 + 2);
            ushort[] value = ReadHoldingReg(addr, 1);
            uint Pdata = value[0];
            double NPdata = Pdata >> 2;
            NPdata = NPdata * 0.003051944088;

            return NPdata;
        }

        public double P10R_GetPressure(ushort portNo)
        {
            ushort addr = (ushort)((int)portNo * 1000 + 2);
            ushort[] value = ReadHoldingReg(addr, 1);
            uint Pdata = value[0];
            double NPdata = Pdata >> 2;
            NPdata = NPdata * 0.0061038881768;

            return NPdata;
        }


        /// <summary>
        /// festo 比例閥 控制
        /// </summary>
        /// <param name="portNo"></param>
        /// <param name="value"></param>
        public void PValveSetPressure(ushort portNo, ushort value)
        {
            ushort addr = (ushort)((int)portNo * 1000 + 50);
            WriteHoldingReg(addr, value);
        }

        /// <summary>
        ///  festo 比例閥 設定值讀取
        /// </summary>
        /// <param name="portNo"></param>
        /// <param name="value"></param>
        public async Task<ushort> ASYN_PValveGet_SetPressure(ushort portNo)
        {
            ushort addr = (ushort)((int)portNo * 1000 + 50);
            
            ushort[] tmp = await ReadHoldingRegistersAsync(addr, 1);
            
            return tmp[0];
        }

        /// <summary>
        ///  festo 比例閥 實際值讀取
        /// </summary>
        /// <param name="portNo"></param>
        /// <param name="value"></param>
        public async Task<ushort> ASYN_PValveGet_ActPressure(ushort portNo)
        {
            ushort addr = (ushort)((int)portNo * 1000 +2);
            ushort[] tmp = await ReadHoldingRegistersAsync(addr, 1);
            return tmp[0];
        }

        /// <summary>
        ///  festo 比例閥 設定值讀取
        /// </summary>
        /// <param name="portNo"></param>
        /// <param name="value"></param>
        public  ushort PValveGet_SetPressure(ushort portNo)
        {
            ushort addr = (ushort)((int)portNo * 1000 + 50);

            ushort[] tmp =  ReadHoldingReg(addr, 1);

            return tmp[0];
        }

        /// <summary>
        ///  festo 比例閥 實際值讀取
        /// </summary>
        /// <param name="portNo"></param>
        /// <param name="value"></param>
        public  ushort PValveGet_ActPressure(ushort portNo)
        {
            ushort addr = (ushort)((int)portNo * 1000 + 2);
            ushort[] tmp =  ReadHoldingReg(addr, 1);
            return tmp[0];
        }
    }
}
