﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Module_Interface;
using System.Windows.Forms;

namespace Powermeter_Ophir_Interface
{
    public enum sensorProperty { Range, Wavelength, Diffuser, Mode, Pulselength, Threshold, Filter, Trigger };

    public class Powermeter_Ophir : CommModule
    {
        private Dictionary<string, string> _iniDic;
        private OphirLMMeasurementLib.CoLMMeasurement _olmm;
        private Object serialNumbers;
        private int hDevice;
        private int channel = 0;
        public double measurementStr;


        public Powermeter_Ophir(string name) : base(name)
        {
            try
            {
                // Update _iniDic and private parameters
                _iniDic = this.GetIniDic();
                this.UpdatePrivateParams();
                _olmm = new OphirLMMeasurementLib.CoLMMeasurement();

            }
            catch
            {

            }
        }

        /// <summary>
        /// Desctructor
        /// </summary>
        ~Powermeter_Ophir()
        {
            Destruction();
        }

        private void Destruction()
        {
            // Write back ini file
            this.WriteIniFile(_iniDic);

            // Secure that the communication has been deinitialized or closed
            if (this.GetState() == SteadyState.Ready)
            {
                try
                {
                    this.Deinitialize();
                }
                catch (Exception)
                {

                }
            }
            if (this.GetState() == SteadyState.Idle)
            {
                try
                {
                    this.Close();
                }
                catch (Exception)
                {
                    throw;
                }
            }
        }
        #region Protected Override Methods
        protected override void UpdatePrivateParams()
        {
            try
            {

            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        protected override void DoConnect()
        {
            try
            {
                //搜尋USB裝置
                _olmm.ScanUSB(out serialNumbers);
                string[] snStr = (string[])serialNumbers;
                //OpenUSB
                _olmm.OpenUSBDevice(snStr[0], out hDevice);
                //裝置串流開始
                _olmm.StartStream(hDevice, channel);

              //  _olmm.DataReady += new OphirLMMeasurementLib._ICoLMMeasurementEvents_DataReadyEventHandler(this.DataReadyHandler);

            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        protected override void DoInitialize()
        {

        }

        protected override void DoDeinitialize()
        {

        }

        protected override void DoClose()
        {
            try
            {
                //_olmm.CloseAll();
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        #endregion

        #region Public Methods
        //public void GetProperty(object sender, sensorProperty prop, out Object options)
        public object GetProperty(object sender, sensorProperty prop)
        {
            try
            {
                this.CheckState(SteadyState.Idle, SteadyState.Ready);

                int nChannel = Convert.ToInt32(((Button)sender).Tag);

                int index = 0;

                object options = 0;

                switch (prop)
                {
                    case sensorProperty.Mode:
                        _olmm.GetMeasurementMode(hDevice, nChannel, out index, out options);
                        break;

                    case sensorProperty.Range:
                        _olmm.GetRanges(hDevice, nChannel, out index, out options);
                        break;

                    case sensorProperty.Wavelength:
                        _olmm.GetWavelengths(hDevice, nChannel, out index, out options);
                        break;

                    case sensorProperty.Diffuser:
                        _olmm.GetDiffuser(hDevice, nChannel, out index, out options);
                        break;

                    case sensorProperty.Pulselength:
                        _olmm.GetPulseLengths(hDevice, nChannel, out index, out options);
                        break;

                    case sensorProperty.Threshold:
                        _olmm.GetThreshold(hDevice, nChannel, out index, out options);
                        break;

                    case sensorProperty.Filter:
                        _olmm.GetFilter(hDevice, nChannel, out index, out options);
                        break;

                    case sensorProperty.Trigger:
                        _olmm.GetExtTrigOnOff(hDevice, nChannel, out index, out options);
                        break;

                    default:
                        break;
                }
                string[] _options = (string[])options;

                return _options[index];

            }
            catch (Exception ex)
            {
                throw ex;
            }

        }


        public void GetPowerStart()
        {
            if (_olmm != null && hDevice != 0)
            {
                _olmm.DataReady += this.DataReadyHandler;
            }
        }

        public void GetPowerStop()
        {
            if (_olmm != null)
            {
                _olmm.DataReady -= this.DataReadyHandler;
            }
        }



        public double GetPower()
        {
            try
            {
                object timeStampArray;
                object statusArray;
                object dataArray;

                // 確認狀態必須是 Idle 或 Ready
                this.CheckState(SteadyState.Idle, SteadyState.Ready);

                // 從裝置讀取數據
                _olmm.GetData(hDevice, channel, out dataArray, out timeStampArray, out statusArray);

                // 嘗試轉型成 double[]
                double[] dataArr = dataArray as double[];

                // 安全檢查：避免空陣列或 null
                if (dataArr == null || dataArr.Length == 0)
                {
                    return measurementStr = -1;
                }

                // 如果有多筆數據，可以取平均或最後一筆
                 measurementStr = dataArr.Average();   // 取平均
                //measurementStr = dataArr.Last();        // 取最新一筆

                // 檢查是否為零
                if (measurementStr == 0)
                    throw new Exception("Fail to Get Power.");

                return measurementStr;
            }
            catch (Exception ex)
            {
                // 這裡可以寫 log 或直接拋出
                throw new Exception("GetPower 發生錯誤：" + ex.Message, ex);
            }
        }

        //public double GetPower()
        //{
        //    try
        //    {
        //        object timeStampArray;
        //        object statusArray;
        //        object dataArray;

        //        this.CheckState(SteadyState.Idle, SteadyState.Ready);

        //        //System.Threading.Thread.Sleep(500);

        //        //讀取數據
        //        _olmm.GetData(hDevice, channel, out dataArray, out timeStampArray, out statusArray);

        //        //功率               
        //        double[] dataArr = (double[])dataArray;
        //        measurementStr = dataArr[0];

        //        if (measurementStr == 0)
        //            throw new Exception("Fail to Get Power.");
        //        return measurementStr;
        //    }
        //    catch (Exception ex)
        //    {
        //        throw ex;
        //    }

        //}
        void DataReadyHandler(int hDevice, int channel)
        {
            //讀取數據
            GetPower();
        }
        #endregion
    }
}
