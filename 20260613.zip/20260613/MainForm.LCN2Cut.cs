﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System;
using System.IO;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;
using ConfocalLaser_Interface;
using Aerotech.A3200.Status;
using System.Diagnostics;
using NCScriptParser_Interface;
using static NCScriptParser_Interface.NCScriptParser;
using System.Text.RegularExpressions;
using System.Timers;
using Aerotech.A3200;
using System.Runtime.InteropServices;
using System.Globalization;
using Aerotech.A3200.Exceptions;
using static ConfocalLaser_Interface.ConfocalLaser;
using Module_Interface;
using CHPT;
using Newtonsoft.Json;

using System.Drawing.Imaging;


namespace LaserProcess_LCH
{        /********
         * 要解除封鎖LCH2切禁用的UI互動介面   Enable_LCN_Mode=true
         * 配置檔要改成True     ConfigSystem.ini -> //ConnectSetting -> Powermeter =True
         * 氣壓要調到很小不然二切會髒不能用，所以氣壓異常要PASS
         * aerotech 1/2維補償檔要拿掉
         * CCD亮度為74 曝光時間1/60
         * 
         * 
         * 
         * ***************/

    public partial class MainForm
    {
        /// <summary>
        /// LCH的LCN2切模式總開關，手動於此將其改為True。(一/二維補償檔案要拿掉)
        /// </summary>
        const bool Enable_LCN_Mode = false;


        delegate void dGP_Relese();
        delegate void dDataUPLoad();

        Thread Xuan, DataUPLoad_send, _Auto_GH_DrawCenter, _Auto_FindHole, _Auto_GH_FindEdgeCenter, _Auto_GH_FindEdge_DrawCenter, _RotateDisk_Work, _AutoDwring, Thick_Test, Demo_Test, Demo_Test_2CUT, Thick_Test_Alarm, Thick_Test_2CUT, _Auto_GH_FindCenter, _GuideID, thread_CutFrame, thread_image_test, Thick_Test_hole, Demo_Test_RD, _AutoCutLayer, Aero_thMotionRun, thread_focus_Test, Autohole, Thick_Test_RD, thread_fixZ, _autofocus;
        /// <summary>
        /// 優化嘗試用來安全退出 "2切自動流程" 的旗標，放置於while(原先為true改為_isDemo_Test_2CUT)
        /// </summary>
        bool _isDemo_Test_2CUT = false;
        /// <summary>
        /// 優化嘗試用來安全退出 "打圖型" 流程的旗標，放置於while(原先為true改為_isAutoDwring)
        /// </summary>
        bool _isAutoDwring = false;
        /// <summary>
        /// 優化嘗試用來安全退出 "定位孔置中" 流程的旗標，放置於while(原先為true改為_isAuto_FindHole)
        /// </summary>
        bool _isAuto_FindHole = false;
        /// <summary>
        ///  優化嘗試用來安全退出 "自動對焦" 流程的旗標，放置於while(原先為true改為_isAuto_FindHole)
        /// </summary>
        bool _isautofocus = false;
        /// <summary>
        ///  優化嘗試用來安全退出 "測高" 流程的旗標，放置於while(原先為true改為_isThick_Test_2CUT)
        /// </summary>
        bool _isThick_Test_2CUT = false;
        /// <summary>
        ///  優化嘗試用來安全退出 "特徵搜尋" 流程的旗標，放置於while(原先為true改為_isthread_image_test)
        /// </summary>
        bool _isthread_image_test = false;
        /// <summary>
        ///  優化嘗試用來安全退出 "TCP上拋MES" 流程的旗標，放置於while(原先為true改為_isthread_image_test)
        /// </summary>
        bool _isDataUPLoad = false;

        #region 宣告
        string   CURRENT_time, MACHINE_NUMBER, AOUT, OPERATION, SCANPATH,     HIGHT_DIFFERENCE_first, HIGHT_DIFFERENCE_rework, TEMPLATE, SCORE, DEFOCUSVALUE, XORIGIN, YORIGIN, ZORIGIN,  TEMP2,  RH2,  ERROR_MESSAGE;
        /// <summary>
        /// 上拋資訊容器-加工進度百分比(不用加%)
        /// </summary>
        string SCHEDULE;
        /// <summary>
        /// 上拋資訊容器-機台運轉狀態(待料 = 0,生產  = 1,故障  = 2,保養 = 5,測試(製造部) = 11,實驗(工程或研發借機) = 12,廠務  = 13,關機  = 14)
        /// </summary>
        string STATUS;
        /// <summary>
        /// 上拋資訊容器-機台濕度
        /// </summary>
        string RH1;
        /// <summary>
        /// 上拋資訊容器-機台溫度(度C)
        /// </summary>
        string TEMP1;
        /// <summary>
        /// 上拋資訊容器-剩餘於加工時間(分鐘包含小數點第二位)
        /// </summary>
        string TIMELEFT;
        /// <summary>
        /// 上拋資訊容器-開始加工時間(年月日時分秒)
        /// </summary>
        string START_TIME;
        /// <summary>
        /// 上拋資訊容器-微孔總數
        /// </summary>
        string NUMBER_TOTAL;
        /// <summary>
        /// 上拋資訊容器-已加工微孔數
        /// </summary>
        string NUMBER_COMPLETIONS;
        /// <summary>
        /// 上拋資訊容器-未加工微孔數
        /// </summary>
        string NUMBER_REMAINING;
        /// <summary>
        /// 上拋資訊容器-設定功率(W)
        /// </summary>
        string SET_POWER;
        /// <summary>
        ///上拋資訊容器- 實際功率(W)
        /// </summary>
        string POWER;
        /// <summary>
        /// 上拋資訊容器-微孔平均加工時間(秒)
        /// </summary>
        string Pin_time;
        /// <summary>
        /// 上拋資訊容器-預計結束時間(年月日時分秒)
        /// </summary>
        string End_time;
        /// <summary>
        /// 上拋資訊容器-生產批號
        /// </summary>
        string LOTNO = "0";
        /// <summary>
        /// 上拋資訊容器-加工座標檔
        /// </summary>
        string CPATH ="0";
        /// <summary>
        /// 上拋資訊容器-加工進度百分比
        /// </summary>
        string Progress_Percentage ="";
        /// <summary>
        ///上拋資訊容器-氮氣壓力 (MPa)
        /// </summary>
        string N2pressure = "2.5";

        CHPT_TCP _TCP_DataUPLoad = new CHPT_TCP();


        /// 只計算一次預計完成時間
        /// </summary>
        bool endtimeflag;
        /// <summary>
        /// 儲存每一根針的加工時間(要算平均)
        /// </summary>
        List<double> pin_time_average = new List<double>();//不用限定範圍可一直儲存不同筆資料，(像似動態陣列)，資料筆數會一直向上加上去，儲存x座標位置

        /// <summary>
        /// 當前是否為LCN模式
        /// </summary>
        bool _isLCN = false;
        /// <summary>
        ///特徵搜尋失敗數量
        /// </summary>
        int image_error_count = 0;
        /// <summary>
        /// 是否開始讀取功率值
        /// </summary>
        bool _isReadPowerMeter = false;

        //[BM:高度異常保護]
        /// <summary>
        /// z軸移動檢查值
        /// </summary>
        double zlimit = -257.8;//舊平台-260
        /// <summary>
        /// 測高回傳值安全限制
        /// </summary>
        double thicknesslimit = 1000;//1000

        bool hight_Error_flag = false, hight_Error_flag_2CUT = false;
        double max = 0, min = 0;
        double max_2CUT = 0, min_2CUT = 0;

        string str;

        /// <summary>
        /// 是否已成功載入並解析加工檔案。
        /// </summary>
        bool ProcessFileRead_flag = false;
        double tk_value = 0;
        bool Flag_ORG = false;

        double A, B, PH_A, PH_B;

        double _powerToOutPowerGain = 21.4 * 0.94;//438206*1.17;//20210305
        double _powerToOutPowerOffset = 2.772;      //-1183.3*1.17;//20210305
        double _powerToPHOutPowerGain = 21.4 * 0.94;
        double _powerToPHOutPowerOffset = 2.772;
        double _powerToDegreeSlope = 0.009836;
        double _powerToDegreeOffset = 37.0262295;
        double _angle_A = 0.0152, _angle_B = 0.5;//0.0136
        double _powerToPHDegreeSlope = 0.009836;
        double _powerToPHDegreeOffset = 37.0262295;
        double _PHangle_A = 0.0152, _PHangle_B = 0.5;//0.0136
        decimal a_max = 90;
        decimal a_min = 30;

        /// <summary>
        /// 打圖形Carbide功率
        /// </summary>
        public string Carbide_MarkPower;
        /// <summary>
        /// GH 圓邊圓心定位流程旗標。<br/>
        /// 控制 <c>Auto_GH_FindEdgeCenter()</c> 的執行狀態與流程階段。<br/>
        /// 每個數值代表不同的流程步驟（如場景設定、量測、資料解析等），由 switch-case 控制流程進展。
        /// </summary>
        int GH_FindEdgeCenter_flag = 0;
        /// <summary>
		/// GH 圓邊圓心繪製流程旗標。<br/>
		/// 控制 <c>Auto_GH_FindEdge_DrawCenter()</c> 的執行狀態與流程階段。<br/>
		/// 每個數值代表不同的繪製步驟（如場景設定、量測、繪製完成等），由 switch-case 控制流程進展。
		/// </summary>
		int GH_FindEdge_DrawCenter_flag = 0;
        /// <summary>
		/// 分離盤每個加工點的旋轉角度間距，單位：度。<br/>
		/// 由 <c>360 / _RotateWorkNum</c> 計算得出。
		/// </summary>
		double _RotateWorkAngle = 0;

        /// <summary>
        /// 分離盤加工流程旗標，控制 <c>RotateDisk_Work()</c> 的執行狀態與流程階段。
        /// </summary>
        int _RotateWork_flag = 0;

        /// <summary>
        /// 左側取像是否完成。<br/>
        /// 由 <c>RotateDiskGrab_Flow(1)</c> 成功辨識後設定為 <c>true</c>。
        /// </summary>
        bool _RotateGrabFinish_L = false;

        /// <summary>
        /// 右側取像是否完成。<br/>
        /// 由 <c>RotateDiskGrab_Flow(2)</c> 成功辨識後設定為 <c>true</c>。
        /// </summary>
        bool _RotateGrabFinish_R = false;
        /// <summary>
        /// GH 圓心繪製流程旗標。
        /// </summary>
        int GH_DrawCenter_flag = 0;
        /// <summary>
        /// GH 圓心定位流程旗標。
        /// </summary>
        int GH_FindCenter_flag = 0;
        /// <summary>
		/// 導版加工流程旗標，控制 <c>Guide_ID()</c> 的執行狀態與流程階段。
		/// </summary>
		int _GuideID_Flag = 0;
        /// <summary>
        /// 撈框流程旗標，控制 cutframe() 狀態機的執行階段。
        /// </summary>
        int CutFrame_Flag = 0;
        //加工流程控制旗標與狀態
        /// <summary>
        /// 是否啟用 GCode 加工流程清單。
        /// </summary>
        bool run_gcode_list;
        /// <summary>
        /// RD 自動加工流程旗標，控制 <c>DEMO_TEST_P_RD()</c> 的執行狀態。
        /// </summary>
        int DEMO_flag_P_RD;
        /// <summary>
        /// 一切主流程啟動旗標。<br/>
        /// 當使用者啟動標準雷射加工流程（如 Demo、RD、原始切割）時，此旗標會設為 true，表示流程正在執行中。
        /// </summary>
        bool START_flag = false;
        //=========功率量測
        /// <summary>
        /// 程式設定之功率值百分比
        /// </summary>
        double laserPowerPct = 0;
        /// <summary>
        /// 實際量測之功率值
        /// </summary>
        double _OutputPower = 0.0;
        double PowerCheck_Ofs = 0;
        /// <summary>
        /// 2切自動流程功率補償錯誤次數
        /// </summary>
        int PowerError = 0;
        //=========功率量測

        //=========軸集合
        int[] axisIndexXY = { (int)MotionAxis.X, (int)MotionAxis.Y };
        /// <summary>
        /// 3軸集合
        /// </summary>
        int[] axisIndexXYZ = { (int)MotionAxis.X, (int)MotionAxis.Y, (int)MotionAxis.Z };

        //=========軸集合


        /// <summary>
        /// 實際量測功率（mW），由功率計取得。
        /// </summary>
        double outPower = 0;
        /// <summary>
        /// 電子鎖是否上鎖狀態
        /// </summary>
        bool _isDoorLock = false;
        /// <summary>
        /// 是否吸附狀態
        /// </summary>
        bool _isVacuum = false;


        double p_max = 2000;
        double p_min = 50;
        private const int _avgWindow = 1; //Unit: sec
        private int _avgSamples;
        private int _avgCount = 0;
        private double[] _samples;
        private const int _powerDisplayPeriod = 1; //Unit: sec
        private int _powerDisplaySamples;
        private int _powerDisplayCount = 0;
        private const double _powerCutoff = 0.000;   //Power cut-off threshold of ThorLabs PD power; Unit: mW
        private const double _powerStep = 0.005;    //Unit: mW
        private bool _flagScanResult = false;
        private string _strScanResult = "";
        private decimal _stepSize;
        private decimal _velocity;
        private decimal _acceleration;
        private decimal _positionStart;
        private decimal _positionEnd;
        private string _dirPath;
        private string _logDirPath;
        private bool _flagStop = false;
        /// <summary>
        /// Demo 模式中已處理的針點數量。
        /// </summary>
        int counter_pin_num = 0;
        int Counter = 0;
        /// <summary>
        /// 一切座標檔案中針點的總數量（對應 <c>tb_tip.Text</c> 層級）。<br/>
        /// 用於計算 <c>pin_pitch</c> 與 Group 分群。
        /// </summary>
        int pin_TotalNumber = 0;
        System.DateTime StartTime;
        /// <summary>
        /// Demo 模式中記錄的角度值，用於功率補償。
        /// </summary>
        double angle_register = 0;
        //狀態紀錄
        public Record_Update record_update = new Record_Update();
        /// <summary>
        /// 儲存小方框區域的厚度量測結果。<br/>
        /// 用於補償微小區域或特殊結構的厚度分析。
        /// </summary>
        double[] Thick_Array_SmallBox = new double[10000];
        /// <summary>
        /// 任務索引值，用於識別目前執行的任務。
        /// </summary>
        private int taskIndex;
        //測高後記錄
        /// <summary>
        /// 儲存一般厚度量測結果的陣列。<br/>
        /// 用於非 2CUT 模式下的標準厚度記錄與分析。
        /// </summary>
        double[] Thick_Array = new double[10000];

        /// <summary>
        /// 儲存厚度補償後的對稱陣列。<br/>
        /// 每筆厚度值會複製兩次，用於補償演算法與座標映射。
        /// </summary>
        double[] Thick_Array_sym = new double[10000];

        /// <summary>
        /// 儲存 2CUT 模式下的厚度量測結果。<br/>
        /// 資料由 Confocal 量測儀取得，並依座標順序排列。
        /// </summary>
        double[] Thick_Array_2CUT = new double[10000];

        /// <summary>
        /// 儲存厚度異常警示資料的二維陣列。<br/>
        /// 維度為 [區域編號, 點位編號]，用於記錄超出門檻的厚度值。
        /// </summary>
        double[,] Thick_Array_Alarm = new double[100, 100];
        //判斷針長設定值
        double[] Len_Set = new double[9];
        int[] Len_Range_Min = new int[9];
        int[] Len_Range_Max = new int[9];
        int Range_maxmum = 0;
        int Range_minmun = 0;

        TCP_IP_Client.TCPServerAP tcp1;
        string im_reciver, scene_num;
        string[] sub_im = new string[5];
        bool image_reciver_flag = false;
        /// <summary>
        /// 孔1的實際定位 X 座標（由使用者確認後儲存）。<br/>
        /// 用於座標轉換與補償計算的基準點。
        /// </summary>
        string str_X1;

        /// <summary>
        /// 孔2的實際定位 X 座標。<br/>
        /// 用於計算孔1→孔2的相對位移與旋轉角度。
        /// </summary>
        string str_X2;

        /// <summary>
        /// 孔3的實際定位 X 座標。<br/>
        /// 用於計算孔2→孔3的縮放比例與座標轉換。
        /// </summary>
        string str_X3;

        /// <summary>
        /// 孔4的實際定位 X 座標。<br/>
        /// 若使用四點定位或進階補償時可用。
        /// </summary>
        string str_X4;

        /// <summary>
        /// 孔1的實際定位 Y 座標。<br/>
        /// 搭配 str_X1 用於座標轉換基準。
        /// </summary>
        string str_Y1;

        /// <summary>
        /// 孔2的實際定位 Y 座標。<br/>
        /// 用於計算孔1→孔2的旋轉角度。
        /// </summary>
        string str_Y2;

        /// <summary>
        /// 孔3的實際定位 Y 座標。<br/>
        /// 用於計算孔2→孔3的縮放比例。
        /// </summary>
        string str_Y3;

        /// <summary>
        /// 孔4的實際定位 Y 座標。<br/>
        /// 若使用四點定位或進階補償時可用。
        /// </summary>
        string str_Y4;

        /// <summary>
        /// 孔1的實際定位 Z 座標。<br/>
        /// 用於厚度補償或 Z 軸定位基準。
        /// </summary>
        string str_Z1;
        /// <summary>
        /// 儲存目前程式執行狀態的文字描述，例如 "初始化中"、"執行中"、"錯誤" 等。
        /// 可用於 UI 顯示、日誌記錄或狀態判斷邏輯。
        /// </summary>
        string prog_status;


        //datetimes
        DateTime CurrTime;

        bool CCD_Connect_flag = false;
        /// <summary>
        /// 二切割流程啟動旗標。<br/>
        /// 用於控制二切割（2CUT）模式的流程啟動與執行狀態。
        /// </summary>
        bool START_flag_2CUT = false;

        /// <summary>
        /// 測高旗標(警報流程)
        /// </summary>
        int Thick_flag_Alarm = 0;
        /// <summary>
        /// Demo 模式流程旗標，用於控制雷射加工流程狀態。
        /// </summary>
        int DEMO_flag_P = 0;
        /// <summary>
        /// 自動對焦流程步進旗標
        /// </summary>
        int AT_focus_flag = 0;
        int _AutoDwring_flag = 0;
        bool Laser_OK = false;
        /// <summary>
        /// 測高旗標(正常流程)
        /// </summary>
        int Thick_flag = 0;
        int Run_flag_1 = 0, DEMO_flag = 0;
        /// <summary>
        ///  變焦試打流程旗標，用於控制流程狀態。
        /// </summary>
        int FocusTest_flag = 0;
        /// <summary>
        /// Z 補償流程旗標，用於控制流程狀態。
        /// </summary>
        int fixZ_flag = 0;
        /// <summary>
        /// 單針切割流程旗標，用於控制 Auto_CutLayer 狀態機的執行階段。
        /// </summary>
        int _AutoCutLyer_flag = 0;

        /// <summary>
        /// RD 厚度量測流程旗標，控制 <c>Thick_Test_Array_RD()</c> 的執行狀態。
        /// </summary>
        int Thick_flag_RD;

        /// <summary>
        /// 厚度補償目前執行的 X/Y 向索引（孔位區域）。
        /// </summary>
        int fixZ_i_hole_x, fixZ_i_hole_y;

        /// <summary>
        /// 厚度補償總點數（X/Y 向）與總數量（X × Y）（孔位區域）。
        /// </summary>
        int fixZ_num_x_hole, fixZ_num_y_hole, fixZ_totalnum_hole;

        /// <summary>
        /// 厚度量測結果（mm）與點距（mm）（孔位區域）。
        /// </summary>
        double fixZ_hight_hole, fixZ_pitch_hole;

        /// <summary>
        /// 厚度補償流程旗標（孔位區域），控制 <c>FixZ_Hole()</c> 的執行狀態。
        /// </summary>
        int fixZ_flag_hole;

        /// <summary>
        /// 厚度量測流程旗標，控制 <c>Thick_Test_Array_hole()</c> 的執行狀態。
        /// </summary>
        int Thick_flag_hole;

        /// <summary>
        /// 自動導孔加工流程旗標，控制 <c>Auto_Array_hole()</c> 的執行狀態。
        /// </summary>
        int Autohole_flag;

        /// <summary>
        /// 自動導孔功率補償錯誤計數器。
        /// </summary>
        int Autohole_PPerror;

        /// <summary>
        /// 是否已成功載入厚度量測加工檔案。
        /// </summary>
        bool ProcessFileRead_flag_PH;

        /// <summary>
        /// 厚度量測目前執行的點位索引與計數器。
        /// </summary>
        int tkn_i_hole, count_hole;

        /// <summary>
        /// 厚度量測目前執行的 Z 陣列索引與總點數。
        /// </summary>
        int ArrayZ_i_hole, hole_number;

        /// <summary>
        /// 厚度補償已完成點數（孔位區域）。
        /// </summary>
        int fixZ_hole_count;

        /// <summary>
        /// 補償流程旗標與加工層級設定（其他區域）。
        /// </summary>
        int fixZ_flag_other, layer_other_set;

        /// <summary>
        /// 控制器物件，用於與硬體控制器進行通訊。
        /// </summary>
        private Controller myController;
        /// <summary>
        /// 各軸是否完成回原點（Home）動作。
        /// </summary>
        bool HOME_X = false, HOME_Y = false, HOME_Z = false;
        /// <summary>
        /// 是否所有軸完成回原點（Home）動作。
        /// </summary>
        bool Home = false;
        /// <summary>
        /// 各軸是否啟用（Enable），通常用於馬達驅動器的使能狀態。
        /// </summary>
        bool En_X = false, En_Y = false, En_Z = false;
        /// <summary>
        /// 是否所有軸都啟用。
        /// </summary>
        bool En = false;
        /// <summary>
        /// 各軸是否已到達目標位置。（InPosition）
        /// </summary>
        bool Motion_X = false, Motion_Y = false, Motion_Z = false;
        /// <summary>
        /// 各軸的極限開關狀態（正向與負向），用於安全保護。
        /// </summary>
        bool Limit_XP, Limit_XN, Limit_YP, Limit_YN, Limit_ZP, Limit_ZN;
        /// <summary>
        /// 控制軸狀態監控執行緒是否啟用。
        /// </summary>
        bool Thread_Enabled = true;
        /// <summary>
        /// 儲存 該軸 移動至絕對位置座標。<br/>
        /// </summary>
        double ABS_X = 0, ABS_Y = 0, ABS_Z = 0;
        /// <summary>
        /// 儲存各軸的移動距離（相對位置）。
        /// </summary>
        double Distance_X = 0, Distance_Y = 0, Distance_Z = 0;
        /// <summary>
        /// 儲存各軸的移動速度。
        /// </summary>
        double Speed_X = 0, Speed_Y = 0, Speed_Z = 0;
        /// <summary>
        /// 儲存各軸的原始位置（例如啟動時的位置或回原點前的位置）。
        /// </summary>
        double Original_X = 0, Original_Y = 0, Original_Z = 0;
        /// <summary>
        /// 是否允許 該軸 執行移動命令。<br/>
        /// </summary>
        bool Allow_X = false, Allow_Y = false, Allow_Z = false;


        //二切NG針
        string NG2Cut_FilePath = "";
        private List<bool> NG2Cut = new List<bool>();

        /// <summary>
        /// 定義系統中可儲存的最大座標點數量。<br/>
        /// 用於初始化座標相關陣列的第一維大小。
        /// </summary>
        public const int total_point = 50;

        /// <summary>
        /// 定義每個座標點的軸數（X, Y, Z）。<br/>
        /// 用於初始化座標陣列的第二維大小。
        /// </summary>
        public const int total_axis = 3;
        /// <summary>
        /// 系統所有基準點位與校正參數儲存陣列
        /// </summary>
        /// <remarks>
        /// <para>point_position[Row(功能點位),Col(軸編號)]</para>
        /// <para>Row 意義對照：</para>
        /// <para>　　0~8　:  加工原點位置 ~ 點位9</para>
        /// <para>　　18　 : 正極限位置</para>
        /// <para>　　19　 : 負極限位置</para>
        /// <para>　　20　 : 雷射 - CCD 相機相對位置 (X,Y)</para>
        /// <para>　　21　 : 雷射 - 測距儀相對位置 (X,Y)</para>
        /// <para>　　22[0]: 雷射加工高度</para>
        /// <para>　　22[1]: CCD 對焦高度</para>
        /// <para>　　22[2]: 測距儀高度</para>
        /// <para>　　23[0]: 2切測高偏移</para>
        /// <para>　　23[1]: 2切特徵到中心偏移</para>
        /// <para>　　23[2]: 2切特徵到針尾偏移</para>
        /// <para>　　24~27: 定位孔1 ~ 定位孔4 (X,Y)</para>
        /// <para>　　28　 : 雷射功率校正參數 (A,B)</para>
        /// <para>　　33[0]: 2切 X 整體補償值</para>
        /// <para>　　33[1]: 2切 Y 整體補償值</para>
        /// <para>　　34　 : NS 短間距 2切參數</para>
        /// <para>　　39　 : BR 短間距 2切參數</para>
        /// <para>　　40　 : NS Align 2切參數</para>
        /// <para>　　41　 : BR Align 2切參數</para>
        /// <para>　　35　 : 雷射角度補償 (斜率、補正值)</para>
        /// <para>　　36　 : 雷射角度極限 (上限、下限)</para>
        /// <para>　　37　 : 雷射功率極限 (上限、下限)</para>
        /// <para>　　38[0]: 二切圖形旋轉角度</para>
        /// <para>　　42　 : 導版雷射角度補償</para>
        /// <para>　　43　 : 導版雷射功率校正 (A,B)</para>
        /// <para>　　44[0]: 導版雷射高度設定</para>
        /// </remarks>
        public static string[,] point_position = new string[total_point, total_axis];

        //檔案
        string[] process_arry = new string[10000];
        string[] process_X = new string[10000];
        string[] process_Y = new string[10000];
        string[] process_Z = new string[10000];
        string[] process_Layer = new string[10000];
        //2cut
        /// <summary>
        /// 讀取出座標檔所有資訊 
        /// </summary>
        string[] process_arry_2CUT = new string[10000];

        /// <summary>
        /// 讀取出座標檔 第1直行的資訊，x座標
        /// </summary>
        string[] process_X_2CUT = new string[10000];

        /// <summary>
        /// 讀取出座標檔 第2直行的資訊，y座標
        /// </summary>
        string[] process_Y_2CUT = new string[10000];
        /// <summary>
        /// 讀取出座標檔 第3直行的資訊，z座標
        /// </summary>
        string[] process_Z_2CUT = new string[10000];
        /// <summary>
        /// 讀取出座標檔 第4直行的資訊，圖層
        /// </summary>
        string[] process_Layer_2CUT = new string[10000];

        string[] process_compensateZ = new string[10000];
        string[] process_compensateZ_2CUT = new string[10000];
        //檔案_厚度測試
        string[] pin_X = new string[10000];
        string[] pin_Y = new string[10000];
        string[] pin_Z = new string[10000];
        string[] tkn_X = new string[10000];
        string[] tkn_Y = new string[10000];
        string[] holeS_X = new string[10000];
        string[] holeS_Y = new string[10000];
        //2CUT
        /// <summary>
        /// 每個針區的特徵位置 x座標
        /// </summary>
        string[] pin_X_2CUT = new string[30000];
        /// <summary>
        /// 每個針區的特徵位置 y座標
        /// </summary>
        string[] pin_Y_2CUT = new string[30000];
        string[] pin_Z_2CUT = new string[30000];
        /// <summary>
        /// 儲存2切座標檔中奇數欄位x座標
        /// </summary>
        string[] tkn_X_2CUT = new string[10000];
        /// <summary>
        /// 儲存2切座標檔中奇數欄位x座標
        /// </summary>
        string[] tkn_Y_2CUT = new string[10000];
        string[] holeS_X_2CUT = new string[30000];
        string[] holeS_Y_2CUT = new string[30000];
        //特徵
        /// <summary>
        /// 儲存座標檔中每一根針x座標，也就是特徵位置
        /// </summary>
        string[] simple_X = new string[10000];
        /// <summary>
        /// 儲存座標檔中每一根針y座標，也就是特徵位置
        /// </summary>
        string[] simple_Y = new string[10000];
        //方框辨識特徵
        string[] Smallbox_X = new string[10000];
        string[] Smallbox_Y = new string[10000];



        System.DateTime currentTime, SaveTime, LogTime, time_srever;

        /// <summary>
        /// 檔案中孔1至孔2的距離（X方向），用於計算 X 軸縮放比例。<br/>
        /// 單位為 mm，預設值為 1 以避免除以零。
        /// </summary>
        double r_file_X = 1;

        /// <summary>
        /// 檔案中孔2至孔3的距離（Y方向），用於計算 Y 軸縮放比例。<br/>
        /// 單位為 mm，預設值為 1 以避免除以零。
        /// </summary>
        double r_file_Y = 1;

        /// <summary>
        /// 實際機台上孔1至孔2的距離（X方向），用於計算 X 軸縮放比例。<br/>
        /// 由使用者實際定位座標計算得出。
        /// </summary>
        double r_axis_X = 1;

        /// <summary>
        /// 實際機台上孔2至孔3的距離（Y方向），用於計算 Y 軸縮放比例。<br/>
        /// 由使用者實際定位座標計算得出。
        /// </summary>
        double r_axis_Y = 1;


        /// <summary>
        /// 二切座標檔案中針點的總數量。<br/>
        /// 用於 2CUT 模式的厚度補償與加工流程。
        /// </summary>
        int pin_TotalNumber_2CUT = 0;

        /// <summary>
        /// 二切厚度量測點的總數量。<br/>
        /// 對應 <c>tkn_X/Y_2CUT</c> 陣列，用於 Confocal 測高。
        /// </summary>
        int tkn_TotalNumber_2CUT = 0;

        /// <summary>
        /// 二切小樣特徵點的總數量。<br/>
        /// 用於特徵辨識或簡化加工流程（如 <c>simple_X/Y_2CUT</c>）。
        /// </summary>
        int small_TotalNumber_2CUT = 0;


        /// <summary>
        /// PRR/LCN 探針補償資料結構實例，用於儲存從檔案讀取的補償座標、針點數量與相關設定。
        /// 此物件會在載入 PRR/LCN 檔案後被初始化並填入解析結果，供後續厚度補償或座標轉換流程使用。
        /// </summary>
        private N_PRRLCN n_PRR_List = new N_PRRLCN();

        //座標轉換與旋轉參數
        /// <summary>
        /// X 軸縮放比例，用於座標轉換校正。
        /// </summary>
        double scale_X = 1;

        /// <summary>
        /// Y 軸縮放比例，用於座標轉換校正。
        /// </summary>
        double scale_Y = 1;

        /// <summary>
        /// 座標旋轉角度（弧度），由孔位計算得出。
        /// </summary>
        double theta = 0;

        //厚度量測流程控制（2CUT）
        /// <summary>
        /// 2CUT 厚度量測流程旗標，用於控制流程狀態。
        /// </summary>
        int Thick_flag_2CUT = 0;

        /// <summary>
        /// 目前處理的厚度針點索引。
        /// </summary>
        int tkn_i_2CUT = 0;

        /// <summary>
        /// 已處理的厚度針點數量。
        /// </summary>
        int count_2CUT = 0;

        /// <summary>
        /// 小框厚度量測目前索引。
        /// </summary>
        int tkn_i_smallbox = 0;

        /// <summary>
        /// 小框厚度量測已處理數量。
        /// </summary>
        int count_smallbox = 0;

        /// <summary>
        /// 是否發生厚度變異（2CUT 模式），用於補償判斷。
        /// </summary>
        bool thick_variate_flag_2CUT = false;

        //檔案與流程狀態
        /// <summary>
        /// 是否已成功載入 2CUT 加工座標檔。
        /// </summary>
        bool ProcessFileRead_flag_2CUT = false;

        /// <summary>
        /// 每組區域內的針數，用於分組與補償計算。
        /// </summary>
        int ReginPinNum = 0;

        /// <summary>
        /// 特徵點總數量，用於影像比對與座標轉換。
        /// </summary>
        int Sym_TotalNumber = 0;

        /// <summary>
        /// 2CUT 模式下的針點間距。
        /// </summary>
        double pin_pitch_2CUT = 0;

        //影像比對流程控制
        /// <summary>
        /// 影像流程旗標，用於控制特徵搜尋流程狀態。
        /// </summary>
        int image_flag = 0;

        /// <summary>
        /// 目前處理的影像索引。
        /// </summary>
        int image_i = 0;

        /// <summary>
        /// CCD 回傳錯誤次數。
        /// </summary>
        int CCD_error = 0;

        /// <summary>
        /// CCD 重試次數。
        /// </summary>
        int CCD_retry = 0;

        /// <summary>
        /// CCD 連續錯誤次數，用於跳過或中止流程。
        /// </summary>
        int CCD_error_conti = 0;

        /// <summary>
        /// 影像比對錯誤總數。
        /// </summary>
        int image_error_num = 0;
        /// <summary>
        /// 影像比對正確數。
        /// </summary>
        int image_ok_num = 0;


        //探針座標與誤差記錄
        /// <summary>
        /// 區域補償後的探針頭部 X 座標陣列。
        /// </summary>
        double[] HeadPOS_X_Regin = new double[3000];

        /// <summary>
        /// 區域補償後的探針頭部 Y 座標陣列。
        /// </summary>
        double[] HeadPOS_Y_Regin = new double[3000];

        /// <summary>
        /// 探針頭部 X 座標陣列。
        /// </summary>
        double[] HeadPOS_X = new double[5000];

        /// <summary>
        /// 探針頭部 Y 座標陣列。
        /// </summary>
        double[] HeadPOS_Y = new double[5000];

        /// <summary>
        /// 探針尾端 X 座標陣列。
        /// </summary>
        double[] TipPOS_X = new double[5000];

        /// <summary>
        /// 探針尾端 Y 座標陣列。
        /// </summary>
        double[] TipPOS_Y = new double[5000];

        /// <summary>
        /// 單點影像比對結果標記（1=成功, -1=失敗）。
        /// </summary>
        double[] image_error_flag = new double[3000];

        /// <summary>
        /// 全域影像比對結果標記（1=成功, -1=失敗）。
        /// </summary>
        double[] image_error_all = new double[5000];

        //CCD 回傳座標與補償參數
        /// <summary>
        /// CCD 回傳的 X 偏移量（mm）。
        /// </summary>
        double X_CCD;

        /// <summary>
        /// CCD 回傳的 Y 偏移量（mm）。
        /// </summary>
        double Y_CCD;

        /// <summary>
        /// X 軸補償公式係數 A。
        /// </summary>
        double coe_A;

        /// <summary>
        /// X 軸補償公式係數 B。
        /// </summary>
        double coe_B;

        /// <summary>
        /// X 軸補償偏移量。
        /// </summary>
        double deltaX;

        /// <summary>
        /// 成功影像比對次數。
        /// </summary>
        int image_OK;

        /// <summary>
        /// 失敗影像比對次數。
        /// </summary>
        int image_NG;

        /// <summary>
        /// 預期廠景編號，用於比對 CCD 回傳值。
        /// </summary>
        double scene_num_jud = 9;

        /// <summary>
        /// 加工分組編號。
        /// </summary>
        int group;

        /// <summary>
        /// CCD 回傳的廠景識別碼（如 EXR,2）。
        /// </summary>
        string detect_num;

        /// <summary>
        /// 暫存針長值，用於補償計算。
        /// </summary>
        double Len_Temp;

        /// <summary>
        /// 影像比對結束索引。
        /// </summary>
        int image_END;

        //小框座標與誤差記錄
        /// <summary>
        /// 小框目前處理索引。
        /// </summary>
        int smallbox_i = 0;

        /// <summary>
        /// 小框 X 座標陣列。
        /// </summary>
        double[] Smallbox_PosX = new double[1000];

        /// <summary>
        /// 小框 Y 座標陣列。
        /// </summary>
        double[] Smallbox_PosY = new double[1000];

        /// <summary>
        /// 小框比對錯誤總數。
        /// </summary>
        int Smallbox_error_num = 0;

        /// <summary>
        /// 小框比對結果標記（1=成功, -1=失敗）。
        /// </summary>
        double[] Smallbox_error_flag = new double[1000];

        //2CUT 加工流程控制
        /// <summary>
        /// 2CUT 加工流程旗標，用於控制 DEMO_TEST_2CUT 狀態機。
        /// </summary>
        int DEMO_flag_2CUT = 0;

        /// <summary>
        /// 目前處理的針點索引（頭部）。
        /// </summary>
        int process_2CUT_i = 0;

        /// <summary>
        /// 目前處理的針點索引（尾部）。
        /// </summary>
        int process_2CUT_TIP_i = 0;

        /// <summary>
        /// 加工結束索引（尾部）。
        /// </summary>
        int process_2CUT_END = 0;

        /// <summary>
        /// 加工結束索引（尾端）。
        /// </summary>
        int process_2CUT_TIP_END = 0;

        /// <summary>
        /// 小框加工目前索引。
        /// </summary>
        int process_smallbox_i = 0;

        /// <summary>
        /// 小框加工 NG 數量。
        /// </summary>
        int process_smallbox_ng = 0;

        /// <summary>
        /// 最終功率補償後的輸出功率值。
        /// </summary>
        double outPowerSend;

        /// <summary>
        /// 儲存功率計量測值，單位W
        /// </summary>
        List<double> OutputPower = new List<double>();//不用限定範圍可一直儲存不同筆資料，(像似動態陣列)，資料筆數會一直向上加上去


        #endregion

        #region method
        private void data_jason()
        {
            double setpower;
            if (double.TryParse(txt_SetPower_2.Text, out setpower)) //嘗試將 txt_SetPower_2.Text 轉成 double，失敗則設為 0。
            {

            }
            else
            {
                setpower = 0;
            }

            
            //DateTime dt_max = DateTime.Parse(DateTime.Now.ToString("00:00:00")).AddSeconds((Convert.ToDouble(lb_TimeR.Text) * 60)); //獲取剩餘的加工時間
            //String dt_max1 = string.Format("{0: HH:mm:ss}", dt_max);   //将转换的datetime对象格式化

            //TCP_Sever.DATA_Server = "<ru03t86>" + "CURRENT_time:" + time_srever.ToString("HH:mm:ss.fff") + " ," + "MACHINE_NUMBER:LCX " + "," + "SET_POWER:" + (setpower / 1000).ToString("F3") + "," + "POWER:" + (outPowerSend / 1000).ToString("F3") + "," + "AOUT:" + currentPosition.ToString("F3") + "," + "OPERATION:" + operation + "," + "CPATH:" + TB_LoadFilePath_2CUT.Text + "," + "SCANPATH:" + Path_SCAN + "," + "START_TIME:" + StartTime.ToString("HH:mm:ss.fff") + "," + "NUMBER_TOTAL:" + textBox_HoleNum.Text + "," + "NUMBER_COMPLETIONS:" + textBox_HoldDone.Text + "," + "NUMBER_REMAINING:" + textBox_HoleRemain.Text + "," + "SCHEDULE:" + ((Convert.ToDouble(textBox_HoldDone.Text) / Convert.ToDouble(textBox_HoleNum.Text)) * 100).ToString("F0") + "," + "TIMELEFT:" + dt_max1 + "," + "HIGHT_DIFFERENCE_first:" + (max - min).ToString("F3") + "," + "HIGHT_DIFFERENCE_rework:" + (max_2CUT - min_2CUT).ToString("F3") + "," + "TEMPLATE:null" + "," + "SCORE:null" + "," + "DEFOCUSVALUE:0.000+" + "," + "XORIGIN:" + str_X1 + "," + "YORIGIN:" + str_Y1 + "," + "ZORIGIN:" + str_Z1 + "," + "TEMP1:" + txt_Temp1.Text + "," + "TEMP2:" + txt_Temp2.Text + "," + "RH1:" + txt_Humid1.Text + "," + "RH2:" + txt_Humid2.Text + "," + "STATUS:" + status_TCP.ToString() + "," + "ERROR_MESSAGE:" + "NULL" + "</ru03t86>";
            CURRENT_time = time_srever.ToString("HH:mm:ss.fff");//當前時間
            AOUT = "0.000";//currentPosition.ToString("F3");
            OPERATION = operation;
            if (operation == "First")
            {
                //CPATH = TB_LoadFilePath.Text;
            }
            else if (operation == "Rework")
            {
               // CPATH = TB_LoadFilePath_2CUT.Text;
            }

            SCANPATH = "0.00";//Path_SCAN;

            //LOTNO = tb_LaserDeskText.Text;


            if (!string.IsNullOrEmpty(txt_AutoMode_LotMumber.Text))
            {
                CPATH = txt_AutoMode_FileName.Text;
            }
            else
            {
                CPATH = "0.00";
            }

            if (!string.IsNullOrEmpty(Progress_Percentage))
            {
                SCHEDULE = Progress_Percentage;//((Convert.ToDouble(textBox_HoldDone.Text) / Convert.ToDouble(textBox_HoleNum.Text)) * 100).ToString("F0");
            }
            else
            {
                SCHEDULE = (0).ToString("F0");

                
            }

            if (!string.IsNullOrEmpty(txt_System_ProcessZone_Temp.Text)&& !string.IsNullOrEmpty(txt_System_ProcessZone_Humid.Text))//檢查有沒有值
            {
                //============LCH設備資訊上拋==================
                TEMP1 = txt_System_ProcessZone_Temp.Text;//溫度
                RH1 = txt_System_ProcessZone_Humid.Text;//濕度
              //============LCH設備資訊上拋==================


                TEMP2 = txt_System_LaserController_Temp.Text;
                RH2 = txt_System_LaserController_Humid.Text;

            }
            else//若沒有值則發null
            {
                TEMP2 = "null";
                RH2 = "null";

                TEMP1 = "null";
                RH1 = "null";

            }

            HIGHT_DIFFERENCE_first = (max - min).ToString("F3");
            HIGHT_DIFFERENCE_rework = (max_2CUT - min_2CUT).ToString("F3");
            TEMPLATE = "null";
            SCORE = "null";
            DEFOCUSVALUE = "0.000";
            XORIGIN = str_X1;
            YORIGIN = str_Y1;
            ZORIGIN = str_Z1;
            STATUS = $"{_CHPT_MES.Machine_State}";//status_TCP.ToString();
            ERROR_MESSAGE = "NULL";




            //============LCH設備資訊上拋==================
            TIMELEFT = lb_TimeR.Text;// dt_max1//lb_TimeR.Text;// 剩餘加工時間(分鐘包含小數點第二位)

            SET_POWER = SET_W.ToString("F3");
            POWER = W.ToString("F3");
            End_time = lb_EndTime.Text;//預計完成時間 年月日時分秒
            Pin_time = lb_Microhole_Time.Text;//lb_PinTime.Text;//平均每Pin時間
            START_TIME = lb_StartTime.Text;
            MACHINE_NUMBER = EquipmentNo;//機台名稱


            ////=======================更改上拋資訊更換成只上報微孔
            NUMBER_TOTAL = Microhole_Total.ToString();//微孔總數
            NUMBER_COMPLETIONS = Microhole_Done.ToString();//已完成微孔
            NUMBER_REMAINING = Microhole_Remain.ToString();//未完成微孔

            /*以下為原先所有加工項目的內容*/
            //NUMBER_TOTAL = _NbrOfProcess_Total.ToString();//加工總數
            //NUMBER_COMPLETIONS = _NbrOfProcess_Done.ToString();//已完成加工項目     
            //NUMBER_REMAINING = (_NbrOfProcess_Total - _NbrOfProcess_Done).ToString();//未完成項目

            ////=======================更改上拋資訊更換成只上報微孔
            if (!string.IsNullOrEmpty(txt_AutoMode_LotMumber.Text))
            {
                LOTNO = txt_AutoMode_LotMumber.Text;//批號
            }
            else
            {
                LOTNO = "0.00";
            }



            //============LCH設備資訊上拋==================


            StringWriter sw = new StringWriter();// StringWriter是一個記憶體中的文字緩衝器，用來暫存 JSON 內容。
            JsonTextWriter writer = new JsonTextWriter(sw);//  建立JsonTextWriter負責把資料寫成合法的 JSON 格式。

            writer.WriteStartObject();//開始建立物件內的屬性及其對應的值                                                                                      
            //屬性名稱                                               //屬性的值
            writer.WritePropertyName("CURRENT_time"); writer.WriteValue(CURRENT_time);
            writer.WritePropertyName("MACHINE_NUMBER"); writer.WriteValue(MACHINE_NUMBER);
            writer.WritePropertyName("SET_POWER"); writer.WriteValue(SET_POWER);
            writer.WritePropertyName("POWER"); writer.WriteValue(POWER);
            writer.WritePropertyName("AOUT"); writer.WriteValue(AOUT);
            writer.WritePropertyName("OPERATION"); writer.WriteValue(OPERATION);
            writer.WritePropertyName("CPATH"); writer.WriteValue(CPATH);
            writer.WritePropertyName("SCANPATH"); writer.WriteValue(SCANPATH);
            writer.WritePropertyName("START_TIME"); writer.WriteValue(START_TIME);
            writer.WritePropertyName("NUMBER_TOTAL"); writer.WriteValue(NUMBER_TOTAL);
            writer.WritePropertyName("NUMBER_COMPLETIONS"); writer.WriteValue(NUMBER_COMPLETIONS);
            writer.WritePropertyName("NUMBER_REMAINING"); writer.WriteValue(NUMBER_REMAINING);
            writer.WritePropertyName("SCHEDULE"); writer.WriteValue(SCHEDULE);
            writer.WritePropertyName("TIMELEFT"); writer.WriteValue(TIMELEFT);
            writer.WritePropertyName("HIGHT_DIFFERENCE_first"); writer.WriteValue(HIGHT_DIFFERENCE_first);
            writer.WritePropertyName("HIGHT_DIFFERENCE_rework"); writer.WriteValue(HIGHT_DIFFERENCE_rework);
            writer.WritePropertyName("TEMPLATE"); writer.WriteValue(TEMPLATE);
            writer.WritePropertyName("SCORE"); writer.WriteValue(SCORE);
            writer.WritePropertyName("DEFOCUSVALUE"); writer.WriteValue(DEFOCUSVALUE);
            writer.WritePropertyName("XORIGIN"); writer.WriteValue(XORIGIN);
            writer.WritePropertyName("YORIGIN"); writer.WriteValue(YORIGIN);
            writer.WritePropertyName("ZORIGIN"); writer.WriteValue(ZORIGIN);
            writer.WritePropertyName("TEMP1"); writer.WriteValue(TEMP1);
            writer.WritePropertyName("TEMP2"); writer.WriteValue(TEMP2);
            writer.WritePropertyName("RH1"); writer.WriteValue(RH1);
            writer.WritePropertyName("RH2"); writer.WriteValue(RH2);
            writer.WritePropertyName("STATUS"); writer.WriteValue(STATUS);
            writer.WritePropertyName("ERROR_MESSAGE"); writer.WriteValue(ERROR_MESSAGE);
            writer.WritePropertyName("LOTNO"); writer.WriteValue(LOTNO);

            writer.WritePropertyName("End_time"); writer.WriteValue(End_time);
            writer.WritePropertyName("Pin_time"); writer.WriteValue(Pin_time);

          //  writer.WritePropertyName("Progress_Percentage"); writer.WriteValue(Progress_Percentage);
            writer.WritePropertyName("N2pressure"); writer.WriteValue(N2pressure);
            writer.WritePropertyName("Layer"); writer.WriteValue(UD_or_LD);

            
               

            writer.WriteEndObject();   //結束建立物件內的屬性及其對應的值                                                                                 

            _TCP_DataUPLoad.Send(sw.ToString() + "\r");
            //_TCP.Send(sw.ToString() + "\r");

            // ==================== 檔案處理部分 ====================
            string fileName = DateTime.Now.ToString("yyyyMMdd") + "_Server.ini";
            string folderPath = Path.Combine(C_Path, "LCN_LOG", "Server");
            string fullFilePath = Path.Combine(folderPath, fileName);   // ← 關鍵：組合完整路徑

            // 確保資料夾存在（很重要！）
            if (!Directory.Exists(folderPath))
            {
                Directory.CreateDirectory(folderPath);
            }

            // 讀取現有內容
            List<string> lines = new List<string>();
            if (File.Exists(fullFilePath))
            {
                lines = File.ReadAllLines(fullFilePath).ToList();
            }

            // 新增一筆紀錄
            lines.Add("=== Record at " + DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss.fff") + " ===");
            lines.Add(sw.ToString());
            lines.Add(new string('-', 80));

            // 保留最新 20 筆（每筆 3 行）
            int maxLines = 20 * 3;
            if (lines.Count > maxLines)
            {
                lines = lines.Skip(lines.Count - maxLines).ToList();
            }

            // 覆寫檔案
            File.WriteAllLines(fullFilePath, lines);
            // ====================================================
        }


        /// <summary>
        /// 通用 Log 寫入方法
        /// </summary>
        /// <param name="subFolder">LCN_LOG 底下的子資料夾名稱 (例如: "Image", "2cut", "2thick", "Log")</param>
        /// <param name="fileName">檔案名稱 (例如: "_ImageSimplePos.ini")</param>
        /// <param name="content">要寫入的內容</param>
        private void WriteLog(string subFolder, string fileName, string content)
        {
            CurrTime = DateTime.Now;

            // 基礎路徑：Environment.CurrentDirectory + LCN_LOG + 子資料夾
            string logFolder = Path.Combine(C_Path, "LCN_LOG", subFolder);

            Directory.CreateDirectory(logFolder);   // 確保資料夾存在

            // 完整檔案路徑
            string fullPath = Path.Combine(logFolder, CurrTime.ToString("yyyyMMdd") + fileName);

            using (StreamWriter sw = new StreamWriter(fullPath, true))  // true = 附加模式
            {
                sw.WriteLine($"{CurrTime.ToString("yyyyMMddHHmmss")} ; {content}");
            }
        }
        /// <summary>
        /// 根據輸入的功率 (mW)，利用查表 + 線性插值計算對應的百分比
        /// </summary>
        private Tuple<double, bool> PowerSet(double mW)
        {
            // 如果字典沒有初始化或沒有資料，直接回傳失敗
            if (_ConfigPower._Power_Dict == null || _ConfigPower._Power_Dict.Count == 0)
                return Tuple.Create(-1.0, false);

            // 將字典依百分比 (Key) 排序
            var ordered = _ConfigPower._Power_Dict.OrderBy(kvp => kvp.Key).ToList();

            // 逐筆檢查，找出第一個比輸入功率大的點
            for (int i = 0; i < ordered.Count; i++)
            {
                if (mW <= ordered[i].Value) // 找到上界
                {
                    int upperPercent = ordered[i].Key;
                    double upperPower = ordered[i].Value;

                    int lowerPercent;
                    double lowerPower;

                    if (i == 0)
                    {
                        lowerPercent = 0;
                        lowerPower = 0;
                    }
                    else
                    {
                        lowerPercent = ordered[i - 1].Key;
                        lowerPower = ordered[i - 1].Value;
                    }

                    // 線性插值計算百分比
                    double percent = lowerPercent +
                        (mW - lowerPower) / (upperPower - lowerPower) * (upperPercent - lowerPercent);

                    // === 重點修改：讓回傳值以 0.5 為最小單位 ===
                    // 四捨五入到最接近的 0.5
                    percent = Math.Round(percent * 2.0) / 2.0;



                    return Tuple.Create(percent, true);
                }
            }

            // 輸入功率超過最大值
            return Tuple.Create(-1.0, false);
        }



        /// <summary>
        /// 給百分比算出多少mW，並轉換為W
        /// </summary>
        /// <param name="Percen"></param>
        /// <returns></returns>
        private Tuple<double, double> Percentage_conversion_W(double Percen)
        {
            // 如果字典沒有初始化或沒有資料，直接回傳失敗
            if (_ConfigPower._Power_Dict == null || _ConfigPower._Power_Dict.Count == 0)
                return Tuple.Create(-1.0, -1.0);

            double originalPercent = Percen;
            double roundedPercent = Math.Round(Percen * 2.0) / 2.0;

            if (roundedPercent < 0)
                roundedPercent = 0;

            var ordered = _ConfigPower._Power_Dict.OrderBy(kvp => kvp.Key).ToList();

            // 計算兩個功率 (單位：W)
            double w_rounded = GetPowerInW(roundedPercent, ordered);
            double w_original = GetPowerInW(originalPercent, ordered);

            return Tuple.Create(w_rounded, w_original);
        }

        // 內部計算函式（避免重複程式碼）
        private double GetPowerInW(double percent, List<KeyValuePair<int, double>> ordered)
        {
            if (percent <= 0)
                return 0.0;

            for (int i = 0; i < ordered.Count; i++)
            {
                if (ordered[i].Key >= percent)
                {
                    double upper_mW = ordered[i].Value;

                    // 剛好命中
                    if (ordered[i].Key == percent)
                        return upper_mW / 1000.0;

                    // 小於第一個點
                    if (i == 0)
                        return upper_mW / 1000.0;

                    // 線性插值
                    var lower = ordered[i - 1];
                    double mW = lower.Value +
                                (percent - lower.Key) / (ordered[i].Key - lower.Key) *
                                (upper_mW - lower.Value);

                    return mW / 1000.0;
                }
            }

            // 超過最大百分比
            return ordered.Last().Value / 1000.0;
        }


        private void SaveFullFormScreenshot() // ====================== 完整截取整個 Form 的方法 ======================
        {
            try
            {
                // 1. 建立儲存路徑： LCNimage \ 當天日期資料夾
                string basePath = Path.Combine(C_Path, "LCNimage");
                string todayFolder = DateTime.Now.ToString("yyyyMMdd");
                string saveDirectory = Path.Combine(basePath, todayFolder);

                if (!Directory.Exists(saveDirectory))
                {
                    Directory.CreateDirectory(saveDirectory);
                }

                // 2. 檔名使用 時分秒 + 毫秒，避免同一秒重複覆蓋
                string fileName = DateTime.Now.ToString("HHmmssfff") + ".png";
                string fullPath = Path.Combine(saveDirectory, fileName);

                // 3. 截取整個 Form（包含標題列、邊框）
                Rectangle bounds = this.Bounds;     // 這一行就是錯誤所在，要放在方法裡面

                using (Bitmap bmp = new Bitmap(bounds.Width, bounds.Height, PixelFormat.Format32bppArgb))
                {
                    using (Graphics g = Graphics.FromImage(bmp))
                    {
                        g.CopyFromScreen(bounds.Location, Point.Empty, bounds.Size);
                    }

                    bmp.Save(fullPath, ImageFormat.Png);
                }

                // 可選擇是否顯示訊息
                // MessageBox.Show($"完整表單截圖已儲存！\n{fullPath}", "成功", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            catch (Exception ex)
            {
                MessageBox.Show($"截圖失敗：{ex.Message}", "錯誤", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        /// <summary>
        /// 判斷目前是否有任何加工流程正在執行中。<br/>
        /// 若所有流程旗標皆為 0（表示未執行），且系統已啟用、已回原點、雷射連線正常，則回傳 false（表示未執行流程）。<br/>
        /// 否則回傳 true（表示有流程正在執行）。
        /// </summary>
        /// <returns>
        /// true：有流程執行中；false：系統空閒可啟動新流程。
        /// </returns>
        private Boolean motioning()
        {
            if (fixZ_flag_other == 0 && fixZ_flag_hole == 0 && Autohole_flag == 0 && Thick_flag_hole == 0 && En && Home && Thick_flag_RD == 0 && _AutoCutLyer_flag == 0 && Thick_flag == 0 && DEMO_flag == 0 && FocusTest_flag == 0 && fixZ_flag == 0 && Thick_flag_Alarm == 0 && Thick_flag_2CUT == 0 && DEMO_flag_P == 0 && AT_focus_flag == 0 && image_flag == 0 && DEMO_flag_2CUT == 0 && _AutoDwring_flag == 0  /*_rotationStage.GetIsHomed()&&*/)
            {
                return false;
            }
            else
            {
                return true;
            }
        }


        private Boolean Lenth_Set_Detect()
        {
            if (checkBox_Diff_Len.Checked)
            {
                //1
                if (cb_Len0.Checked)
                {
                    if (double.TryParse(tb_Len0.Text, out Len_Set[0]))
                    {
                        if (int.TryParse(tb_rangemin0.Text, out Len_Range_Min[0]))
                        {
                            if (int.TryParse(tb_rangemax0.Text, out Len_Range_Max[0]))
                            {
                                if (Len_Range_Min[0] > Len_Range_Max[0])
                                {
                                    MessageBox.Show("區域設定有誤");
                                    return false;
                                }
                                else
                                {
                                    Range_minmun = Len_Range_Min[0];
                                    //2
                                    if (cb_Len1.Checked)

                                    {
                                        if (double.TryParse(tb_Len1.Text, out Len_Set[1]))
                                        {

                                            if (int.TryParse(tb_rangemin1.Text, out Len_Range_Min[1]))
                                            {
                                                if (int.TryParse(tb_rangemax1.Text, out Len_Range_Max[1]))
                                                {
                                                    if (Len_Range_Min[1] > Len_Range_Max[1])
                                                    {
                                                        MessageBox.Show("區域設定有誤");
                                                        return false;
                                                    }
                                                    else
                                                    {
                                                        if (Len_Range_Min[1] - Len_Range_Max[0] != 1)
                                                        {
                                                            MessageBox.Show("區域設定非連續");
                                                            return false;
                                                        }
                                                        else
                                                        {

                                                            //3
                                                            if (cb_Len2.Checked)
                                                            {
                                                                if (double.TryParse(tb_Len2.Text, out Len_Set[2]))
                                                                {
                                                                    if (int.TryParse(tb_rangemin2.Text, out Len_Range_Min[2]))
                                                                    {
                                                                        if (int.TryParse(tb_rangemax2.Text, out Len_Range_Max[2]))
                                                                        {
                                                                            if (Len_Range_Min[2] > Len_Range_Max[2])
                                                                            {
                                                                                MessageBox.Show("區域設定有誤");
                                                                                return false;
                                                                            }
                                                                            else
                                                                            {
                                                                                if (Len_Range_Min[2] - Len_Range_Max[1] != 1)
                                                                                {
                                                                                    MessageBox.Show("區域設定非連續");
                                                                                    return false;
                                                                                }
                                                                                else
                                                                                {

                                                                                    //4
                                                                                    if (cb_Len3.Checked)
                                                                                    {
                                                                                        if (double.TryParse(tb_Len3.Text, out Len_Set[3]))
                                                                                        {
                                                                                            if (int.TryParse(tb_rangemin3.Text, out Len_Range_Min[3]))
                                                                                            {
                                                                                                if (int.TryParse(tb_rangemax3.Text, out Len_Range_Max[3]))
                                                                                                {
                                                                                                    if (Len_Range_Min[3] > Len_Range_Max[3])
                                                                                                    {
                                                                                                        MessageBox.Show("區域設定有誤");
                                                                                                        return false;
                                                                                                    }
                                                                                                    else
                                                                                                    {
                                                                                                        if (Len_Range_Min[3] - Len_Range_Max[2] != 1)
                                                                                                        {
                                                                                                            MessageBox.Show("區域設定非連續");
                                                                                                            return false;
                                                                                                        }
                                                                                                        else
                                                                                                        {

                                                                                                            //5
                                                                                                            if (cb_Len4.Checked)
                                                                                                            {
                                                                                                                if (double.TryParse(tb_Len4.Text, out Len_Set[4]))
                                                                                                                {
                                                                                                                    if (int.TryParse(tb_rangemin4.Text, out Len_Range_Min[4]))
                                                                                                                    {
                                                                                                                        if (int.TryParse(tb_rangemax4.Text, out Len_Range_Max[4]))
                                                                                                                        {
                                                                                                                            if (Len_Range_Min[4] > Len_Range_Max[4])
                                                                                                                            {
                                                                                                                                MessageBox.Show("區域設定有誤");
                                                                                                                                return false;
                                                                                                                            }
                                                                                                                            else
                                                                                                                            {
                                                                                                                                if (Len_Range_Min[4] - Len_Range_Max[3] != 1)
                                                                                                                                {
                                                                                                                                    MessageBox.Show("區域設定非連續");
                                                                                                                                    return false;
                                                                                                                                }
                                                                                                                                else
                                                                                                                                {

                                                                                                                                    //6
                                                                                                                                    if (cb_Len5.Checked)
                                                                                                                                    {
                                                                                                                                        if (double.TryParse(tb_Len5.Text, out Len_Set[5]))
                                                                                                                                        {
                                                                                                                                            if (int.TryParse(tb_rangemin5.Text, out Len_Range_Min[5]))
                                                                                                                                            {
                                                                                                                                                if (int.TryParse(tb_rangemax5.Text, out Len_Range_Max[5]))
                                                                                                                                                {
                                                                                                                                                    if (Len_Range_Min[5] > Len_Range_Max[5])
                                                                                                                                                    {
                                                                                                                                                        MessageBox.Show("區域設定有誤");
                                                                                                                                                        return false;
                                                                                                                                                    }
                                                                                                                                                    else
                                                                                                                                                    {
                                                                                                                                                        if (Len_Range_Min[5] - Len_Range_Max[4] != 1)
                                                                                                                                                        {
                                                                                                                                                            MessageBox.Show("區域設定非連續");
                                                                                                                                                            return false;
                                                                                                                                                        }
                                                                                                                                                        else
                                                                                                                                                        {

                                                                                                                                                            //7
                                                                                                                                                            if (cb_Len6.Checked)
                                                                                                                                                            {
                                                                                                                                                                if (double.TryParse(tb_Len6.Text, out Len_Set[6]))
                                                                                                                                                                {
                                                                                                                                                                    if (int.TryParse(tb_rangemin6.Text, out Len_Range_Min[6]))
                                                                                                                                                                    {
                                                                                                                                                                        if (int.TryParse(tb_rangemax6.Text, out Len_Range_Max[6]))
                                                                                                                                                                        {
                                                                                                                                                                            if (Len_Range_Min[6] > Len_Range_Max[6])
                                                                                                                                                                            {
                                                                                                                                                                                MessageBox.Show("區域設定有誤");
                                                                                                                                                                                return false;
                                                                                                                                                                            }
                                                                                                                                                                            else
                                                                                                                                                                            {
                                                                                                                                                                                if (Len_Range_Min[6] - Len_Range_Max[5] != 1)
                                                                                                                                                                                {
                                                                                                                                                                                    MessageBox.Show("區域設定非連續");
                                                                                                                                                                                    return false;
                                                                                                                                                                                }
                                                                                                                                                                                else
                                                                                                                                                                                {

                                                                                                                                                                                    //8
                                                                                                                                                                                    if (cb_Len7.Checked)
                                                                                                                                                                                    {
                                                                                                                                                                                        if (double.TryParse(tb_Len7.Text, out Len_Set[7]))
                                                                                                                                                                                        {
                                                                                                                                                                                            if (int.TryParse(tb_rangemin7.Text, out Len_Range_Min[7]))
                                                                                                                                                                                            {
                                                                                                                                                                                                if (int.TryParse(tb_rangemax7.Text, out Len_Range_Max[7]))
                                                                                                                                                                                                {
                                                                                                                                                                                                    if (Len_Range_Min[7] > Len_Range_Max[7])
                                                                                                                                                                                                    {
                                                                                                                                                                                                        MessageBox.Show("區域設定有誤");
                                                                                                                                                                                                        return false;
                                                                                                                                                                                                    }
                                                                                                                                                                                                    else
                                                                                                                                                                                                    {
                                                                                                                                                                                                        if (Len_Range_Min[7] - Len_Range_Max[6] != 1)
                                                                                                                                                                                                        {
                                                                                                                                                                                                            MessageBox.Show("區域設定非連續");
                                                                                                                                                                                                            return false;
                                                                                                                                                                                                        }
                                                                                                                                                                                                        else
                                                                                                                                                                                                        {

                                                                                                                                                                                                            //9
                                                                                                                                                                                                            if (cb_Len8.Checked)
                                                                                                                                                                                                            {
                                                                                                                                                                                                                if (double.TryParse(tb_Len8.Text, out Len_Set[8]))
                                                                                                                                                                                                                {
                                                                                                                                                                                                                    if (int.TryParse(tb_rangemin8.Text, out Len_Range_Min[8]))
                                                                                                                                                                                                                    {
                                                                                                                                                                                                                        if (int.TryParse(tb_rangemax8.Text, out Len_Range_Max[8]))
                                                                                                                                                                                                                        {

                                                                                                                                                                                                                            if (Len_Range_Min[8] > Len_Range_Max[8])
                                                                                                                                                                                                                            {
                                                                                                                                                                                                                                MessageBox.Show("區域設定有誤");
                                                                                                                                                                                                                                return false;
                                                                                                                                                                                                                            }
                                                                                                                                                                                                                            else
                                                                                                                                                                                                                            {
                                                                                                                                                                                                                                if (Len_Range_Min[8] - Len_Range_Max[7] != 1)
                                                                                                                                                                                                                                {
                                                                                                                                                                                                                                    MessageBox.Show("區域設定非連續");
                                                                                                                                                                                                                                    return false;
                                                                                                                                                                                                                                }
                                                                                                                                                                                                                                else//判斷最大值
                                                                                                                                                                                                                                {
                                                                                                                                                                                                                                    Range_maxmum = Len_Range_Max[8];
                                                                                                                                                                                                                                    return true;
                                                                                                                                                                                                                                }
                                                                                                                                                                                                                            }
                                                                                                                                                                                                                        }
                                                                                                                                                                                                                        else
                                                                                                                                                                                                                        {
                                                                                                                                                                                                                            MessageBox.Show("區域max_9設定錯誤");
                                                                                                                                                                                                                            return false;
                                                                                                                                                                                                                        }
                                                                                                                                                                                                                    }
                                                                                                                                                                                                                    else
                                                                                                                                                                                                                    {
                                                                                                                                                                                                                        MessageBox.Show("區域min_9設定錯誤");
                                                                                                                                                                                                                        return false;
                                                                                                                                                                                                                    }
                                                                                                                                                                                                                }
                                                                                                                                                                                                                else
                                                                                                                                                                                                                {
                                                                                                                                                                                                                    MessageBox.Show("長度9設定錯誤");
                                                                                                                                                                                                                    return false;
                                                                                                                                                                                                                }



                                                                                                                                                                                                            }//8
                                                                                                                                                                                                            else
                                                                                                                                                                                                            {
                                                                                                                                                                                                                Range_maxmum = Len_Range_Max[7];
                                                                                                                                                                                                                return true;
                                                                                                                                                                                                            }

                                                                                                                                                                                                        }
                                                                                                                                                                                                    }
                                                                                                                                                                                                }
                                                                                                                                                                                                else
                                                                                                                                                                                                {
                                                                                                                                                                                                    MessageBox.Show("區域max_8設定錯誤");
                                                                                                                                                                                                    return false;
                                                                                                                                                                                                }
                                                                                                                                                                                            }
                                                                                                                                                                                            else
                                                                                                                                                                                            {
                                                                                                                                                                                                MessageBox.Show("區域min_8設定錯誤");
                                                                                                                                                                                                return false;
                                                                                                                                                                                            }
                                                                                                                                                                                        }
                                                                                                                                                                                        else
                                                                                                                                                                                        {
                                                                                                                                                                                            MessageBox.Show("長度8設定錯誤");
                                                                                                                                                                                            return false;
                                                                                                                                                                                        }

                                                                                                                                                                                    }//7
                                                                                                                                                                                    else
                                                                                                                                                                                    {
                                                                                                                                                                                        Range_maxmum = Len_Range_Max[6];
                                                                                                                                                                                        return true;
                                                                                                                                                                                    }

                                                                                                                                                                                }
                                                                                                                                                                            }
                                                                                                                                                                        }
                                                                                                                                                                        else
                                                                                                                                                                        {
                                                                                                                                                                            MessageBox.Show("區域max_7設定錯誤");
                                                                                                                                                                            return false;
                                                                                                                                                                        }
                                                                                                                                                                    }
                                                                                                                                                                    else
                                                                                                                                                                    {
                                                                                                                                                                        MessageBox.Show("區域min_7設定錯誤");
                                                                                                                                                                        return false;
                                                                                                                                                                    }
                                                                                                                                                                }
                                                                                                                                                                else
                                                                                                                                                                {
                                                                                                                                                                    MessageBox.Show("長度7設定錯誤");
                                                                                                                                                                    return false;
                                                                                                                                                                }

                                                                                                                                                            }//6
                                                                                                                                                            else
                                                                                                                                                            {
                                                                                                                                                                Range_maxmum = Len_Range_Max[5];
                                                                                                                                                                return true;
                                                                                                                                                            }

                                                                                                                                                        }
                                                                                                                                                    }
                                                                                                                                                }
                                                                                                                                                else
                                                                                                                                                {
                                                                                                                                                    MessageBox.Show("區域max_6設定錯誤");
                                                                                                                                                    return false;
                                                                                                                                                }
                                                                                                                                            }
                                                                                                                                            else
                                                                                                                                            {
                                                                                                                                                MessageBox.Show("區域min_6設定錯誤");
                                                                                                                                                return false;
                                                                                                                                            }
                                                                                                                                        }
                                                                                                                                        else
                                                                                                                                        {
                                                                                                                                            MessageBox.Show("長度6設定錯誤");
                                                                                                                                            return false;
                                                                                                                                        }
                                                                                                                                    }//5
                                                                                                                                    else
                                                                                                                                    {
                                                                                                                                        Range_maxmum = Len_Range_Max[4];
                                                                                                                                        return true;
                                                                                                                                    }

                                                                                                                                }
                                                                                                                            }
                                                                                                                        }
                                                                                                                        else
                                                                                                                        {
                                                                                                                            MessageBox.Show("區域max_5設定錯誤");
                                                                                                                            return false;
                                                                                                                        }
                                                                                                                    }
                                                                                                                    else
                                                                                                                    {
                                                                                                                        MessageBox.Show("區域min_5設定錯誤");
                                                                                                                        return false;
                                                                                                                    }
                                                                                                                }
                                                                                                                else
                                                                                                                {
                                                                                                                    MessageBox.Show("長度5設定錯誤");
                                                                                                                    return false;
                                                                                                                }
                                                                                                            }//4
                                                                                                            else
                                                                                                            {
                                                                                                                Range_maxmum = Len_Range_Max[3];
                                                                                                                return true;
                                                                                                            }

                                                                                                        }
                                                                                                    }

                                                                                                }
                                                                                                else
                                                                                                {
                                                                                                    MessageBox.Show("區域max_4設定錯誤");
                                                                                                    return false;
                                                                                                }
                                                                                            }
                                                                                            else
                                                                                            {
                                                                                                MessageBox.Show("區域min_4設定錯誤");
                                                                                                return false;
                                                                                            }
                                                                                        }
                                                                                        else
                                                                                        {
                                                                                            MessageBox.Show("長度4設定錯誤");
                                                                                            return false;
                                                                                        }




                                                                                    }//3
                                                                                    else
                                                                                    {
                                                                                        Range_maxmum = Len_Range_Max[2];
                                                                                        return true;
                                                                                    }


                                                                                }
                                                                            }
                                                                        }
                                                                        else
                                                                        {
                                                                            MessageBox.Show("區域max_3設定錯誤");
                                                                            return false;
                                                                        }
                                                                    }
                                                                    else
                                                                    {
                                                                        MessageBox.Show("區域min_3設定錯誤");
                                                                        return false;
                                                                    }
                                                                }
                                                                else
                                                                {
                                                                    MessageBox.Show("長度3設定錯誤");
                                                                    return false;
                                                                }


                                                            }//2
                                                            else
                                                            {
                                                                Range_maxmum = Len_Range_Max[1];
                                                                return true;
                                                            }

                                                        }
                                                    }
                                                }
                                                else
                                                {
                                                    MessageBox.Show("區域max_2設定錯誤");
                                                    return false;
                                                }
                                            }
                                            else
                                            {
                                                MessageBox.Show("區域min_2設定錯誤");
                                                return false;
                                            }
                                        }
                                        else
                                        {
                                            MessageBox.Show("長度2設定錯誤");
                                            return false;
                                        }


                                    }//1
                                    else
                                    {

                                        Range_maxmum = Len_Range_Max[0];
                                        return true;
                                    }
                                }
                            }
                            else
                            {
                                MessageBox.Show("區域max_1設定錯誤");
                                return false;
                            }
                        }
                        else
                        {

                            MessageBox.Show("區域min_1設定錯誤");
                            return false;
                        }
                    }
                    else
                    {

                        MessageBox.Show("長度1設定錯誤");
                        return false;
                    }



                }//0
                else
                {
                    MessageBox.Show("未設定任何長度");
                    return false;
                }

            }//checkBox_Diff_Len.Checked
            else
            {
                return true;
            }

        }


        private void tcp_connect()
        {
            tcp1 = new TCP_IP_Client.TCPServerAP();
            //[BM:LCH二切功能-與LCN不同]
            tcp1.IP = _CameraCVX.HostName();
            tcp1.Port = _CameraCVX.PortActiveX();
            tcp1.Start();
            //_TCP_image.IP = "169.254.1.100";
            //_TCP_image.Port = 8502;
            //_TCP_image.Connect();

        }

        private double new_X(string X, string Y)
        {
            return Convert.ToDouble(X) * Math.Cos(theta) - Convert.ToDouble(Y) * Math.Sin(theta);
        }
        private double new_Y(string X, string Y)
        {
            return Convert.ToDouble(X) * Math.Sin(theta) + Convert.ToDouble(Y) * Math.Cos(theta);
        }





        /// <summary>
        /// 計算兩點之間的直線距離（畢氏定理）。<br/>
        /// 用於座標轉換、距離量測、縮放比例計算等場景。<br/>
        /// 公式：√(X² + Y²)
        /// </summary>
        /// <param name="X_POS">X 軸位移量</param>
        /// <param name="Y_POS">Y 軸位移量</param>
        /// <returns>兩點之間的距離</returns>
        private double Pythagorean(double X_POS, double Y_POS)// 傳入 X、Y 位移量
        {
            return Math.Sqrt(Math.Pow(X_POS, 2) + Math.Pow(Y_POS, 2));// 回傳 √(X² + Y²)
        }



        /// <summary>
        /// 解析 NG 針 XML 檔案，驗證總針數是否與目前設定相符，並記錄 NG 針狀態。
        /// 若檔案不存在或格式錯誤則回傳錯誤訊息。
        /// </summary>
        /// <param name="error_message">錯誤訊息回傳參考。</param>
        /// <returns>是否成功讀取與解析。</returns>
        private bool Read_NG2Cut(ref string error_message)// 解析 NG 針 XML 檔案，驗證針數是否匹配，並記錄 NG 針狀態。
        {
            try
            {
                int pin_number = (pin_TotalNumber_2CUT / 2) * Convert.ToInt16(tb_ReginPinNum.Text);

                string filename = Path.Combine(NG2Cut_FilePath, tb_NG2Cut.Text + ".xml");

                if (System.IO.File.Exists(filename))
                {

                    //節點名稱
                    Buffer_Xml_Element element_name = new Buffer_Xml_Element();

                    //DataSet
                    DataSet dataset = new DataSet();

                    dataset.ReadXml(filename);

                    int totalpin = Convert.ToInt32(dataset.Tables[element_name.Sub_Data].Rows[0][element_name.Total_Pin]);

                    bool[] pin = new bool[totalpin];

                    NG2Cut.Clear();

                    if (totalpin != pin_number)
                    {
                        error_message = String.Format("二切針數與NG針檔案總針數不匹配, 請確認數量, 二切針數: {0}, NG針總針數: {1}", pin_number, totalpin);

                        return false;

                    }
                    NG2Cut.AddRange(pin);

                    if (totalpin == NG2Cut.Count)
                    {

                        for (int i = 0; i < dataset.Tables[element_name.Data].Rows.Count; i++)
                        {
                            int value = Convert.ToInt32(dataset.Tables[element_name.Data].Rows[i][element_name.LNC_Run_Pin]);

                            NG2Cut[value - 1] = true;
                        }

                        error_message = "";

                        return true;
                    }
                    else
                    {
                        error_message = String.Format("暫存區記憶與NG針檔案總針數不匹配, 請確認數量, 二切針數: {0}, NG針總針數: {1}", NG2Cut.Count, totalpin);

                        return false;
                    }
                }
                else
                {
                    error_message = "查無此檔案";
                    return false;
                }
            }
            catch (Exception ex)
            {
                error_message = ex.ToString();
                return false;
            }
        }

        /// <summary>
        /// 從指定的 PRR/LCN 檔案讀取探針補償資料，檢查格式是否以 'PASS' 開頭，並解析括號內的座標資料。
        /// 若格式正確則呼叫解析方法填入 n_prrlcn 結構，否則回傳錯誤訊息。
        /// </summary>
        /// <param name="filename">檔案完整路徑。</param>
        /// <param name="n_prrlcn">補償資料結構實例。</param>
        /// <param name="message">錯誤訊息回傳參考。</param>
        /// <returns>是否成功讀取與解析。</returns>
        private bool n_PRRLCNHandler_ReadFile(string filename, N_PRRLCN n_prrlcn, ref string message)// 從指定檔案讀取內容，檢查格式是否正確 (以 'PASS' 開頭)，並解析有效數據。
        {
            using (var reader = new StreamReader(filename))
            {
                string filestart = "'PASS'";
                char filespacer = ',';
                char cutstart = '[';
                char cutend = ']';
                int start;
                int end;
                bool result = false;


                var line = reader.ReadLine();

                if (line.StartsWith(filestart))
                {
                    start = line.IndexOf(cutstart);
                    end = line.LastIndexOf(cutend);

                    var n_line = line.Substring(start + 1, (end - start - 1));

                    var items = n_line.Split(filespacer);

                    result = n_PRRLCNHandler_GetValue(items, n_prrlcn, ref message);

                    return result;
                }
                else
                {
                    message = "檔案起始瑪錯誤: " + filestart;

                    return result;
                }

            }
        }
        private bool n_PRRLCNHandler_GetValue(string[] items, N_PRRLCN n_prrlcn, ref string message) // 方法：處理探針檢測資料，回傳成功或失敗
        {
            try
            {
                char filespacer = ' '; // 定義分隔字元（空白）

                foreach (string item in items) // 逐一處理輸入的字串陣列
                {
                    string s;
                    s = item.Trim(filespacer); // 去掉字串前後的空白
                    n_PRR_List.ProbeNumber.Add(s); // 加入到探針編號清單
                }

                textBox16.Clear(); // 清空 NG 顯示框
                textBox17.Clear(); // 清空 OK 顯示框

                string ok_list = ""; // 用來存放 OK 結果的字串
                string ng_list = ""; // 用來存放 NG 結果的字串

                for (int i = 0; i < n_PRR_List.TotalNumber; i++) // 迴圈跑所有探針總數
                {
                    int listcount = n_PRR_List.ProbeNumber.Count; // 目前探針編號清單的數量

                    if (listcount > n_PRR_List.OKPinNumber) // 如果清單數量大於目前 OKPinNumber
                    {
                        int n = Convert.ToInt32(n_PRR_List.ProbeNumber[n_PRR_List.OKPinNumber]); // 取出目前 OKPinNumber 對應的探針編號並轉成整數

                        if (i == (n - 1)) // 如果迴圈索引符合該探針編號（注意減一）
                        {
                            n_PRR_List.ProbeResult.Add(true); // 加入結果為 OK (true)

                            ok_list = ok_list + i.ToString() + "\r\n"; // 把 OK 編號加入字串清單

                            n_PRR_List.OKPinNumber++; // OKPinNumber 往下移一位
                        }
                        else
                        {
                            n_PRR_List.ProbeResult.Add(false); // 加入結果為 NG (false)

                            ng_list = ng_list + i.ToString() + "\r\n"; // 把 NG 編號加入字串清單
                        }
                    }
                    else // 如果清單數量不足
                    {
                        n_PRR_List.ProbeResult.Add(false); // 加入結果為 NG (false)

                        ng_list = ng_list + i.ToString() + "\r\n"; // 把 NG 編號加入字串清單
                    }
                }

                textBox16.Text = ng_list; // 將 NG 結果顯示在 textBox16
                textBox17.Text = ok_list; // 將 OK 結果顯示在 textBox17

                TB_OkPinCount.Text = ok_list.Split(new[] { "\r\n" }, StringSplitOptions.RemoveEmptyEntries).Length.ToString(); ;//顯示okpin數量



                return true; // 成功完成，回傳 true
            }
            catch
            {
                message = "拆解檔案失敗"; // 發生例外時，回傳錯誤訊息

                return false; // 回傳 false 表示失敗
            }
        }

        /// <summary>
        /// 自動載入 PRR/LCN 檔案，並嘗試讀取與解析內容。
        /// 若成功則更新 UI 狀態並顯示成功訊息，否則顯示錯誤或提醒未選檔案。
        /// </summary>
        private void B_PRRLCN_Auto_Load(string path)
        {
            // ✅ 直接指定路徑，不用開對話框
            string f = path;
            tb_PRRLCN.Text = f;

            int pin_number = (pin_TotalNumber_2CUT / 2) * Convert.ToInt16(tb_ReginPinNum.Text);

            n_PRR_List.Claer();
            n_PRR_List.TotalNumber = pin_number;

            string message = "";

            // 檢查路徑是否為空 AND 檔案是否存在
            if (!string.IsNullOrEmpty(tb_PRRLCN.Text) && File.Exists(tb_PRRLCN.Text))
            {
                if (n_PRRLCNHandler_ReadFile(tb_PRRLCN.Text, n_PRR_List, ref message))
                {
                    CB_PRRLCN_Switch.Checked = true;
                    MessageBox.Show("讀取二切連動檔案完成");
                }
                else
                {
                    MessageBox.Show(message);
                }
            }
            else
            {
                MessageBox.Show("讀取二切連動檔案失敗，檔案不存在或未選取");
                DateTime currentTime = DateTime.Now;
                using (StreamWriter sw = new StreamWriter(Path.Combine(Application.StartupPath, "Log", currentTime.ToString("yyyyMMdd") + "_ErrorLog.ini"), true))// 寫入 LOG，檔案路徑在 ...\LaserProcess\bin\Debug\Log\當天日期
                {
                    sw.WriteLine(currentTime.ToString("yyyyMMddHHmm") + "  ;  " + "錯誤訊息=" + $"讀取二切連動檔案失敗，檔案不存在或未選取");
                }
            }
        }


        /// <summary>
        /// LCN載入點位資訊 
        /// </summary>
        /// <param name="file"></param>
        /// <returns></returns>
        private Boolean Load_PointFile(string file)
        {
            try
            {
                //[BM-偏移打資訊-讀取配置檔內容]
                //GuideID_offset_X = int.Parse(IniReadValue("偏移打標", "Xoffset", file));
                //GuideID_offset_Y = int.Parse(IniReadValue("偏移打標", "Yoffset", file));
                tb_GuideIDText_1_offsetX.Text = IniReadValue("偏移打標", "Xoffset", file);
                tb_GuideIDText_1_offsetY.Text = IniReadValue("偏移打標", "Yoffset", file);

                for (int i = 0; i < total_axis; i++)
                {
                    point_position[0, i] = IniReadValue(" 加工原點位置", "軸" + (i).ToString(), file);
                    point_position[1, i] = IniReadValue("視覺原點位置", "軸" + (i).ToString(), file);
                    point_position[2, i] = IniReadValue("測高原點位置", "軸" + (i).ToString(), file);
                    point_position[3, i] = IniReadValue("出料位置", "軸" + (i).ToString(), file);
                    point_position[4, i] = IniReadValue("入料位置", "軸" + (i).ToString(), file);
                    point_position[5, i] = IniReadValue("功率量測位置", "軸" + (i).ToString(), file);
                    point_position[6, i] = IniReadValue("點位7", "軸" + (i).ToString(), file);
                    point_position[7, i] = IniReadValue("點位8", "軸" + (i).ToString(), file);
                    point_position[8, i] = IniReadValue("點位9", "軸" + (i).ToString(), file);
                    point_position[18, i] = IniReadValue("限制_正", "軸" + (i).ToString(), file);
                    point_position[19, i] = IniReadValue("限制_負", "軸" + (i).ToString(), file);


                }
                for (int i = 0; i < 2; i++)
                {
                    point_position[20, i] = IniReadValue("相對位置雷射-相機", "軸" + (i).ToString(), file);
                    point_position[21, i] = IniReadValue("相對位置雷射-測距", "軸" + (i).ToString(), file);

                    point_position[24, i] = IniReadValue("定位孔1", "軸" + (i).ToString(), file);
                    point_position[25, i] = IniReadValue("定位孔2", "軸" + (i).ToString(), file);
                    point_position[26, i] = IniReadValue("定位孔3", "軸" + (i).ToString(), file);
                    point_position[27, i] = IniReadValue("定位孔4", "軸" + (i).ToString(), file);


                    //20201118
                    point_position[28, i] = IniReadValue("雷射功率校正", "軸" + (i).ToString(), file);


                }
                point_position[22, 0] = IniReadValue("高度設定", "雷射" + (0).ToString(), file);
                point_position[22, 1] = IniReadValue("高度設定", "CCD" + (0).ToString(), file);
                point_position[22, 2] = IniReadValue("高度設定", "測距" + (0).ToString(), file);

                point_position[23, 0] = IniReadValue("2切參數", "測高偏移" + (0).ToString(), file);
                point_position[23, 1] = IniReadValue("2切參數", "特徵到中心" + (0).ToString(), file);
                point_position[23, 2] = IniReadValue("2切參數", "特徵到針尾" + (0).ToString(), file);
                point_position[33, 0] = IniReadValue("2切參數", "X補償值" + (0).ToString(), file);
                point_position[33, 1] = IniReadValue("2切參數", "Y補償值" + (0).ToString(), file);

                point_position[34, 0] = IniReadValue("2切參數", "短間距測高偏移" + (0).ToString(), file);
                point_position[34, 1] = IniReadValue("2切參數", "短間距特徵到針尾" + (0).ToString(), file);
                point_position[34, 2] = IniReadValue("2切參數", "短間距定位點到特徵" + (0).ToString(), file);

                point_position[39, 0] = IniReadValue("2切參數", "BR短間距測高偏移" + (0).ToString(), file);
                point_position[39, 1] = IniReadValue("2切參數", "BR短間距特徵到針尾" + (0).ToString(), file);
                point_position[39, 2] = IniReadValue("2切參數", "BR短間距定位點到特徵" + (0).ToString(), file);

                point_position[40, 0] = IniReadValue("2切參數", "NS測高偏移" + (0).ToString(), file);
                point_position[40, 1] = IniReadValue("2切參數", "NS特徵到針尾" + (0).ToString(), file);
                point_position[40, 2] = IniReadValue("2切參數", "NS定位點到特徵" + (0).ToString(), file);

                point_position[41, 0] = IniReadValue("2切參數", "BR測高偏移" + (0).ToString(), file);
                point_position[41, 1] = IniReadValue("2切參數", "BR特徵到針尾" + (0).ToString(), file);
                point_position[41, 2] = IniReadValue("2切參數", "BR定位點到特徵" + (0).ToString(), file);

                point_position[35, 0] = IniReadValue("雷射角度補償", "斜率" + (0).ToString(), file);
                point_position[35, 1] = IniReadValue("雷射角度補償", "補正值" + (0).ToString(), file);

                point_position[36, 0] = IniReadValue("雷射角度極限", "上限" + (0).ToString(), file);
                point_position[36, 1] = IniReadValue("雷射角度極限", "下限" + (0).ToString(), file);

                point_position[37, 0] = IniReadValue("雷射功率極限", "上限" + (0).ToString(), file);
                point_position[37, 1] = IniReadValue("雷射功率極限", "下限" + (0).ToString(), file);
                //WritePrivateProfileString("2切參數", "X補償值" + (0).ToString(), (point_position[33, 0] == null) ? (0).ToString() : point_position[33, 0], classSystem.path);
                //WritePrivateProfileString("2切參數", "Y補償值" + (0).ToString(), (point_position[33, 1] == null) ? (0).ToString() : point_position[33, 1], classSystem.path);
                point_position[38, 0] = IniReadValue("二切圖形設定", "角度" + (0).ToString(), file);
                Carbide_MarkPower = IniReadValue("二切圖形設定", "Carbide功率" + (0).ToString(), file);

                point_position[42, 0] = IniReadValue("導版雷射角度補償", "斜率" + (0).ToString(), file);
                point_position[42, 1] = IniReadValue("導版雷射角度補償", "補正值" + (0).ToString(), file);

                point_position[43, 0] = IniReadValue("導版雷射功率校正", "A" + (0).ToString(), file);
                point_position[43, 1] = IniReadValue("導版雷射功率校正", "B" + (0).ToString(), file);

                point_position[44, 0] = IniReadValue("高度設定", "導版雷射" + (0).ToString(), file);

                //show
                ST_X1.Text = point_position[0, 0];
                ST_Y1.Text = point_position[0, 1];
                ST_Z1.Text = point_position[0, 2];
                ST_X2.Text = point_position[1, 0];
                ST_Y2.Text = point_position[1, 1];
                ST_Z2.Text = point_position[1, 2];
                ST_X3.Text = point_position[2, 0];
                ST_Y3.Text = point_position[2, 1];
                ST_Z3.Text = point_position[2, 2];
                ST_X4.Text = point_position[3, 0];
                ST_Y4.Text = point_position[3, 1];
                ST_Z4.Text = point_position[3, 2];

                ST_X5.Text = point_position[4, 0];
                ST_Y5.Text = point_position[4, 1];
                ST_Z5.Text = point_position[4, 2];

                ST_X6.Text = point_position[5, 0];
                ST_Y6.Text = point_position[5, 1];
                ST_Z6.Text = point_position[5, 2];

                ST_X7.Text = point_position[6, 0];
                ST_Y7.Text = point_position[6, 1];
                ST_Z7.Text = point_position[6, 2];

                ST_X8.Text = point_position[7, 0];
                ST_Y8.Text = point_position[7, 1];
                ST_Z8.Text = point_position[7, 2];

                ST_X9.Text = point_position[8, 0];
                ST_Y9.Text = point_position[8, 1];
                ST_Z9.Text = point_position[8, 2];

                X_LC_textBox.Text = point_position[20, 0];
                Y_LC_textBox.Text = point_position[20, 1];

                X_LK_textBox.Text = point_position[21, 0];
                Y_LK_textBox.Text = point_position[21, 1];

                //tb_FixZ_Hight.Text = Laser_Height_textBox.Text = point_position[22, 0];
                Laser_Height_textBox.Text = point_position[22, 0];
                CCD_Height_textBox.Text = point_position[22, 1];
                Keyence_Height_textBox.Text = point_position[22, 2];

                tb_2Cut_NX.Text = point_position[23, 0];
                tb_2Cut_HeadNY.Text = point_position[23, 1];
                tb_2Cut_TipPY.Text = point_position[23, 2];

                //2 cut

                tb_HX_1.Text = point_position[24, 0];
                tb_HY_1.Text = point_position[24, 1];

                tb_HX_2.Text = point_position[25, 0];
                tb_HY_2.Text = point_position[25, 1];

                tb_HX_3.Text = point_position[26, 0];
                tb_HY_3.Text = point_position[26, 1];

                tb_HX_4.Text = point_position[27, 0];
                tb_HY_4.Text = point_position[27, 1];


                holeS_X_2CUT[0] = point_position[24, 0];
                holeS_X_2CUT[1] = point_position[25, 0];
                holeS_X_2CUT[2] = point_position[26, 0];
                holeS_X_2CUT[3] = point_position[27, 0];

                holeS_Y_2CUT[0] = point_position[24, 1];
                holeS_Y_2CUT[1] = point_position[25, 1];
                holeS_Y_2CUT[2] = point_position[26, 1];
                holeS_Y_2CUT[3] = point_position[27, 1];


                radioButton1.Text = "孔1" + "   (" + holeS_X_2CUT[0] + " , " + holeS_Y_2CUT[0] + " )";
                radioButton2.Text = "孔2" + "   (" + holeS_X_2CUT[1] + " , " + holeS_Y_2CUT[1] + " )";
                radioButton3.Text = "孔3" + "   (" + holeS_X_2CUT[2] + " , " + holeS_Y_2CUT[2] + " )";
                radioButton4.Text = "孔4" + "   (" + holeS_X_2CUT[3] + " , " + holeS_Y_2CUT[3] + " )";

                A_textBox.Text = point_position[28, 0];
                B_textBox.Text = point_position[28, 1];

                if (double.TryParse(point_position[28, 0], out A))
                {
                    if (double.TryParse(point_position[28, 1], out B))
                    {
                        _powerToOutPowerGain = A;
                        _powerToOutPowerOffset = B;
                    }
                }

                PH_A_textBox.Text = point_position[43, 0];
                PH_B_textBox.Text = point_position[43, 1];

                if (double.TryParse(point_position[43, 0], out PH_A))
                {
                    if (double.TryParse(point_position[43, 1], out PH_B))
                    {
                        _powerToPHOutPowerGain = PH_A;
                        _powerToPHOutPowerOffset = PH_B;
                    }
                }
                PH_Laser_Height_textBox.Text = point_position[44, 0];
                //Comp_X


                tb_Comp_X.Text = point_position[33, 0];
                tb_Comp_Y.Text = point_position[33, 1];

                //NS短間距2切參數
                tb_NS_Short2Cut_NY.Text = point_position[34, 0];
                tb_NS_Short2Cut_TipPY.Text = point_position[34, 1];
                tb_NS_Short2Cut_HeadX.Text = point_position[34, 2];

                //BR短間距2切參數
                tb_BR_Short2Cut_NY.Text = point_position[39, 0];
                tb_BR_Short2Cut_TipPY.Text = point_position[39, 1];
                tb_BR_Short2Cut_HeadX.Text = point_position[39, 2];

                //NS Align 2切參數
                tb_NS_Align2Cut_NY.Text = point_position[40, 0];
                tb_NS_Align2Cut_TipPY.Text = point_position[40, 1];
                tb_NS_Align2Cut_HeadX.Text = point_position[40, 2];

                //BR Align 2切參數
                tb_BR_Align2Cut_NY.Text = point_position[41, 0];
                tb_BR_Align2Cut_TipPY.Text = point_position[41, 1];
                tb_BR_Align2Cut_HeadX.Text = point_position[41, 2];

                //雷射角度補償
                tb_DegreeSlope.Text = point_position[35, 0];
                tb_DegreeOffset.Text = point_position[35, 1];



                double slope, offset;
                if (double.TryParse(point_position[35, 0], out slope))
                {
                    if (double.TryParse(point_position[35, 1], out offset))
                    {
                        _powerToDegreeSlope = slope;
                        _angle_A = slope;
                        _powerToDegreeOffset = offset;
                        _angle_B = offset;
                    }
                }

                tb_PH_DegreeSlope.Text = point_position[42, 0];
                tb_PH_DegreeOffset.Text = point_position[42, 1];

                double PHslope, PHoffset;
                if (double.TryParse(point_position[42, 0], out PHslope))
                {
                    if (double.TryParse(point_position[42, 1], out PHoffset))
                    {
                        _powerToPHDegreeSlope = PHslope;
                        _PHangle_A = PHslope;
                        _powerToPHDegreeOffset = PHoffset;
                        _PHangle_B = PHoffset;
                    }
                }


                //雷射角度極限
                tb_Angle_Max.Text = point_position[36, 0];
                tb_Angle_Min.Text = point_position[36, 1];

                decimal angle_max, angle_min;
                if (decimal.TryParse(point_position[36, 0], out angle_max))
                {
                    if (decimal.TryParse(point_position[36, 1], out angle_min))
                    {
                        a_max = angle_max;
                        a_min = angle_min;
                    }
                }

                //雷射功率極限
                tb_Power_Max.Text = point_position[37, 0];
                tb_Power_Min.Text = point_position[37, 1];

                double power_max, power_min;
                if (double.TryParse(point_position[37, 0], out power_max))
                {
                    if (double.TryParse(point_position[37, 1], out power_min))
                    {
                        p_max = power_max;
                        p_min = power_min;

                        label243.Text = "請輸入介於" + p_min.ToString() + "~" + p_max.ToString() + "之間的數值!";
                    }
                }

                //二切圖形設定
                tb_AngleSet.Text = point_position[38, 0];
                tb_Carbide_Mark_PowerSet.Text = Carbide_MarkPower;

                return true;
            }
            catch
            {
                return false;
            }
        }
        [DllImport("kernel32", CharSet = CharSet.Unicode)]
        private static extern int GetPrivateProfileString(string section, string key, string def, StringBuilder retVal, int size, string filePath);
        private static string IniReadValue(string Section, string Key, string path)
        {
            StringBuilder temp = new StringBuilder(255);
            int i = GetPrivateProfileString(Section, Key, "", temp, 255, path);
            return temp.ToString();
        }


        private void Point_SaveFile(string file)
        {
            //[BM-偏移打資訊-寫入偏移量資料到配置檔]
            WritePrivateProfileString("偏移打標", "Xoffset", (tb_GuideIDText_1_offsetX.Text == "") ? (0).ToString() : tb_GuideIDText_1_offsetX.Text, file);
            WritePrivateProfileString("偏移打標", "Yoffset", (tb_GuideIDText_1_offsetY.Text == "") ? (0).ToString() : tb_GuideIDText_1_offsetY.Text, file);


            // 加工原點位置~9:陣列0~8
            //雷射到CCD:陣列20
            //雷射到測距:陣列21
            //limit+:30
            //limit-:31
            //RD補償值設定:33
            for (int i = 0; i < total_axis; i++)
            {

                WritePrivateProfileString(" 加工原點位置", "軸" + (i).ToString(), (point_position[0, i] == null) ? (0).ToString() : point_position[0, i], file);
                WritePrivateProfileString("視覺原點位置", "軸" + (i).ToString(), (point_position[1, i] == null) ? (0).ToString() : point_position[1, i], file);
                WritePrivateProfileString("測高原點位置", "軸" + (i).ToString(), (point_position[2, i] == null) ? (0).ToString() : point_position[2, i], file);
                WritePrivateProfileString("出料位置", "軸" + (i).ToString(), (point_position[3, i] == null) ? (0).ToString() : point_position[3, i], file);
                WritePrivateProfileString("入料位置", "軸" + (i).ToString(), (point_position[4, i] == null) ? (0).ToString() : point_position[4, i], file);
                WritePrivateProfileString("功率量測位置", "軸" + (i).ToString(), (point_position[5, i] == null) ? (0).ToString() : point_position[5, i], file);
                WritePrivateProfileString("點位7", "軸" + (i).ToString(), (point_position[6, i] == null) ? (0).ToString() : point_position[6, i], file);
                WritePrivateProfileString("點位8", "軸" + (i).ToString(), (point_position[7, i] == null) ? (0).ToString() : point_position[7, i], file);
                WritePrivateProfileString("點位9", "軸" + (i).ToString(), (point_position[8, i] == null) ? (0).ToString() : point_position[8, i], file);

                WritePrivateProfileString("限制_正", "軸" + (i).ToString(), (point_position[18, i] == null) ? (0).ToString() : point_position[18, i], file);
                WritePrivateProfileString("限制_負", "軸" + (i).ToString(), (point_position[19, i] == null) ? (0).ToString() : point_position[19, i], file);


            }

            for (int i = 0; i < 2; i++)
            {
                WritePrivateProfileString("相對位置雷射-相機", "軸" + (i).ToString(), (point_position[20, i] == null) ? (0).ToString() : point_position[20, i], file);
                WritePrivateProfileString("相對位置雷射-測距", "軸" + (i).ToString(), (point_position[21, i] == null) ? (0).ToString() : point_position[21, i], file);

                WritePrivateProfileString("定位孔1", "軸" + (i).ToString(), (point_position[24, i] == null) ? (0).ToString() : point_position[24, i], file);
                WritePrivateProfileString("定位孔2", "軸" + (i).ToString(), (point_position[25, i] == null) ? (0).ToString() : point_position[25, i], file);
                WritePrivateProfileString("定位孔3", "軸" + (i).ToString(), (point_position[26, i] == null) ? (0).ToString() : point_position[26, i], file);
                WritePrivateProfileString("定位孔4", "軸" + (i).ToString(), (point_position[27, i] == null) ? (0).ToString() : point_position[27, i], file);

                //20201118
                WritePrivateProfileString("雷射功率校正", "軸" + (i).ToString(), (point_position[28, i] == null) ? (0).ToString() : point_position[28, i], file);
            }

            WritePrivateProfileString("高度設定", "雷射" + (0).ToString(), (point_position[22, 0] == null) ? (0).ToString() : point_position[22, 0], file);
            WritePrivateProfileString("高度設定", "CCD" + (0).ToString(), (point_position[22, 1] == null) ? (0).ToString() : point_position[22, 1], file);
            WritePrivateProfileString("高度設定", "測距" + (0).ToString(), (point_position[22, 2] == null) ? (0).ToString() : point_position[22, 2], file);

            WritePrivateProfileString("2切參數", "測高偏移" + (0).ToString(), (point_position[23, 0] == null) ? (0).ToString() : point_position[23, 0], file);
            WritePrivateProfileString("2切參數", "特徵到中心" + (0).ToString(), (point_position[23, 1] == null) ? (0).ToString() : point_position[23, 1], file);
            WritePrivateProfileString("2切參數", "特徵到針尾" + (0).ToString(), (point_position[23, 2] == null) ? (0).ToString() : point_position[23, 2], file);



            WritePrivateProfileString("2切參數", "X補償值" + (0).ToString(), (point_position[33, 0] == null) ? (0).ToString() : point_position[33, 0], file);
            WritePrivateProfileString("2切參數", "Y補償值" + (0).ToString(), (point_position[33, 1] == null) ? (0).ToString() : point_position[33, 1], file);

            WritePrivateProfileString("2切參數", "短間距測高偏移" + (0).ToString(), (point_position[34, 0] == null) ? (0).ToString() : point_position[34, 0], file);
            WritePrivateProfileString("2切參數", "短間距特徵到針尾" + (0).ToString(), (point_position[34, 1] == null) ? (0).ToString() : point_position[34, 1], file);
            WritePrivateProfileString("2切參數", "短間距定位點到特徵" + (0).ToString(), (point_position[34, 2] == null) ? (0).ToString() : point_position[34, 2], file);

            WritePrivateProfileString("雷射角度補償", "斜率" + (0).ToString(), (point_position[35, 0] == null) ? (0).ToString() : point_position[35, 0], file);
            WritePrivateProfileString("雷射角度補償", "補正值" + (0).ToString(), (point_position[35, 1] == null) ? (0).ToString() : point_position[35, 1], file);

            WritePrivateProfileString("雷射角度極限", "上限" + (0).ToString(), (point_position[36, 0] == null) ? (0).ToString() : point_position[36, 0], file);
            WritePrivateProfileString("雷射角度極限", "下限" + (0).ToString(), (point_position[36, 1] == null) ? (0).ToString() : point_position[36, 1], file);

            WritePrivateProfileString("雷射功率極限", "上限" + (0).ToString(), (point_position[37, 0] == null) ? (0).ToString() : point_position[37, 0], file);
            WritePrivateProfileString("雷射功率極限", "下限" + (0).ToString(), (point_position[37, 1] == null) ? (0).ToString() : point_position[37, 1], file);

            WritePrivateProfileString("二切圖形設定", "角度" + (0).ToString(), (point_position[38, 0] == null) ? (0).ToString() : point_position[38, 0], file);
            WritePrivateProfileString("二切圖形設定", "Carbide功率" + (0).ToString(), (Carbide_MarkPower == null) ? (0).ToString() : Carbide_MarkPower, file);

            WritePrivateProfileString("2切參數", "BR短間距測高偏移" + (0).ToString(), (point_position[39, 0] == null) ? (0).ToString() : point_position[39, 0], file);
            WritePrivateProfileString("2切參數", "BR短間距特徵到針尾" + (0).ToString(), (point_position[39, 1] == null) ? (0).ToString() : point_position[39, 1], file);
            WritePrivateProfileString("2切參數", "BR短間距定位點到特徵" + (0).ToString(), (point_position[39, 2] == null) ? (0).ToString() : point_position[39, 2], file);

            WritePrivateProfileString("2切參數", "NS測高偏移" + (0).ToString(), (point_position[40, 0] == null) ? (0).ToString() : point_position[40, 0], file);
            WritePrivateProfileString("2切參數", "NS特徵到針尾" + (0).ToString(), (point_position[40, 1] == null) ? (0).ToString() : point_position[40, 1], file);
            WritePrivateProfileString("2切參數", "NS定位點到特徵" + (0).ToString(), (point_position[40, 2] == null) ? (0).ToString() : point_position[40, 2], file);

            WritePrivateProfileString("2切參數", "BR測高偏移" + (0).ToString(), (point_position[41, 0] == null) ? (0).ToString() : point_position[41, 0], file);
            WritePrivateProfileString("2切參數", "BR特徵到針尾" + (0).ToString(), (point_position[41, 1] == null) ? (0).ToString() : point_position[41, 1], file);
            WritePrivateProfileString("2切參數", "BR定位點到特徵" + (0).ToString(), (point_position[41, 2] == null) ? (0).ToString() : point_position[41, 2], file);

            WritePrivateProfileString("導版雷射角度補償", "斜率" + (0).ToString(), (point_position[42, 0] == null) ? (0).ToString() : point_position[42, 0], file);
            WritePrivateProfileString("導版雷射角度補償", "補正值" + (0).ToString(), (point_position[42, 1] == null) ? (0).ToString() : point_position[42, 1], file);

            WritePrivateProfileString("導版雷射功率校正", "A" + (0).ToString(), (point_position[43, 0] == null) ? (0).ToString() : point_position[43, 0], file);
            WritePrivateProfileString("導版雷射功率校正", "B" + (0).ToString(), (point_position[43, 1] == null) ? (0).ToString() : point_position[43, 1], file);

            WritePrivateProfileString("高度設定", "導版雷射" + (0).ToString(), (point_position[44, 0] == null) ? (0).ToString() : point_position[44, 0], file);
        }
        [DllImport("kernel32", CharSet = CharSet.Unicode)]
        private static extern long WritePrivateProfileString(string section, string key, string val, string filePath);



        private void GP_relese()
        {
            group_Movement.Enabled = true;
            bt_ini();
        }
        private void bt_ini()
        {
            //button12.Enabled = false;
            //button13.Enabled = false;
            //Focus_test.Enabled = false;
            //bt_FixZ_Start.Enabled = false;
            //bt_vacuum.Enabled = true;
            //bt_vacuum2.Enabled = true;
            //bt_vacuum3.Enabled = true;
            //bt_vacuum4.Enabled = true;
            //bt_vacuum5.Enabled = true;
        }


        private void thread_stop()
        {
            _AutoDwring_flag = 0;
            if (_AutoDwring != null)
            {
                _AutoDwring.Abort();
            }
            if (Aero_thMotionRun != null)
            {
                Aero_thMotionRun.Abort();
                Thread_Enabled = true;
            }
            if (Thick_Test_Alarm != null)
            {
                Thick_Test_Alarm.Abort();
            }
            Thick_flag_Alarm = 0;
            if (Thick_Test != null)
            {
                Thick_Test.Abort();
            }
            Thick_flag = 0;
            if (Demo_Test != null)
            {
                Demo_Test.Abort();
            }
            DEMO_flag_P = 0;
            DEMO_flag = 0;
            if (thread_focus_Test != null)
            {
                thread_focus_Test.Abort();
            }

            FocusTest_flag = 0;
            if (thread_fixZ != null)
            {
                thread_fixZ.Abort();
            }
            fixZ_flag = 0;
            if (_autofocus != null)
            {
                _autofocus.Abort();
            }
            AT_focus_flag = 0;
            if (Thick_Test_2CUT != null)
            {
                Thick_Test_2CUT.Abort();
            }
            Thick_flag_2CUT = 0;
            if (thread_image_test != null)
            {
                thread_image_test.Abort();
            }
            image_flag = 0;
            if (Demo_Test_2CUT != null)
            {
                Demo_Test_2CUT.Abort();
            }
            DEMO_flag_2CUT = 0;

            if (Thick_Test_RD != null)
            {
                Thick_Test_RD.Abort();
            }
            Thick_flag_RD = 0;

            if (Demo_Test_RD != null)
            {
                Demo_Test_RD.Abort();
            }
            DEMO_flag_P_RD = 0;

            if (_AutoCutLayer != null)
            {
                _AutoCutLayer.Abort();
            }
            _AutoCutLyer_flag = 0;

            if (thread_CutFrame != null)
            {
                thread_CutFrame.Abort();
            }
            if (Thick_Test_hole != null)
            {
                Thick_Test_hole.Abort();
            }
            Thick_flag_hole = 0;

            run_gcode_list = false;
            CutFrame_Flag = 0;
            if (_GuideID != null)
            {
                _GuideID.Abort();
            }
            _GuideID_Flag = 0;

            NG2Cut.Clear();

            if (_Auto_GH_FindCenter != null)
            {
                _Auto_GH_FindCenter.Abort();
            }
            GH_FindCenter_flag = 0;

            if (_Auto_GH_DrawCenter != null)
            {
                _Auto_GH_DrawCenter.Abort();
            }
            GH_DrawCenter_flag = 0;

            if (_Auto_GH_FindEdgeCenter != null)
            {
                _Auto_GH_FindEdgeCenter.Abort();
            }
            GH_FindEdgeCenter_flag = 0;

            if (_Auto_GH_FindEdge_DrawCenter != null)
            {
                _Auto_GH_FindEdge_DrawCenter.Abort();
            }
            GH_FindEdge_DrawCenter_flag = 0;
            if (_RotateDisk_Work != null)
            {
                _RotateWork_flag = 0;
                _RotateDisk_Work.Abort();

                _RotateGrabFinish_L = false;
                _RotateGrabFinish_R = false;
            }
        }
        /// <summary>
        /// 解析 2CUT 模式下的加工座標檔，將座標資料分類為針點與其他圖層，並計算 pin pitch。
        /// 同時根據分組規則產生厚度測試座標與特徵點座標，更新 UI 顯示座標數量與間距。
        /// 若有非預期圖層則顯示警告訊息，並設定 ProcessFileRead_flag_2CUT 為 true。
        /// </summary>
        private void file_produce_2CUT()//2切檔案整理
        {
            if (System.IO.File.Exists(TB_LoadFilePath_2CUT.Text))
            {
                if (TB_LoadFilePath_2CUT.Text != "" && System.IO.File.Exists(TB_LoadFilePath_2CUT.Text))
                {
                    int dd = 0, bb = 0, cc = 0, ee = 0;
                    Sym_TotalNumber = 0;
                    //procerr_TotalNumber_2CUT = 0;
                    pin_TotalNumber_2CUT = 0;
                    tkn_TotalNumber_2CUT = 0;
                    small_TotalNumber_2CUT = 0;
                    StreamReader sr = new StreamReader(TB_LoadFilePath_2CUT.Text);
                    while (!sr.EndOfStream)
                    {
                        process_arry_2CUT[dd] = sr.ReadLine();
                        if (process_arry_2CUT[dd].Length > 2)
                        {
                            string[] sArray = process_arry_2CUT[dd].Split('\t');// 一定是單引
                            process_X_2CUT[dd] = sArray[0];
                            process_Y_2CUT[dd] = sArray[1];
                            process_Z_2CUT[dd] = sArray[2];
                            process_Layer_2CUT[dd] = sArray[3];

                            if (process_Layer_2CUT[dd] == TB_Head_2CUT.Text)//如果是圖層 9
                            {
                                pin_X_2CUT[bb] = process_X_2CUT[dd];
                                pin_Y_2CUT[bb] = process_Y_2CUT[dd];
                                bb++;
                                pin_TotalNumber_2CUT++;

                            }
                            else if (process_Layer_2CUT[dd] == tb_Smallbox.Text && cb_smallbox_switch.Checked == true)
                            {
                                Smallbox_X[ee] = process_X_2CUT[dd];
                                Smallbox_Y[ee] = process_Y_2CUT[dd];
                                ee++;
                                small_TotalNumber_2CUT++;

                            }
                            else
                            {
                                cc++;
                            }
                            dd++;
                        }

                    }
                    if (!RB_NS_ShortPitch.Checked && !RB_BR_ShortPitch.Checked && !RB_NS_Alignment.Checked && !RB_BR_Alignment.Checked)
                    {
                        pin_pitch_2CUT = Math.Abs(Convert.ToDouble(pin_X_2CUT[0]) - Convert.ToDouble(pin_X_2CUT[1])) / (Convert.ToInt16(tb_ReginPinNum.Text) - 1);
                    }
                    else if (RB_NS_ShortPitch.Checked)
                    {
                        pin_pitch_2CUT = Math.Abs((Convert.ToDouble(pin_X_2CUT[0]) - Convert.ToDouble(point_position[34, 2])) - (Convert.ToDouble(pin_X_2CUT[1]) + Convert.ToDouble(point_position[34, 2]))) / (Convert.ToInt16(tb_ReginPinNum.Text) - 1);

                        // pin_pitch_2CUT = Math.Abs((Convert.ToDouble(pin_X_2CUT[0]) + Convert.ToDouble(point_position[34, 2])) - (Convert.ToDouble(pin_X_2CUT[1]) - Convert.ToDouble(point_position[34, 2]))) / (Convert.ToInt16(tb_ReginPinNum.Text) - 1);

                    }
                    else if (RB_BR_ShortPitch.Checked)
                    {
                        pin_pitch_2CUT = Math.Abs((Convert.ToDouble(pin_X_2CUT[0]) - Convert.ToDouble(point_position[39, 2])) - (Convert.ToDouble(pin_X_2CUT[1]) + Convert.ToDouble(point_position[39, 2]))) / (Convert.ToInt16(tb_ReginPinNum.Text) - 1);

                        // pin_pitch_2CUT = Math.Abs((Convert.ToDouble(pin_X_2CUT[0]) + Convert.ToDouble(point_position[39, 2])) - (Convert.ToDouble(pin_X_2CUT[1]) - Convert.ToDouble(point_position[39, 2]))) / (Convert.ToInt16(tb_ReginPinNum.Text) - 1);//原本
                    }
                    else if (RB_NS_Alignment.Checked)
                    {
                        pin_pitch_2CUT = Math.Abs((Convert.ToDouble(pin_X_2CUT[0]) - Convert.ToDouble(point_position[40, 2])) - (Convert.ToDouble(pin_X_2CUT[1]) + Convert.ToDouble(point_position[40, 2]))) / (Convert.ToInt16(tb_ReginPinNum.Text) - 1);

                        // pin_pitch_2CUT = Math.Abs((Convert.ToDouble(pin_X_2CUT[0]) + Convert.ToDouble(point_position[40, 2])) - (Convert.ToDouble(pin_X_2CUT[1]) - Convert.ToDouble(point_position[40, 2]))) / (Convert.ToInt16(tb_ReginPinNum.Text) - 1);
                    }
                    else if (RB_BR_Alignment.Checked)
                    {
                        pin_pitch_2CUT = Math.Abs((Convert.ToDouble(pin_X_2CUT[0]) - Convert.ToDouble(point_position[41, 2])) - (Convert.ToDouble(pin_X_2CUT[1]) + Convert.ToDouble(point_position[41, 2]))) / (Convert.ToInt16(tb_ReginPinNum.Text) - 1);

                        // pin_pitch_2CUT = Math.Abs((Convert.ToDouble(pin_X_2CUT[0]) + Convert.ToDouble(point_position[41, 2])) - (Convert.ToDouble(pin_X_2CUT[1]) - Convert.ToDouble(point_position[41, 2]))) / (Convert.ToInt16(tb_ReginPinNum.Text) - 1);
                    }



                    for (int i = 0; i < pin_TotalNumber_2CUT / 2; i++)
                    {
                        tkn_X_2CUT[i] = (-1 * Convert.ToDouble(pin_X_2CUT[i * 2])).ToString();
                        tkn_Y_2CUT[i] = (-1 * Convert.ToDouble(pin_Y_2CUT[i * 2])).ToString();


                        //tkn_X_2CUT[i] = pin_X_2CUT[i * 2];
                        //tkn_Y_2CUT[i] = pin_Y_2CUT[i * 2];
                        tkn_TotalNumber_2CUT++;


                    }

                    for (int i = 0; i < (pin_TotalNumber_2CUT); i++)
                    {
                        simple_X[i] = (-1 * Convert.ToDouble(pin_X_2CUT[i])).ToString();
                        simple_Y[i] = (-1 * Convert.ToDouble(pin_Y_2CUT[i])).ToString();

                        //simple_X[i] = pin_X_2CUT[i];
                        //    simple_Y[i] = pin_Y_2CUT[i];
                        Sym_TotalNumber++;
                    }

                    label260.Text = "座標數量: " + pin_TotalNumber_2CUT.ToString();
                    label258.Text = "pin_pitch: " + pin_pitch_2CUT.ToString();
                    sr.Close();

                    if (cb_smallbox_switch.Checked == true &&
                        ee <= 1)
                    {
                        MessageBox.Show("有勾選方框辨識功能, 但檔案內無辨識座標, 請重新確認檔案, 辨識圖層為: " + tb_Smallbox.Text);
                    }

                    if (cc > 0)
                    {
                        MessageBox.Show("有 " + cc.ToString() + " 個不是圖層9,注意檔案是否為特徵點檔案");
                    }

                    ProcessFileRead_flag_2CUT = true;
                }

            }
            else
            {
                ProcessFileRead_flag_2CUT = false;
                MessageBox.Show("檔案路徑錯誤!!!");
            }
        }

        #endregion

        #region Timer
        private void timer1_Tick(object sender, EventArgs e)
        {
            textBox_ProcessMSG.Text = prog_status;//回到ui執行緒更新內容


            #region 檢查加工檔欄位是否有資訊
            if (!string.IsNullOrWhiteSpace(TB_LoadFilePath_2CUT.Text))
            {
                ProcessFileRead_flag = true;
            }
            #endregion

            #region 載檔後解析
            label260.Text = "座標數量: " + pin_TotalNumber_2CUT.ToString();
            label258.Text = "pin_pitch: " + pin_pitch_2CUT.ToString();
            #endregion

            #region 定為孔置中顯示數置值
            lb_LCC_X_reg.Text = LCC_X_reg.ToString();
            lb_LCC_Y_reg.Text = LCC_Y_reg.ToString();
            lb_LCC_Y.Text = LCC_Y.ToString();
            lb_LCC_X.Text = LCC_X.ToString();
            #endregion

            #region 測高最大最小值
            lb_max_2CUT.Text = max_2CUT.ToString();
            lb_min_2CUT.Text = min_2CUT.ToString();
            #endregion

            #region 加工資訊欄
            if (DEMO_flag_2CUT != 0)
            {
                DateTime END = DateTime.Now;
                TimeSpan SS = END - StartTime;

                lb_start_time.Text = StartTime.ToString("yyyy-MM-dd HH:mm:ss");

                textBox_HoleNum.Text = ((pin_TotalNumber_2CUT * Convert.ToInt16(tb_ReginPinNum.Text)) / 2).ToString();
                textBox_HoldDone.Text = ((process_2CUT_i + process_2CUT_TIP_i) / 2).ToString();
                textBox_HoleRemain.Text = (((pin_TotalNumber_2CUT * Convert.ToInt16(tb_ReginPinNum.Text)) / 2) - ((process_2CUT_i + process_2CUT_TIP_i) / 2)).ToString();

                //tb_time_R.Text = ((int)(((pin_TotalNumber_2CUT * Convert.ToInt16(tb_ReginPinNum.Text)) - (process_2CUT_i + process_2CUT_TIP_i))) * 0.5 / 60).ToString();
                tb_time_R.Text = (Convert.ToInt16(textBox_HoleNum.Text) - Convert.ToInt16(textBox_HoldDone.Text) * 1.238 / 60).ToString();//0.5為1跟針多少時間(秒)
                tb_time_TH.Text = SS.TotalMinutes.ToString();

                //  double CUT2 = ((int)(((pin_TotalNumber_2CUT * Convert.ToInt16(tb_ReginPinNum.Text)) - (process_2CUT_i + process_2CUT_TIP_i))) * 0.5 / 60) * 60 / Convert.ToInt16(textBox_HoleRemain.Text);
                if (Convert.ToInt32(textBox_HoleRemain.Text) > 0)
                {
                    double CUT2 = Convert.ToDouble(tb_time_R.Text) * 60 / Convert.ToInt16(textBox_HoleRemain.Text);//*60是分鐘換成秒 ，除textBox_HoleRemain.Text是計算剩下分鐘要分配給幾根針

                    if (pin_time_average.Count > 1000)
                    {
                        pin_time_average.Clear();
                    }
                    else
                    {
                        pin_time_average.Add(CUT2);
                        lb_Pin_time.Text = pin_time_average.Average().ToString("F2");
                    }
                }

                if (pin_time_average.Count != 0 && endtimeflag)//若有數值 則用每根針所需的分鐘數*剩下幾根針+到開始時間計算出預計完工年月日時分秒
                {
                    DateTime endTime = StartTime.AddMinutes(((int)(((pin_TotalNumber_2CUT * Convert.ToInt16(tb_ReginPinNum.Text)) - (process_2CUT_i + process_2CUT_TIP_i))) * 0.5 / 60));
                    lb_end_time.Text = endTime.ToString("yyyy-MM-dd HH:mm:ss");
                    endtimeflag = false;
                }
            }
            else
            {
                lb_start_time.Text = "0";
                lb_end_time.Text = "0";
                lb_Pin_time.Text = "0";

                tb_time_R.Text = "0";
                tb_time_TH.Text = "0";

                textBox_HoleNum.Text = "0";
                textBox_HoldDone.Text = "0";
                textBox_HoleRemain.Text = "0";
            }
            #endregion

            #region 特徵搜尋

            label279.Text = pin_TotalNumber_2CUT.ToString();
            label280.Text = image_ok_num.ToString();
            label287.Text = image_error_count.ToString();

            label446.Text = small_TotalNumber_2CUT.ToString();
            label444.Text = Smallbox_error_num.ToString();


            label445.Text = (smallbox_i - Smallbox_error_num).ToString();

            #endregion

            #region 取得量測的雷射功率(W)
            if (_isReadPowerMeter)
            {
                getPowermeterStatus();

                if (_Powermeter.measurementStr > 0.01) //Convert Unit from W
                {
                    OutputPower.Add(_Powermeter.measurementStr);
                }
            }
            #endregion

            #region 要載入2個刀具檔才可以開始二切
            if (!string.IsNullOrWhiteSpace(TB_LoadFilePath_EndJobx.Text) && !string.IsNullOrWhiteSpace(TB_LoadFilePath_HeadJobx.Text))
            {
                checkBox_AutoStart2CUT.Enabled = true;
                bt_2CUTStart.Enabled = true;
            }
            #endregion
        }

        private void MES_timer_Tick(object sender, EventArgs e)
        {
            // data_jason();
        }

        #endregion

        #region UI control

        #region 載入2切頭、尾刀具檔
        private void BT_LoadFile_HeadJobx_Click(object sender, EventArgs e)
        {
            OpenFileDialog dialog = new OpenFileDialog(); // 建立檔案選擇對話框
            dialog.Multiselect = true; // 可選擇多個檔案（目前未使用）
            dialog.Title = "請選擇2切針頭 .jobx 檔案"; // 設定對話框標題
            dialog.Filter = "JobX 檔案 (*.jobx)|*.jobx";
            dialog.DefaultExt = "jobx";

            if (dialog.ShowDialog() == System.Windows.Forms.DialogResult.OK)// 若使用者選擇檔案並按下確定
            {
                TB_LoadFilePath_HeadJobx.Text = dialog.FileName; // 顯示檔案路徑於 UI 欄位
                //捲到最後面
                TB_LoadFilePath_HeadJobx.SelectionStart = TB_LoadFilePath_HeadJobx.Text.Length;
                TB_LoadFilePath_HeadJobx.ScrollToCaret();





            }
        }

        private void BT_LoadFile_EndJobx_Click(object sender, EventArgs e)
        {
            OpenFileDialog dialog = new OpenFileDialog(); // 建立檔案選擇對話框
            dialog.Multiselect = true; // 可選擇多個檔案（目前未使用）
            dialog.Title = "請選擇2切針尾 .jobx 檔案"; // 設定對話框標題
            dialog.Filter = "JobX 檔案 (*.jobx)|*.jobx";
            dialog.DefaultExt = "jobx";

            if (dialog.ShowDialog() == System.Windows.Forms.DialogResult.OK)// 若使用者選擇檔案並按下確定
            {
                TB_LoadFilePath_EndJobx.Text = dialog.FileName; // 顯示檔案路徑於 UI 欄位
                                                                //捲到最後面
                TB_LoadFilePath_EndJobx.SelectionStart = TB_LoadFilePath_EndJobx.Text.Length;
                TB_LoadFilePath_EndJobx.ScrollToCaret();
            }
        }

        #endregion

        #region 軸控
        /// <summary>
        ///雷射加工位置 ->測高
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>

        private void button_LaserKeyence_Click(object sender, EventArgs e)
        {
            if (!motioning())
            {
                WriteLog("Log", "_Log.ini", $"雷射到測高");

                Distance_X = Convert.ToDouble(point_position[21, 0]);
                Distance_Y = Convert.ToDouble(point_position[21, 1]);
                Aero_thMotionRun_Tick(Motion_Num.Rapid);
            }
            else
            {
                MessageBox.Show("motioning");
            }
        }
        /// <summary>
        /// 測高->雷射加工位置
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void button_KeyenceLaser_Click(object sender, EventArgs e)
        {
            if (!motioning())
            {
                WriteLog("Log", "_Log.ini", $"測高到雷射");

                Distance_X = -Convert.ToDouble(point_position[21, 0]);
                Distance_Y = -Convert.ToDouble(point_position[21, 1]);
                Aero_thMotionRun_Tick(Motion_Num.Rapid);
            }
            else
            {
                MessageBox.Show("motioning");
            }
        }
        /// <summary>
        /// 雷射加工位置->ccd
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void button_LaserCCD_Click(object sender, EventArgs e)
        {
            if (!motioning())
            {
                WriteLog("Log", "_Log.ini", $"雷射到ccd");

                Distance_X = Convert.ToDouble(point_position[20, 0]);
                Distance_Y = Convert.ToDouble(point_position[20, 1]);
                Aero_thMotionRun_Tick(Motion_Num.Rapid);
            }
            else
            {
                MessageBox.Show("motioning");
            }
        }
        /// <summary>
        /// ccd->雷射加工位置
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void button_CCDLaser_Click(object sender, EventArgs e)
        {
            if (!motioning())
            {
                WriteLog("Log", "_Log.ini", $"ccd到雷射");

                Distance_X = -Convert.ToDouble(point_position[20, 0]);
                Distance_Y = -Convert.ToDouble(point_position[20, 1]);
                Aero_thMotionRun_Tick(Motion_Num.Rapid);
            }
            else
            {
                MessageBox.Show("motioning");
            }
        }

        /// <summary>
        /// ccd->測距
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void button_CCDKeyence_Click(object sender, EventArgs e)
        {
            if (!motioning())
            {
                WriteLog("Log", "_Log.ini", $"ccd到測距");
                Distance_X = -(Convert.ToDouble(point_position[20, 0]) - Convert.ToDouble(point_position[21, 0]));
                Distance_Y = -(Convert.ToDouble(point_position[20, 1]) - Convert.ToDouble(point_position[21, 1]));
                Aero_thMotionRun_Tick(Motion_Num.Rapid);
            }
            else
            {
                MessageBox.Show("motioning");
            }
        }

        /// <summary>
        /// 測距->ccd
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void button_KeyenceCCD_Click(object sender, EventArgs e)
        {
            if (!motioning())
            {
                LogTime = DateTime.Now;

                WriteLog("Log", "_Log.ini", $"測距到ccd");


                //using (StreamWriter text = new StreamWriter(Path.Combine(Environment.CurrentDirectory, "LCN_LOG", "Log") + LogTime.ToString("yyyyMMdd") + "_Log.ini", true))//  using (StreamWriter text = new StreamWriter(classSystem.path_thickness + LogTime.ToString("yyyyMMdd") + "_Log.ini", true))
                //{
                //    text.WriteLine(LogTime.ToString("yyyyMMddHHmm") + ";" + "*測距到ccd*");
                //    text.Close();
                //}
                Distance_X = Convert.ToDouble(point_position[20, 0]) - Convert.ToDouble(point_position[21, 0]);
                Distance_Y = Convert.ToDouble(point_position[20, 1]) - Convert.ToDouble(point_position[21, 1]);
                Aero_thMotionRun_Tick(Motion_Num.Rapid);
            }
            else
            {
                MessageBox.Show("motioning..........plz wait");
            }
        }

        private void buttonX_P_MouseDown(object sender, MouseEventArgs e)
        {
            if (rdo_jog.Checked == true)
            {
                try
                {
                    this.myController.Commands[this.taskIndex].Motion.FreeRun(0, double.Parse(VSet_X.Text));

                }
                catch (A3200Exception exception)
                {
                    txt_Motion_ErrorMsg.Text = exception.Message;
                }
            }
        }

        private void buttonX_P_MouseUp(object sender, MouseEventArgs e)
        {
            if (rdo_jog.Checked == true)
            {
                try
                {
                    this.myController.Commands[this.taskIndex].Motion.FreeRunStop(0);
                }
                catch (A3200Exception exception)
                {
                    txt_Motion_ErrorMsg.Text = exception.Message;
                }
            }
        }

        private void buttonX_N_MouseDown(object sender, MouseEventArgs e)
        {
            if (rdo_jog.Checked == true)
            {
                try
                {
                    this.myController.Commands[this.taskIndex].Motion.FreeRun(0, -double.Parse(VSet_X.Text));
                }
                catch (A3200Exception exception)
                {
                    txt_Motion_ErrorMsg.Text = exception.Message;
                }
            }
        }

        private void buttonX_N_MouseUp(object sender, MouseEventArgs e)
        {
            if (rdo_jog.Checked == true)
            {
                try
                {
                    this.myController.Commands[this.taskIndex].Motion.FreeRunStop(0);
                }
                catch (A3200Exception exception)
                {
                    txt_Motion_ErrorMsg.Text = exception.Message;
                }
            }
        }

        private void buttonY_N_MouseDown(object sender, MouseEventArgs e)
        {
            if (rdo_jog.Checked == true)
            {
                try
                {
                    this.myController.Commands[this.taskIndex].Motion.FreeRun(1, -double.Parse(VSet_Y.Text));
                }
                catch (A3200Exception exception)
                {
                    txt_Motion_ErrorMsg.Text = exception.Message;
                }
            }
        }

        private void buttonY_N_MouseUp(object sender, MouseEventArgs e)
        {
            if (rdo_jog.Checked == true)
            {
                try
                {
                    this.myController.Commands[this.taskIndex].Motion.FreeRunStop(1);
                }
                catch (A3200Exception exception)
                {
                    txt_Motion_ErrorMsg.Text = exception.Message;
                }
            }
        }
        private void buttonY_P_MouseDown(object sender, MouseEventArgs e)
        {
            if (rdo_jog.Checked == true)
            {
                try
                {
                    this.myController.Commands[this.taskIndex].Motion.FreeRun(1, double.Parse(VSet_Y.Text));
                }
                catch (A3200Exception exception)
                {
                    txt_Motion_ErrorMsg.Text = exception.Message;
                }
            }
        }

        private void buttonY_P_MouseUp(object sender, MouseEventArgs e)
        {
            if (rdo_jog.Checked == true)
            {
                try
                {
                    this.myController.Commands[this.taskIndex].Motion.FreeRunStop(1);
                }
                catch (A3200Exception exception)
                {
                    txt_Motion_ErrorMsg.Text = exception.Message;
                }
            }
        }

        private void buttonZ_P_MouseDown(object sender, MouseEventArgs e)
        {
            if (rdo_jog.Checked == true)
            {
                try
                {
                    this.myController.Commands[this.taskIndex].Motion.FreeRun(2, double.Parse(VSet_Z.Text));
                }
                catch (A3200Exception exception)
                {
                    txt_Motion_ErrorMsg.Text = exception.Message;
                }
            }
        }

        private void buttonZ_P_MouseUp(object sender, MouseEventArgs e)
        {
            if (rdo_jog.Checked == true)
            {
                try
                {
                    this.myController.Commands[this.taskIndex].Motion.FreeRunStop(2);
                }
                catch (A3200Exception exception)
                {
                    txt_Motion_ErrorMsg.Text = exception.Message;
                }
            }
        }

        private void buttonZ_N_MouseUp(object sender, MouseEventArgs e)
        {
            if (rdo_jog.Checked == true)
            {
                try
                {
                    this.myController.Commands[this.taskIndex].Motion.FreeRunStop(2);
                }
                catch (A3200Exception exception)
                {
                    txt_Motion_ErrorMsg.Text = exception.Message;
                }
            }
        }

        private void buttonZ_N_MouseDown(object sender, MouseEventArgs e)
        {
            if (rdo_jog.Checked == true)
            {
                try
                {
                    this.myController.Commands[this.taskIndex].Motion.FreeRun(2, -double.Parse(VSet_Z.Text));
                }
                catch (A3200Exception exception)
                {
                    txt_Motion_ErrorMsg.Text = exception.Message;
                }
            }
        }









        private void buttonX_P_Click(object sender, EventArgs e)
        {
            if (rdo_jog.Checked == false)
            {
                if (rdo_PR.Checked == true)
                {
                    try
                    {
                        this.myController.Commands[this.taskIndex].Motion.MoveInc(0, Convert.ToDouble(txt_Distance_X.Text), double.Parse(VSet_X.Text));

                    }
                    catch (A3200Exception exception)
                    {
                        txt_Motion_ErrorMsg.Text = exception.Message;
                    }
                }
                else
                {
                    if (rdo_PA.Checked == true)
                    {
                        try
                        {
                            this.myController.Commands[this.taskIndex].Motion.MoveAbs(0, Convert.ToDouble(txt_Distance_X.Text), double.Parse(VSet_X.Text));

                        }
                        catch (A3200Exception exception)
                        {
                            txt_Motion_ErrorMsg.Text = exception.Message;
                        }
                    }
                }
            }

        }

        private void buttonX_N_Click(object sender, EventArgs e)
        {
            if (rdo_jog.Checked == false)
            {
                if (rdo_PR.Checked == true)
                {
                    try
                    {
                        this.myController.Commands[this.taskIndex].Motion.MoveInc(0, -Convert.ToDouble(txt_Distance_X.Text), double.Parse(VSet_X.Text));

                    }
                    catch (A3200Exception exception)
                    {
                        txt_Motion_ErrorMsg.Text = exception.Message;
                    }
                }
                else
                {
                    if (rdo_PA.Checked == true)
                    {
                        try
                        {
                            this.myController.Commands[this.taskIndex].Motion.MoveAbs(0, Convert.ToDouble(txt_Distance_X.Text), double.Parse(VSet_X.Text));

                        }
                        catch (A3200Exception exception)
                        {
                            txt_Motion_ErrorMsg.Text = exception.Message;
                        }
                    }
                }
            }
        }

        private void buttonY_N_Click(object sender, EventArgs e)
        {
            if (rdo_jog.Checked == false)
            {
                if (rdo_PR.Checked == true)
                {
                    try
                    {
                        this.myController.Commands[this.taskIndex].Motion.MoveInc(1, -Convert.ToDouble(txt_Distance_Y.Text), double.Parse(VSet_Y.Text));

                    }
                    catch (A3200Exception exception)
                    {
                        txt_Motion_ErrorMsg.Text = exception.Message;
                    }
                }
                else
                {
                    if (rdo_PA.Checked == true)
                    {
                        try
                        {
                            this.myController.Commands[this.taskIndex].Motion.MoveAbs(1, Convert.ToDouble(txt_Distance_Y.Text), double.Parse(VSet_Y.Text));

                        }
                        catch (A3200Exception exception)
                        {
                            txt_Motion_ErrorMsg.Text = exception.Message;
                        }
                    }
                }
            }

        }

        private void buttonY_P_Click(object sender, EventArgs e)
        {
            if (rdo_jog.Checked == false)
            {
                if (rdo_PR.Checked == true)
                {
                    try
                    {
                        this.myController.Commands[this.taskIndex].Motion.MoveInc(1, Convert.ToDouble(txt_Distance_Y.Text), double.Parse(VSet_Y.Text));

                    }
                    catch (A3200Exception exception)
                    {
                        txt_Motion_ErrorMsg.Text = exception.Message;
                    }
                }
                else
                {
                    if (rdo_PA.Checked == true)
                    {
                        try
                        {
                            this.myController.Commands[this.taskIndex].Motion.MoveAbs(1, Convert.ToDouble(txt_Distance_Y.Text), double.Parse(VSet_Y.Text));

                        }
                        catch (A3200Exception exception)
                        {
                            txt_Motion_ErrorMsg.Text = exception.Message;
                        }
                    }
                }
            }
        }

        private void buttonZ_N_Click(object sender, EventArgs e)
        {
            if (rdo_jog.Checked == false)
            {
                if (rdo_PR.Checked == true)
                {
                    try
                    {
                        this.myController.Commands[this.taskIndex].Motion.MoveInc(2, -Convert.ToDouble(txt_Distance_Z.Text), double.Parse(VSet_Z.Text));

                    }
                    catch (A3200Exception exception)
                    {
                        txt_Motion_ErrorMsg.Text = exception.Message;
                    }
                }
                else
                {
                    if (rdo_PA.Checked == true)
                    {
                        try
                        {
                            this.myController.Commands[this.taskIndex].Motion.MoveAbs(2, Convert.ToDouble(txt_Distance_Z.Text), double.Parse(VSet_Z.Text));

                        }
                        catch (A3200Exception exception)
                        {
                            txt_Motion_ErrorMsg.Text = exception.Message;
                        }
                    }
                }
            }
        }

        private void buttonZ_P_Click(object sender, EventArgs e)
        {
            if (rdo_jog.Checked == false)
            {
                if (rdo_PR.Checked == true)
                {
                    try
                    {
                        this.myController.Commands[this.taskIndex].Motion.MoveInc(2, Convert.ToDouble(txt_Distance_Z.Text), double.Parse(VSet_Z.Text));

                    }
                    catch (A3200Exception exception)
                    {
                        txt_Motion_ErrorMsg.Text = exception.Message;
                    }
                }
                else
                {
                    if (rdo_PA.Checked == true)
                    {
                        try
                        {
                            this.myController.Commands[this.taskIndex].Motion.MoveAbs(2, Convert.ToDouble(txt_Distance_Z.Text), double.Parse(VSet_Z.Text));

                        }
                        catch (A3200Exception exception)
                        {
                            txt_Motion_ErrorMsg.Text = exception.Message;
                        }
                    }
                }
            }

        }

        /// <summary>
        ///LCN速度選擇表
        /// </summary>
        private void combobox_setup()
        {
            comboBox_X.Items.Add("1");
            comboBox_X.Items.Add("10");
            comboBox_X.Items.Add("20");
            comboBox_X.Items.Add("40");
            comboBox_X.Items.Add("60");
            comboBox_X.SelectedIndex = 3;
            comboBox_Y.Items.Add("1");
            comboBox_Y.Items.Add("10");
            comboBox_Y.Items.Add("20");
            comboBox_Y.Items.Add("40");
            comboBox_Y.Items.Add("60");
            comboBox_Y.SelectedIndex = 3;
            comboBox_Z.Items.Add("1");
            comboBox_Z.Items.Add("10");
            comboBox_Z.Items.Add("20");
            comboBox_Z.Items.Add("40");
            comboBox_Z.Items.Add("60");
            comboBox_Z.SelectedIndex = 2;
        }

        private void comboBox_X_SelectedIndexChanged(object sender, EventArgs e)
        {
            VSet_X.Text = comboBox_X.Text;

        }

        private void comboBox_Y_SelectedIndexChanged(object sender, EventArgs e)
        {
            VSet_Y.Text = comboBox_Y.Text;
        }

        private void comboBox_Z_SelectedIndexChanged(object sender, EventArgs e)
        {
            VSet_Z.Text = comboBox_Z.Text;
        }




        #endregion


        #region 連線aerotech
        private void btn_connect_Click_1(object sender, EventArgs e)
        {
            group_MotionControl.Enabled = false;
            groupBox73.Enabled = true;
            tabControl3.Enabled = true;
            groupBox57.Enabled = true;
            groupBox23.Enabled = true;
            pl_PowerTun.Enabled = true;





            try
            {
                if (myController == null)
                {
                    pn_LCNcontrol.Visible = true;


                    //LCH斷線
                    // Unregister task state and diagPackect arrived events
                    _MC_Controller.ControlCenter.Diagnostics.NewDiagPacketArrived -= new EventHandler<NewDiagPacketArrivedEventArgs>(Diagnostics_NewDiagPacketArrived);

                    _MotionControl.Deinitialize();

                    _MotionControl.Close();

                    // Disable GUI Controls
                    //EnableGUIMotionControls(false);

                    // Disable UI control
                    // enableUIGroup(false);

                    // Update Motion Main Status
                    updateMainStatusImage(MainState.Disconnect);







                    //LCN連線
                    this.myController = Controller.Connect();
                    // register task state and diagPackect arrived events
                    //this.myController.ControlCenter.TaskStates.NewTaskStatesArrived += new EventHandler<NewTaskStatesArrivedEventArgs>(TaskStates_NewTaskStatesArrived);
                    this.myController.ControlCenter.Diagnostics.NewDiagPacketArrived += new EventHandler<NewDiagPacketArrivedEventArgs>(Diagnostics_NewDiagPacketArrived);

                    //_AxisStatus = new Thread(Status_Axis);
                    //_AxisStatus.Start();



                    //btn_connect.Enabled = false;
                    //btn_disconnect.Enabled = true;
                }



                #region 上拋給MES方法
                _TCP_DataUPLoad.IP = _ConfigSystem._Server_IP;
                _TCP_DataUPLoad.Port = _ConfigSystem._Server_Port;
                _TCP_DataUPLoad.Connect();
                this.Invoke(new dDataUPLoad(DataUPLoad_Start));
                #endregion












                timer1.Enabled = true;
                timer1.Start();

            }
            catch (A3200Exception exception)
            {
                txt_Motion_ErrorMsg.Text = exception.Message;
            }

        }


        private void btn_disconnect_Click_1(object sender, EventArgs e)
        {
            //   _isLCN = false;
            group_MotionControl.Enabled = true;

            try
            {
                if (myController != null)
                {
                    pn_LCNcontrol.Visible = false;


                    // register task state and diagPackect arrived events
                    //this.myController.ControlCenter.TaskStates.NewTaskStatesArrived += new EventHandler<NewTaskStatesArrivedEventArgs>(TaskStates_NewTaskStatesArrived);
                    this.myController.ControlCenter.Diagnostics.NewDiagPacketArrived -= new EventHandler<NewDiagPacketArrivedEventArgs>(Diagnostics_NewDiagPacketArrived);
                    Controller.Disconnect();


                    //_MotionControl.Deinitialize();

                    //_MotionControl.Close();

                    //btn_connect.Enabled = true;
                    //btn_disconnect.Enabled = false;
                    //  _AxisStatus.Abort();







                    Thread.Sleep(3000);









                    //LCH連線
                    _MotionControl.Connect();

                    _MotionControl.Initialize();

                    // Consign controller after connection
                    _MC_Controller = _MotionControl.GetController();

                    // register task state and diagPackect arrived events
                    //_MC_Controller.ControlCenter.TaskStates.NewTaskStatesArrived += new EventHandler<NewTaskStatesArrivedEventArgs>(TaskStates_NewTaskStatesArrived);
                    _MC_Controller.ControlCenter.Diagnostics.NewDiagPacketArrived += new EventHandler<NewDiagPacketArrivedEventArgs>(Diagnostics_NewDiagPacketArrived);

                    // Set the G code mode to Absolute mode
                    string code = "G90";
                    executeGCode(code);

                    // Enable GUI Controls
                    //EnableGUIMotionControls(true);

                    // Disable UI control
                    //  enableUIGroup(true);

                    // Update Motion Main Status
                    updateMainStatusImage(MainState.Connect);
                }
                timer1.Stop();
            }
            catch (A3200Exception exception)
            {
                txt_Motion_ErrorMsg.Text = exception.Message;
            }

        }
        #endregion

        #region 出、入料
        /// <summary>
        /// 出料位置
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void button18_Click(object sender, EventArgs e)
        {
            //#region LCN與LCH軸控切換
            //try
            //{
            //    if (myController == null)
            //    {



            //        //LCH斷線
            //        // Unregister task state and diagPackect arrived events
            //        _MC_Controller.ControlCenter.Diagnostics.NewDiagPacketArrived -= new EventHandler<NewDiagPacketArrivedEventArgs>(Diagnostics_NewDiagPacketArrived);

            //        _MotionControl.Deinitialize();

            //        _MotionControl.Close();

            //        // Disable GUI Controls
            //        //EnableGUIMotionControls(false);

            //        // Disable UI control
            //        // enableUIGroup(false);

            //        // Update Motion Main Status
            //        updateMainStatusImage(MainState.Disconnect);



            //        //LCN連線
            //        this.myController = Controller.Connect();
            //        // register task state and diagPackect arrived events
            //        //this.myController.ControlCenter.TaskStates.NewTaskStatesArrived += new EventHandler<NewTaskStatesArrivedEventArgs>(TaskStates_NewTaskStatesArrived);
            //        this.myController.ControlCenter.Diagnostics.NewDiagPacketArrived += new EventHandler<NewDiagPacketArrivedEventArgs>(Diagnostics_NewDiagPacketArrived);

            //        //_AxisStatus = new Thread(Status_Axis);
            //        //_AxisStatus.Start();



            //        //btn_connect.Enabled = false;
            //        //btn_disconnect.Enabled = true;
            //    }
            //}
            //catch (A3200Exception exception)
            //{
            //    txt_Motion_ErrorMsg.Text = exception.Message;
            //}
            //#endregion

            if (myController.Commands.Motion.WaitForMotionDone(Aerotech.A3200.Commands.WaitOption.InPosition, 0, 2000) && myController.Commands.Motion.WaitForMotionDone(Aerotech.A3200.Commands.WaitOption.InPosition, 1, 2000) && myController.Commands.Motion.WaitForMotionDone(Aerotech.A3200.Commands.WaitOption.InPosition, 2, 2000))
            {

                if (Motion_X && Motion_Y && Motion_Z)
                {
                    if (Thick_flag == 0 && DEMO_flag == 0 && FocusTest_flag == 0 && fixZ_flag == 0 && Thick_flag_Alarm == 0 && Thick_flag_2CUT == 0 && DEMO_flag_P == 0 && AT_focus_flag == 0 && image_flag == 0 && DEMO_flag_2CUT == 0)
                    {
                        ABS_X = Convert.ToDouble(point_position[3, 0]);
                        ABS_Y = Convert.ToDouble(point_position[3, 1]);
                        ABS_Z = Convert.ToDouble(point_position[3, 2]);
                        Allow_X = Allow_Y = Allow_Z = true;
                        //Allow_Z = false;
                        //MessageBox.Show(i.ToString()+","+ ABS_X.ToString() + ";" + j.ToString()+","+ABS_Y.ToString());
                        //Aero_thMotionRun_Tick(Motion_Num.Motion_ABS);

                        if (Allow_X)
                        {
                            this.myController.Commands[this.taskIndex].Motion.MoveAbs(0, ABS_X, 50);
                        }
                        if (Allow_Y)
                        {
                            this.myController.Commands[this.taskIndex].Motion.MoveAbs(1, ABS_Y, 50);
                        }
                        if (Allow_Z)
                        {
                            this.myController.Commands[this.taskIndex].Motion.MoveAbs(2, ABS_Z, 20);
                        }
                    }
                }
            }

        }
        /// <summary>
        /// 入料位置
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void button19_Click(object sender, EventArgs e)
        {
            //#region LCN與LCH軸控切換
            //try
            //{
            //    if (myController == null)
            //    {



            //        //LCH斷線
            //        // Unregister task state and diagPackect arrived events
            //        _MC_Controller.ControlCenter.Diagnostics.NewDiagPacketArrived -= new EventHandler<NewDiagPacketArrivedEventArgs>(Diagnostics_NewDiagPacketArrived);

            //        _MotionControl.Deinitialize();

            //        _MotionControl.Close();

            //        // Disable GUI Controls
            //        //EnableGUIMotionControls(false);

            //        // Disable UI control
            //        // enableUIGroup(false);

            //        // Update Motion Main Status
            //        updateMainStatusImage(MainState.Disconnect);



            //        //LCN連線
            //        this.myController = Controller.Connect();
            //        // register task state and diagPackect arrived events
            //        //this.myController.ControlCenter.TaskStates.NewTaskStatesArrived += new EventHandler<NewTaskStatesArrivedEventArgs>(TaskStates_NewTaskStatesArrived);
            //        this.myController.ControlCenter.Diagnostics.NewDiagPacketArrived += new EventHandler<NewDiagPacketArrivedEventArgs>(Diagnostics_NewDiagPacketArrived);

            //        //_AxisStatus = new Thread(Status_Axis);
            //        //_AxisStatus.Start();



            //        //btn_connect.Enabled = false;
            //        //btn_disconnect.Enabled = true;
            //    }
            //}
            //catch (A3200Exception exception)
            //{
            //    txt_Motion_ErrorMsg.Text = exception.Message;
            //}
            //#endregion
            if (myController.Commands.Motion.WaitForMotionDone(Aerotech.A3200.Commands.WaitOption.InPosition, 0, 2000) && myController.Commands.Motion.WaitForMotionDone(Aerotech.A3200.Commands.WaitOption.InPosition, 1, 2000) && myController.Commands.Motion.WaitForMotionDone(Aerotech.A3200.Commands.WaitOption.InPosition, 2, 2000))
            {
                if (Motion_X && Motion_Y && Motion_Z)
                {
                    if (Thick_flag == 0 && DEMO_flag == 0 && FocusTest_flag == 0 && fixZ_flag == 0 && Thick_flag_Alarm == 0 && Thick_flag_2CUT == 0 && DEMO_flag_P == 0 && AT_focus_flag == 0 && image_flag == 0 && DEMO_flag_2CUT == 0)
                    {
                        DialogResult myResult = MessageBox.Show("確認平台上無異物?", "系統訊息", MessageBoxButtons.YesNo);
                        if (myResult == DialogResult.Yes)
                        {
                            ABS_X = Convert.ToDouble(point_position[4, 0]);
                            ABS_Y = Convert.ToDouble(point_position[4, 1]);
                            ABS_Z = Convert.ToDouble(point_position[4, 2]);
                            Allow_X = Allow_Y = Allow_Z = true;
                            //Allow_Z = false;
                            //MessageBox.Show(i.ToString()+","+ ABS_X.ToString() + ";" + j.ToString()+","+ABS_Y.ToString());
                            //Aero_thMotionRun_Tick(Motion_Num.Motion_ABS);

                            if (Allow_X)
                            {
                                this.myController.Commands[this.taskIndex].Motion.MoveAbs(0, ABS_X, 40);
                            }
                            if (Allow_Y)
                            {
                                this.myController.Commands[this.taskIndex].Motion.MoveAbs(1, ABS_Y, 40);
                            }
                            if (Allow_Z)
                            {
                                this.myController.Commands[this.taskIndex].Motion.MoveAbs(2, ABS_Z, 20);
                            }
                        }
                    }
                }
            }

        }
        #endregion

        #region 參數點位相關按鍵
        private void button_LoadPoint_Click(object sender, EventArgs e)
        {
            Load_PointFile(Path.Combine(C_Path, "LCN_System", "point_save.ini"));
        }

        private void button_SavePoint_Click(object sender, EventArgs e)
        {
            DateTime myDate = DateTime.Now;
            string myDateString = myDate.ToString("yyyy-MM-dd HH_mm_ss");

            Point_SaveFile(Path.Combine(C_Path, "LCN_System", "point_save.ini"));
        }

        private void button_ST_1_Click(object sender, EventArgs e)
        {
            ST_X1.Text = point_position[0, 0] = txt_Motion_Position_X.Text;
            ST_Y1.Text = point_position[0, 1] = txt_Motion_Position_Y.Text;
            ST_Z1.Text = point_position[0, 2] = txt_Motion_Position_Z.Text;
        }

        private void button_ST_2_Click(object sender, EventArgs e)
        {
            ST_X2.Text = point_position[1, 0] = txt_Motion_Position_X.Text;
            ST_Y2.Text = point_position[1, 1] = txt_Motion_Position_Y.Text;
            ST_Z2.Text = point_position[1, 2] = txt_Motion_Position_Z.Text;
        }

        private void button_ST_3_Click(object sender, EventArgs e)
        {
            ST_X3.Text = point_position[2, 0] = txt_Motion_Position_X.Text;
            ST_Y3.Text = point_position[2, 1] = txt_Motion_Position_Y.Text;
            ST_Z3.Text = point_position[2, 2] = txt_Motion_Position_Z.Text;
        }

        private void button_ST_4_Click(object sender, EventArgs e)
        {
            ST_X4.Text = point_position[3, 0] = txt_Motion_Position_X.Text;
            ST_Y4.Text = point_position[3, 1] = txt_Motion_Position_Y.Text;
            ST_Z4.Text = point_position[3, 2] = txt_Motion_Position_Z.Text;
        }

        private void button_ST_5_Click(object sender, EventArgs e)
        {
            ST_X5.Text = point_position[4, 0] = txt_Motion_Position_X.Text;
            ST_Y5.Text = point_position[4, 1] = txt_Motion_Position_Y.Text;
            ST_Z5.Text = point_position[4, 2] = txt_Motion_Position_Z.Text;
        }

        private void button_ST_6_Click(object sender, EventArgs e)
        {
            ST_X6.Text = point_position[5, 0] = txt_Motion_Position_X.Text;
            ST_Y6.Text = point_position[5, 1] = txt_Motion_Position_Y.Text;
            ST_Z6.Text = point_position[5, 2] = txt_Motion_Position_Z.Text;
        }

        private void button_ST_7_Click(object sender, EventArgs e)
        {
            ST_X7.Text = point_position[6, 0] = txt_Motion_Position_X.Text;
            ST_Y7.Text = point_position[6, 1] = txt_Motion_Position_Y.Text;
            ST_Z7.Text = point_position[6, 2] = txt_Motion_Position_Z.Text;
        }

        private void button_ST_8_Click(object sender, EventArgs e)
        {
            ST_X8.Text = point_position[7, 0] = txt_Motion_Position_X.Text;
            ST_Y8.Text = point_position[7, 1] = txt_Motion_Position_Y.Text;
            ST_Z8.Text = point_position[7, 2] = txt_Motion_Position_Z.Text;
        }

        private void button_ST_9_Click(object sender, EventArgs e)
        {
            ST_X9.Text = point_position[8, 0] = txt_Motion_Position_X.Text;
            ST_Y9.Text = point_position[8, 1] = txt_Motion_Position_Y.Text;
            ST_Z9.Text = point_position[8, 2] = txt_Motion_Position_Z.Text;
        }
        private void button_LC_Click(object sender, EventArgs e)
        {
            point_position[20, 0] = X_LC_textBox.Text;
            point_position[20, 1] = Y_LC_textBox.Text;
        }


        private void button_LK_Click(object sender, EventArgs e)
        {
            point_position[21, 0] = X_LK_textBox.Text;
            point_position[21, 1] = Y_LK_textBox.Text;
        }
        private void button_Height_Click(object sender, EventArgs e)
        {
            point_position[22, 0] = Laser_Height_textBox.Text;
            point_position[22, 1] = CCD_Height_textBox.Text;
            point_position[22, 2] = Keyence_Height_textBox.Text;
            point_position[44, 0] = PH_Laser_Height_textBox.Text;
        }
        private void button_Limit_Click(object sender, EventArgs e)
        {
            point_position[30, 0] = XLimt_P_textBox.Text;
            point_position[30, 1] = YLimt_P_textBox.Text;
            point_position[30, 2] = ZLimt_P_textBox.Text;

            point_position[31, 0] = XLimt_N_textBox.Text;
            point_position[31, 1] = YLimt_N_textBox.Text;
            point_position[31, 2] = ZLimt_N_textBox.Text;
        }
        private void button_Hole_2Cut_Click(object sender, EventArgs e)
        {
            point_position[24, 0] = tb_HX_1.Text;
            point_position[24, 1] = tb_HY_1.Text;

            point_position[25, 0] = tb_HX_2.Text;
            point_position[25, 1] = tb_HY_2.Text;

            point_position[26, 0] = tb_HX_3.Text;
            point_position[26, 1] = tb_HY_3.Text;

            point_position[27, 0] = tb_HX_4.Text;
            point_position[27, 1] = tb_HY_4.Text;

        }
        private void button28_Click(object sender, EventArgs e)
        {
            tb_HX_1.Text = holeS_X[0];
            tb_HY_1.Text = holeS_Y[0];

            tb_HX_2.Text = holeS_X[1];
            tb_HY_2.Text = holeS_Y[1];

            tb_HX_3.Text = holeS_X[2];
            tb_HY_3.Text = holeS_Y[2];

            tb_HX_4.Text = holeS_X[3];
            tb_HY_4.Text = holeS_Y[3];
        }
        private void button59_Click(object sender, EventArgs e)
        {
            point_position[38, 0] = tb_AngleSet.Text;

        }
        private void btn_Carbide_MarkPower_Click(object sender, EventArgs e)
        {
            Carbide_MarkPower = tb_Carbide_Mark_PowerSet.Text;

        }
        private void button_PowerCal_Click(object sender, EventArgs e)
        {
            point_position[28, 0] = A_textBox.Text;
            point_position[28, 1] = B_textBox.Text;

        }
        private void B_Angle_Cal_Click(object sender, EventArgs e)
        {
            point_position[35, 0] = tb_DegreeSlope.Text;
            point_position[35, 1] = tb_DegreeOffset.Text;

        }
        private void button_PH_PowerCal_Click(object sender, EventArgs e)
        {
            point_position[43, 0] = PH_A_textBox.Text;
            point_position[43, 1] = PH_B_textBox.Text;

        }
        private void B_PH_Angle_Cal_Click(object sender, EventArgs e)
        {
            point_position[42, 0] = tb_PH_DegreeSlope.Text;
            point_position[42, 1] = tb_PH_DegreeOffset.Text;

        }
        private void B_Angle_Limit_Click(object sender, EventArgs e)
        {
            point_position[36, 0] = tb_Angle_Max.Text;
            point_position[36, 1] = tb_Angle_Min.Text;

        }
        private void B_Power_Limit_Click(object sender, EventArgs e)
        {
            point_position[37, 0] = tb_Power_Max.Text;
            point_position[37, 1] = tb_Power_Min.Text;
        }
        private void bt_CompSave_Click(object sender, EventArgs e)
        {
            point_position[33, 0] = tb_Comp_X.Text;
            point_position[33, 1] = tb_Comp_Y.Text;

        }
        private void button_BR_Short2CUT_Click_1(object sender, EventArgs e)
        {
            point_position[39, 0] = tb_BR_Short2Cut_NY.Text;
            point_position[39, 1] = tb_BR_Short2Cut_TipPY.Text;
            point_position[39, 2] = tb_BR_Short2Cut_HeadX.Text;
        }

        private void button_NS_Align2CUT_Click(object sender, EventArgs e)
        {
            point_position[40, 0] = tb_NS_Align2Cut_NY.Text;
            point_position[40, 1] = tb_NS_Align2Cut_TipPY.Text;
            point_position[40, 2] = tb_NS_Align2Cut_HeadX.Text;
        }

        private void button_BR_Align2CUT_Click(object sender, EventArgs e)
        {
            point_position[41, 0] = tb_BR_Align2Cut_NY.Text;
            point_position[41, 1] = tb_BR_Align2Cut_TipPY.Text;
            point_position[41, 2] = tb_BR_Align2Cut_HeadX.Text;
        }
        private void button_Short2CUT_Click(object sender, EventArgs e)
        {
            point_position[34, 0] = tb_NS_Short2Cut_NY.Text;
            point_position[34, 1] = tb_NS_Short2Cut_TipPY.Text;
            point_position[34, 2] = tb_NS_Short2Cut_HeadX.Text;

        }
        private void button_2CUT_Click(object sender, EventArgs e)
        {
            point_position[23, 0] = tb_2Cut_NX.Text;
            point_position[23, 1] = tb_2Cut_HeadNY.Text;
            point_position[23, 2] = tb_2Cut_TipPY.Text;

        }


        #endregion

        #region 吸附解除
        /// <summary>
        /// 真空吸附按鈕
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void bt_vacuum_Click(object sender, EventArgs e)
        {
            currentTime = DateTime.Now;
            LogTime = DateTime.Now;

            WriteLog("Log", "_Log.ini", $"吸附樣品");
            //StreamWriter sw = new StreamWriter(Path.Combine(Environment.CurrentDirectory, "LCN_LOG", "Log") + LogTime.ToString("yyyyMMdd") + "_Log.ini", true);
            //sw.WriteLine(currentTime.ToString("yyyyMMddHHmm") + "  ;  " + "吸附樣品 ");
            ////sw.Flush();
            //sw.Close();

            if (_isSysSimulated)
                return;

            // Enable Chuck vacuum
            enableChuckVacuum(true);

            UpdateDIPnlBackColor(pl_vacuum2, true);



            bt_vacuum2.Enabled = false;
            解除2.Enabled = true;








            /* DO_6_ON();
             CB_DO_6.Checked = true;
             bt_vacuum.Enabled = false;
             解除.Enabled = true;

             解除2.Enabled = true;
             解除3.Enabled = true;
             解除4.Enabled = true;
             解除5.Enabled = true;
             解除6.Enabled = true;
             bt_vacuum6.Enabled = false;
             解除7.Enabled = true;
             bt_vacuum7.Enabled = false;
             bt_vacuum_PH.Enabled = false;
             解除_PH.Enabled = true;
             btn_Vacuum_GH.Enabled = false;
             btn_解除_GH.Enabled = true;
             btn_vacuumRotate.Enabled = false;
             btn_解除Rotate.Enabled = true;*/
        }
        /// <summary>
        /// 真空解除按鈕
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void 解除_Click(object sender, EventArgs e)
        {
            currentTime = DateTime.Now;
            LogTime = DateTime.Now;

            WriteLog("Log", "_Log.ini", $"解除吸附");

            //StreamWriter sw = new StreamWriter(Path.Combine(Environment.CurrentDirectory, "LCN_LOG", "Log") + LogTime.ToString("yyyyMMdd") + "_Log.ini", true);
            //sw.WriteLine(currentTime.ToString("yyyyMMddHHmm") + "  ;  " + "解除吸附 ");
            ////sw.Flush();
            //sw.Close();

            enableChuckVacuum(false);

            解除2.Enabled = false;
            bt_vacuum2.Enabled = true;

            UpdateDIPnlBackColor(pl_vacuum2, false);











            //DO_6_OFF();
            //CB_DO_6.Checked = false;
            //bt_vacuum.Enabled = true;
            //解除.Enabled = false;
            //bt_vacuum2.Enabled = true;

            //bt_vacuum6.Enabled = true;
            //解除6.Enabled = false;
            //bt_vacuum7.Enabled = true;
            //解除7.Enabled = false;
            //bt_vacuum_PH.Enabled = true;
            //解除_PH.Enabled = false;
            //btn_Vacuum_GH.Enabled = true;
            //btn_解除_GH.Enabled = false;
            //btn_vacuumRotate.Enabled = true;
            //btn_解除Rotate.Enabled = false;
            //btn_vacuumRotate.Enabled = true;
            //btn_解除Rotate.Enabled = false;
        }
        #endregion

        #region 開、關門
        /// <summary>
        /// 電子鎖-上鎖
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void Door_lock_Click(object sender, EventArgs e)
        {
            currentTime = DateTime.Now;
            LogTime = DateTime.Now;
            WriteLog("Log", "_Log.ini", $"鎖門");

            //StreamWriter sw = new StreamWriter(Path.Combine(Environment.CurrentDirectory, "LCN_LOG", "Log") + LogTime.ToString("yyyyMMdd") + "_Log.ini", true);
            //sw.WriteLine(currentTime.ToString("yyyyMMddHHmm") + "  ;  " + "鎖門 ");
            ////sw.Flush();
            //sw.Close();

            this.controlDO(_controlDoorLock, true);
            _isDoorLock = true;

            UpdateDIPnlBackColor(pl_door2, true);


            /*
            DO_5_ON();
            CB_DO_5.Checked = true;
            Door_lock.Enabled = false;
            Door_unlock.Enabled = true;
            Door_lock2.Enabled = false;
            Door_unlock2.Enabled = true;
            Door_unlock3.Enabled = true;
            Door_unlock4.Enabled = true;
            Door_unlock5.Enabled = true;
            Door_lock6.Enabled = false;
            Door_unlock6.Enabled = true;
            Door_lock7.Enabled = false;
            Door_unlock7.Enabled = true;
            Door_lock_PH.Enabled = false;
            Door_unlock_PH.Enabled = true;
            btn_DoorLock_GH.Enabled = false;
            btn_DoorUnlock_GH.Enabled = true;
            btn_DoorLock_Rotate.Enabled = false;
            btn_Door_unlock_Rotate.Enabled = true;*/
        }
        /// <summary>
        /// 電子鎖-解鎖
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void Door_unlock_Click(object sender, EventArgs e)
        {
            LogTime = DateTime.Now;
            currentTime = DateTime.Now;
            WriteLog("Log", "_Log.ini", $"開鎖");

            //StreamWriter sw = new StreamWriter(Path.Combine(Environment.CurrentDirectory, "LCN_LOG", "Log") + LogTime.ToString("yyyyMMdd") + "_Log.ini", true);
            //sw.WriteLine(currentTime.ToString("yyyyMMddHHmm") + "  ;  " + "開鎖");
            ////sw.Flush();
            //sw.Close();

            UpdateDIPnlBackColor(pl_door2, false);


            this.controlDO(_controlDoorLock, false);
            _isDoorLock = false;

            /* DO_5_OFF();
             CB_DO_5.Checked = true;
             Door_lock.Enabled = true;
             Door_unlock.Enabled = false;

             Door_lock2.Enabled = true;
             Door_unlock2.Enabled = false;
             Door_lock3.Enabled = true;
             Door_unlock3.Enabled = false;
             Door_lock4.Enabled = true;
             Door_unlock4.Enabled = false;
             Door_lock5.Enabled = true;
             Door_unlock5.Enabled = false;
             Door_lock6.Enabled = true;
             Door_unlock6.Enabled = false;
             Door_lock7.Enabled = true;
             Door_unlock7.Enabled = false;
             Door_lock_PH.Enabled = true;
             Door_unlock_PH.Enabled = false;
             btn_DoorLock_GH.Enabled = true;
             btn_DoorUnlock_GH.Enabled = false;
             btn_DoorLock_Rotate.Enabled = true;
             btn_Door_unlock_Rotate.Enabled = false;*/
        }

        #endregion

        #region 載二切座標檔相關
        /// <summary>
        /// 載入 2CUT 加工檔案，更新路徑欄位並呼叫 file_produce_2CUT() 解析座標與圖層資訊。
        /// 同時記錄 log 並更新 UI 顯示孔位資訊與 pin pitch。
        /// </summary>
        private void BT_LoadFile_2CUT_Click(object sender, EventArgs e)
        {
            Auto_Load = false;//將掃碼自動載檔旗標取消
            lb_LotNo.Text = $"手動載檔二切無批號資訊";

            ProcessFileRead_flag = true;

            //20260324冠璋要求重置按鈕按下時路徑都不清除，除非重新刷barcode代入
            /*TB_LoadFilePath.Clear();//清除一切路徑檔
            TB_LoadFilePath_2CUT.Clear();//清除二切路徑檔
            tb_PRRLCN.Clear();//清除二切連棟檔路徑*/

            //[BM:LCN加工時間估算法及資料上報優化-將先前的批號清除(要傳給MES使用的內容)]
            lb_LotNo.Text = "";

            currentTime = DateTime.Now; // 取得目前時間（用於日誌）
            LogTime = DateTime.Now; // 同步記錄時間


            WriteLog("Log", "_Log.ini", $"載入2切檔案");


            //StreamWriter sw = new StreamWriter(Path.Combine(Environment.CurrentDirectory, "LCN_LOG", "Log") + LogTime.ToString("yyyyMMdd") + "_Log.ini", true); // 建立日誌檔案（以日期命名）
            Auto_Load = false;//按下手動載檔後，將掃碼自動載檔旗標關閉

            //sw.WriteLine(currentTime.ToString("yyyyMMddHHmm") + "  ;  " + "載入2切檔案 "); // 寫入日誌：載入加工檔
            //sw.Close(); // 關閉日誌檔案

            string file; // 宣告檔案路徑變數

            OpenFileDialog dialog = new OpenFileDialog(); // 建立檔案選擇對話框
            dialog.Multiselect = true; // 可選擇多個檔案（目前未使用）
            dialog.Title = "請選擇資料夾"; // 設定對話框標題
            dialog.Filter = "所有檔案(*.*)|*.*"; // 設定檔案類型篩選器

            if (dialog.ShowDialog() == System.Windows.Forms.DialogResult.OK)// 若使用者選擇檔案並按下確定
            {
                file = dialog.FileName; // 取得選擇的檔案路徑
                TB_LoadFilePath_2CUT.Text = file; // 顯示檔案路徑於 UI 欄位

                file_produce_2CUT(); // 呼叫方法解析檔案內容並建立座標資料

            }

        }

        private async void TB_LoadFilePath_2CUT_TextChanged(object sender, EventArgs e)//2切座標檔
        {

            TB_LoadFilePath_2CUT.SelectionStart = TB_LoadFilePath_2CUT.Text.Length;
            TB_LoadFilePath_2CUT.ScrollToCaret();

            if (Auto_Load == true)
            {
                // 每次輸入時取消之前的延遲
                cts?.Cancel();
                cts = new CancellationTokenSource();
                var token = cts.Token;
                try
                {
                    await Task.Delay(200, token);
                    if (!token.IsCancellationRequested)
                    {
                        DateTime currentTime = DateTime.Now;

                        WriteLog("Log", "_Log.ini", $"人員調整 二切 座標檔路徑，路徑={TB_LoadFilePath_2CUT.Text}");


                        //string logPath = Path.Combine(Path.Combine(Environment.CurrentDirectory, "LCN_LOG", "Log"), currentTime.ToString("yyyyMMdd") + "_Log.ini");

                        //using (StreamWriter sw = new StreamWriter(logPath, true))
                        //{
                        //    sw.WriteLine(currentTime.ToString("yyyyMMddHHmm") + "  ;  " + "人員調整 二切 座標檔路徑，路徑=" + TB_LoadFilePath_2CUT.Text);
                        //}
                    }
                }
                catch (TaskCanceledException)
                {
                    // 被取消，不做事
                }
            }

        }
        #endregion


        #region 特徵搜尋相關
        /// <summary>
        /// 移動至指定探針的頭部位置，並根據對應的厚度補償值調整 Z 軸高度。
        /// 若補償值為空則預設為 0，執行前會確認三軸皆已到位且未在執行中。
        /// </summary>
        /// <param name="sender">觸發事件的按鈕控制項。</param>
        /// <param name="e">事件參數。</param>
        private void bt_H_Click(object sender, EventArgs e)// 移動至探針頭部位置，根據補償值調整 Z 軸高度。
        {
            if (myController.Commands.Motion.WaitForMotionDone(Aerotech.A3200.Commands.WaitOption.InPosition, 0, 2000) && myController.Commands.Motion.WaitForMotionDone(Aerotech.A3200.Commands.WaitOption.InPosition, 1, 2000) && myController.Commands.Motion.WaitForMotionDone(Aerotech.A3200.Commands.WaitOption.InPosition, 2, 2000))
            {

                if (Motion_X && Motion_Y && Motion_Z)
                {
                    if (!motioning())
                    {
                        ABS_X = HeadPOS_X[Convert.ToInt32(tb_PinLocated.Text)];
                        ABS_Y = HeadPOS_Y[Convert.ToInt32(tb_PinLocated.Text)];
                        //z越負,測高儀越負
                        if (process_compensateZ_2CUT[Convert.ToInt32(tb_PinLocated.Text)] == "")
                        {
                            process_compensateZ_2CUT[Convert.ToInt32(tb_PinLocated.Text)] = " 0";
                        }
                        ABS_Z = Convert.ToDouble(point_position[22, 1]) + Convert.ToDouble(process_compensateZ_2CUT[Convert.ToInt32(tb_PinLocated.Text)]);
                        Allow_X = Allow_Y = Allow_Z = true;






                        if (ABS_Z > zlimit)//計算出來的絕對位置要大於接近撞吸嘴的危險值
                        {




                            if (Allow_X)
                            {
                                this.myController.Commands[this.taskIndex].Motion.MoveAbs(0, ABS_X, 40);
                            }
                            if (Allow_Y)
                            {
                                this.myController.Commands[this.taskIndex].Motion.MoveAbs(1, ABS_Y, 40);
                            }
                            if (Allow_Z)
                            {
                                this.myController.Commands[this.taskIndex].Motion.MoveAbs(2, ABS_Z, 20);
                            }
                        }
                        else
                        {
                            MessageBox.Show($"z軸高度計算後超出安全高度({zlimit}): {ABS_Z}", "z軸高度軟體限制",
                                         MessageBoxButtons.OK, MessageBoxIcon.Error);

                            WriteLog("Log", "_Log.ini", $"z軸高度計算後超出安全高度({zlimit}): {ABS_Z}");

                        }





                    }
                }
            }
        }
        /// <summary>
        /// 移動至指定探針的尾端位置，並根據對應的厚度補償值調整 Z 軸高度。
        /// 若補償值為空則預設為 0，執行前會確認三軸皆已到位且未在執行中。
        /// </summary>
        /// <param name="sender">觸發事件的按鈕控制項。</param>
        /// <param name="e">事件參數。</param>
        private void bt_B_Click(object sender, EventArgs e)// 移動至探針尾端位置，根據補償值調整 Z 軸高度。
        {
            if (myController.Commands.Motion.WaitForMotionDone(Aerotech.A3200.Commands.WaitOption.InPosition, 0, 2000) && myController.Commands.Motion.WaitForMotionDone(Aerotech.A3200.Commands.WaitOption.InPosition, 1, 2000) && myController.Commands.Motion.WaitForMotionDone(Aerotech.A3200.Commands.WaitOption.InPosition, 2, 2000))
            {

                if (Motion_X && Motion_Y && Motion_Z)
                {
                    if (!motioning())
                    {
                        ABS_X = TipPOS_X[Convert.ToInt32(tb_PinLocated.Text)];
                        ABS_Y = TipPOS_Y[Convert.ToInt32(tb_PinLocated.Text)];
                        //z越負,測高儀越負
                        if (process_compensateZ_2CUT[Convert.ToInt32(tb_PinLocated.Text)] == "")
                        {
                            process_compensateZ_2CUT[Convert.ToInt32(tb_PinLocated.Text)] = " 0";
                        }
                        ABS_Z = Convert.ToDouble(point_position[22, 1]) + Convert.ToDouble(process_compensateZ_2CUT[Convert.ToInt32(tb_PinLocated.Text)]);
                        Allow_X = Allow_Y = Allow_Z = true;









                        if (ABS_Z > zlimit)//計算出來的絕對位置要大於接近撞吸嘴的危險值
                        {



                            if (Allow_X)
                            {
                                this.myController.Commands[this.taskIndex].Motion.MoveAbs(0, ABS_X, 40);
                            }
                            if (Allow_Y)
                            {
                                this.myController.Commands[this.taskIndex].Motion.MoveAbs(1, ABS_Y, 40);
                            }
                            if (Allow_Z)
                            {
                                this.myController.Commands[this.taskIndex].Motion.MoveAbs(2, ABS_Z, 20);
                            }
                        }
                        else
                        {
                            MessageBox.Show($"z軸高度計算後超出安全高度({zlimit}): {ABS_Z}", "z軸高度軟體限制",
                                         MessageBoxButtons.OK, MessageBoxIcon.Error);
                            WriteLog("Log", "_Log.ini", $"z軸高度計算後超出安全高度({zlimit}): {ABS_Z}");
                        }






                    }
                }
            }
        }


        #endregion

        /// <summary>
        /// 移動z軸 STEP3.移動到測高儀焦距
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void button14_Click_1(object sender, EventArgs e)
        {

            currentTime = DateTime.Now;
            LogTime = DateTime.Now;
            WriteLog("Log", "_Log.ini", $"移動z軸到測距高度");

            //StreamWriter sw = new StreamWriter(Path.Combine(Environment.CurrentDirectory, "LCN_LOG", "Log") + LogTime.ToString("yyyyMMdd") + "_Log.ini", true);
            //sw.WriteLine(currentTime.ToString("yyyyMMddHHmm") + "  ;  " + "移動z軸到測距高度 ");
            ////sw.Flush();
            //sw.Close();
            if (myController.Commands.Motion.WaitForMotionDone(Aerotech.A3200.Commands.WaitOption.InPosition, 0, 2000) && myController.Commands.Motion.WaitForMotionDone(Aerotech.A3200.Commands.WaitOption.InPosition, 1, 2000) && myController.Commands.Motion.WaitForMotionDone(Aerotech.A3200.Commands.WaitOption.InPosition, 2, 2000))
            {

                if (Motion_X && Motion_Y && Motion_Z)
                {
                    if (!motioning())
                    {
                        DialogResult myResult = MessageBox.Show("確認平台上無異物?", "系統訊息", MessageBoxButtons.YesNo);
                        if (myResult == DialogResult.Yes)
                        {
                            //groupBox_Axis.Enabled = false;
                            this.myController.Commands[this.taskIndex].Motion.MoveAbs(2, Convert.ToDouble(Keyence_Height_textBox.Text), double.Parse("15"));
                        }
                    }
                    else
                    {
                        MessageBox.Show("流程進行中");
                    }
                }
            }

        }
        /// <summary>
        /// 自動對焦流程按鈕
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void bt_autofocus_Click(object sender, EventArgs e)
        {
            #region LCN與LCH軸控切換
            try
            {
                if (myController == null)
                {



                    //LCH斷線
                    // Unregister task state and diagPackect arrived events
                    _MC_Controller.ControlCenter.Diagnostics.NewDiagPacketArrived -= new EventHandler<NewDiagPacketArrivedEventArgs>(Diagnostics_NewDiagPacketArrived);

                    _MotionControl.Deinitialize();

                    _MotionControl.Close();

                    // Disable GUI Controls
                    //EnableGUIMotionControls(false);

                    // Disable UI control
                    // enableUIGroup(false);

                    // Update Motion Main Status
                    updateMainStatusImage(MainState.Disconnect);



                    //LCN連線
                    this.myController = Controller.Connect();
                    // register task state and diagPackect arrived events
                    //this.myController.ControlCenter.TaskStates.NewTaskStatesArrived += new EventHandler<NewTaskStatesArrivedEventArgs>(TaskStates_NewTaskStatesArrived);
                    this.myController.ControlCenter.Diagnostics.NewDiagPacketArrived += new EventHandler<NewDiagPacketArrivedEventArgs>(Diagnostics_NewDiagPacketArrived);

                    //_AxisStatus = new Thread(Status_Axis);
                    //_AxisStatus.Start();



                    //btn_connect.Enabled = false;
                    //btn_disconnect.Enabled = true;
                }
            }
            catch (A3200Exception exception)
            {
                txt_Motion_ErrorMsg.Text = exception.Message;
            }
            #endregion

            if (myController.Commands.Motion.WaitForMotionDone(Aerotech.A3200.Commands.WaitOption.InPosition, 0, 2000) && myController.Commands.Motion.WaitForMotionDone(Aerotech.A3200.Commands.WaitOption.InPosition, 1, 2000) && myController.Commands.Motion.WaitForMotionDone(Aerotech.A3200.Commands.WaitOption.InPosition, 2, 2000))
            {

                if (Motion_X && Motion_Y && Motion_Z)
                {
                    if (!motioning())
                    {

                        DialogResult myResult = MessageBox.Show("確認平台上無異物?", "系統訊息", MessageBoxButtons.YesNo);
                        if (myResult == DialogResult.Yes)
                        {
                            StartTime = DateTime.Now;
                            LogTime = DateTime.Now;
                            // START_flag = true;
                            //DO_1_OFF();
                            //DO_2_ON();

                            _autofocus = new Thread(_AT_focus);
                            _autofocus.Start();
                            _isautofocus = true;
                            AT_focus_flag = 1;


                        }
                    }
                    else
                    {
                        MessageBox.Show("流程進行中");
                    }
                }
            }


        }
        /// <summary>
        /// 打圖型-粗對位
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void bt_Precut_Click(object sender, EventArgs e)
        {
            if (axCVX1.Connected)
            {
                if (myController.Commands.Motion.WaitForMotionDone(Aerotech.A3200.Commands.WaitOption.InPosition, 0, 2000) && myController.Commands.Motion.WaitForMotionDone(Aerotech.A3200.Commands.WaitOption.InPosition, 1, 2000) && myController.Commands.Motion.WaitForMotionDone(Aerotech.A3200.Commands.WaitOption.InPosition, 2, 2000))
                {
                    if (Motion_X && Motion_Y && Motion_Z)
                    {
                        if (!motioning())
                        {
                            if (CCD_Connect_flag)
                            {
                                LogTime = DateTime.Now;
                                _AutoDwring = new Thread(AutoDwring);
                                _AutoDwring.Start();
                                _AutoDwring_flag = 1;
                                _isAutoDwring = true;
                            }
                            else
                            {
                                MessageBox.Show("視覺系統未連線成功");
                            }
                        }
                        else
                        {
                            MessageBox.Show("流程執行中,請案停");
                        }
                    }
                }
                else
                {
                    MessageBox.Show("軸正在移動中");
                }

            }
            else
            {
                MessageBox.Show("視覺系統未連線");
            }
            //  }
            //else
            //{
            //    MessageBox.Show("請鎖門");
            //}
        }

        #region 找定位孔
        int FindHole_flag = 0;
        string hole_comp_X, hole_comp_Y;
        private void bt_cal_Click(object sender, EventArgs e)
        {
            LogTime = DateTime.Now; // 取得目前時間作為日誌時間
            WriteLog("Log", "_Log.ini", $"{LogTime.ToString("yyyyMMddHHmm")} ; 按下*計算*");

            //using (StreamWriter text = new StreamWriter(Path.Combine(Environment.CurrentDirectory, "LCN_LOG", "Log") + LogTime.ToString("yyyyMMdd") + "_Log.ini", true)) // 建立日誌檔案（以日期命名）
            //{
            //    text.WriteLine(LogTime.ToString("s") + "," + "按下*計算*"); // 寫入日誌：使用者按下計算
            //    text.Close(); // 關閉日誌檔案
            //}

            r_file_X = Pythagorean( // 計算檔案中孔1到孔2的距離（X方向）
                Convert.ToDouble(holeS_X_2CUT[1]) - Convert.ToDouble(holeS_X_2CUT[0]),
                Convert.ToDouble(holeS_Y_2CUT[1]) - Convert.ToDouble(holeS_Y_2CUT[0])
            );

            r_file_Y = Pythagorean( // 計算檔案中孔2到孔3的距離（Y方向）
                Convert.ToDouble(holeS_X_2CUT[2]) - Convert.ToDouble(holeS_X_2CUT[1]),
                Convert.ToDouble(holeS_Y_2CUT[2]) - Convert.ToDouble(holeS_Y_2CUT[1])
            );

            r_axis_X = Pythagorean( // 計算實際機台上孔1到孔2的距離（X方向）
                Convert.ToDouble(str_X2) - Convert.ToDouble(str_X1),
                Convert.ToDouble(str_Y2) - Convert.ToDouble(str_Y1)
            );

            r_axis_Y = Pythagorean( // 計算實際機台上孔2到孔3的距離（Y方向）
                Convert.ToDouble(str_X3) - Convert.ToDouble(str_X2),
                Convert.ToDouble(str_Y3) - Convert.ToDouble(str_Y2)
            );
            //[BM:計算縮放比例]
            scale_X = r_axis_X / r_file_X; // 計算 X 軸縮放比例（實際距離 / 檔案距離）
            scale_Y = r_axis_Y / r_file_Y; // 計算 Y 軸縮放比例

            theta = Math.Atan( // 計算孔1到孔2的旋轉角度（弧度）
                (Convert.ToDouble(str_Y2) - Convert.ToDouble(str_Y1)) /
                (Convert.ToDouble(str_X2) - Convert.ToDouble(str_X1))
            );

            lb_theta.Text = "旋轉角度 = " + (theta * 180 / Math.PI).ToString("F2"); // 顯示旋轉角度（轉換為角度顯示）
            lb_Gain_X.Text = "X脹縮 = " + scale_X.ToString("F4"); // 顯示 X 軸縮放比例
            lb_Gain_Y.Text = "Y脹縮 = " + scale_Y.ToString("F4"); // 顯示 Y 軸縮放比例

            button29.Enabled = false; // 停用「孔1→孔2」按鈕，避免重複操作
            button30.Enabled = false; // 停用「孔2→孔3」按鈕
            bt_cal.Enabled = false;   // 停用「計算」按鈕

            radioButton1.Checked = true;  // 預設選取孔1
            radioButton3.Checked = false; // 取消孔3選取
            radioButton2.Checked = false; // 取消孔2選取

        }

        private void bt_HoleFix_Click(object sender, EventArgs e)
        {
            bt_hole_located.Visible = false;//防手賤當機
            if (axCVX1.Created)
            {
                if (myController.Commands.Motion.WaitForMotionDone(Aerotech.A3200.Commands.WaitOption.InPosition, 0, 2000) && myController.Commands.Motion.WaitForMotionDone(Aerotech.A3200.Commands.WaitOption.InPosition, 1, 2000) && myController.Commands.Motion.WaitForMotionDone(Aerotech.A3200.Commands.WaitOption.InPosition, 2, 2000))
                {

                    if (Motion_X && Motion_Y && Motion_Z)
                    {
                        if (Thick_flag == 0 && DEMO_flag == 0 && FocusTest_flag == 0 && fixZ_flag == 0 && Thick_flag_Alarm == 0 && Thick_flag_2CUT == 0 && DEMO_flag_P == 0 && AT_focus_flag == 0 && image_flag == 0 && DEMO_flag_2CUT == 0)
                        {
                            _autofocus = new Thread(_AT_focus);
                            _autofocus.Start();
                            _isautofocus = true;
                            AT_focus_flag = 1;
                            _isAuto_FindHole = true;
                        }
                        else
                        {
                            MessageBox.Show("流程執行中,請案停");
                        }
                    }
                }
                else
                {
                    MessageBox.Show("軸正在移動中");
                }
            }
            else
            {
                MessageBox.Show("視覺系統未連線");
            }
        }

        /// <summary>
        /// 將孔1的定位座標轉換為孔2的相對位置，並移動 XY 軸至孔2位置。
        /// 同時更新 UI 的選取孔位狀態。
        /// </summary>
        private void button29_Click_1(object sender, EventArgs e)//孔1移動至孔2
        {
            bt_hole_located.Visible = true;//防手賤當機

            LogTime = DateTime.Now; // 取得目前時間
            WriteLog("Log", "_Log.ini", $"孔1到孔2");
            //using (StreamWriter text = new StreamWriter(Path.Combine(Environment.CurrentDirectory, "LCN_LOG", "Log") + LogTime.ToString("yyyyMMdd") + "_Log.ini", true)) // 建立日誌檔案
            //{
            //    text.WriteLine(LogTime.ToString("yyyyMMddHHmm") + "," + "孔1到孔2*"); // 寫入日誌：孔1到孔2
            //    text.Close(); // 關閉檔案
            //}

            if (myController.Commands.Motion.WaitForMotionDone(Aerotech.A3200.Commands.WaitOption.InPosition, 0, 2000) && myController.Commands.Motion.WaitForMotionDone(Aerotech.A3200.Commands.WaitOption.InPosition, 1, 2000) && myController.Commands.Motion.WaitForMotionDone(Aerotech.A3200.Commands.WaitOption.InPosition, 2, 2000))// 確認三軸皆已到位
            {
                if (Motion_X && Motion_Y && Motion_Z)
                {
                    if (!motioning())// 若系統未執行其他流程
                    {
                        ABS_X = Convert.ToDouble(str_X1) + (Convert.ToDouble(point_position[25, 0]) - Convert.ToDouble(point_position[24, 0])); // 計算孔2相對 X 座標
                        ABS_Y = Convert.ToDouble(str_Y1) + (Convert.ToDouble(point_position[25, 1]) - Convert.ToDouble(point_position[24, 1])); // 計算孔2相對 Y 座標

                        myController.Commands[taskIndex].Motion.MoveAbs(0, ABS_X, fastspeed); // 移動 X 軸
                        myController.Commands[taskIndex].Motion.MoveAbs(1, ABS_Y, fastspeed); // 移動 Y 軸

                        radioButton1.Checked = false; // 取消孔1選取
                        radioButton3.Checked = false; // 取消孔3選取
                        radioButton2.Checked = true; // 選取孔2
                    }
                    else
                    {
                        MessageBox.Show("流程執行中,請案停");// 顯示流程執行中提示

                    }
                }
            }
            else
            {
                MessageBox.Show("軸正在移動中");
            }
        }
        /// <summary>
        /// 將孔2的定位座標轉換為孔3的相對位置，並移動 XY 軸至孔3位置。
        /// 同時計算旋轉角度 theta 並更新 UI 的選取孔位狀態。
        /// </summary>
        private void button30_Click(object sender, EventArgs e)//孔2移動至孔3
        {
            bt_hole_located.Visible = true;//防手賤當機

            LogTime = DateTime.Now; // 取得目前時間
            WriteLog("Log", "_Log.ini", $"孔2到孔3");

            //using (StreamWriter text = new StreamWriter(Path.Combine(Environment.CurrentDirectory, "LCN_LOG", "Log") + LogTime.ToString("yyyyMMdd") + "_Log.ini", true)) // 建立日誌檔案
            //{
            //    text.WriteLine(LogTime.ToString("yyyyMMddHHmm") + "," + "孔2到孔3*"); // 寫入日誌：孔2到孔3
            //    text.Close(); // 關閉檔案
            //}

            if (myController.Commands.Motion.WaitForMotionDone(Aerotech.A3200.Commands.WaitOption.InPosition, 0, 2000) && myController.Commands.Motion.WaitForMotionDone(Aerotech.A3200.Commands.WaitOption.InPosition, 1, 2000) && myController.Commands.Motion.WaitForMotionDone(Aerotech.A3200.Commands.WaitOption.InPosition, 2, 2000))
            {
                if (Motion_X && Motion_Y && Motion_Z)
                {
                    if (!motioning())// 若系統未執行其他流程
                    {
                        double t = (Convert.ToDouble(str_Y2) - Convert.ToDouble(str_Y1)) / (Convert.ToDouble(str_X2) - Convert.ToDouble(str_X1)); // 計算斜率
                        theta = Math.Atan(t); // 計算旋轉角度

                        double move_x = Convert.ToDouble(point_position[26, 0]) - Convert.ToDouble(point_position[25, 0]); // 孔3相對 X 位移
                        double move_y = Convert.ToDouble(point_position[26, 1]) - Convert.ToDouble(point_position[25, 1]); // 孔3相對 Y 位移

                        ABS_X = Convert.ToDouble(str_X2) + new_X(move_x.ToString(), move_y.ToString()); // 計算孔3絕對 X 座標
                        ABS_Y = Convert.ToDouble(str_Y2) + new_Y(move_x.ToString(), move_y.ToString()); // 計算孔3絕對 Y 座標

                        myController.Commands[taskIndex].Motion.MoveAbs(0, ABS_X, fastspeed); // 移動 X 軸
                        myController.Commands[taskIndex].Motion.MoveAbs(1, ABS_Y, fastspeed); // 移動 Y 軸

                        button30.Enabled = true; // 啟用按鈕
                        radioButton1.Checked = false; // 取消孔1選取
                        radioButton3.Checked = true; // 選取孔3
                        radioButton2.Checked = false; // 取消孔2選取
                    }
                    else
                    {
                        MessageBox.Show("流程執行中,請案停");
                    }
                }
            }
            else
            {
                MessageBox.Show("軸正在移動中");
            }
        }
        /// <summary>
        /// 確認目前選取的孔位，並將其座標儲存至對應欄位。
        /// 同時記錄 log 並啟用後續流程按鈕。
        /// </summary>
        private void button53_Click(object sender, EventArgs e)//確認按鈕 孔設定完畢
        {
            bt_hole_located.Visible = true;//防手賤當機

            LogTime = DateTime.Now; // 取得目前時間



            //using (StreamWriter text = new StreamWriter(Path.Combine(Environment.CurrentDirectory, "LCN_LOG", "Log") + LogTime.ToString("yyyyMMdd") + "_Log.ini", true)) // 建立日誌檔案
            //{
            int h = 0; // 初始化孔位編號
            if (radioButton1.Checked == true) h = 1; // 孔1選取
            if (radioButton2.Checked == true) h = 2; // 孔2選取
            if (radioButton3.Checked == true) h = 3; // 孔3選取
            if (radioButton4.Checked == true) h = 4; // 孔4選取

            //    text.WriteLine(LogTime.ToString("yyyyMMddHHmm") + "," + "按下孔定位 " + h.ToString() + "*確認*"); // 寫入日誌
            //    text.Close(); // 關閉檔案
            //}
            WriteLog("Log", "_Log.ini", $"按下孔定位{ h.ToString() }確認");


            if (radioButton1.Checked == true) // 若選取孔1
            {
                str_X1 = CAL_POS_X1.Text = txt_Motion_Position_X.Text; // 儲存 X 座標
                str_Y1 = CAL_POS_Y1.Text = txt_Motion_Position_Y.Text; // 儲存 Y 座標
                str_Z1 = txt_Motion_Position_Z.Text; // 儲存 Z 座標
                button29.Enabled = true; // 啟用孔1→孔2按鈕
            }
            if (radioButton2.Checked == true)
            {
                str_X2 = CAL_POS_X2.Text = txt_Motion_Position_X.Text;
                str_Y2 = CAL_POS_Y2.Text = txt_Motion_Position_Y.Text;
                button30.Enabled = true; // 啟用孔2→孔3按鈕
            }
            if (radioButton3.Checked == true)
            {
                str_X3 = CAL_POS_X3.Text = txt_Motion_Position_X.Text;
                str_Y3 = CAL_POS_Y3.Text = txt_Motion_Position_Y.Text;
                bt_cal.Enabled = true; // 啟用座標轉換按鈕
            }
            if (radioButton4.Checked == true)
            {
                str_X4 = CAL_POS_X4.Text = txt_Motion_Position_X.Text;
                str_Y4 = CAL_POS_Y4.Text = txt_Motion_Position_Y.Text;
            }
        }
        #endregion

        string operation;
        /// <summary>
        /// 啟動 2CUT 模式下的厚度量測流程，包含座標解析、流程旗標設定、執行緒啟動與 MES 上報。
        /// </summary>
        private void bt_ThickCut2_Start_Click(object sender, EventArgs e)//厚度量測
        {
            if (myController.Commands.Motion.WaitForMotionDone(Aerotech.A3200.Commands.WaitOption.InPosition, 0, 2000) && myController.Commands.Motion.WaitForMotionDone(Aerotech.A3200.Commands.WaitOption.InPosition, 1, 2000) && myController.Commands.Motion.WaitForMotionDone(Aerotech.A3200.Commands.WaitOption.InPosition, 2, 2000))// 確認三軸皆已到定位
            {
                if (Motion_X && Motion_Y && Motion_Z)// 三軸狀態穩定
                {
                    if (!motioning()) // 若系統未執行其他流程
                    {
                        file_produce_2CUT(); // 重新解析 2CUT 加工檔案
                        if (ProcessFileRead_flag_2CUT) // 確認檔案已成功載入
                        {
                            operation = "Rework"; // 設定作業類型為 Rework（重工）

                            ReginPinNum = Convert.ToInt16(tb_ReginPinNum.Text); // 取得區域針數設定
                            CurrTime = DateTime.Now; // 記錄目前時間（用於資料檔名）

                            START_flag_2CUT = true; // 設定 2CUT 流程啟動旗標

                            //20260324冠璋要求任何情況都不鎖定，只有在 ""一切開始""   ""二切開始""才鎖定
                            //groupBox_Axis.Enabled = false; // 停用軸控制 UI，避免干擾

                            Thick_Test_2CUT = new Thread(_Thick_Test_Array_2CUT); // 建立厚度量測執行緒
                            Thick_Test_2CUT.Start(); // 啟動執行緒
                            _isThick_Test_2CUT = true;
                            Thick_flag_2CUT = 1; // 設定厚度量測流程狀態為啟動                          

                            // 參數紀錄區
                            string mathine_name = tb_Machine_Name.Text; // 機台名稱
                            string part_number = ""; // 零件編號（預設空白）
                            string batch_number = tb_lot_number.Text; // 批號
                            string serial_number = tb_LaserDeskText.Text; // 序號
                            string product_name = ""; // 品名（預設空白）
                            string pin_length = tb_needle_len.Text; // 針長
                            string total_pin = pin_TotalNumber.ToString(); // 總針數
                            string laser_Process_file = tb_Path_SCAN.Text; // 雷射加工檔路徑
                            string laser_Pos_file = tb_Path_coordinates.Text; // 雷射座標檔路徑
                            string laser_power = tb_Laser_energy.Text; // 雷射功率

                            record_update.Start(2, mathine_name, part_number, batch_number, serial_number, product_name, pin_length, total_pin, laser_Process_file, laser_Pos_file, laser_power); // 初始化紀錄模組
                            record_update.Save_Buffer(); // 儲存紀錄緩衝區

                            // MES_Production(chpt_mes.Description_Message[(int)MES_Description.Measurement]); // 上報 MES：厚度量測開始
                        }
                    }
                    else
                    {
                        MessageBox.Show("流程執行中,請案停");// 若流程正在執行，提示使用者停止
                    }
                }
            }
            else
            {
                MessageBox.Show("軸正在移動中");// 若三軸尚未到位，提示使用者等待
            }
        }

        /// <summary>
        /// 重製按鈕
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void bt_reset_Click(object sender, EventArgs e)
        {
            #region 定位孔置中清除資料

            str_X1 = CAL_POS_X1.Text = "0"; // 儲存 X 座標
            str_Y1 = CAL_POS_Y1.Text = "0"; // 儲存 Y 座標
            str_X2 = CAL_POS_X2.Text = "0";
            str_Y2 = CAL_POS_Y2.Text = "0";
            str_X3 = CAL_POS_X3.Text = "0";
            str_Y3 = CAL_POS_Y3.Text = "0";
            str_X4 = CAL_POS_X4.Text = "0";
            str_Y4 = CAL_POS_Y4.Text = "0";


            #endregion


            _isDemo_Test_2CUT = false;
            DEMO_flag_2CUT = 0;
            _isAutoDwring = false;
            _AutoDwring_flag = 0;
            _isAuto_FindHole = false;
            FindHole_flag = 0;
            _isautofocus = false;
            AT_focus_flag = 0;
            _isThick_Test_2CUT = false;
            Thick_flag_2CUT = 0;
            _isthread_image_test = false;
            image_flag = 0;



            Flag_ORG = false;
            bt_ini();
            this.Invoke(new dGP_Relese(GP_relese));
        }

        /// <summary>
        /// 執行自動特徵搜尋流程，包含座標確認、CCD 連線檢查、針長設定驗證與影像執行緒啟動。
        /// 若條件符合則記錄 log、啟動影像比對執行緒 <c>_image_test</c>，並進行 MES 上報與參數紀錄。
        /// 若任一條件不符則顯示錯誤訊息。
        /// </summary>
        /// <param name="sender">觸發事件的按鈕。</param>
        /// <param name="e">事件參數。</param>
        private void button27_Click(object sender, EventArgs e)//執行自動尋找特徵
        {
            if (myController.Commands.Motion.WaitForMotionDone(Aerotech.A3200.Commands.WaitOption.InPosition, 0, 2000) && myController.Commands.Motion.WaitForMotionDone(Aerotech.A3200.Commands.WaitOption.InPosition, 1, 2000) && myController.Commands.Motion.WaitForMotionDone(Aerotech.A3200.Commands.WaitOption.InPosition, 2, 2000))
            {
                if (RB_Front.Checked || RB_Back.Checked)//兩者都沒選就異常
                {
                    if (Motion_X && Motion_Y && Motion_Z)
                    {
                        if (!motioning())
                        {
                            if (ProcessFileRead_flag_2CUT)
                            {
                                if (CCD_Connect_flag)
                                {
                                    if (Lenth_Set_Detect())
                                    {
                                        //file_produce_2CUT();
                                        //operation = "Rework";
                                        ReginPinNum = Convert.ToInt16(tb_ReginPinNum.Text);
                                        CurrTime = DateTime.Now;
                                        currentTime = DateTime.Now;

                                        WriteLog("Log", "_Log.ini", $"特徵搜尋");

                                        //using (StreamWriter text = new StreamWriter(Path.Combine(Environment.CurrentDirectory, "LCN_LOG", "Log") + LogTime.ToString("yyyyMMdd") + "_Log.ini", true))
                                        //{
                                        //    text.WriteLine(currentTime.ToString("yyyyMMddHHmm") + "  ;  " + "特徵搜尋 ");
                                        //    //sw.Flush();
                                        //    text.Close();
                                        //}
                                        //StreamWriter s2 = new StreamWriter(classSystem.path_WorkList + LogTime.ToString("yyyMMdd") + "_稼動率.ini", true);
                                        //s2.WriteLine(currentTime.ToString("yyyMMddHHmm") + "  ;  " + "特徵搜尋 ");

                                        //s2.Close();
                                        smallbox_i = 0;
                                        //20260324冠璋要求任何情況都不鎖定，只有在 ""一切開始""   ""二切開始""才鎖定
                                        //groupBox_Axis.Enabled = false;
                                        START_flag_2CUT = true;
                                        //DO_1_OFF();
                                        //DO_2_ON();
                                        image_error_count = 0;

                                        thread_image_test = new Thread(_image_test);
                                        thread_image_test.Start();
                                        _isthread_image_test = true;
                                        image_flag = 1;
                                        //START_flag = true;

                                        //參數紀錄
                                        string mathine_name = tb_Machine_Name.Text;
                                        string part_number = "";
                                        string batch_number = tb_lot_number.Text;
                                        string serial_number = tb_LaserDeskText.Text;
                                        string product_name = "";
                                        string pin_length = tb_needle_len.Text;
                                        string total_pin = pin_TotalNumber.ToString();
                                        string laser_Process_file = tb_Path_SCAN.Text;
                                        string laser_Pos_file = tb_Path_coordinates.Text;
                                        string laser_power = tb_Laser_energy.Text;

                                        record_update.Start(3, mathine_name, part_number, batch_number, serial_number, product_name, pin_length, total_pin, laser_Process_file, laser_Pos_file, laser_power);

                                        record_update.Save_Buffer();

                                        //MES上報
                                        //MES_Production(chpt_mes.Description_Message[(int)MES_Description.Alignment]);
                                    }


                                }
                                else
                                {
                                    MessageBox.Show("視覺系統未連線成功");
                                }
                            }
                            else
                            {
                                MessageBox.Show("檔案路徑錯誤");
                            }
                        }
                        else
                        {
                            MessageBox.Show("流程執行中,請案停");
                        }
                    }
                }
                else
                {
                    MessageBox.Show("請選擇當前為 正面 或 背面 加工");
                }
            }
            else
            {
                MessageBox.Show("軸正在移動中");
            }
        }

        /// <summary>
        /// 二切手動按下開始
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void bt_2CUTStart_Click(object sender, EventArgs e)
        {
            if (_isSysSimulated) // 判斷系統是否處於模擬模式
                return; // 如果是模擬模式，直接返回，不執行後續流程
            if (myController.Commands.Motion.WaitForMotionDone(Aerotech.A3200.Commands.WaitOption.InPosition, 0, 2000) && myController.Commands.Motion.WaitForMotionDone(Aerotech.A3200.Commands.WaitOption.InPosition, 1, 2000) && myController.Commands.Motion.WaitForMotionDone(Aerotech.A3200.Commands.WaitOption.InPosition, 2, 2000))
            {

                if (Motion_X && Motion_Y && Motion_Z)
                {
                    if (!motioning())
                    {

                        if (ProcessFileRead_flag_2CUT)
                        {
                            if (chk_SafetyLock.Checked == false)//檢查是否為解除安全模式
                            {
                                if (_isDoorLock)
                                {
                                    if (hight_Error_flag_2CUT == false)
                                    {

                                        _isProcessing = true;//加工亮綠燈


                                        //file_produce_2CUT();
                                        angle_register = Convert.ToDouble(lb_degree.Text);
                                        StartTime = DateTime.Now;
                                        LogTime = DateTime.Now;
                                        START_flag_2CUT = true;
                                        //DO_1_OFF();
                                        //DO_2_ON();
                                        group_Movement.Enabled = false;
                                        //參數紀錄
                                        string mathine_name = tb_Machine_Name.Text;
                                        string part_number = "";
                                        string batch_number = tb_lot_number.Text;
                                        string serial_number = tb_LaserDeskText.Text;
                                        string product_name = "";
                                        string pin_length = tb_needle_len.Text;
                                        string total_pin = (pin_TotalNumber_2CUT * ReginPinNum / 2).ToString();
                                        string laser_Process_file = tb_Path_SCAN.Text;
                                        string laser_Pos_file = tb_Path_coordinates.Text;
                                        string laser_power = tb_Laser_energy.Text;

                                        record_update.Start(1, mathine_name, part_number, batch_number, serial_number, product_name, pin_length, total_pin, laser_Process_file, laser_Pos_file, laser_power);

                                        record_update.Save_Buffer();

                                        Demo_Test_2CUT = new Thread(_DEMO_TEST_2CUT);
                                        Demo_Test_2CUT.Start();
                                        _isDemo_Test_2CUT = true;

                                        DEMO_flag_2CUT = 1;


                                        //button_Start.Enabled = false;






                                        //MES上報
                                        //  MES_Production(chpt_mes.Description_Message[(int)MES_Description.Laser_Cutting]);

                                    }
                                    else
                                    {
                                        MessageBox.Show("2切高度量測有誤");
                                    }
                                }
                                else
                                {
                                    MessageBox.Show("請關門並上鎖");
                                }
                            }
                            else//如果是安全模式解鎖狀態
                            {
                                if (hight_Error_flag_2CUT == false)
                                {


                                    //file_produce_2CUT();
                                    StartTime = DateTime.Now;
                                    LogTime = DateTime.Now;
                                    START_flag = true;
                                    //DO_1_OFF();
                                    //DO_2_ON();
                                    group_Movement.Enabled = false;
                                    //參數紀錄
                                    string mathine_name = tb_Machine_Name.Text;
                                    string part_number = "";
                                    string batch_number = tb_lot_number.Text;
                                    string serial_number = tb_LaserDeskText.Text;
                                    string product_name = "";
                                    string pin_length = tb_needle_len.Text;
                                    string total_pin = (pin_TotalNumber_2CUT * ReginPinNum / 2).ToString();
                                    string laser_Process_file = tb_Path_SCAN.Text;
                                    string laser_Pos_file = tb_Path_coordinates.Text;
                                    string laser_power = tb_Laser_energy.Text;

                                    record_update.Start(1, mathine_name, part_number, batch_number, serial_number, product_name, pin_length, total_pin, laser_Process_file, laser_Pos_file, laser_power);

                                    record_update.Save_Buffer();

                                    Demo_Test_2CUT = new Thread(_DEMO_TEST_2CUT);
                                    Demo_Test_2CUT.Start();


                                    DEMO_flag_2CUT = 1;

                                    //MES上報
                                    //  MES_Production(chpt_mes.Description_Message[(int)MES_Description.Laser_Cutting]);
                                }
                                else
                                {
                                    MessageBox.Show("2切高度量測有誤");
                                }
                            }

                        }
                    }
                    else
                    {
                        MessageBox.Show("流程進行中");
                    }
                }
            }
            else
            {
                MessageBox.Show("軸正在移動中");
            }



        }

        /// <summary>
        /// 讀取使用者選定的 PRR/LCN 探針補償檔案，並解析其內容至 n_PRR_List 結構中。
        /// 根據目前的針數與區域設定計算總筆數，初始化資料結構後執行讀取流程。
        /// 若成功載入則更新 UI 狀態並顯示成功訊息，否則顯示錯誤訊息或提醒未選取檔案。
        /// </summary>
        /// <param name="sender">觸發事件的按鈕控制項。</param>
        /// <param name="e">事件參數。</param>        
        private void B_PRRLCN_Apply_Click(object sender, EventArgs e)//讀取選定的檔案並解析探針數據，更新 UI 狀態。
        {
            string ff = tb_PRR_FilePath.Text;
            string f = tb_PRRLCN.Text;

            string fff = ff + "\\" + f + ".txt";

            int pin_number = (pin_TotalNumber_2CUT / 2) * Convert.ToInt16(tb_ReginPinNum.Text);

            n_PRR_List.Claer();

            n_PRR_List.TotalNumber = pin_number;

            string message = "";

            if (f != "")
            {
                if (n_PRRLCNHandler_ReadFile(fff, n_PRR_List, ref message))
                {
                    CB_PRRLCN_Switch.Checked = true;
                    MessageBox.Show("讀取二切連動檔案完成");
                }
                else
                {
                    MessageBox.Show(message);
                }
            }
            else
            {
                MessageBox.Show("讀取二切連動檔案失敗, 未選取檔案");
            }
        }
        /// <summary>
        /// 測試基恩斯通訊時間
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void button7_Click(object sender, EventArgs e)
        {
            string response = _CameraCVX.Trigger1(1000);   // 你可以調整等待時間

        }
        /// <summary>
        /// 開啟檔案選擇對話框，讓使用者選取 PRR/LCN 檔案，並嘗試讀取與解析內容。
        /// 若成功則更新 UI 狀態並顯示成功訊息，否則顯示錯誤或提醒未選檔案。
        /// </summary>
        /// <param name="sender">觸發事件的按鈕。</param>
        /// <param name="e">事件參數。</param>
        private void B_PRRLCN_Load_Click(object sender, EventArgs e)//選擇二切連動檔案，並讀取內容更新 UI。
        {
            OpenFileDialog dialog = new OpenFileDialog();
            dialog.Multiselect = true;//該值確定是否可以選擇多個檔案
            dialog.Title = "請選擇資料夾";
            dialog.Filter = "所有檔案(*.*)|*.*";

            if (dialog.ShowDialog() == System.Windows.Forms.DialogResult.OK)
            {
                string f = dialog.FileName;
                tb_PRRLCN.Text = f;

                int pin_number = (pin_TotalNumber_2CUT / 2) * Convert.ToInt16(tb_ReginPinNum.Text);

                n_PRR_List.Claer();

                n_PRR_List.TotalNumber = pin_number;

                /*if (PRRLCNHandler.ReadFile(tb_PRRLCN.Text, out PRR_List))
				{
					if (PRR_List.ProbeNumber != pin_number)
					{
						MessageBox.Show(String.Format("二切針數與連動檔案針數不匹配, 請確認數量, 二切針數: {0}, 連動針數: {1}", pin_number, PRR_List.ProbeNumber));
					}
					else
					{
						MessageBox.Show("讀取二切連動檔案完成");
					}
				}
				else
				{
					MessageBox.Show("讀取二切連動檔案失敗");
				}*/

                string message = "";

                if (tb_PRRLCN.Text != "")
                {
                    if (n_PRRLCNHandler_ReadFile(tb_PRRLCN.Text, n_PRR_List, ref message))
                    {
                        CB_PRRLCN_Switch.Checked = true;
                        MessageBox.Show("讀取二切連動檔案完成");
                    }
                    else
                    {
                        MessageBox.Show(message);
                    }
                }
                else
                {
                    MessageBox.Show("讀取二切連動檔案失敗, 未選取檔案");
                }
            }
        }
        /// <summary>
        /// 點擊按鈕後讀取 NG 針 XML 檔案，並驗證針數是否與目前設定相符。
        /// 若成功則顯示完成訊息，否則顯示錯誤原因。
        /// </summary>
        /// <param name="sender">觸發事件的按鈕。</param>
        /// <param name="e">事件參數。</param>
        private void B_NG2Cut_Load_Click(object sender, EventArgs e)// 讀取 NG 針檔案，驗證數據並顯示結果。
        {
            string message = "";
            if (Read_NG2Cut(ref message))
            {
                MessageBox.Show("讀取NG針檔案完成");
            }
            else
            {
                MessageBox.Show("讀取NG針檔案失敗, " + message);
            }
        }
        /// <summary>
        /// 當「針長差異補償」選項變更時觸發，啟用或停用針長補償設定區塊 <c>gb_Diff_Len</c>。
        /// 用於控制是否啟用針長差異補償功能。
        /// </summary>
        /// <param name="sender">觸發事件的核取方塊。</param>
        /// <param name="e">事件參數。</param>
        private void checkBox_Diff_Len_CheckedChanged(object sender, EventArgs e)//針長功能設定
        {
            if (!checkBox_Diff_Len.Checked)
            {
                gb_Diff_Len.Enabled = false;

            }
            else
            {
                gb_Diff_Len.Enabled = true;
            }
        }




        private void button10_Click(object sender, EventArgs e)
        {
            SaveFullFormScreenshot();
        }

        #endregion

        #region  Thread
        private void DataUPLoad_Start()
        {
            //DataUPLoad_recv = new Thread(DataUPLoad_RECV);
            //DataUPLoad_recv.Start();

            DataUPLoad_send = new Thread(DataUPLoad_SEND);
            _isDataUPLoad = true;
            DataUPLoad_send.Start();
            //timer1.Start();
        }
        private void DataUPLoad_SEND()
        {
            try {
            //if (sr.ReadLine() != null)
            while (_isDataUPLoad)
            {

                    //if (flag_rep_measure)
                    if (_TCP_DataUPLoad.Check_Connect())
                    {
                     


                            data_jason();
                            //_TCP_DataUPLoad.Send(sw.ToString() + "\r");
                            Thread.Sleep(2000);
                        
                    }
                    else
                    {
                        Thread.Sleep(2000);
                    try
                    {
                        _TCP_DataUPLoad.Connect();
                    }
                    catch
                    {

                    }
                }
            }
            }
            finally
            {
                DataUPLoad_send.Abort();
            }
        }

        /// <summary>
        /// 影像測試執行緒主體，持續呼叫 <c>image_test()</c> 方法執行特徵比對或影像處理流程。
        /// 用於非同步執行自動特徵搜尋。
        /// </summary>
        private void _image_test()
        {
            try
            {
                while (_isthread_image_test)
                {
                    image_test();
                }
            }
            finally
            {

                // ← 無論正常結束、還是被外部要求停止，都一定會執行這裡
                image_i = 0;
                _isthread_image_test = false;


                // 這裡啟動下一個執行緒（保證當前執行續真正結束後才跑）
                if (checkBox_AutoStart2CUT.Checked)//Demo_Test_2CUT == null || !Demo_Test_2CUT.IsAlive) &&
                {
                    if (!string.IsNullOrEmpty(TB_LoadFilePath_HeadJobx.Text) && !string.IsNullOrEmpty(TB_LoadFilePath_EndJobx.Text))
                    {
                        if (myController.Commands.Motion.WaitForMotionDone(Aerotech.A3200.Commands.WaitOption.InPosition, 0, 2000) && myController.Commands.Motion.WaitForMotionDone(Aerotech.A3200.Commands.WaitOption.InPosition, 1, 2000) && myController.Commands.Motion.WaitForMotionDone(Aerotech.A3200.Commands.WaitOption.InPosition, 2, 2000))
                        {
                            if (Motion_X && Motion_Y && Motion_Z)
                            {
                                if (!motioning())
                                {
                                    if (ProcessFileRead_flag_2CUT)
                                    {
                                        if (chk_SafetyLock.Checked == false)//檢查是否為解除安全模式
                                        {
                                            if (_isDoorLock)
                                            {
                                                if (hight_Error_flag_2CUT == false)
                                                {
                                                    _isProcessing = true;//加工亮綠燈

                                                    angle_register = Convert.ToDouble(lb_degree.Text);
                                                    StartTime = DateTime.Now;
                                                    LogTime = DateTime.Now;
                                                    START_flag_2CUT = true;
                                                    // group_Movement.Enabled = false;

                                                    //參數紀錄
                                                    string mathine_name = tb_Machine_Name.Text;
                                                    string part_number = "";
                                                    string batch_number = tb_lot_number.Text;
                                                    string serial_number = tb_LaserDeskText.Text;
                                                    string product_name = "";
                                                    string pin_length = tb_needle_len.Text;
                                                    string total_pin = (pin_TotalNumber_2CUT * ReginPinNum / 2).ToString();
                                                    string laser_Process_file = tb_Path_SCAN.Text;
                                                    string laser_Pos_file = tb_Path_coordinates.Text;
                                                    string laser_power = tb_Laser_energy.Text;

                                                    record_update.Start(1, mathine_name, part_number, batch_number, serial_number, product_name, pin_length, total_pin, laser_Process_file, laser_Pos_file, laser_power);

                                                    record_update.Save_Buffer();

                                                    Demo_Test_2CUT = new Thread(_DEMO_TEST_2CUT);
                                                    Demo_Test_2CUT.Start();
                                                    _isDemo_Test_2CUT = true;

                                                    DEMO_flag_2CUT = 1;

                                                    //MES上報
                                                    //  MES_Production(chpt_mes.Description_Message[(int)MES_Description.Laser_Cutting]);
                                                }
                                                else
                                                {
                                                    MessageBox.Show("2切高度量測有誤");
                                                }
                                            }
                                            else
                                            {
                                                MessageBox.Show("請關門並上鎖");
                                            }
                                        }
                                        else//如果是安全模式解鎖狀態
                                        {
                                            if (hight_Error_flag_2CUT == false)
                                            {


                                                //file_produce_2CUT();
                                                StartTime = DateTime.Now;
                                                LogTime = DateTime.Now;
                                                START_flag = true;
                                                //DO_1_OFF();
                                                //DO_2_ON();
                                                group_Movement.Enabled = false;
                                                //參數紀錄
                                                string mathine_name = tb_Machine_Name.Text;
                                                string part_number = "";
                                                string batch_number = tb_lot_number.Text;
                                                string serial_number = tb_LaserDeskText.Text;
                                                string product_name = "";
                                                string pin_length = tb_needle_len.Text;
                                                string total_pin = (pin_TotalNumber_2CUT * ReginPinNum / 2).ToString();
                                                string laser_Process_file = tb_Path_SCAN.Text;
                                                string laser_Pos_file = tb_Path_coordinates.Text;
                                                string laser_power = tb_Laser_energy.Text;

                                                record_update.Start(1, mathine_name, part_number, batch_number, serial_number, product_name, pin_length, total_pin, laser_Process_file, laser_Pos_file, laser_power);

                                                record_update.Save_Buffer();

                                                Demo_Test_2CUT = new Thread(_DEMO_TEST_2CUT);
                                                Demo_Test_2CUT.Start();


                                                DEMO_flag_2CUT = 1;

                                                //MES上報
                                                //  MES_Production(chpt_mes.Description_Message[(int)MES_Description.Laser_Cutting]);
                                            }
                                            else
                                            {
                                                MessageBox.Show("2切高度量測有誤");
                                            }
                                        }
                                    }
                                }
                                else
                                {
                                    MessageBox.Show("流程進行中");
                                }
                            }
                        }
                        else
                        {
                            MessageBox.Show("軸正在移動中");
                        }
                    }
                    else
                    {
                        MessageBox.Show("勾選自動開始二切後，無選擇刀具檔無法開始二切加工。請載入刀具檔後，手動按下2切開始加工");
                    }
                }



































                //    // 這裡啟動下一個執行緒（保證當前執行續真正結束後才跑）
                //    if ((Demo_Test_2CUT == null || !Demo_Test_2CUT.IsAlive) && checkBox_AutoStart2CUT.Checked == true)
                //    {



                //        angle_register = Convert.ToDouble(lb_degree.Text);
                //        StartTime = DateTime.Now;
                //        ////[BM:LCN加工時間估算法及資料上報優化-紀錄一切開始時間]
                //        //lb_start_time.Text = StartTime.ToString("yyyy-MM-dd HH:mm:ss");

                //        LogTime = DateTime.Now;
                //        START_flag_2CUT = true;
                //        //DO_1_OFF();
                //        //DO_2_ON();
                //        groupBox_Axis.Enabled = false;
                //        //參數紀錄
                //        string mathine_name = tb_Machine_Name.Text;
                //        string part_number = "";
                //        string batch_number = tb_lot_number.Text;
                //        string serial_number = tb_LaserDeskText.Text;
                //        string product_name = "";
                //        string pin_length = tb_needle_len.Text;
                //        string total_pin = (pin_TotalNumber_2CUT * ReginPinNum / 2).ToString();
                //        string laser_Process_file = tb_Path_SCAN.Text;
                //        string laser_Pos_file = tb_Path_coordinates.Text;
                //        string laser_power = tb_Laser_energy.Text;

                //        record_update.Start(1, mathine_name, part_number, batch_number, serial_number, product_name, pin_length, total_pin, laser_Process_file, laser_Pos_file, laser_power);

                //        record_update.Save_Buffer();

                //        //MES上報
                //        // MES_Production(chpt_mes.Description_Message[(int)MES_Description.Laser_Cutting]);

                //        Thread.Sleep(1500);

                //        Demo_Test_2CUT = new Thread(_DEMO_TEST_2CUT);
                //        Demo_Test_2CUT.Start();


                //        DEMO_flag_2CUT = 1;
                //    }




            }





        }
        /// <summary>
        /// 暴力破解 辨識不到的問題
        /// </summary>
        bool CCD_Retry = false;
        /// <summary>
        /// 自動尋找特徵流程主體，依據 <c>image_flag</c> 狀態進行特徵點定位、廠景切換、影像量測、補償移動與結果記錄。
        /// 此流程包含以下階段：
        /// <list type="number">
        /// <item><description>確認系統狀態與 CCD 連線</description></item>
        /// <item><description>切換廠景參數（Scene）</description></item>
        /// <item><description>確認廠景切換成功</description></item>
        /// <item><description>移動至特徵點位置</description></item>
        /// <item><description>執行影像量測並判斷是否需補償</description></item>
        /// <item><description>補償移動並重新量測</description></item>
        /// <item><description>記錄特徵點位置與量測結果</description></item>
        /// </list>
        /// 若 CCD 回傳異常或相似度不足，則記錄錯誤並跳過該點；流程支援 ShortPitch 與 Alignment 模式的座標偏移補償。
        /// </summary>
        private void image_test()//自動尋找特徵流程
        {
            // ==================== 在最前面統一宣告 ====================
            //string logFolder = Path.Combine(C_Path, "LCN_LOG", "Image");
            //Directory.CreateDirectory(logFolder);   // 只建立一次

            switch (image_flag)
            {
                case 0:
                    _isthread_image_test = false;
                    prog_status = "特徵尋找結束";

                    Thread.Sleep(100);

                    break;
                case 1:
                    //確認home完成/severon
                    if (En && Home && ProcessFileRead_flag_2CUT && axCVX1.Connected)
                    //if (En && Home && ProcessFileRead_flag_2CUT && coreRA1.IsConnected)
                    {
                        prog_status = "特徵尋找開始";
                        if (checkBox_Diff_Len.Checked)
                        {
                            image_i = Range_minmun * 2;
                            image_END = (Range_maxmum + 1) * 2;
                        }
                        else
                        {
                            image_i = 0;
                            image_END = Sym_TotalNumber;
                        }
                        image_flag = 2;
                        CCD_error = 0;
                        CCD_error_conti = 0;
                        image_error_num = 0;
                        Smallbox_error_num = 0;
                        image_ok_num = 0;
                    }
                    else
                    {
                        if (!En)
                        {
                            image_flag = 0;
                            MessageBox.Show("Please Check Servo ON !");

                        }

                        if (!Home)
                        {
                            image_flag = 0;
                            MessageBox.Show("Please Check Homed !");

                        }
                        if (!ProcessFileRead_flag_2CUT)
                        {
                            image_flag = 0;
                            MessageBox.Show("未載入加工檔案 !");
                        }
                        if (!axCVX1.Connected)
                        {
                            image_flag = 0;
                            MessageBox.Show("未連線視覺系統 !");
                        }

                    }
                    break;
                case 2:
                    //廠景切換
                    if (axCVX1.Connected)
                    {


                        image_flag = 20;

                    }
                    else
                    {
                        image_flag = 0;
                        MessageBox.Show("視覺系統未連線");
                    }
                    break;

                case 20:

                    try
                    {
                        if (RB_Front.Checked)//正面加工
                        {
                            string response = _CameraCVX.ExternalRead(150);   // 發送並接收回傳值
                            _lastEXRResponse = response;

                            if (_lastEXRResponse == "EXR,4" || _lastEXRResponse.Contains("EXR,4"))//檢察當前檢測條件是不是定為特徵搜尋
                            {
                                image_flag = 21;
                                //   image_reciver_flag = false;
                            }
                            else
                            {
                                // 若不是則進行切換切 Scene 
                                _CameraCVX.ExternalWrite(4, 150);

                                image_flag = 2;
                            }

                        }
                        else//背面加工，一定背面加工，因為一定要選其中一個才進的來此流程
                        {
                            string response = _CameraCVX.ExternalRead(150);   // 發送並接收回傳值
                            _lastEXRResponse = response;

                            if (_lastEXRResponse == "EXR,3" || _lastEXRResponse.Contains("EXR,3"))//檢察當前檢測條件是不是定為特徵搜尋
                            {
                                image_flag = 21;
                                //   image_reciver_flag = false;
                            }
                            else
                            {
                                // 若不是則進行切換切 Scene 
                                _CameraCVX.ExternalWrite(3, 150);

                                image_flag = 2;
                            }
                        }

                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show($"Scene 切換失敗: {ex.Message}", "CV-X 錯誤",
                                       MessageBoxButtons.OK, MessageBoxIcon.Error);
                        image_flag = 100;
                    }



                    ////eee
                    ////判斷廠景是否切換成功
                    ////確認SCENE

                    ////if ((INT_DI_data_U1 & 4) < 1)
                    ////{
                    ////_TCP_image.Send("SCENE" + "\r\n");
                    ////Thread.Sleep(100);

                    ////確認條件
                    //tcp1.ReadMsg = "";
                    //tcp1.WriteLine("EXR");
                    ////_TCP_image.Send("SCENE" + "\r\n");
                    //Thread.Sleep(100);
                    ////StringBuilder Nodata = new StringBuilder("");
                    ////coreRA1.Macro_DirectExecute("NO& =SceneNo");
                    ////int No = coreRA1.Macro_GetVariable("NO&", Nodata, 10);
                    ////SceneNo = Convert.ToInt32(Nodata.ToString());

                    //image_flag = 21;
                    ////}
                    break;
                case 21:

                    try
                    {
                        string response = _CameraCVX.ExternalRead(150);   // 發送並接收回傳值
                        _lastEXRResponse = response;



                        if (RB_Front.Checked)//正面加工
                        {

                            if (_lastEXRResponse == "EXR,4")
                            {
                                image_flag = 3;

                            }

                            else
                            {
                                MessageBox.Show($"基恩斯檢測項目切換失敗: {_lastEXRResponse}", "CV-X 錯誤",
                                               MessageBoxButtons.OK, MessageBoxIcon.Error);

                                image_flag = 100;   // 錯誤時的旗標

                            }
                        }

                        else//背面加工，一定背面加工，因為一定要選其中一個才進的來此流程
                        {
                            if (_lastEXRResponse == "EXR,3")
                            {
                                image_flag = 3;

                            }

                            else
                            {
                                MessageBox.Show($"基恩斯檢測項目切換失敗: {_lastEXRResponse}", "CV-X 錯誤",
                                               MessageBoxButtons.OK, MessageBoxIcon.Error);

                                image_flag = 100;   // 錯誤時的旗標

                            }

                        }
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show($"基恩斯檢測失敗: {ex.Message}", "CV-X 錯誤",
                                       MessageBoxButtons.OK, MessageBoxIcon.Error);

                        image_flag = 100;   // 錯誤時的旗標
                    }



                    break;
                case 3:
                    //移動xy軸

                    if (myController.Commands.Motion.WaitForMotionDone(Aerotech.A3200.Commands.WaitOption.InPosition, 0, 2000) && myController.Commands.Motion.WaitForMotionDone(Aerotech.A3200.Commands.WaitOption.InPosition, 1, 2000) && myController.Commands.Motion.WaitForMotionDone(Aerotech.A3200.Commands.WaitOption.InPosition, 2, 2000))
                    {
                        if (Motion_X && Motion_Y && Motion_Z)
                        {
                            //左下到右上
                            //加上偏移到肋
                            //ABS_X = Convert.ToDouble(str_X1) + new_X((Convert.ToDouble(tkn_X[image_i]) ).ToString(), tkn_Y[image_i]);
                            //ABS_Y = Convert.ToDouble(str_Y1) + new_Y((Convert.ToDouble(tkn_X[image_i]) ).ToString(), tkn_Y[image_i]);
                            //特徵點位置
                            //ccd

                            //20210831 D.C
                            //公式:(str_X1(孔1實際位置) - (座標檔孔1位置)) + (座標檔特徵點)
                            //因座標檔內孔1不一定為(0,0)
                            ABS_X = (Convert.ToDouble(str_X1) - Convert.ToDouble(point_position[24, 0])) + new_X((simple_X[image_i]), (simple_Y[image_i]));
                            ABS_Y = (Convert.ToDouble(str_Y1) - Convert.ToDouble(point_position[24, 1])) + new_Y((simple_X[image_i]), (simple_Y[image_i]));   //20260505移除+0.1     //20260502rex-0.3 =>+0.1
                            //相機高度+量測
                            ABS_Z = Convert.ToDouble(point_position[22, 1]) + (Thick_Array_sym[image_i]);
                            Allow_X = Allow_Y = true;
                            Allow_Z = true;


                            //[BM:優化紀錄資訊Log]
                            WriteLog("Image", "_ImageSimplePosCheck.ini",
                                $"No: {image_i}, ABS_X: {ABS_X}, POS_X: {simple_X[image_i]}, " +
                                $"ABS_Y: {ABS_Y}, POS_Y: {simple_Y[image_i]}, " +
                                $"ABS_Z: {ABS_Z}, POS_Z: {Thick_Array_sym[image_i]}");
                            //存檔
                            //StreamWriter sw = new StreamWriter(Path.Combine(Environment.CurrentDirectory, "LCN_LOG", "Image") + CurrTime.ToString("yyyyMMddHHmm") + "_ImageSimplePosCheck.ini", true);

                            //sw.WriteLine("No: " + image_i.ToString() + ", ABS_X: " + ABS_X.ToString() + ", POS_X: " + simple_X[image_i].ToString() +
                            //                                           ", ABS_Y: " + ABS_Y.ToString() + ", POS_Y: " + simple_Y[image_i].ToString() +
                            //                                           ", ABS_Z: " + ABS_Z.ToString() + ", POS_Z: " + Thick_Array_sym[image_i].ToString());
                            ////sw.Flush();
                            //sw.Close();

                            if (ABS_Z > zlimit)//計算出來的絕對位置要大於接近撞吸嘴的危險值
                            {


                                //Aero_thMotionRun_Tick(Motion_Num.Motion_ABS);
                                if (Allow_X)
                                {
                                    this.myController.Commands[this.taskIndex].Motion.MoveAbs(0, ABS_X, fastspeed);
                                    //Thread.Sleep(50);
                                }
                                if (Allow_Y)
                                {
                                    this.myController.Commands[this.taskIndex].Motion.MoveAbs(1, ABS_Y, fastspeed);
                                    //Thread.Sleep(50);
                                }
                                if (Allow_Z)
                                {
                                    this.myController.Commands[this.taskIndex].Motion.MoveAbs(2, ABS_Z, fastspeed);
                                    //Thread.Sleep(50);
                                }
                            }
                            else
                            {
                                MessageBox.Show($"z軸高度計算後超出安全高度({zlimit}): {ABS_Z}", "z軸高度軟體限制",
                                             MessageBoxButtons.OK, MessageBoxIcon.Error);
                                WriteLog("Thread", "_thread.ini", $"z軸高度計算後超出安全高度({ zlimit}): { ABS_Z}");
                                image_flag = 0;
                            }
                            image_flag = 4;
                        }
                    }

                    break;
                case 4:
                    //確認到位
                    //this.Invoke(new Action<NewDiagPacketArrivedEventArgs>(SetAxisState));
                    if (myController.Commands.Motion.WaitForMotionDone(Aerotech.A3200.Commands.WaitOption.InPosition, 0, 2000) && myController.Commands.Motion.WaitForMotionDone(Aerotech.A3200.Commands.WaitOption.InPosition, 1, 2000) && myController.Commands.Motion.WaitForMotionDone(Aerotech.A3200.Commands.WaitOption.InPosition, 2, 2000))
                    {
                        if (Motion_X && Motion_Y && Motion_Z)
                        {

                            try
                            {
                                // 取代原本的 tcp1.WriteLine("T1");
                                string response = _CameraCVX.Trigger1(500);   // 若timeout太短會收不到第二行資訊

                                // 記錄最後一次的回應，給 case 4 使用
                                _lastTriggerResponse = response;
                                Thread.Sleep(100);

                                image_flag = 5;
                            }
                            catch (Exception ex)
                            {
                                MessageBox.Show($"T1 觸發失敗: {ex.Message}", "CV-X 錯誤",
                                               MessageBoxButtons.OK, MessageBoxIcon.Error);
                                image_flag = 100;
                            }

                            //if ((INT_DI_data_U1 & 4) < 1)
                            //{ 

                            //// _TCP_image.Send("M" + "\r\n");
                            //tcp1.ReadMsg = "";
                            //tcp1.WriteLine("T1");
                            //Thread.Sleep(100);
                            //image_flag = 5;
                            ////str = "";
                            //}
                        }
                    }
                    else
                    {
                        Thread.Sleep(30);
                    }


                    break;

                case 5:
                    //影像量測
                    //***要加上辨識不到的情況

                    //DATA

                    string[] s_im = _lastTriggerResponse.Split(',', '\r');// 一定是單引

                    sub_im[0] = s_im[0];//T1
                    sub_im[1] = s_im[1];//X; /2000
                    sub_im[2] = s_im[2];//Y; /2000+負號
                    sub_im[3] = s_im[3];//SIMILER
                    if ((Convert.ToDouble(sub_im[3]) >= 60) && sub_im[0] == "T1")//辨識成功
                    {
                        X_CCD = Convert.ToDouble(sub_im[1]) / 970;
                        Y_CCD = -Convert.ToDouble(sub_im[2]) / 970;
                        //***需加上ng的情況***
                        if (X_CCD > 99 || Y_CCD > 99)//如果傳回來的值>990mm ，進這裡錯誤直接再次檢測
                        {
                            CCD_error++;
                            if (CCD_error < 5)
                            {
                                //Thread.Sleep(500);
                                image_flag = 4;
                            }
                            else
                            {
                                CCD_error = 0;
                                CCD_error_conti++;
                                //image_flag = 0;
                                //MessageBox.Show("視覺檢查發生異常");
                                //跳過

                                image_error_count++;

                                image_error_flag[image_i] = -1;//紀錄異常值
                                image_error_num++;
                                image_flag = 60;

                            }
                        }
                        else//若是正常值
                        {
                            if (Math.Abs(X_CCD) < 0.0003 && Math.Abs(Y_CCD) < 0.0003) //很準的話直接進下一段流程 原先門檻0.0008
                            {
                                //Thread.Sleep(100);
                                CCD_error_conti = 0;

                                image_error_flag[image_i] = 1;
                                image_ok_num++;
                                image_flag = 60;
                            }
                            else //需要移動平台進行補償
                            {
                                CCD_retry++;
                                if (CCD_retry > 10)//一直補償都進不去0.0003的話
                                {
                                    CCD_retry = 0;
                                    image_error_flag[image_i] = -1;//紀錄異常值
                                    image_error_num++;

                                    image_flag = 60;
                                }
                                else
                                {

                                    image_flag = 6;//進入平台移動補償位置
                                }
                            }
                        }
                    }
                    else
                    {


                        if (CCD_retry > 8)//若左右橫移超過8次記標是錯誤
                        {
                            image_error_count++;

                            image_error_flag[image_i] = -1;//紀錄異常值
                            CCD_error_conti = 0;
                            CCD_retry = 0;//移動位置左右反覆向下移動搜尋的左右移動依據
                            image_flag = 60;
                        }
                        else
                        {

                            //========================移動換位再次拍攝
                            CCD_retry++;

                            bool hasRemainder = (CCD_retry % 2) != 0;


                            if (hasRemainder)
                            {
                                this.myController.Commands[this.taskIndex].Motion.MoveAbs(0, Convert.ToDouble(txt_Motion_Position_X.Text) - 0.01, 40);

                                this.myController.Commands[this.taskIndex].Motion.MoveAbs(1, Convert.ToDouble(txt_Motion_Position_Y.Text) - 0.01, 40);

                            }
                            else
                            {
                                this.myController.Commands[this.taskIndex].Motion.MoveAbs(0, Convert.ToDouble(txt_Motion_Position_X.Text) + 0.01, 40);

                                this.myController.Commands[this.taskIndex].Motion.MoveAbs(1, Convert.ToDouble(txt_Motion_Position_Y.Text) - 0.01, 40);
                            }


                            Thread.Sleep(500);
                            image_flag = 4;// 再次辨識
                                           //========================移動換位再次拍攝
                        }

                    }




                    break;
                case 6:
                    //補償完再回去檢查,如果檢查不需補正跳下一步並記錄位置
                    //移動xy軸

                    if (myController.Commands.Motion.WaitForMotionDone(Aerotech.A3200.Commands.WaitOption.InPosition, 0, 2000) && myController.Commands.Motion.WaitForMotionDone(Aerotech.A3200.Commands.WaitOption.InPosition, 1, 2000) && myController.Commands.Motion.WaitForMotionDone(Aerotech.A3200.Commands.WaitOption.InPosition, 2, 2000))
                    {
                        if (Motion_X && Motion_Y && Motion_Z)
                        {

                            Distance_X = X_CCD;
                            Distance_Y = Y_CCD;
                            double[] Speed = { 40, 40 };
                            double[] Distance = { Distance_X, Distance_Y };
                            //myController.Commands.Axes[0, 1].Motion.Rapid(Distance, Speed);
                            this.myController.Commands[this.taskIndex].Motion.MoveInc(0, Distance_X, fastspeed);
                            this.myController.Commands[this.taskIndex].Motion.MoveInc(1, Distance_Y, fastspeed);
                            //Thread.Sleep(500);

                            image_flag = 7;
                        }
                    }


                    break;
                case 7:
                    if (myController.Commands.Motion.WaitForMotionDone(Aerotech.A3200.Commands.WaitOption.InPosition, 0, 2000) && myController.Commands.Motion.WaitForMotionDone(Aerotech.A3200.Commands.WaitOption.InPosition, 1, 2000) && myController.Commands.Motion.WaitForMotionDone(Aerotech.A3200.Commands.WaitOption.InPosition, 2, 2000))
                    {
                        if (Motion_X && Motion_Y && Motion_Z)
                        {
                            // 原先是檢查到物體後軸移動到中心之後再檢測一次，改為止移動後就儲存不再次檢察






                            Thread.Sleep(100);
                            X_CCD = Y_CCD = 999;
                            //Thread.Sleep(300);
                            image_flag = 4;//回到影像檢測

















                            ////原先是檢查到物體後軸移動到中心之後再檢測一次，改為止移動後就儲存不再次檢察

                            ////if (CCD_Retry)
                            ////{
                            //X_CCD = Y_CCD = 999;

                            ////Thread.Sleep(100);
                            //CCD_error_conti = 0;
                            //image_error_flag[image_i] = 1;
                            //CCD_Retry = false;
                            //image_flag = 60;
                            ////  }

                            ////else
                            ////{
                            ////    X_CCD = Y_CCD = 999;
                            ////    //Thread.Sleep(300);



                            ////    image_flag = 4;//回到影像檢測
                            ////}
                        }
                    }



                    break;
                case 60:
                    //儲存特徵點位置
                    //sw.WriteLine("X_POS= " + txt_Motion_Position_X.Text + "  ;  " + "Y_POS= " + txt_Motion_Position_Y.Text + " ; " + "厚度= " + Thick_Array[tkn_i].ToString());

                    if (myController.Commands.Motion.WaitForMotionDone(Aerotech.A3200.Commands.WaitOption.InPosition, 0, 2000) && myController.Commands.Motion.WaitForMotionDone(Aerotech.A3200.Commands.WaitOption.InPosition, 1, 2000) && myController.Commands.Motion.WaitForMotionDone(Aerotech.A3200.Commands.WaitOption.InPosition, 2, 2000))
                    {
                        if (Motion_X && Motion_Y && Motion_Z)
                        {
                            if (cb_8error.Checked == false)
                            {
                                if (CCD_error_conti > 8)
                                {
                                    image_flag = 10;
                                }
                                else
                                {
                                    CCD_error_conti = 0;
                                    CCD_retry = 0;
                                    if (!RB_NS_ShortPitch.Checked && !RB_BR_ShortPitch.Checked && !RB_NS_Alignment.Checked && !RB_BR_Alignment.Checked)
                                    {
                                        HeadPOS_X_Regin[image_i] = Convert.ToDouble(txt_Motion_Position_X.Text);
                                        HeadPOS_Y_Regin[image_i] = Convert.ToDouble(txt_Motion_Position_Y.Text);
                                    }
                                    else if (RB_NS_ShortPitch.Checked)
                                    {
                                        //程式內部由0開始 +1方便閱讀
                                        if (((image_i + 1) % 2) == 1)
                                        {
                                            HeadPOS_X_Regin[image_i] = Convert.ToDouble(txt_Motion_Position_X.Text) + new_X(point_position[34, 2], (0).ToString());
                                            HeadPOS_Y_Regin[image_i] = Convert.ToDouble(txt_Motion_Position_Y.Text) + new_Y(point_position[34, 2], (0).ToString());
                                        }
                                        else if (((image_i + 1) % 2) == 0)
                                        {
                                            HeadPOS_X_Regin[image_i] = Convert.ToDouble(txt_Motion_Position_X.Text) - new_X(point_position[34, 2], (0).ToString());
                                            HeadPOS_Y_Regin[image_i] = Convert.ToDouble(txt_Motion_Position_Y.Text) - new_Y(point_position[34, 2], (0).ToString());
                                        }
                                    }
                                    else if (RB_BR_ShortPitch.Checked)
                                    {
                                        //程式內部由0開始 +1方便閱讀
                                        if (((image_i + 1) % 2) == 1)
                                        {
                                            HeadPOS_X_Regin[image_i] = Convert.ToDouble(txt_Motion_Position_X.Text) + new_X(point_position[39, 2], (0).ToString());
                                            HeadPOS_Y_Regin[image_i] = Convert.ToDouble(txt_Motion_Position_Y.Text) + new_Y(point_position[39, 2], (0).ToString());
                                        }
                                        else if (((image_i + 1) % 2) == 0)
                                        {
                                            HeadPOS_X_Regin[image_i] = Convert.ToDouble(txt_Motion_Position_X.Text) - new_X(point_position[39, 2], (0).ToString());
                                            HeadPOS_Y_Regin[image_i] = Convert.ToDouble(txt_Motion_Position_Y.Text) - new_Y(point_position[39, 2], (0).ToString());
                                        }
                                    }
                                    else if (RB_NS_Alignment.Checked)
                                    {
                                        //程式內部由0開始 +1方便閱讀
                                        if (((image_i + 1) % 2) == 1)
                                        {
                                            HeadPOS_X_Regin[image_i] = Convert.ToDouble(txt_Motion_Position_X.Text) + new_X(point_position[40, 2], (0).ToString());
                                            HeadPOS_Y_Regin[image_i] = Convert.ToDouble(txt_Motion_Position_Y.Text) + new_Y(point_position[40, 2], (0).ToString());
                                        }
                                        else if (((image_i + 1) % 2) == 0)
                                        {
                                            HeadPOS_X_Regin[image_i] = Convert.ToDouble(txt_Motion_Position_X.Text) - new_X(point_position[40, 2], (0).ToString());
                                            HeadPOS_Y_Regin[image_i] = Convert.ToDouble(txt_Motion_Position_Y.Text) - new_Y(point_position[40, 2], (0).ToString());
                                        }
                                    }
                                    else if (RB_BR_Alignment.Checked)
                                    {
                                        //程式內部由0開始 +1方便閱讀
                                        if (((image_i + 1) % 2) == 1)
                                        {
                                            HeadPOS_X_Regin[image_i] = Convert.ToDouble(txt_Motion_Position_X.Text) + new_X(point_position[41, 2], (0).ToString());
                                            HeadPOS_Y_Regin[image_i] = Convert.ToDouble(txt_Motion_Position_Y.Text) + new_Y(point_position[41, 2], (0).ToString());
                                        }
                                        else if (((image_i + 1) % 2) == 0)
                                        {
                                            HeadPOS_X_Regin[image_i] = Convert.ToDouble(txt_Motion_Position_X.Text) - new_X(point_position[41, 2], (0).ToString());
                                            HeadPOS_Y_Regin[image_i] = Convert.ToDouble(txt_Motion_Position_Y.Text) - new_Y(point_position[41, 2], (0).ToString());
                                        }
                                    }
                                    //[BM:優化紀錄資訊Log]
                                    // ====================== Image 位置記錄 (SimplePos) ======================
                                    WriteLog("Image", "_ImageSimplePos.ini", $"{HeadPOS_X_Regin[image_i]} , {HeadPOS_Y_Regin[image_i]} , {image_error_flag[image_i]}");
                                    //存檔
                                    //StreamWriter sw = new StreamWriter(Path.Combine(Environment.CurrentDirectory, "LCN_LOG", "Image") + CurrTime.ToString("yyyyMMddHHmm") + "_ImageSimplePos.ini", true);
                                    //sw.WriteLine(HeadPOS_X_Regin[image_i] + "  ,  " + HeadPOS_Y_Regin[image_i] + "  ,  " + image_error_flag[image_i]);
                                    ////sw.Flush();
                                    //sw.Close();
                                    X_CCD = Y_CCD = 999;
                                    image_flag = 8;
                                }
                            }
                            else
                            {
                                CCD_retry = 0;
                                if (!RB_NS_ShortPitch.Checked && !RB_BR_ShortPitch.Checked && !RB_NS_Alignment.Checked && !RB_BR_Alignment.Checked)
                                {
                                    HeadPOS_X_Regin[image_i] = Convert.ToDouble(txt_Motion_Position_X.Text);
                                    HeadPOS_Y_Regin[image_i] = Convert.ToDouble(txt_Motion_Position_Y.Text);
                                }
                                else if (RB_NS_ShortPitch.Checked)
                                {
                                    //程式內部由0開始 +1方便閱讀
                                    if (((image_i + 1) % 2) == 1)
                                    {
                                        HeadPOS_X_Regin[image_i] = Convert.ToDouble(txt_Motion_Position_X.Text) + new_X(point_position[34, 2], (0).ToString());
                                        HeadPOS_Y_Regin[image_i] = Convert.ToDouble(txt_Motion_Position_Y.Text) + new_Y(point_position[34, 2], (0).ToString());
                                    }
                                    else if (((image_i + 1) % 2) == 0)
                                    {
                                        HeadPOS_X_Regin[image_i] = Convert.ToDouble(txt_Motion_Position_X.Text) - new_X(point_position[34, 2], (0).ToString());
                                        HeadPOS_Y_Regin[image_i] = Convert.ToDouble(txt_Motion_Position_Y.Text) - new_Y(point_position[34, 2], (0).ToString());
                                    }
                                }
                                else if (RB_BR_ShortPitch.Checked)
                                {
                                    //程式內部由0開始 +1方便閱讀
                                    if (((image_i + 1) % 2) == 1)
                                    {
                                        HeadPOS_X_Regin[image_i] = Convert.ToDouble(txt_Motion_Position_X.Text) + new_X(point_position[39, 2], (0).ToString());
                                        HeadPOS_Y_Regin[image_i] = Convert.ToDouble(txt_Motion_Position_Y.Text) + new_Y(point_position[39, 2], (0).ToString());
                                    }
                                    else if (((image_i + 1) % 2) == 0)
                                    {
                                        HeadPOS_X_Regin[image_i] = Convert.ToDouble(txt_Motion_Position_X.Text) - new_X(point_position[39, 2], (0).ToString());
                                        HeadPOS_Y_Regin[image_i] = Convert.ToDouble(txt_Motion_Position_Y.Text) - new_Y(point_position[39, 2], (0).ToString());
                                    }
                                }
                                else if (RB_NS_Alignment.Checked)
                                {
                                    //程式內部由0開始 +1方便閱讀
                                    if (((image_i + 1) % 2) == 1)
                                    {
                                        HeadPOS_X_Regin[image_i] = Convert.ToDouble(txt_Motion_Position_X.Text) + new_X(point_position[40, 2], (0).ToString());
                                        HeadPOS_Y_Regin[image_i] = Convert.ToDouble(txt_Motion_Position_Y.Text) + new_Y(point_position[40, 2], (0).ToString());
                                    }
                                    else if (((image_i + 1) % 2) == 0)
                                    {
                                        HeadPOS_X_Regin[image_i] = Convert.ToDouble(txt_Motion_Position_X.Text) - new_X(point_position[40, 2], (0).ToString());
                                        HeadPOS_Y_Regin[image_i] = Convert.ToDouble(txt_Motion_Position_Y.Text) - new_Y(point_position[40, 2], (0).ToString());
                                    }
                                }
                                else if (RB_BR_Alignment.Checked)
                                {
                                    //程式內部由0開始 +1方便閱讀
                                    if (((image_i + 1) % 2) == 1)
                                    {
                                        HeadPOS_X_Regin[image_i] = Convert.ToDouble(txt_Motion_Position_X.Text) + new_X(point_position[41, 2], (0).ToString());
                                        HeadPOS_Y_Regin[image_i] = Convert.ToDouble(txt_Motion_Position_Y.Text) + new_Y(point_position[41, 2], (0).ToString());
                                    }
                                    else if (((image_i + 1) % 2) == 0)
                                    {
                                        HeadPOS_X_Regin[image_i] = Convert.ToDouble(txt_Motion_Position_X.Text) - new_X(point_position[41, 2], (0).ToString());
                                        HeadPOS_Y_Regin[image_i] = Convert.ToDouble(txt_Motion_Position_Y.Text) - new_Y(point_position[41, 2], (0).ToString());
                                    }
                                }
                                //[BM:優化紀錄資訊Log]
                                // ====================== Image SimplePos 記錄 ======================
                                WriteLog("Image", "_ImageSimplePos.ini", $"{HeadPOS_X_Regin[image_i]} , {HeadPOS_Y_Regin[image_i]} , {image_error_flag[image_i]}");
                                //存檔
                                //StreamWriter sw = new StreamWriter(Path.Combine(Environment.CurrentDirectory, "LCN_LOG", "Image") + CurrTime.ToString("yyyyMMddHHmm") + "_ImageSimplePos.ini", true);
                                //sw.WriteLine(HeadPOS_X_Regin[image_i] + "  ,  " + HeadPOS_Y_Regin[image_i] + "  ,  " + image_error_flag[image_i]);
                                ////sw.Flush();
                                //sw.Close();
                                X_CCD = Y_CCD = 999;
                                image_flag = 8;
                            }
                        }
                    }
                    break;

                case 8:
                    //測試完畢?最後一個?回到case1

                    image_i++;
                    if (image_i >= image_END)//360
                    {
                        Thread.Sleep(1000);

                        SaveFullFormScreenshot();
                        image_flag = 801;
                    }
                    else
                    {
                        Thread.Sleep(1000);

                        SaveFullFormScreenshot();
                        image_flag = 3;
                    }
                    break;
                case 801:
                    //判斷方框辨識是否開啟
                    if (cb_smallbox_switch.Checked == true)
                    {
                        if (small_TotalNumber_2CUT == 0)
                            image_flag = 81;
                        else
                            image_flag = 802;
                    }
                    else
                    {
                        image_flag = 81;
                    }
                    break;
                case 802:
                    //廠景切換
                    if (axCVX1.Connected)
                    {
                        tcp1.ReadMsg = "";
                        tcp1.WriteLine("EXW,20");
                        Thread.Sleep(150);

                        image_flag = 803;
                    }
                    else
                    {
                        image_flag = 0;
                        MessageBox.Show("視覺系統未連線");
                    }
                    break;
                case 803:
                    //判斷廠景是否切換成功
                    //確認條件
                    tcp1.ReadMsg = "";
                    tcp1.WriteLine("EXR");

                    Thread.Sleep(100);

                    image_flag = 804;
                    break;
                case 804:
                    if (image_reciver_flag)
                    {
                        detect_num = "EXR,20";

                        if (tcp1.ReadMsg == detect_num)
                        {

                            image_flag = 805;
                            image_reciver_flag = false;
                        }
                        else
                        {
                            image_flag = 802;
                        }
                    }
                    break;
                case 805:
                    //移動xy軸

                    if (myController.Commands.Motion.WaitForMotionDone(Aerotech.A3200.Commands.WaitOption.InPosition, 0, 2000) && myController.Commands.Motion.WaitForMotionDone(Aerotech.A3200.Commands.WaitOption.InPosition, 1, 2000) && myController.Commands.Motion.WaitForMotionDone(Aerotech.A3200.Commands.WaitOption.InPosition, 2, 2000))
                    {
                        if (Motion_X && Motion_Y && Motion_Z)
                        {

                            ABS_X = (Convert.ToDouble(str_X1) - Convert.ToDouble(point_position[24, 0])) + new_X((Smallbox_X[smallbox_i]), (Smallbox_Y[smallbox_i]));
                            ABS_Y = (Convert.ToDouble(str_Y1) - Convert.ToDouble(point_position[24, 1])) + new_Y((Smallbox_X[smallbox_i]), (Smallbox_Y[smallbox_i]));
                            //相機高度+量測
                            ABS_Z = Convert.ToDouble(point_position[22, 1]) - Thick_Array_SmallBox[smallbox_i];
                            Allow_X = Allow_Y = true;
                            Allow_Z = true;

                            //Aero_thMotionRun_Tick(Motion_Num.Motion_ABS);
                            if (Allow_X)
                            {
                                this.myController.Commands[this.taskIndex].Motion.MoveAbs(0, ABS_X, 40);
                                //Thread.Sleep(50);
                            }
                            if (Allow_Y)
                            {
                                this.myController.Commands[this.taskIndex].Motion.MoveAbs(1, ABS_Y, 40);
                                //Thread.Sleep(50);
                            }
                            if (Allow_Z)
                            {
                                this.myController.Commands[this.taskIndex].Motion.MoveAbs(2, ABS_Z, 20);
                                //Thread.Sleep(50);
                            }
                            image_flag = 806;
                        }
                    }
                    break;
                case 806:
                    //確認到位
                    if (myController.Commands.Motion.WaitForMotionDone(Aerotech.A3200.Commands.WaitOption.InPosition, 0, 2000) && myController.Commands.Motion.WaitForMotionDone(Aerotech.A3200.Commands.WaitOption.InPosition, 1, 2000) && myController.Commands.Motion.WaitForMotionDone(Aerotech.A3200.Commands.WaitOption.InPosition, 2, 2000))
                    {
                        if (Motion_X && Motion_Y && Motion_Z)
                        {

                            tcp1.ReadMsg = "";
                            tcp1.WriteLine("T1");
                            Thread.Sleep(100);
                            image_flag = 807;

                        }
                    }
                    else
                    {
                        Thread.Sleep(30);
                    }
                    break;
                case 807:
                    //DATA

                    s_im = tcp1.ReadMsg.Split(',', '\r');// 一定是單引
                    sub_im[0] = s_im[0];//T1
                    sub_im[1] = s_im[1];//X; /2000
                    sub_im[2] = s_im[2];//Y; /2000+負號
                    sub_im[3] = s_im[3];//SIMILER

                    if ((Convert.ToDouble(sub_im[3]) >= 70) && sub_im[0] == "T1")
                    {
                        X_CCD = Convert.ToDouble(sub_im[1]) / 2000;
                        Y_CCD = -Convert.ToDouble(sub_im[2]) / 2000;
                        image_reciver_flag = false;
                        //***需加上ng的情況***
                        if (X_CCD > 990 || Y_CCD > 990
                            )
                        {
                            CCD_error++;
                            if (CCD_error < 5)
                            {
                                image_flag = 806;
                            }
                            else
                            {
                                CCD_error = 0;
                                CCD_error_conti++;
                                image_error_count++;

                                //跳過
                                Smallbox_error_flag[smallbox_i] = -1;//紀錄異常值
                                Smallbox_error_num++;
                                image_flag = 810;

                            }
                        }
                        else
                        {
                            if (Math.Abs(X_CCD) < 0.0008 && Math.Abs(Y_CCD) < 0.0008)
                            {
                                //Thread.Sleep(100);
                                CCD_error_conti = 0;
                                image_error_count++;
                                Smallbox_error_flag[smallbox_i] = 1;
                                image_flag = 810;
                            }
                            else
                            {
                                CCD_retry++;
                                if (CCD_retry > 8)
                                {
                                    CCD_retry = 0;
                                    image_flag = 810;
                                }
                                else
                                {

                                    image_flag = 808;
                                }

                            }
                        }
                    }
                    else
                    {
                        Smallbox_error_num++;
                        CCD_error_conti++;
                        image_error_count++;
                        Smallbox_error_flag[smallbox_i] = -1;//紀錄異常值
                        image_flag = 810;

                    }

                    break;
                case 808:
                    // 移動xy軸

                    if (myController.Commands.Motion.WaitForMotionDone(Aerotech.A3200.Commands.WaitOption.InPosition, 0, 2000) && myController.Commands.Motion.WaitForMotionDone(Aerotech.A3200.Commands.WaitOption.InPosition, 1, 2000) && myController.Commands.Motion.WaitForMotionDone(Aerotech.A3200.Commands.WaitOption.InPosition, 2, 2000))
                    {
                        if (Motion_X && Motion_Y && Motion_Z)
                        {

                            Distance_X = X_CCD;
                            Distance_Y = Y_CCD;
                            double[] Speed = { 40, 40 };
                            double[] Distance = { Distance_X, Distance_Y };
                            //myController.Commands.Axes[0, 1].Motion.Rapid(Distance, Speed);
                            this.myController.Commands[this.taskIndex].Motion.MoveInc(0, Distance_X, 50);
                            this.myController.Commands[this.taskIndex].Motion.MoveInc(1, Distance_Y, 50);
                            image_flag = 809;
                        }
                    }

                    break;
                case 809:
                    if (myController.Commands.Motion.WaitForMotionDone(Aerotech.A3200.Commands.WaitOption.InPosition, 0, 2000) && myController.Commands.Motion.WaitForMotionDone(Aerotech.A3200.Commands.WaitOption.InPosition, 1, 2000) && myController.Commands.Motion.WaitForMotionDone(Aerotech.A3200.Commands.WaitOption.InPosition, 2, 2000))
                    {
                        if (Motion_X && Motion_Y && Motion_Z)
                        {
                            X_CCD = Y_CCD = 999;
                            //Thread.Sleep(300);
                            image_flag = 806;//回到影像檢測
                        }
                    }
                    break;
                case 810:
                    //儲存特徵點位置
                    if (myController.Commands.Motion.WaitForMotionDone(Aerotech.A3200.Commands.WaitOption.InPosition, 0, 2000) && myController.Commands.Motion.WaitForMotionDone(Aerotech.A3200.Commands.WaitOption.InPosition, 1, 2000) && myController.Commands.Motion.WaitForMotionDone(Aerotech.A3200.Commands.WaitOption.InPosition, 2, 2000))
                    {
                        if (Motion_X && Motion_Y && Motion_Z)
                        {
                            if (cb_8error.Checked == false)
                            {
                                if (CCD_error_conti > 8)
                                {
                                    image_flag = 10;
                                }
                                else
                                {
                                    CCD_retry = 0;

                                    {
                                        Smallbox_PosX[smallbox_i] = Convert.ToDouble(txt_Motion_Position_X.Text);
                                        Smallbox_PosY[smallbox_i] = Convert.ToDouble(txt_Motion_Position_Y.Text);
                                    }
                                    //[BM:優化紀錄資訊Log]
                                    // ====================== 存檔 - 小方框位置記錄 ======================
                                    WriteLog("Image", "_ImageSimplePos.ini", $"方框: {Smallbox_PosX[smallbox_i]} , {Smallbox_PosY[smallbox_i]} , {Smallbox_error_flag[smallbox_i]}");

                                    ////存檔
                                    //StreamWriter sw = new StreamWriter(Path.Combine(Environment.CurrentDirectory, "LCN_LOG", "Image") + CurrTime.ToString("yyyyMMddHHmm") + "_ImageSimplePos.ini", true);
                                    //sw.WriteLine("方框: " + Smallbox_PosX[smallbox_i] + "  ,  " + Smallbox_PosY[smallbox_i] + "  ,  " + Smallbox_error_flag[smallbox_i]);
                                    ////sw.Flush();
                                    //sw.Close();
                                    X_CCD = Y_CCD = 999;
                                    image_flag = 811;
                                }
                            }
                            else
                            {
                                CCD_retry = 0;

                                Smallbox_PosX[smallbox_i] = Convert.ToDouble(txt_Motion_Position_X.Text);
                                Smallbox_PosY[smallbox_i] = Convert.ToDouble(txt_Motion_Position_Y.Text);

                                //[BM:優化紀錄資訊Log]
                                WriteLog("Image", "_ImageSimplePos.ini", $"方框: {Smallbox_PosX[smallbox_i]} , {Smallbox_PosY[smallbox_i]} , {Smallbox_error_flag[smallbox_i]}");


                                ////存檔
                                //StreamWriter sw = new StreamWriter(Path.Combine(Environment.CurrentDirectory, "LCN_LOG", "Image") + CurrTime.ToString("yyyyMMddHHmm") + "_ImageSimplePos.ini", true);
                                //sw.WriteLine("方框: " + Smallbox_PosX[smallbox_i] + "  ,  " + Smallbox_PosY[smallbox_i] + "  ,  " + Smallbox_error_flag[smallbox_i]);
                                ////sw.Flush();
                                //sw.Close();
                                X_CCD = Y_CCD = 999;
                                image_flag = 811;
                            }
                        }
                    }
                    break;
                case 811:
                    //測試完畢?最後一個?回到case1

                    smallbox_i++;
                    if (smallbox_i >= small_TotalNumber_2CUT)
                    {
                        image_flag = 81;
                    }
                    else
                    {
                        image_flag = 805;
                    }
                    break;
                case 81:
                    //切割長度整理20210621
                    if (checkBox_Diff_Len.Checked == true)
                    {




                        image_flag = 91;
                    }
                    else
                    {
                        image_flag = 9;
                    }



                    break;
                case 9:
                    //建造特徵點陣列
                    point_position[23, 2] = tb_2Cut_TipPY.Text;
                    prog_status = "產生頭尾位置....";
                    for (int i = 0; i < Sym_TotalNumber / 2; i++)
                    {
                        double THETA = 0;
                        coe_A = (HeadPOS_Y_Regin[i * 2 + 1] - HeadPOS_Y_Regin[i * 2]) / (HeadPOS_X_Regin[i * 2 + 1] - HeadPOS_X_Regin[i * 2]);

                        //coe_B = HeadPOS_Y_Regin[i * 2] - (coe_A * HeadPOS_X_Regin[i * 2]);原本

                        coe_B = HeadPOS_Y_Regin[i * 2] - (coe_A * HeadPOS_X_Regin[i * 2]);

                        //deltaX = 0.4 * Math.Cos(Math.PI * theta / 180);
                        THETA = Math.Atan(coe_A);

                        deltaX = pin_pitch_2CUT * Math.Cos(THETA);

                        //單區裡面第一根與最後一根都在此處先計算好了 是準的沒有補正 都是準的
                        HeadPOS_X[i * ReginPinNum] = HeadPOS_X_Regin[i * 2];
                        HeadPOS_Y[i * ReginPinNum] = HeadPOS_Y_Regin[i * 2];

                        HeadPOS_X[i * ReginPinNum + ReginPinNum - 1] = HeadPOS_X_Regin[i * 2 + 1];
                        HeadPOS_Y[i * ReginPinNum + ReginPinNum - 1] = HeadPOS_Y_Regin[i * 2 + 1];

                        //尾巴
                        if (!RB_NS_ShortPitch.Checked && !RB_BR_ShortPitch.Checked)
                        {
                            TipPOS_X[i * ReginPinNum] = HeadPOS_X[i * ReginPinNum] + Convert.ToDouble(point_position[23, 2]) * (-1) * Math.Sin(THETA);
                            TipPOS_Y[i * ReginPinNum] = HeadPOS_Y[i * ReginPinNum] - Convert.ToDouble(point_position[23, 2]) * (-1) * Math.Cos(THETA);
                            TipPOS_X[i * ReginPinNum + ReginPinNum - 1] = HeadPOS_X[i * ReginPinNum + ReginPinNum - 1] + Convert.ToDouble(point_position[23, 2]) * (-1) * Math.Sin(THETA);
                            TipPOS_Y[i * ReginPinNum + ReginPinNum - 1] = HeadPOS_Y[i * ReginPinNum + ReginPinNum - 1] - Convert.ToDouble(point_position[23, 2]) * (-1) * Math.Cos(THETA);
                        }
                        else
                        {

                            //直接算出一區內尾部的第1個及最後一個的xy座標
                            TipPOS_X[i * ReginPinNum] = HeadPOS_X[i * ReginPinNum] + Convert.ToDouble(point_position[23, 2]) * (-1) * Math.Sin(THETA);
                            TipPOS_Y[i * ReginPinNum] = HeadPOS_Y[i * ReginPinNum] - Convert.ToDouble(point_position[23, 2]) * (-1) * Math.Cos(THETA);
                            TipPOS_X[i * ReginPinNum + ReginPinNum - 1] = HeadPOS_X[i * ReginPinNum + ReginPinNum - 1] + Convert.ToDouble(point_position[23, 2]) * (-1) * Math.Sin(THETA);
                            TipPOS_Y[i * ReginPinNum + ReginPinNum - 1] = HeadPOS_Y[i * ReginPinNum + ReginPinNum - 1] - Convert.ToDouble(point_position[23, 2]) * (-1) * Math.Cos(THETA);

                        }
                        //error
                        image_error_all[i * ReginPinNum] = image_error_flag[i * 2];
                        image_error_all[i * ReginPinNum + ReginPinNum - 1] = image_error_flag[i * 2 + 1];

                        //TipPOS_X[i * 8] = new_X_tip(HeadPOS_X[i * 8].ToString(), (HeadPOS_Y[i * 8] - Convert.ToDouble(point_position[23, 2])).ToString(), THETA);
                        //TipPOS_Y[i * 8] = new_Y_tip(HeadPOS_X[i * 8].ToString(), (HeadPOS_Y[i * 8] - Convert.ToDouble(point_position[23, 2])).ToString(), THETA);
                        //TipPOS_X[i * 8 + ReginPinNum - 1] = new_X_tip(HeadPOS_X[i * 8 + ReginPinNum - 1].ToString(), (HeadPOS_Y[i * 8 + ReginPinNum - 1] - Convert.ToDouble(point_position[23, 2])).ToString(), THETA);
                        //TipPOS_Y[i * 8 + ReginPinNum - 1] = new_Y_tip(HeadPOS_X[i * 8 + ReginPinNum - 1].ToString(), (HeadPOS_Y[i * 8 + ReginPinNum - 1] - Convert.ToDouble(point_position[23, 2])).ToString(), THETA);

                        //產生每根針特徵座標 //再用等兼具算法計算出每一根針座標
                        for (int j = 1; j < ReginPinNum - 1; j++)
                        {

                            // HeadPOS_X[i * ReginPinNum + j] = HeadPOS_X_Regin[i * 2] + deltaX * j; // 原本是這樣
                            //  HeadPOS_Y[i * ReginPinNum + j] = coe_A * HeadPOS_X[i * ReginPinNum + j] + coe_B;// 原本是這樣









                            HeadPOS_X[i * ReginPinNum + j] = HeadPOS_X_Regin[i * 2] - deltaX * j;
                            HeadPOS_Y[i * ReginPinNum + j] = coe_A * HeadPOS_X[i * ReginPinNum + j] + coe_B;

                            if (!RB_NS_ShortPitch.Checked && !RB_BR_ShortPitch.Checked)
                            {
                                TipPOS_X[i * ReginPinNum + j] = HeadPOS_X[i * ReginPinNum + j] + Convert.ToDouble(point_position[23, 2]) * (-1) * Math.Sin(THETA);
                                TipPOS_Y[i * ReginPinNum + j] = HeadPOS_Y[i * ReginPinNum + j] - Convert.ToDouble(point_position[23, 2]) * (-1) * Math.Cos(THETA);
                            }
                            else
                            {
                                TipPOS_X[i * ReginPinNum + j] = HeadPOS_X[i * ReginPinNum + j] + Convert.ToDouble(point_position[23, 2]) * (-1) * Math.Sin(THETA);

                                // double sss = Convert.ToDouble(point_position[23, 2]) * Math.Cos(THETA);

                                TipPOS_Y[i * ReginPinNum + j] = HeadPOS_Y[i * ReginPinNum + j] - Convert.ToDouble(point_position[23, 2]) * (-1) * Math.Cos(THETA);//原本
                                //TipPOS_Y[i * ReginPinNum + j] = HeadPOS_Y[i * ReginPinNum + j] + Convert.ToDouble(point_position[23, 2]) * (-1) * Math.Cos(THETA);

                            }
                            //TipPOS_X[i * 8 + j] = new_X_tip(HeadPOS_X[i * 8 + j].ToString(), (HeadPOS_Y[i * 8 + j] - Convert.ToDouble(point_position[23, 2])).ToString(), THETA);
                            //TipPOS_Y[i * 8 + j] = new_Y_tip(HeadPOS_X[i * 8 + j].ToString(), (HeadPOS_Y[i * 8 + j] - Convert.ToDouble(point_position[23, 2])).ToString(), THETA);

                        }
                        if (image_error_all[i * ReginPinNum] == -1 || image_error_all[i * ReginPinNum + ReginPinNum - 1] == -1)
                        {
                            for (int j = 1; j < ReginPinNum - 1; j++)
                            {
                                image_error_all[i * ReginPinNum + j] = -1;
                            }
                        }
                        else
                        {
                            for (int j = 1; j < ReginPinNum - 1; j++)
                            {
                                image_error_all[i * ReginPinNum + j] = 1;
                            }
                        }
                    }
                    //[BM:優化紀錄資訊Log]
                    // ====================== Image HeadPos & TipPos 存檔 ======================
                    for (int c = 0; c < pin_TotalNumber_2CUT * ReginPinNum / 2; c++)
                    {
                        WriteLog("Image", "_ImageHeadPos.ini", $"{HeadPOS_X[c]},{HeadPOS_Y[c]},{image_error_all[c]}");
                        WriteLog("Image", "_ImageTipPos.ini", $"{TipPOS_X[c]},{TipPOS_Y[c]}");
                    }
                    //存檔
                    //StreamWriter sH = new StreamWriter(Path.Combine(Environment.CurrentDirectory, "LCN_LOG", "Image") + CurrTime.ToString("yyyyMMddHHmm") + "_ImageHeadPos.ini", true);
                    //StreamWriter sT = new StreamWriter(Path.Combine(Environment.CurrentDirectory, "LCN_LOG", "Image") + CurrTime.ToString("yyyyMMddHHmm") + "_ImageTipPos.ini", true);
                    //for (int c = 0; c < pin_TotalNumber_2CUT * ReginPinNum / 2; c++)
                    //{
                    //    sH.WriteLine(HeadPOS_X[c] + "," + HeadPOS_Y[c] + "," + image_error_all[c]);
                    //    sT.WriteLine(TipPOS_X[c] + "," + TipPOS_Y[c]);
                    //}
                    //sT.Close();
                    //sH.Close();

                    image_flag = 10;


                    break;

                case 91:
                    //建造特徵點陣列
                    //point_position[23, 2] = tb_2Cut_TipPY.Text;
                    prog_status = "產生頭尾位置....";
                    for (int i = Range_minmun; i <= Range_maxmum; i++)
                    {
                        if (i == Range_minmun || i <= Len_Range_Max[0])
                        {
                            Len_Temp = Len_Set[0];
                        }
                        else if (i <= Len_Range_Max[1])
                        {
                            Len_Temp = Len_Set[1];
                        }
                        else if (i <= Len_Range_Max[2])
                        {
                            Len_Temp = Len_Set[2];
                        }
                        else if (i <= Len_Range_Max[3])
                        {
                            Len_Temp = Len_Set[3];
                        }
                        else if (i <= Len_Range_Max[4])
                        {
                            Len_Temp = Len_Set[4];
                        }
                        else if (i <= Len_Range_Max[5])
                        {
                            Len_Temp = Len_Set[5];
                        }
                        else if (i <= Len_Range_Max[6])
                        {
                            Len_Temp = Len_Set[6];
                        }
                        else if (i <= Len_Range_Max[7])
                        {
                            Len_Temp = Len_Set[7];
                        }
                        else if (i <= Len_Range_Max[8])
                        {
                            Len_Temp = Len_Set[8];
                        }

                        double THETA = 0;
                        coe_A = (HeadPOS_Y_Regin[i * 2 + 1] - HeadPOS_Y_Regin[i * 2]) / (HeadPOS_X_Regin[i * 2 + 1] - HeadPOS_X_Regin[i * 2]);
                        coe_B = HeadPOS_Y_Regin[i * 2] - (coe_A * HeadPOS_X_Regin[i * 2]);

                        //deltaX = 0.4 * Math.Cos(Math.PI * theta / 180);
                        THETA = Math.Atan(coe_A);

                        deltaX = pin_pitch_2CUT * Math.Cos(THETA);
                        HeadPOS_X[i * ReginPinNum] = HeadPOS_X_Regin[i * 2];
                        HeadPOS_Y[i * ReginPinNum] = HeadPOS_Y_Regin[i * 2];
                        HeadPOS_X[i * ReginPinNum + ReginPinNum - 1] = HeadPOS_X_Regin[i * 2 + 1];
                        HeadPOS_Y[i * ReginPinNum + ReginPinNum - 1] = HeadPOS_Y_Regin[i * 2 + 1];

                        //尾巴
                        TipPOS_X[i * ReginPinNum] = HeadPOS_X[i * ReginPinNum] + Len_Temp * Math.Sin(THETA);
                        TipPOS_Y[i * ReginPinNum] = HeadPOS_Y[i * ReginPinNum] - Len_Temp * Math.Cos(THETA);
                        TipPOS_X[i * ReginPinNum + ReginPinNum - 1] = HeadPOS_X[i * ReginPinNum + ReginPinNum - 1] + Len_Temp * Math.Sin(THETA);
                        TipPOS_Y[i * ReginPinNum + ReginPinNum - 1] = HeadPOS_Y[i * ReginPinNum + ReginPinNum - 1] - Len_Temp * Math.Cos(THETA);
                        //error
                        image_error_all[i * ReginPinNum] = image_error_flag[i * 2];
                        image_error_all[i * ReginPinNum + ReginPinNum - 1] = image_error_flag[i * 2 + 1];

                        //TipPOS_X[i * 8] = new_X_tip(HeadPOS_X[i * 8].ToString(), (HeadPOS_Y[i * 8] - Convert.ToDouble(point_position[23, 2])).ToString(), THETA);
                        //TipPOS_Y[i * 8] = new_Y_tip(HeadPOS_X[i * 8].ToString(), (HeadPOS_Y[i * 8] - Convert.ToDouble(point_position[23, 2])).ToString(), THETA);
                        //TipPOS_X[i * 8 + ReginPinNum - 1] = new_X_tip(HeadPOS_X[i * 8 + ReginPinNum - 1].ToString(), (HeadPOS_Y[i * 8 + ReginPinNum - 1] - Convert.ToDouble(point_position[23, 2])).ToString(), THETA);
                        //TipPOS_Y[i * 8 + ReginPinNum - 1] = new_Y_tip(HeadPOS_X[i * 8 + ReginPinNum - 1].ToString(), (HeadPOS_Y[i * 8 + ReginPinNum - 1] - Convert.ToDouble(point_position[23, 2])).ToString(), THETA);

                        //產生每根針特徵座標
                        for (int j = 1; j < ReginPinNum - 1; j++)
                        {
                            HeadPOS_X[i * ReginPinNum + j] = HeadPOS_X_Regin[i * 2] + deltaX * j;
                            HeadPOS_Y[i * ReginPinNum + j] = coe_A * HeadPOS_X[i * ReginPinNum + j] + coe_B;

                            TipPOS_X[i * ReginPinNum + j] = HeadPOS_X[i * ReginPinNum + j] + Len_Temp * Math.Sin(THETA);
                            TipPOS_Y[i * ReginPinNum + j] = HeadPOS_Y[i * ReginPinNum + j] - Len_Temp * Math.Cos(THETA);
                            //TipPOS_X[i * 8 + j] = new_X_tip(HeadPOS_X[i * 8 + j].ToString(), (HeadPOS_Y[i * 8 + j] - Convert.ToDouble(point_position[23, 2])).ToString(), THETA);
                            //TipPOS_Y[i * 8 + j] = new_Y_tip(HeadPOS_X[i * 8 + j].ToString(), (HeadPOS_Y[i * 8 + j] - Convert.ToDouble(point_position[23, 2])).ToString(), THETA);

                        }
                        if (image_error_all[i * ReginPinNum] == -1 || image_error_all[i * ReginPinNum + ReginPinNum - 1] == -1)
                        {
                            for (int j = 1; j < ReginPinNum - 1; j++)
                            {
                                image_error_all[i * ReginPinNum + j] = -1;
                            }
                        }
                        else
                        {
                            for (int j = 1; j < ReginPinNum - 1; j++)
                            {
                                image_error_all[i * ReginPinNum + j] = 1;
                            }
                        }
                    }

                    //////存檔
                    //StreamWriter sH = new StreamWriter(classSystem.path_thickness + CurrTime.ToString("yyyyMMddHHmm") + "_ImageHeadPos.ini", true);
                    //StreamWriter sT = new StreamWriter(classSystem.path_thickness + CurrTime.ToString("yyyyMMddHHmm") + "_ImageTipPos.ini", true);
                    //for (int c = Range_minmun * ReginPinNum; c < (Range_maxmum + 1) * ReginPinNum; c++)
                    //{
                    //	sH.WriteLine(HeadPOS_X[c] + "," + HeadPOS_Y[c] + "," + image_error_all[c]);
                    //	sT.WriteLine(TipPOS_X[c] + "," + TipPOS_Y[c]);
                    //}
                    //sT.Close();
                    //sH.Close();

                    image_flag = 10;


                    break;


                case 10:
                    //結束

                    if (myController.Commands.Motion.WaitForMotionDone(Aerotech.A3200.Commands.WaitOption.InPosition, 0, 2000) && myController.Commands.Motion.WaitForMotionDone(Aerotech.A3200.Commands.WaitOption.InPosition, 1, 2000))
                    {
                        if (cb_8error.Checked == false)
                        {
                            if (CCD_error_conti > 8)
                            {
                                prog_status = "影像特徵辨識連續失敗超過8次";
                                currentTime = DateTime.Now;


                                WriteLog("Log", "_Log.ini", $"特徵連續失敗超過8次");
                                //using (StreamWriter text = new StreamWriter(Path.Combine(C_Path, "LCN_LOG", "Log") + LogTime.ToString("yyyyMMdd") + "_Log.ini", true))
                                //{
                                //    text.WriteLine(currentTime.ToString("yyyyMMddHHmm") + "  ;  " + "特徵連續失敗超過8次 ");
                                //    //sw.Flush();
                                //    text.Close();
                                //}

                                //參數紀錄
                                record_update.End();

                                record_update.Save_Log();

                                record_update.Clear();

                                //MES上報
                                //MES_Waiting(chpt_mes.Description_Message[(int)MES_Description.ProcessEnd]);

                                //this.Invoke(new dGP_Relese(GP_relese));
                                Thread.Sleep(1500);
                                START_flag_2CUT = false;
                                CCD_error_conti = 0;
                                _isthread_image_test = false;

                                image_flag = 0;
                                //DO_1_ON();
                                //DO_2_OFF();



                            }
                            else
                            {
                                prog_status = "特徵辨識完成";
                                currentTime = DateTime.Now;

                                WriteLog("Thread", "_thread.ini", $"特徵完成");


                                //參數紀錄
                                record_update.End();

                                record_update.Save_Log();

                                record_update.Clear();

                                //MES上報
                                //MES_Waiting(chpt_mes.Description_Message[(int)MES_Description.ProcessEnd]);

                                Thread.Sleep(1500);

                                //this.Invoke(new dGP_Relese(GP_relese));
                                START_flag_2CUT = false;
                                CCD_error_conti = 0;
                                _isthread_image_test = false;

                                image_flag = 0;
                            }

                        }
                        else
                        {
                            prog_status = "特徵辨識完成";
                            currentTime = DateTime.Now;

                            WriteLog("Log", "_Log.ini", $"特徵辨識完成");

                            //using (StreamWriter text = new StreamWriter(Path.Combine(C_Path, "LCN_LOG", "Log") + LogTime.ToString("yyyyMMdd") + "_Log.ini", true))// using (StreamWriter text = new StreamWriter(classSystem.FilePath_Log + LogTime.ToString("yyyyMMdd") + "_Log.ini", true))
                            //{
                            //    text.WriteLine(currentTime.ToString("yyyyMMddHHmm") + "  ;  " + "特徵完成 ");
                            //    //sw.Flush();
                            //    text.Close();
                            //}

                            //參數紀錄
                            record_update.End();

                            record_update.Save_Log();

                            record_update.Clear();

                            //MES上報
                            //  MES_Waiting(chpt_mes.Description_Message[(int)MES_Description.ProcessEnd]);

                            //  Thread.Sleep(1500);

                            //this.Invoke(new dGP_Relese(GP_relese));
                            //if (checkBox_AutoStart2CUT.Checked)
                            //{
                            //    //自動開始2切

                            //    angle_register = Convert.ToDouble(lb_degree.Text);
                            //    StartTime = DateTime.Now;
                            //    LogTime = DateTime.Now;
                            //    START_flag_2CUT = true;
                            //    //DO_1_OFF();
                            //    //DO_2_ON();
                            //    groupBox_Axis.Enabled = false;
                            //    //參數紀錄
                            //    string mathine_name = tb_Machine_Name.Text;
                            //    string part_number = "";
                            //    string batch_number = tb_lot_number.Text;
                            //    string serial_number = tb_LaserDeskText.Text;
                            //    string product_name = "";
                            //    string pin_length = tb_needle_len.Text;
                            //    string total_pin = (pin_TotalNumber_2CUT * ReginPinNum / 2).ToString();
                            //    string laser_Process_file = tb_Path_SCAN.Text;
                            //    string laser_Pos_file = tb_Path_coordinates.Text;
                            //    string laser_power = tb_Laser_energy.Text;

                            //    record_update.Start(1, mathine_name, part_number, batch_number, serial_number, product_name, pin_length, total_pin, laser_Process_file, laser_Pos_file, laser_power);

                            //    record_update.Save_Buffer();

                            //    //MES上報
                            //    //MES_Production(chpt_mes.Description_Message[(int)MES_Description.Laser_Cutting]);

                            //    //Thread.Sleep(1500);

                            //    //Demo_Test_2CUT = new Thread(_DEMO_TEST_2CUT);
                            //    //Demo_Test_2CUT.Start();


                            //    //DEMO_flag_2CUT = 1;



                            //    //START_flag_2CUT = false;
                            //    CCD_error_conti = 0;
                            //    _isthread_image_test = false;

                            //    image_flag = 0;
                            //    //DO_1_ON();
                            //    //DO_2_OFF();

                            //}
                            //else
                            //{
                            Thread.Sleep(1500);
                            START_flag_2CUT = false;
                            CCD_error_conti = 0;
                            _isthread_image_test = false;

                            image_flag = 0;
                            //DO_1_ON();
                            //DO_2_OFF();

                            // }
                        }

                    }
                    break;
            }
        }

        /// <summary>
        /// 厚度量測流程的執行緒方法，持續呼叫 Thick_Test_Array_2CUT() 直到外部中止。
        /// </summary>
        private void _Thick_Test_Array_2CUT() // 厚度量測執行緒方法
        {
            try
            {
                while (_isThick_Test_2CUT) // 無限迴圈持續執行量測流程
                {
                    Thick_Test_Array_2CUT(); // 呼叫主流程方法，依照 Thick_flag_2CUT 狀態執行對應邏輯
                }
            }
            finally
            {
                Thick_flag_2CUT = 0;
                _isThick_Test_2CUT = false;
            }
        }
        /// <summary>
        /// 2CUT 模式下的 Z 陣列索引（若使用雙層補償）。
        /// </summary>
        int ArrayZ_i_2CUT = 0;
        /// <summary>
        /// 測高模組是否連接成功
        /// </summary>
        bool Confocal_Connect_flag = false;

        List<double> ax = new List<double>();//不用限定範圍可一直儲存不同筆資料，(像似動態陣列)，資料筆數會一直向上加上去，儲存x座標位置
        List<double> ay = new List<double>();//不用限定範圍可一直儲存不同筆資料，(像似動態陣列)，資料筆數會一直向上加上去，儲存x座標位置

        List<double> newax = new List<double>();//不用限定範圍可一直儲存不同筆資料，(像似動態陣列)，資料筆數會一直向上加上去，儲存x座標位置
        List<double> neway = new List<double>();//不用限定範圍可一直儲存不同筆資料，(像似動態陣列)，資料筆數會一直向上加上去，儲存x座標位置

        /// <summary>
        /// 執行 2CUT 模式下的厚度量測流程，依據 Thick_flag_2CUT 狀態進行座標移動、測高、資料記錄與補償陣列建立。
        /// 支援多種座標轉換模式（ShortPitch、Alignment）與錯誤處理。
        /// </summary>
        private void Thick_Test_Array_2CUT()//厚度量測流程
        {
            //tkn_i = 0;
            //int ArrayZ_i = 0;
            //tkn_TotalNumber;
            //int i = 0;
            //int j = 0;
            switch (Thick_flag_2CUT)// 狀態機控制流程進度
            {
                case 0: // 初始化階段

                    string target = "整版測高完成,可以繼續操作";
                    if (!string.Equals(prog_status?.Trim(), target, StringComparison.Ordinal))
                    {
                        prog_status = "整版測高異常結束(請重新在試一次)";
                        WriteLog("Thread", "_thread.ini",
                            $"整版測高流程異常結束");
                    }
                    else
                    {
                        WriteLog("Thread", "_thread.ini",
                            $"整版測高流程正常結束");
                    }

                    Thread.Sleep(100); // 暫停 100ms
                    ArrayZ_i_2CUT = 0; // 重設補償陣列索引
                    count_2CUT = 0; // 重設計數器
                    tkn_i_2CUT = 0; // 重設量測點索引
                    tkn_i_smallbox = 0; // 重設小方框索引
                    count_smallbox = 0; // 重設小方框計數器
                    Thick_flag_2CUT = 0;
                    _isThick_Test_2CUT = false;
                    break;

                case 1: // 啟動前檢查
                    if (En && Home && ProcessFileRead_flag_2CUT) // 確認 Servo、Home、檔案與儀器連線
                    {
                        Confocal_Connect_flag = _ConfocalLaser.GetState().Equals(SteadyState.Ready);
                        prog_status = "整版測高開始"; // 更新流程狀態
                        WriteLog("Thread", "_thread.ini", $"整版測高流程開始");

                        ArrayZ_i_2CUT = 0; // 重設補償索引
                        count_2CUT = 0; // 重設計數器
                        tkn_i_2CUT = 0; // 重設量測點索引
                        tkn_i_smallbox = 0; // 重設小方框索引
                        Thick_flag_2CUT = 2; // 進入下一階段
                        LogTime = DateTime.Now; // 記錄時間
                        START_flag = true; // 啟動主流程旗標
                    }
                    else // 條件不符，顯示錯誤
                    {
                        if (!En) { Thick_flag_2CUT = 0; MessageBox.Show("Please Check Servo ON !"); WriteLog("Thread", "_thread.ini", $"Please Check Servo ON !"); }
                        if (!Home) { Thick_flag_2CUT = 0; MessageBox.Show("Please Check Homed !"); WriteLog("Thread", "_thread.ini", $"Please Check Homed !"); }
                        if (!ProcessFileRead_flag_2CUT) { Thick_flag_2CUT = 0; MessageBox.Show("未載入加工檔案 !"); WriteLog("Thread", "_thread.ini", $"未載入檔案 !"); }
                        if (!Confocal_Connect_flag) { Thick_flag_2CUT = 0; MessageBox.Show("未連線高度量測儀 !"); WriteLog("Thread", "_thread.ini", $"測高未連線"); }
                    }
                    break;

                case 2: // 流程準備完成，進入移動階段
                    Thick_flag_2CUT = 3; // 進入座標移動
                    break;

                case 3:// 移動至量測點
                    if (myController.Commands.Motion.WaitForMotionDone(Aerotech.A3200.Commands.WaitOption.InPosition, 0, 2000) && myController.Commands.Motion.WaitForMotionDone(Aerotech.A3200.Commands.WaitOption.InPosition, 1, 2000) && myController.Commands.Motion.WaitForMotionDone(Aerotech.A3200.Commands.WaitOption.InPosition, 2, 2000))
                    {
                        if (Motion_X && Motion_Y && Motion_Z)// 三軸穩定
                        {
                            //左下到右上
                            //加上偏移到肋 str_X1(CCD)+"相對位置:CCD->測高"

                            //20210831 D.C
                            //公式:(str_X1(孔1實際位置) - (座標檔孔1位置)) - (CCD->測高相對位置) + (座標檔特徵點 + 測高補償)
                            //因座標檔內孔1不一定為(0,0)


                            /*
                             * 觀念為因配置檔是以雷射加工位置為中心 雷射->ccd 及 雷射->測高
                             * 雷射->ccd 的意思是雷射移動到ccd是多少距離 (距離=後項-前項) ;雷射->測高 意思一樣
                             * 因為孔1 的中心位置 是軸當下的絕對座標是用 ccd中心來看的 

                             * 所以要ccd->測高兩這之間的距離(後項-前項)=(雷射-測高)-(雷射-ccd)=ccd-測高=(Convert.ToDouble(point_position[20, 0]) - Convert.ToDouble(point_position[21, 0]))是獲得 相機 到 測高 的x相對位置
                             * 
                             * 總結測高位置(絕對座標位置)=孔1的絕對座標-相機與測高之間的偏移量-脹縮計算量


                             */


                            // 根據選取模式計算補償後座標
                            if (!RB_NS_ShortPitch.Checked && !RB_BR_ShortPitch.Checked && !RB_NS_Alignment.Checked && !RB_BR_Alignment.Checked)
                            {
                                ABS_X = (Convert.ToDouble(str_X1) - Convert.ToDouble(point_position[24, 0])) - (Convert.ToDouble(point_position[20, 0]) - Convert.ToDouble(point_position[21, 0])) + new_X((Convert.ToDouble(tkn_X_2CUT[tkn_i_2CUT]) + Convert.ToDouble(point_position[23, 0])).ToString(), tkn_Y_2CUT[tkn_i_2CUT]);
                                ABS_Y = (Convert.ToDouble(str_Y1) - Convert.ToDouble(point_position[24, 1])) - (Convert.ToDouble(point_position[20, 1]) - Convert.ToDouble(point_position[21, 1])) + new_Y((Convert.ToDouble(tkn_X_2CUT[tkn_i_2CUT]) + Convert.ToDouble(point_position[23, 0])).ToString(), tkn_Y_2CUT[tkn_i_2CUT]);
                            }
                            else if (RB_NS_ShortPitch.Checked)
                            {
                                ABS_X = (Convert.ToDouble(str_X1) - Convert.ToDouble(point_position[24, 0])) - (Convert.ToDouble(point_position[20, 0]) - Convert.ToDouble(point_position[21, 0])) + new_X((Convert.ToDouble(tkn_X_2CUT[tkn_i_2CUT])).ToString(), (Convert.ToDouble(tkn_Y_2CUT[tkn_i_2CUT]) + Convert.ToDouble(point_position[34, 0])).ToString());
                                ABS_Y = (Convert.ToDouble(str_Y1) - Convert.ToDouble(point_position[24, 1])) - (Convert.ToDouble(point_position[20, 1]) - Convert.ToDouble(point_position[21, 1])) + new_Y((Convert.ToDouble(tkn_X_2CUT[tkn_i_2CUT])).ToString(), (Convert.ToDouble(tkn_Y_2CUT[tkn_i_2CUT]) + Convert.ToDouble(point_position[34, 0])).ToString());
                            }
                            else if (RB_BR_ShortPitch.Checked)
                            {
                                ABS_X = (Convert.ToDouble(str_X1) - Convert.ToDouble(point_position[24, 0])) - (Convert.ToDouble(point_position[20, 0]) - Convert.ToDouble(point_position[21, 0])) + new_X((Convert.ToDouble(tkn_X_2CUT[tkn_i_2CUT])).ToString(), (Convert.ToDouble(tkn_Y_2CUT[tkn_i_2CUT]) + Convert.ToDouble(point_position[39, 0])).ToString());
                                ABS_Y = (Convert.ToDouble(str_Y1) - Convert.ToDouble(point_position[24, 1])) - (Convert.ToDouble(point_position[20, 1]) - Convert.ToDouble(point_position[21, 1])) + new_Y((Convert.ToDouble(tkn_X_2CUT[tkn_i_2CUT])).ToString(), (Convert.ToDouble(tkn_Y_2CUT[tkn_i_2CUT]) + Convert.ToDouble(point_position[39, 0])).ToString());
                            }
                            else if (RB_NS_Alignment.Checked)
                            {
                                ABS_X = (Convert.ToDouble(str_X1) - Convert.ToDouble(point_position[24, 0])) - (Convert.ToDouble(point_position[20, 0]) - Convert.ToDouble(point_position[21, 0])) + new_X((Convert.ToDouble(tkn_X_2CUT[tkn_i_2CUT])).ToString(), (Convert.ToDouble(tkn_Y_2CUT[tkn_i_2CUT]) + Convert.ToDouble(point_position[40, 0])).ToString());
                                ABS_Y = (Convert.ToDouble(str_Y1) - Convert.ToDouble(point_position[24, 1])) - (Convert.ToDouble(point_position[20, 1]) - Convert.ToDouble(point_position[21, 1])) + new_Y((Convert.ToDouble(tkn_X_2CUT[tkn_i_2CUT])).ToString(), (Convert.ToDouble(tkn_Y_2CUT[tkn_i_2CUT]) + Convert.ToDouble(point_position[40, 0])).ToString());
                            }
                            else if (RB_BR_Alignment.Checked)
                            {
                                ABS_X = (Convert.ToDouble(str_X1) - Convert.ToDouble(point_position[24, 0])) - (Convert.ToDouble(point_position[20, 0]) - Convert.ToDouble(point_position[21, 0])) + new_X((Convert.ToDouble(tkn_X_2CUT[tkn_i_2CUT])).ToString(), (Convert.ToDouble(tkn_Y_2CUT[tkn_i_2CUT]) + Convert.ToDouble(point_position[41, 0])).ToString());
                                ABS_Y = (Convert.ToDouble(str_Y1) - Convert.ToDouble(point_position[24, 1])) - (Convert.ToDouble(point_position[20, 1]) - Convert.ToDouble(point_position[21, 1])) + new_Y((Convert.ToDouble(tkn_X_2CUT[tkn_i_2CUT])).ToString(), (Convert.ToDouble(tkn_Y_2CUT[tkn_i_2CUT]) + Convert.ToDouble(point_position[41, 0])).ToString());
                            }
                            ABS_Z = Convert.ToDouble(point_position[22, 2]);// 設定 Z 軸高度
                            Allow_X = Allow_Y = true;
                            Allow_Z = true;
                            if (Allow_X)
                            {
                                this.myController.Commands[this.taskIndex].Motion.MoveAbs(0, ABS_X, fastspeed);
                            }
                            if (Allow_Y)
                            {
                                this.myController.Commands[this.taskIndex].Motion.MoveAbs(1, ABS_Y, fastspeed);
                            }
                            if (Allow_Z)
                            {
                                this.myController.Commands[this.taskIndex].Motion.MoveAbs(2, ABS_Z, fastspeed);
                            }
                            Thick_flag_2CUT = 4;// 進入定位確認
                        }
                    }
                    break;

                case 4: // 確認是否到位
                    if (myController.Commands.Motion.WaitForMotionDone(Aerotech.A3200.Commands.WaitOption.InPosition, 0, 2000) && myController.Commands.Motion.WaitForMotionDone(Aerotech.A3200.Commands.WaitOption.InPosition, 1, 2000) && myController.Commands.Motion.WaitForMotionDone(Aerotech.A3200.Commands.WaitOption.InPosition, 2, 2000))
                    {
                        if (Motion_X && Motion_Y && Motion_Z)//皆到達位置
                        {
                            Thick_flag_2CUT = 5; // 進入測高指令
                            str = ""; // 進入測高指令
                        }
                    }
                    else
                    {
                        Thread.Sleep(20);
                    }
                    break;

                case 5: // 發送測高指令
                    evalResult result = _ConfocalLaser.Trigger(1, out _ConfocalLaser_Output, 800);// waitMSec 建議設 500~1000，不要設 0
                    tk_value = _ConfocalLaser_Output;   // 把測量值存到你原本的變數
                    Thick_flag_2CUT = 6; // 進入回應等待
                    break;

                case 6: // 等待回應
                    if (_ConfocalLaser_Output != 0) { Thick_flag_2CUT = 7; } // 若有回應，進入解析
                    else { Thick_flag_2CUT = 6; } // 否則重試
                    break;

                case 7:  //取得量測數值
                    Thick_Array_2CUT[tkn_i_2CUT] = tk_value / 1000; // 取出厚度值

                    //Thick_Array_2CUT[tkn_i_2CUT] = Convert.ToDouble(str.Substring(3)); // 取出厚度值





                    if (Math.Abs(Thick_Array_2CUT[tkn_i_2CUT]) > 1000) { Thick_Array_2CUT[tkn_i_2CUT] = 0; } // 過濾異常值

                    //[BM:優化紀錄資訊Log]
                    // ====================== 建立資料夾與寫入記錄 ======================

                    WriteLog("2cut", "_2CUT.ini",
                             $"X_POS= {txt_Motion_Position_X.Text} ; " +
                                     $"Y_POS= {txt_Motion_Position_Y.Text} ; " +
                                     $"厚度= {Thick_Array_2CUT[tkn_i_2CUT]}");
                    //StreamWriter sw = new StreamWriter(Path.Combine(Environment.CurrentDirectory, "LCN_LOG", "2cut") + CurrTime.ToString("yyyyMMddHHmm") + "_2CUT.ini", true);// 建立資料記錄檔
                    //sw.WriteLine("X_POS= " + txt_Motion_Position_X.Text + "  ;  " + "Y_POS= " + txt_Motion_Position_Y.Text + " ; " + "厚度= " + Thick_Array_2CUT[tkn_i_2CUT].ToString());// 寫入座標與厚度
                    //sw.Close();// 關閉檔案



                    Thick_flag_2CUT = 8;// 進入下一筆判斷
                    break;

                case 8:// 判斷是否為最後一筆
                    //測試完畢?最後一個?回到case1
                    tkn_i_2CUT++; // 前進下一筆
                    if (tkn_i_2CUT >= tkn_TotalNumber_2CUT)// 若已完成全部
                        Thick_flag_2CUT = 9;//進入補償陣列建立
                    else
                        Thick_flag_2CUT = 2;// 否則回到移動階段
                    break;





                //case 9: // 建立補償陣列
                //        //[BM:優化紀錄資訊Log，整個case9]
                //        // ====================== 1. 先處理補償陣列 ======================
                //    for (int i = 0; i < tkn_TotalNumber_2CUT; i++)// 對每一筆厚度量測資料進行補償陣列建立
                //    {
                //        int j = i * 2;
                //        Thick_Array_sym[j] = Thick_Array_2CUT[i];
                //        Thick_Array_sym[j + 1] = Thick_Array_2CUT[i];
                //    }

                //    for (int i = 1; i < 10; i++)
                //    {
                //        Thick_Array_sym[40 * i - 1] = Thick_Array_2CUT[20 * i - 1];
                //    }

                //    // ====================== 2. 建立資料夾與寫檔 ======================


                //    WriteLog("2thick", "_2CUTtest.ini",
                //               $"No: {image_i}, ABS_X: {ABS_X}, POS_X: {simple_X[image_i]}, " +
                //               $"ABS_Y: {ABS_Y}, POS_Y: {simple_Y[image_i]}, " +
                //               $"ABS_Z: {ABS_Z}, POS_Z: {Thick_Array_sym[image_i]}");

                //    logFolder = Path.Combine(Environment.CurrentDirectory, "LCN_LOG", "2thick");
                //    Directory.CreateDirectory(logFolder);   // ← 重要：自動建立資料夾

                //     fileName = CurrTime.ToString("yyyyMMddHHmm") + "_2CUTtest.ini";
                //     fullPath = Path.Combine(logFolder, fileName);

                //    using (StreamWriter sb = new StreamWriter(fullPath, true))  // true = append
                //    {
                //        if (ArrayZ_i_2CUT < tkn_TotalNumber_2CUT * ReginPinNum)
                //        {
                //            string u = "0"; // 預設值

                //            process_compensateZ_2CUT[ArrayZ_i_2CUT] =
                //            Thick_Array_2CUT[(ArrayZ_i_2CUT) / ReginPinNum].ToString();

                //            u = "1";

                //            if (u == "1")
                //            {
                //                sb.WriteLine($"u= {u} ; ArrayZ_i= {ArrayZ_i_2CUT} ; value= {process_compensateZ_2CUT[ArrayZ_i_2CUT]}");
                //            }
                //        }
                //        else
                //        {
                //            if (!cb_smallbox_switch.Checked)
                //            {
                //                Thick_flag_2CUT = 10;
                //            }
                //            else
                //            {
                //                Thick_flag_2CUT = (small_TotalNumber_2CUT == 0) ? 10 : 900;//若small_TotalNumber_2CUT==0就去case10，否則到900
                //            }
                //        }
                //    } // ← 這裡會自動關閉 sb，不需要 sb.Close()

                //    ArrayZ_i_2CUT++;
                //    break;

                //原先的case9，上述case9是優化紀錄方法
                case 9:// 建立補償陣列
                    for (int i = 0; i < tkn_TotalNumber_2CUT; i++)// 對每一筆厚度量測資料進行補償陣列建立
                    {
                        //int j = i * 2 - 1;
                        int j = i * 2;// 每筆厚度值複製兩次，對應補償陣列的雙倍索引
                        if (j <= 0) // 防止 j 為負值（理論上 i=0 時 j=0）
                        {
                            j = 0; // 強制 j 為 0
                        }
                        Thick_Array_sym[j] = Thick_Array_2CUT[i]; // 將厚度值寫入補償陣列第 j 筆
                        Thick_Array_sym[j + 1] = Thick_Array_2CUT[i]; // 同一筆厚度值複製到 j+1 筆
                    }

                    for (int i = 1; i < 10; i++)// 每 20 筆補償一次，覆寫第 40*i - 1 筆資料
                    {
                        Thick_Array_sym[40 * i - 1] = Thick_Array_2CUT[20 * i - 1];// 強制補償特定位置的厚度值
                    }


                    //StreamWriter sb = new StreamWriter(Path.Combine(Environment.CurrentDirectory, "LCN_LOG", "2thick") + CurrTime.ToString("yyyyMMddHHmm") + "_2CUTtest.ini", true);// 建立補償記錄檔案


                    if (ArrayZ_i_2CUT < tkn_TotalNumber_2CUT * ReginPinNum)// 若補償索引尚未超過總筆數
                    {
                        string u; // 宣告補償標記變數
                        //if (process_Layer_2CUT[ArrayZ_i_2CUT] == TB_Head_2CUT.Text)// 備註：原本依圖層判斷是否補償（已註解）
                        {
                            process_compensateZ_2CUT[ArrayZ_i_2CUT] = Thick_Array_2CUT[(ArrayZ_i_2CUT) / ReginPinNum].ToString();// 將補償值寫入補償陣列
                            u = "1";// 標記為有效補償
                        }
                        //else
                        //{
                        //	count_2CUT++;
                        //	process_compensateZ_2CUT[ArrayZ_i_2CUT] = Thick_Array_2CUT[0].ToString();
                        //	u = "0";
                        //}

                        if (u == "1")// 若為有效補償
                        {
                            WriteLog("2thick", "_2CUTtest.ini", $"u={u};ArrayZ_i={ArrayZ_i_2CUT};value={process_compensateZ_2CUT[ArrayZ_i_2CUT]}");

                            //sb.WriteLine("u= " + u + " ; " + "ArrayZ_i= " + ArrayZ_i_2CUT.ToString() + "  ;  " + "value= " + process_compensateZ_2CUT[ArrayZ_i_2CUT]);// 寫入補償記錄
                            //sw.Flush();
                        }
                    }
                    else// 若補償索引已超過總筆數，進入流程分支判斷
                    {
                        if (!cb_smallbox_switch.Checked) // 若未啟用小方框量測
                        {
                            Thick_flag_2CUT = 10; // 直接進入結束階段
                        }
                        else
                        {
                            if (small_TotalNumber_2CUT == 0) // 若無小方框資料
                                Thick_flag_2CUT = 10; // 直接結束
                            else
                                Thick_flag_2CUT = 900; // 進入小方框量測流程
                        }
                    }
                    ArrayZ_i_2CUT++;// 補償索引前進一筆
                                    //  sb.Close();// 關閉補償記錄檔案
                    break;// 結束 case 9 流程

























                case 900:
                    if (myController.Commands.Motion.WaitForMotionDone(Aerotech.A3200.Commands.WaitOption.InPosition, 0, 2000) && myController.Commands.Motion.WaitForMotionDone(Aerotech.A3200.Commands.WaitOption.InPosition, 1, 2000) && myController.Commands.Motion.WaitForMotionDone(Aerotech.A3200.Commands.WaitOption.InPosition, 2, 2000))
                    {
                        if (Motion_X && Motion_Y && Motion_Z)// 三軸狀態穩定
                        {
                            //為確保測高數值準確 X-5 偏離切割點
                            //公式:(str_X1(孔1實際位置) - (座標檔孔1位置)) - (CCD->測高相對位置) + (座標檔特徵點 + 測高補償) - 0.2
                            //因座標檔內孔1不一定為(0,0)

                            ABS_X = (Convert.ToDouble(str_X1) - Convert.ToDouble(point_position[24, 0])) - (Convert.ToDouble(point_position[20, 0]) - Convert.ToDouble(point_position[21, 0])) + new_X((Convert.ToDouble(Smallbox_X[tkn_i_smallbox]) + Convert.ToDouble(point_position[23, 0])).ToString(), Smallbox_Y[tkn_i_smallbox]) - 0.2;// 計算補償後 X 座標（含偏移）
                            ABS_Y = (Convert.ToDouble(str_Y1) - Convert.ToDouble(point_position[24, 1])) - (Convert.ToDouble(point_position[20, 1]) - Convert.ToDouble(point_position[21, 1])) + new_Y((Convert.ToDouble(Smallbox_X[tkn_i_smallbox]) + Convert.ToDouble(point_position[23, 0])).ToString(), Smallbox_Y[tkn_i_smallbox]);// 計算補償後 Y 座標
                            ABS_Z = Convert.ToDouble(point_position[22, 2]);// 設定 Z 軸高度
                            Allow_X = Allow_Y = true;
                            Allow_Z = true;

                            if (Allow_X)
                            {
                                this.myController.Commands[this.taskIndex].Motion.MoveAbs(0, ABS_X, fastspeed);
                            }
                            if (Allow_Y)
                            {
                                this.myController.Commands[this.taskIndex].Motion.MoveAbs(1, ABS_Y, fastspeed);
                            }
                            if (Allow_Z)
                            {
                                this.myController.Commands[this.taskIndex].Motion.MoveAbs(2, ABS_Z, fastspeed);
                            }
                            Thick_flag_2CUT = 901;
                        }
                    }
                    break;
                case 901:
                    //確認到位
                    if (myController.Commands.Motion.WaitForMotionDone(Aerotech.A3200.Commands.WaitOption.InPosition, 0, 2000) && myController.Commands.Motion.WaitForMotionDone(Aerotech.A3200.Commands.WaitOption.InPosition, 1, 2000) && myController.Commands.Motion.WaitForMotionDone(Aerotech.A3200.Commands.WaitOption.InPosition, 2, 2000))
                    {
                        if (Motion_X && Motion_Y && Motion_Z)
                        {
                            Thick_flag_2CUT = 902;
                            str = "";
                        }
                    }
                    break;
                case 902:

                    // 使用新的 Trigger 方法
                    result = _ConfocalLaser.Trigger(1, out _ConfocalLaser_Output, 800);
                    // waitMSec 建議設 500~1000，不要設 0

                    tk_value = _ConfocalLaser_Output;   // 把測量值存到你原本的變數



                    //_TCP.Send("MS,0,1" + "\r");
                    //Thread.Sleep(100);
                    Thick_flag_2CUT = 903;
                    break;
                case 903:
                    if (_ConfocalLaser_Output != 0)
                    {
                        Thick_flag_2CUT = 904;
                    }
                    else
                    {
                        Thick_flag_2CUT = 903;
                    }
                    break;
                case 904:
                    //取得量測值
                    Thick_Array_SmallBox[tkn_i_smallbox] = Convert.ToDouble(str.Substring(3));
                    if (Math.Abs(Thick_Array_SmallBox[tkn_i_smallbox]) > 3)
                    {
                        Thick_Array_SmallBox[tkn_i_smallbox] = 0;
                    }

                    //[BM:優化紀錄資訊Log]
                    // ====================== 小方框資料記錄 ======================
                    WriteLog("2cut", "_2CUT.ini", $"方框辨識 X_POS= {txt_Motion_Position_X.Text} ; " + $"Y_POS= {txt_Motion_Position_Y.Text} ; " + $"厚度= {Thick_Array_SmallBox[tkn_i_smallbox]}");
                    //sw = new StreamWriter(Path.Combine(Environment.CurrentDirectory, "LCN_LOG", "2cut") + CurrTime.ToString("yyyyMMddHHmm") + "_2CUT.ini", true);
                    //sw.WriteLine("方框辨識 X_POS= " + txt_Motion_Position_X.Text + "  ;  " + "Y_POS= " + txt_Motion_Position_Y.Text + " ; " + "厚度= " + Thick_Array_SmallBox[tkn_i_smallbox].ToString());
                    ////sw.Flush();
                    //sw.Close();

                    Thick_flag_2CUT = 905;
                    break;
                case 905:
                    tkn_i_smallbox++;
                    if (tkn_i_smallbox >= small_TotalNumber_2CUT)
                    {
                        Thick_flag_2CUT = 10;
                    }
                    else
                    {
                        Thick_flag_2CUT = 900;
                    }
                    break;
                case 10:
                    //結束
                    //max_2CUT = -1;

                    //min_2CUT = 1;
                    if (myController.Commands.Motion.WaitForMotionDone(Aerotech.A3200.Commands.WaitOption.InPosition, 0, 2000) && myController.Commands.Motion.WaitForMotionDone(Aerotech.A3200.Commands.WaitOption.InPosition, 1, 2000))
                    {
                        prog_status = "整板測高完成";
                        START_flag = false;
                        this.Invoke(new dGP_Relese(GP_relese));


                        WriteLog("Thread", "_thread.ini", $"2切厚度量完");

                        //參數紀錄
                        record_update.End();

                        record_update.Save_Log();

                        record_update.Clear();

                        //MES上報
                        //  MES_Waiting(chpt_mes.Description_Message[(int)MES_Description.ProcessEnd]);
                        max_2CUT = Thick_Array_2CUT.Max();

                        min_2CUT = Thick_Array_2CUT.Min();



                        //for (int i = 0; i < tkn_TotalNumber_2CUT - 1; i++)
                        //{


                        //    if (Thick_Array_2CUT[i] > max_2CUT)
                        //    {
                        //        max_2CUT = Thick_Array_2CUT[i];
                        //    }
                        //}
                        //for (int i = 0; i < tkn_TotalNumber_2CUT - 1; i++)
                        //{

                        //    if (Thick_Array_2CUT[i] < min_2CUT)
                        //    {
                        //        min_2CUT = Thick_Array_2CUT[i];
                        //    }
                        //}
                        Thread.Sleep(500);
                        START_flag_2CUT = false;
                        thick_variate_flag_2CUT = true;
                        Thick_flag_2CUT = 0;
                        _isThick_Test_2CUT = false;
                        //DO_1_ON();
                        //DO_2_OFF();

                        //[BM:掃碼載檔-2切連動檔自動載檔判斷]
                        //================2切連動檔 掃碼載檔 要在測厚之後
                        //if (Auto_Load == true)
                        //{
                        //    string CheckFilePath;

                        //    CheckFilePath = $"{ mes_filePath_form.MesData["二切連動檔"]}-{mes_filePath_form.MesData["板號"]}.txt"; //檢查連動檔的路徑
                        //    if (!string.IsNullOrEmpty(CheckFilePath) && File.Exists(CheckFilePath))
                        //    {
                        //        B_PRRLCN_Auto_Load($"{mes_filePath_form.MesData["二切連動檔"]}-{mes_filePath_form.MesData["板號"]}.txt");
                        //    }

                        //    else
                        //    {
                        //        MessageBox.Show("二切連動檔 檔案不存在或未選取路徑");

                        //        using (sw = new StreamWriter(Path.Combine(Application.StartupPath, "Log", currentTime.ToString("yyyyMMdd") + "_ErrorLog.ini"), true))// 寫入 LOG，檔案路徑在 ...\LaserProcess\bin\Debug\Log\當天日期
                        //        {
                        //            sw.WriteLine(currentTime.ToString("yyyyMMddHHmm") + "  ;  " + "錯誤訊息=" + $"讀取二切連動檔案失敗，檔案不存在或未選取");
                        //        }
                        //        TB_LoadFilePath_2CUT.Text = "";//清除2切路座標路徑
                        //    }
                        //}
                        //================2切連動檔 掃碼載檔 要在測厚之後

                        //if (Thick_Test_2CUT != null)
                        //{
                        //    Thick_Test_2CUT.Abort();//結束厚度量測流程
                        //}
                    }
                    break;
            }
        }

        /// <summary>
        /// 打圖形粗對位-迴圈
        /// </summary>
        private void Auto_FindHole_W()
        {
            try
            {
                while (_isAuto_FindHole)
                {
                    Auto_FindHole();
                }
            }
            finally
            {
                FindHole_flag = 0;
                _isAuto_FindHole = false;
            }
        }

        private void Auto_FindHole()
        {
            switch (FindHole_flag)
            {
                case 0:

                    string target = "定位孔至中開始完成,可以繼續操作";
                    if (!string.Equals(prog_status?.Trim(), target, StringComparison.Ordinal))
                    {
                        prog_status = "定位孔至中異常結束(請重新在試一次)";
                        WriteLog("Thread", "_thread.ini",
                            $"定位孔至中開始流程異常結束");
                    }
                    else
                    {
                        WriteLog("Thread", "_thread.ini",
                            $"定位孔至中開始流程正常結束");
                    }
                    FindHole_flag = 0;
                    _isAuto_FindHole = false;
                    break;

                case 1:
                    if (axCVX1.Created)
                    {
                        try
                        {
                            prog_status = "定位孔至中開始";
                            WriteLog("Thread", "_thread.ini", $"定位孔至中開始流程開始");

                            string response = _CameraCVX.ExternalRead(150);   // 發送並接收回傳值
                            _lastEXRResponse = response;        // ← 記錄下來給 case 2 使用
                            Thread.Sleep(100);
                            FindHole_flag = 2;
                        }
                        catch (Exception ex)
                        {
                            MessageBox.Show($"讀取當前KEYENCE檢測方式錯誤: {ex.Message}", "CV-X 錯誤",
                                           MessageBoxButtons.OK, MessageBoxIcon.Error);
                            WriteLog("Thread", "_thread.ini", $"讀取當前KEYENCE檢測方式錯誤 {ex.Message}，CV-X 錯誤");

                            FindHole_flag = 0;   // 錯誤時的旗標
                        }
                    }
                    else
                    {
                        MessageBox.Show("視覺系統未連線");
                        WriteLog("Thread", "_thread.ini", $"視覺系統未連線");
                        FindHole_flag = 0;
                    }
                    break;

                case 2:
                    try
                    {
                        if (_lastEXRResponse == "EXR,2" || _lastEXRResponse.Contains("EXR,2"))//檢察當前檢測條件是不是定為孔置中
                        {
                            FindHole_flag = 3;
                        }
                        else
                        {
                            _CameraCVX.ExternalWrite(2, 150);    // 若不是則進行切換切 Scene 
                            FindHole_flag = 1;
                        }
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show($"KEYENCE檢測方式切換失敗: {ex.Message}", "CV-X 錯誤",
                                       MessageBoxButtons.OK, MessageBoxIcon.Error);
                        WriteLog("Thread", "_thread.ini", $"KEYENCE檢測方式切換失敗 {ex.Message}，CV-X 錯誤");
                        FindHole_flag = 0;
                    }
                    break;

                case 3:
                    try
                    {
                        string response = _CameraCVX.Trigger1(500);   // 2000若timeout太短會收不到第二行資訊
                        _lastTriggerResponse = response;  // 記錄最後一次的回應，給 case 4 使用
                        FindHole_flag = 4;
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show($"讀取當前KEYENCE檢測內容錯誤: {ex.Message}", "CV-X 錯誤",
                                       MessageBoxButtons.OK, MessageBoxIcon.Error);
                        WriteLog("Thread", "_thread.ini", $"讀取當前KEYENCE檢測內容錯誤 {ex.Message}，CV-X 錯誤");
                        FindHole_flag = 0;
                    }
                    break;

                case 4:
                    string[] s_im = _lastTriggerResponse.Split(',', '\r');// 一定是單引
                    sub_im[0] = s_im[0];
                    sub_im[1] = s_im[1];
                    sub_im[2] = s_im[2];
                    sub_im[3] = s_im[3];
                    if ((Convert.ToDouble(sub_im[3]) >= 50) && sub_im[0] == "T1")
                    {
                        hole_comp_X = sub_im[1];
                        hole_comp_Y = sub_im[2];
                        FindHole_flag = 5;
                    }
                    else
                    {
                        MessageBox.Show("辨識失敗相似度不符", "CV-X 警告", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                        WriteLog("Thread", "_thread.ini", $"讀取當前KEYENCE檢測內容相似度低於門檻50 {sub_im[3]}，CV-X 錯誤");
                        FindHole_flag = 0;
                        _isAuto_FindHole = false;
                    }
                    break;

                case 5://補償 //移動xy軸
                    if (myController.Commands.Motion.WaitForMotionDone(Aerotech.A3200.Commands.WaitOption.InPosition, 0, 2000) && myController.Commands.Motion.WaitForMotionDone(Aerotech.A3200.Commands.WaitOption.InPosition, 1, 2000) && myController.Commands.Motion.WaitForMotionDone(Aerotech.A3200.Commands.WaitOption.InPosition, 2, 2000))
                    {
                        if (Motion_X && Motion_Y && Motion_Z)
                        {
                            Distance_X = Convert.ToDouble(hole_comp_X) / 970;
                            Distance_Y = -Convert.ToDouble(hole_comp_Y) / 970;
                            double[] Speed = { 30, 30 };
                            double[] Distance = { Distance_X, Distance_Y };
                            this.myController.Commands[this.taskIndex].Motion.MoveInc(0, Distance_X, fastspeed);
                            this.myController.Commands[this.taskIndex].Motion.MoveInc(1, Distance_Y, fastspeed);
                            FindHole_flag = 6;
                        }
                    }
                    break;

                case 6:
                    if (myController.Commands.Motion.WaitForMotionDone(Aerotech.A3200.Commands.WaitOption.InPosition, 0, 2000) && myController.Commands.Motion.WaitForMotionDone(Aerotech.A3200.Commands.WaitOption.InPosition, 1, 2000) && myController.Commands.Motion.WaitForMotionDone(Aerotech.A3200.Commands.WaitOption.InPosition, 2, 2000))
                    {
                        if (Motion_X && Motion_Y && Motion_Z)
                        {
                            Thread.Sleep(100);
                            FindHole_flag = 100;
                        }
                    }
                    break;

                case 7:
                    break;
                case 8:
                    break;
                case 9:
                    break;
                case 10:
                    break;
                case 11:
                    break;

                case 100:
                    prog_status = "定位孔至中開始完成,可以繼續操作";
                    FindHole_flag = 0;
                    _isAuto_FindHole = false;
                    break;
            }
            //coreRA1.Macro_DirectExecute("Measure");
            //StringBuilder sb = new StringBuilder();
            //int maxlength = 10;
            //int ret;

            //string UnitNo = numericUpDown2.Value.ToString();
            //coreRA1.Macro_DirectExecute("GetUnitData " + UnitNo + ", " + dataNo0.Text + ", X#");
            //sb.Clear();
            //ret = coreRA1.Macro_GetVariable("X#", sb, maxlength);
            ////MessageBox.Show("X : " + sb.ToString());
            //label257.Text = sb.ToString();
            //coreRA1.Macro_DirectExecute("GetUnitData " + UnitNo + "," + dataNo1.Text + ", Y#");
            //sb.Clear();
            //ret = coreRA1.Macro_GetVariable("Y#", sb, maxlength);
        }

        /// <summary>
        /// 打圖形粗對位-迴圈
        /// </summary>
        private void AutoDwring()
        {
            try
            {
                while (_isAutoDwring)
                {
                    Auto_Dwring();
                }
            }
            finally
            {
                _AutoDwring_flag = 0;
                _isAutoDwring = false;
            }
        }
        System.DateTime PicTime;
        string LCC_X = "0", LCC_Y = "0", LCC_X_reg = "0", LCC_Y_reg = "0";
        private string _lastEXRResponse = "";
        private string _lastTriggerResponse = "";
        /// <summary>
        /// 打圖形粗對位-動作流程
        /// </summary>
        private void Auto_Dwring()
        {
            switch (_AutoDwring_flag)
            {
                case 0:
                    string target = "圖形校正完成,可以繼續操作";
                    if (!string.Equals(prog_status?.Trim(), target, StringComparison.Ordinal))
                    {
                        prog_status = "打圖型異常結束(請重新在試一次)";
                        WriteLog("Thread", "_thread.ini",
                            $"打圖型流程異常結束");
                    }
                    else
                    {
                        WriteLog("Thread", "_thread.ini",
                            $"打圖型流程正常結束");
                    }
                    _AutoDwring_flag = 0;
                    _isAutoDwring = false;
                    break;

                case 1:
                    if (axCVX1.Connected)
                    {
                        if (_isDoorLock)
                        {
                            prog_status = "打圖型開始";
                            currentTime = DateTime.Now;
                            //[BM:優化紀錄資訊Log]
                            WriteLog("LOG", "_Log.ini", $"打圖型流程開始");
                            WriteLog("Thread", "_thread.ini", $"打圖型流程開始");
                            //using (StreamWriter text = new StreamWriter(Path.Combine(Environment.CurrentDirectory, "LCN_LOG", "Log") + LogTime.ToString("yyyyMMdd") + "_Log.ini", true))// using (StreamWriter text = new StreamWriter(classSystem.FilePath_Log + LogTime.ToString("yyyyMMdd") + "_Log.ini", true))
                            //{
                            //    text.WriteLine(currentTime.ToString("yyyyMMddHHmm") + "  ;  " + "圖形校正 ");
                            //    //sw.Flush();
                            //    text.Close();
                            //}
                            try
                            {
                                string response = _CameraCVX.ExternalRead(150);   // 發送並接收回傳值
                                _lastEXRResponse = response;        // ← 記錄下來給 case 2 使用
                                Thread.Sleep(100);
                                _AutoDwring_flag = 2;
                            }
                            catch (Exception ex)
                            {
                                MessageBox.Show($"讀取當前KEYENCE檢測方式錯誤: {ex.Message}", "CV-X 錯誤",
                                               MessageBoxButtons.OK, MessageBoxIcon.Error);
                                WriteLog("Thread", "_thread.ini", $"讀取當前KEYENCE檢測方式錯誤 {ex.Message}，CV-X 錯誤");
                                _AutoDwring_flag = 0;   // 錯誤時的旗標
                            }
                        }
                        else
                        {
                            MessageBox.Show("門未上鎖");
                            WriteLog("Thread", "_thread.ini", $"門未上鎖");
                            _AutoDwring_flag = 0;
                        }
                    }
                    else
                    {
                        MessageBox.Show("視覺系統未連線");
                        WriteLog("Thread", "_thread.ini", $"視覺系統未連線");
                        _AutoDwring_flag = 0;
                    }
                    break;

                case 2:
                    LCC_X = "0";
                    LCC_Y = "0";
                    LCC_X_reg = "0";
                    LCC_Y_reg = "0";
                    try
                    {
                        // 檢查上次 EXR 的回應是否為 Scene 1（已校正完成）
                        if (_lastEXRResponse == "EXR,1" || _lastEXRResponse.Contains("EXR,1"))
                        {
                            _AutoDwring_flag = 200;
                        }
                        else
                        {
                            // 切換到 Scene 1
                            _CameraCVX.ExternalWrite(1, 150);   // 你習慣的寫法
                            _AutoDwring_flag = 1;
                        }
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show($"KEYENCE檢測方式切換失敗: {ex.Message}", "CV-X 錯誤",
                                       MessageBoxButtons.OK, MessageBoxIcon.Error);
                        WriteLog("Thread", "_thread.ini", $"KEYENCE檢測方式切換失敗 {ex.Message}，CV-X 錯誤");
                        _AutoDwring_flag = 0;
                    }
                    break;

                case 200:
                    prog_status = "功率調整中";
                    if (SetLaserPowerPercentage(0))//更改功率值  // Set Laser Output Power(因為可能會卡住所以先直接降到0才拉升)
                    {
                        if (SetLaserPowerPercentage(10))
                        {
                            _AutoDwring_flag = 299;
                        }
                        else
                        {
                            MessageBox.Show($"雷射功率輸出設定失敗");
                            WriteLog("Thread", "_thread.ini", $"雷射功率輸出設定失敗");
                            _AutoDwring_flag = 0;
                        }
                    }
                    else
                    {
                        MessageBox.Show($"雷射功率輸出設定失敗");
                        WriteLog("Thread", "_thread.ini", $"雷射功率輸出設定失敗");
                        _AutoDwring_flag = 0;
                    }
                    break;


                case 299: //振鏡連接
                    _AutoDwring_flag = 300;
                    break;

                case 300: //ccd->laser &&  雷射高度
                    if (myController.Commands.Motion.WaitForMotionDone(Aerotech.A3200.Commands.WaitOption.InPosition, 0, 2000) && myController.Commands.Motion.WaitForMotionDone(Aerotech.A3200.Commands.WaitOption.InPosition, 1, 2000) && myController.Commands.Motion.WaitForMotionDone(Aerotech.A3200.Commands.WaitOption.InPosition, 2, 2000))
                    {
                        if (Motion_X && Motion_Y && Motion_Z)
                        {
                            Distance_X = -Convert.ToDouble(point_position[20, 0]);
                            Distance_Y = -Convert.ToDouble(point_position[20, 1]);
                            Distance_Z = Convert.ToDouble(point_position[22, 0]) - Convert.ToDouble(point_position[22, 1]);
                            double xuan = Convert.ToDouble(point_position[22, 1]) + Distance_Z;
                            if (xuan > zlimit)
                            {
                                double[] Speed = { 50, 50, 15 };
                                double[] Distance = { Distance_X, Distance_Y, Distance_Z };
                                this.myController.Commands[this.taskIndex].Motion.MoveInc(0, Distance_X, 50);
                                this.myController.Commands[this.taskIndex].Motion.MoveInc(1, Distance_Y, 50);
                                this.myController.Commands[this.taskIndex].Motion.MoveInc(2, Distance_Z, double.Parse("15"));
                                _AutoDwring_flag = 301;
                            }
                            else
                            {
                                MessageBox.Show($"z軸高度計算後超出安全高度({zlimit}): {xuan}", "z軸高度軟體限制",
                                                MessageBoxButtons.OK, MessageBoxIcon.Error);
                                WriteLog("Thread", "_thread.ini", $"z軸高度計算後超出安全高度({ zlimit}): { xuan}");
                                _AutoDwring_flag = 0;
                            }
                        }
                    }
                    break;

                case 301://載入刀具
                    prog_status = "載入加工刀具";
                    #region 載入加工刀具
                    try
                    {
                        bool FileJobxCheck = false;
                        bool JobxNamesCheck = false;
                        string filePath = "";
                        string[] filxes;
                        string JobxName = "show";

                        _isLaserScannerBusy = true;

                        //清除振鏡上刀具
                        _LaserScanner.ClearJobs();

                        filePath = Path.Combine(C_Path, "LCNjob", "Alignment_Jobx", JobxName + ".jobx");
                        filxes = Directory.GetFiles(Path.Combine(C_Path, "LCNjob", "Alignment_Jobx"), "*.jobx");

                        //確認指定路徑是否有此專案刀具
                        foreach (var file in filxes)
                        {
                            if (file == filePath)
                            {
                                FileJobxCheck = true;
                                break;
                            }
                        }
                        if (FileJobxCheck == false)
                        {
                            _AutoDwring_flag = 0;
                            writeError("載入刀具錯誤", "找尋不到刀具名稱！！刀具名稱： " + JobxName);
                            throw new Exception("載入刀具錯誤");
                        }

                        //載入刀具
                        _LaserScanner.LoadJobFromFile(filePath);
                        Thread.Sleep(100);

                        //讀取振鏡上Jobx刀具名稱，與專案刀具進行檢查
                        if (_ConfigProcess._IsAutoProcessCheckJobx)
                        {
                            //讀取振鏡上所有刀具
                            List<string> JobxNames = new List<string>();
                            _LaserScanner.GetJobNames(out JobxNames);

                            //檢查振鏡上刀具是否跟專案刀具一樣                             
                            foreach (var _jobnames in JobxNames)
                            {
                                string jobSubnames = _jobnames.Substring(8);
                                if (jobSubnames == JobxName)
                                {
                                    JobxNamesCheck = true;
                                    break;
                                }
                            }

                            if (JobxNamesCheck == false)
                            {
                                _AutoDwring_flag = 0;
                                writeError("振鏡刀具錯誤", "振鏡上刀具與專案刀具不符！！刀具名稱： " + JobxName);
                                throw new Exception("振鏡刀具錯誤");
                            }
                        }

                        //_LaserScanner.SelectJobByName(JobxName);
                        _isLaserScannerBusy = false;
                    }
                    catch (Exception)
                    {
                        _AutoDwring_flag = 0;
                        MessageBox.Show("載入刀具錯誤，請確認是否有這項刀具。", "Error！！");
                        return;

                    }
                    #endregion
                    //enableProcessGas(true);
                    _AutoDwring_flag = 302;
                    break;

                case 302:
                    if (myController.Commands.Motion.WaitForMotionDone(Aerotech.A3200.Commands.WaitOption.InPosition, 0, 2000) && myController.Commands.Motion.WaitForMotionDone(Aerotech.A3200.Commands.WaitOption.InPosition, 1, 2000) && myController.Commands.Motion.WaitForMotionDone(Aerotech.A3200.Commands.WaitOption.InPosition, 2, 2000))
                    {
                        if (Motion_X && Motion_Y && Motion_Z)
                        {
                            if (!_isLaserScannerBusy)
                            {
                                prog_status = "開始出光";

                                if (!DoLaserProcessing()) // 執行一次並取得回傳結果是true 或是false
                                {
                                    DoLaserReconnect();//重新連線
                                }
                            }

                            if (!_isLaserScannerBusy && _FormLaserScanner.States.PLC_JOB_COMPLETED)//加工完成且雷射狀態為true
                            {
                                prog_status = "結束出光";
                                _AutoDwring_flag = 303;
                            }
                        }
                    }
                    break;

                case 303://delay
                    if (Counter > 50)
                    {
                        Counter = 0;
                        //enableProcessGas(false);
                        _AutoDwring_flag = 304;
                    }
                    else
                    {
                        Counter++;
                        Thread.Sleep(10);
                        _AutoDwring_flag = 303;
                    }
                    break;

                case 304:
                    _AutoDwring_flag = 305;
                    break;

                case 305:
                    _AutoDwring_flag = 306;
                    break;

                case 306://laser -> ccd &&  ccd高度
                    if (myController.Commands.Motion.WaitForMotionDone(Aerotech.A3200.Commands.WaitOption.InPosition, 0, 2000) && myController.Commands.Motion.WaitForMotionDone(Aerotech.A3200.Commands.WaitOption.InPosition, 1, 2000) && myController.Commands.Motion.WaitForMotionDone(Aerotech.A3200.Commands.WaitOption.InPosition, 2, 2000))
                    {
                        if (Motion_X && Motion_Y && Motion_Z)
                        {
                            Distance_X = Convert.ToDouble(point_position[20, 0]);
                            Distance_Y = Convert.ToDouble(point_position[20, 1]);
                            Distance_Z = -(Convert.ToDouble(point_position[22, 0]) - Convert.ToDouble(point_position[22, 1]));
                            double xuan = (Convert.ToDouble(point_position[22, 0]) + (-(Convert.ToDouble(point_position[22, 0]) - Convert.ToDouble(point_position[22, 1]))));
                            double[] Speed = { 50, 50, 15 };
                            double[] Distance = { Distance_X, Distance_Y, Distance_Z };
                            this.myController.Commands[this.taskIndex].Motion.MoveInc(0, Distance_X, fastspeed);
                            this.myController.Commands[this.taskIndex].Motion.MoveInc(1, Distance_Y, fastspeed);
                            this.myController.Commands[this.taskIndex].Motion.MoveInc(2, Distance_Z, double.Parse("15"));
                            _AutoDwring_flag = 307;
                        }
                    }
                    break;

                case 307:
                    if (myController.Commands.Motion.WaitForMotionDone(Aerotech.A3200.Commands.WaitOption.InPosition, 0, 2000) && myController.Commands.Motion.WaitForMotionDone(Aerotech.A3200.Commands.WaitOption.InPosition, 1, 2000) && myController.Commands.Motion.WaitForMotionDone(Aerotech.A3200.Commands.WaitOption.InPosition, 2, 2000))
                    {
                        if (Motion_X && Motion_Y && Motion_Z)
                        {
                            Thread.Sleep(200);
                            _AutoDwring_flag = 3;
                        }
                    }
                    break;

                case 3:
                    try
                    {
                        // 取代原本的 tcp1.WriteLine("T1");
                        string response = _CameraCVX.Trigger1(2000);   // 若timeout太短會收不到第二行資訊
                        // 記錄最後一次的回應，給 case 4 使用
                        _lastTriggerResponse = response;
                        _AutoDwring_flag = 4;
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show($"讀取當前KEYENCE檢測內容錯誤: {ex.Message}", "CV-X 錯誤",
                                       MessageBoxButtons.OK, MessageBoxIcon.Error);
                        WriteLog("Thread", "_thread.ini", $"讀取當前KEYENCE檢測內容錯誤 {ex.Message}，CV-X 錯誤");
                        _AutoDwring_flag = 0;
                    }
                    break;

                case 4:
                    try
                    {
                        string[] s_im = _lastTriggerResponse.Split(new char[] { ',', '\r' },
                                          StringSplitOptions.RemoveEmptyEntries);

                        if (s_im.Length < 4)
                        {
                            throw new Exception("回傳資料格式錯誤");
                            WriteLog("Thread", "_thread.ini", $"回傳資料格式錯誤，CV-X 錯誤");

                        }

                        sub_im[0] = s_im[0]; // T1
                        sub_im[1] = s_im[1]; // X
                        sub_im[2] = s_im[2]; // Y
                        sub_im[3] = s_im[3]; // SIMILER

                        if ((Convert.ToDouble(sub_im[3]) >= 50) && sub_im[0] == "T1")
                        {
                            LCC_X_reg = (Convert.ToDouble(sub_im[1]) / 970).ToString("F3");
                            LCC_Y_reg = (-Convert.ToDouble(sub_im[2]) / 970).ToString("F3");
                            _AutoDwring_flag = 5;
                        }
                        else
                        {
                            MessageBox.Show("辨識失敗相似度不符", "CV-X 警告", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                            WriteLog("Thread", "_thread.ini", $"讀取當前KEYENCE檢測內容相似度低於門檻50 {sub_im[3]}，CV-X 錯誤");
                            _AutoDwring_flag = 0;
                        }
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show($"資料解析失敗: {ex.Message}", "CV-X 錯誤",
                                       MessageBoxButtons.OK, MessageBoxIcon.Error);
                        WriteLog("Thread", "_thread.ini", $"讀取當前KEYENCE檢測內容資料解析失敗 {ex.Message}，CV-X 錯誤");
                        _AutoDwring_flag = 0;
                    }
                    break;

                case 5:  //補償//移動xy軸
                    if (myController.Commands.Motion.WaitForMotionDone(Aerotech.A3200.Commands.WaitOption.InPosition, 0, 2000) && myController.Commands.Motion.WaitForMotionDone(Aerotech.A3200.Commands.WaitOption.InPosition, 1, 2000) && myController.Commands.Motion.WaitForMotionDone(Aerotech.A3200.Commands.WaitOption.InPosition, 2, 2000))
                    {
                        if (Motion_X && Motion_Y && Motion_Z)
                        {
                            // 讀取補償量 (LCC_X_reg, LCC_Y_reg)
                            Distance_X = Convert.ToDouble(LCC_X_reg);
                            Distance_Y = Convert.ToDouble(LCC_Y_reg);
                            this.myController.Commands[this.taskIndex].Motion.MoveInc(0, Distance_X, 50);
                            this.myController.Commands[this.taskIndex].Motion.MoveInc(1, Distance_Y, 50);
                            LCC_X = (Convert.ToDouble(LCC_X) + Convert.ToDouble(LCC_X_reg)).ToString();
                            LCC_Y = (Convert.ToDouble(LCC_Y) + Convert.ToDouble(LCC_Y_reg)).ToString();
                            if ((Math.Abs(Convert.ToDouble(LCC_X_reg)) < 0.001) && (Math.Abs(Convert.ToDouble(LCC_Y_reg)) < 0.002))// 判斷這次補償量是否已經非常小（< 0.001mm）
                            {
                                _AutoDwring_flag = 6;// 補償完成 → 進入下一步
                            }
                            else
                            {
                                _AutoDwring_flag = 307;// 補償量還不夠小 → 繼續補償循環
                            }
                        }
                    }
                    break;

                case 6:
                    if (myController.Commands.Motion.WaitForMotionDone(Aerotech.A3200.Commands.WaitOption.InPosition, 0, 2000) && myController.Commands.Motion.WaitForMotionDone(Aerotech.A3200.Commands.WaitOption.InPosition, 1, 2000) && myController.Commands.Motion.WaitForMotionDone(Aerotech.A3200.Commands.WaitOption.InPosition, 2, 2000))
                    {
                        if (Motion_X && Motion_Y && Motion_Z)
                        {
                            Thread.Sleep(200);
                            _AutoDwring_flag = 100;
                        }
                    }
                    break;

                case 7:
                    //if (pnlMainViewer != null)
                    //{
                    //    Bitmap myImage = new Bitmap(pnlMainViewer.Width, pnlMainViewer.Height);
                    //    pnlMainViewer.DrawToBitmap(myImage, new Rectangle(0, 0, pnlMainViewer.Width, pnlMainViewer.Height));

                    //    PicTime = DateTime.Now;

                    //    // ==================== 建議寫法 ====================


                    //    string saveFolder = Path.Combine(Environment.CurrentDirectory, "LCNimage", "DrawGraphics");           // ← 你可以自行修改路徑

                    //    // 如果資料夾不存在就自動建立
                    //    if (!Directory.Exists(saveFolder))
                    //        Directory.CreateDirectory(saveFolder);

                    //    string fileName = PicTime.ToString("yyyyMMdd_HHmmss") + "_MainViewer.jpg";
                    //    string fullPath = Path.Combine(saveFolder, fileName);   // 組合完整路徑

                    //    myImage.Save(fullPath, System.Drawing.Imaging.ImageFormat.Jpeg);

                    //    myImage.Dispose();

                    //    _AutoDwring_flag = 100;

                    //    // 可選：顯示存檔位置（方便除錯）
                    //    // MessageBox.Show("圖片已儲存至：\n" + fullPath);
                    //}
                    break;

                case 8:
                    break;
                case 9:
                    break;
                case 10:
                    break;
                case 11:
                    break;

                case 100:
                    prog_status = "圖形校正完成,可以繼續操作";
                    _AutoDwring_flag = 0;
                    break;
            }
        }
        /// <summary>
        /// 自動對焦-迴圈
        /// </summary>
        private void _AT_focus()
        {
            try
            {
                while (_isautofocus)
                {
                    AT_focus();
                }
            }
            finally
            {
                // ← 無論正常結束、還是被外部要求停止，都一定會執行這裡
                _isautofocus = false;
                AT_focus_flag = 0;

                // 這裡啟動下一個執行緒（保證 _autofocus 真正結束後才跑）
                if ((_Auto_FindHole == null || !_Auto_FindHole.IsAlive) && _isAuto_FindHole == true)
                {
                    _Auto_FindHole = new Thread(Auto_FindHole_W);
                    _Auto_FindHole.Start();
                    FindHole_flag = 1;
                }
            }
        }

        double offset_AT_focus = 0.5;
        double fastspeed = 100;
        /// <summary>
        /// 自動對焦-動作流程
        /// </summary>
        private void AT_focus()
        {
            switch (AT_focus_flag)
            {
                case 0:
                    _isautofocus = false;
                    WriteLog("Thread", "_thread.ini", $"自動對焦流程結束");
                    prog_status = "自動對焦結束";
                    Thread.Sleep(100);
                    break;

                case 1:
                    if (En && Home && ProcessFileRead_flag)
                    {
                        prog_status = "自動對焦開始";
                        currentTime = DateTime.Now;

                        //[BM:優化紀錄資訊Log]
                        WriteLog("Thread", "_thread.ini", $"自動對焦流程開始");
                        //using (StreamWriter text = new StreamWriter(Path.Combine(Environment.CurrentDirectory, "LCN_LOG", "Log") + LogTime.ToString("yyyyMMdd") + "_Log.ini", true))//using (StreamWriter text = new StreamWriter(classSystem.FilePath_Log + LogTime.ToString("yyyyMMdd") + "_Log.ini", true))
                        //{
                        //    text.WriteLine(currentTime.ToString("yyyyMMddHHmmss") + "  ;  " + "自動對焦 ");
                        //    //sw.Flush();
                        //    text.Close();
                        //    AT_focus_flag = 2;
                        //}

                        AT_focus_flag = 2;
                    }
                    else
                    {
                        if (!En)
                        {
                            AT_focus_flag = 0;
                            //[BM:優化紀錄資訊Log]
                            WriteLog("Thread", "_thread.ini", $"Please Check Servo ON !");
                            MessageBox.Show("Please Check Servo ON !");
                        }
                        if (!Home)
                        {
                            AT_focus_flag = 0;
                            WriteLog("Thread", "_thread.ini", $"Please Check Homed !");
                            MessageBox.Show("Please Check Homed !");
                        }
                        if (!_isDoorLock)
                        {
                            AT_focus_flag = 0;
                            WriteLog("Thread", "_thread.ini", $"Please Check Door_Lock !");
                            MessageBox.Show("Please Check Door_Lock !");
                        }
                        if (!ProcessFileRead_flag)
                        {
                            AT_focus_flag = 0;
                            WriteLog("Thread", "_thread.ini", $"未載入檔案 !");
                            MessageBox.Show("未載入檔案 !");
                        }
                    }
                    break;

                case 2://MOTION CCD->測高
                    if (myController.Commands.Motion.WaitForMotionDone(Aerotech.A3200.Commands.WaitOption.InPosition, 0, 2000) && myController.Commands.Motion.WaitForMotionDone(Aerotech.A3200.Commands.WaitOption.InPosition, 1, 2000) && myController.Commands.Motion.WaitForMotionDone(Aerotech.A3200.Commands.WaitOption.InPosition, 2, 2000))
                    {
                        if (Motion_X && Motion_Y && Motion_Z)
                        {
                            Distance_X = -(Convert.ToDouble(point_position[20, 0]) - Convert.ToDouble(point_position[21, 0]) + offset_AT_focus);
                            Distance_Y = -(Convert.ToDouble(point_position[20, 1]) - Convert.ToDouble(point_position[21, 1]) + offset_AT_focus);
                            double[] Speed = { 50, 50 };
                            double[] Distance = { Distance_X, Distance_Y };
                            this.myController.Commands[this.taskIndex].Motion.MoveInc(0, Distance_X, fastspeed);
                            this.myController.Commands[this.taskIndex].Motion.MoveInc(1, Distance_Y, fastspeed);
                            AT_focus_flag = 3;
                        }
                    }
                    break;

                case 3:
                    //降Z高度
                    if (myController.Commands.Motion.WaitForMotionDone(Aerotech.A3200.Commands.WaitOption.InPosition, 0, 2000) && myController.Commands.Motion.WaitForMotionDone(Aerotech.A3200.Commands.WaitOption.InPosition, 1, 2000) && myController.Commands.Motion.WaitForMotionDone(Aerotech.A3200.Commands.WaitOption.InPosition, 2, 2000))
                    {
                        if (Motion_X && Motion_Y && Motion_Z)
                        {
                            if (Convert.ToDouble(Keyence_Height_textBox.Text) > zlimit)//計算出來的絕對位置要大於接近撞吸嘴的危險值
                            {
                                this.myController.Commands[this.taskIndex].Motion.MoveAbs(2, Convert.ToDouble(Keyence_Height_textBox.Text), double.Parse("15"));
                                AT_focus_flag = 4;
                            }
                            else
                            {
                                MessageBox.Show($"z軸高度計算後超出安全高度({zlimit}): {Convert.ToDouble(Keyence_Height_textBox.Text)}", "z軸高度軟體限制", MessageBoxButtons.OK, MessageBoxIcon.Error);
                                WriteLog("Thread", "_thread.ini", $"z軸高度計算後超出安全高度({ zlimit}): { Convert.ToDouble(Keyence_Height_textBox.Text)}");
                                AT_focus_flag = 0;
                            }
                        }
                    }
                    else
                    {
                        AT_focus_flag = 3;
                    }

                    break;
                case 4:
                    //確認到位
                    if (myController.Commands.Motion.WaitForMotionDone(Aerotech.A3200.Commands.WaitOption.InPosition, 0, 2000) && myController.Commands.Motion.WaitForMotionDone(Aerotech.A3200.Commands.WaitOption.InPosition, 1, 2000) && myController.Commands.Motion.WaitForMotionDone(Aerotech.A3200.Commands.WaitOption.InPosition, 2, 2000))
                    {
                        if (Motion_X && Motion_Y && Motion_Z)
                        {

                            str = "";
                            AT_focus_flag = 5;
                        }
                    }
                    else
                    {
                        AT_focus_flag = 4;
                    }
                    break;


                case 5:  // 測高
                    try
                    {
                        evalResult result = _ConfocalLaser.Trigger(1, out _ConfocalLaser_Output, 800);   // waitMSec 建議設 500~1000，不要設 0


                        tk_value = _ConfocalLaser_Output;   // 把測量值存到你原本的變數

                        //[BM:測高保護]
                        if (Math.Abs(tk_value) > thicknesslimit) //測高回傳值單位為um (限制差超過1mm就發異常)
                        {
                            MessageBox.Show("測高異常");
                            WriteLog("Thread", "_thread.ini", $"測高異常:({tk_value})um");
                            tk_value = 0;
                            AT_focus_flag = 0;
                        }
                        else
                        {
                            tk_value = tk_value * 0.001;//um轉換為mm
                            AT_focus_flag = 8; // 測量成功且數值正常 → 進入下一步
                        }
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("測高失敗: " + ex.Message);
                        WriteLog("Thread", "_thread.ini", $"測高失敗:{ex.Message}");
                        tk_value = 0;
                        AT_focus_flag = 0;
                    }
                    break;

                case 8: //移動回原本ccd下方
                    if (myController.Commands.Motion.WaitForMotionDone(Aerotech.A3200.Commands.WaitOption.InPosition, 0, 2000) && myController.Commands.Motion.WaitForMotionDone(Aerotech.A3200.Commands.WaitOption.InPosition, 1, 2000) && myController.Commands.Motion.WaitForMotionDone(Aerotech.A3200.Commands.WaitOption.InPosition, 2, 2000))
                    {
                        if (Motion_X && Motion_Y && Motion_Z)
                        {
                            Distance_X = (Convert.ToDouble(point_position[20, 0]) - Convert.ToDouble(point_position[21, 0]) + offset_AT_focus);
                            Distance_Y = (Convert.ToDouble(point_position[20, 1]) - Convert.ToDouble(point_position[21, 1]) + offset_AT_focus);
                            double[] Speed = { 50, 50 };
                            double[] Distance = { Distance_X, Distance_Y };
                            this.myController.Commands[this.taskIndex].Motion.MoveInc(0, Distance_X, fastspeed);
                            this.myController.Commands[this.taskIndex].Motion.MoveInc(1, Distance_Y, fastspeed);
                            AT_focus_flag = 9;
                        }
                    }
                    break;

                case 9: //ccd焦距位置
                    if ((Convert.ToDouble(point_position[22, 1]) + tk_value) > zlimit)//計算出來的絕對位置要大於接近撞吸嘴的危險值
                    {
                        this.myController.Commands[this.taskIndex].Motion.MoveAbs(2, (Convert.ToDouble(point_position[22, 1]) + tk_value), double.Parse("15"));
                        AT_focus_flag = 10;
                    }
                    else
                    {
                        MessageBox.Show($"z軸高度計算後超出安全高度({zlimit}): {(Convert.ToDouble(point_position[22, 1]) + tk_value)}", "z軸高度軟體限制", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        WriteLog("Thread", "_thread.ini", $"z軸高度計算後超出安全高度({ zlimit}): { (Convert.ToDouble(point_position[22, 1]) + tk_value)}");
                        AT_focus_flag = 0;
                    }
                    break;

                case 10:
                    if (myController.Commands.Motion.WaitForMotionDone(Aerotech.A3200.Commands.WaitOption.InPosition, 0, 2000) && myController.Commands.Motion.WaitForMotionDone(Aerotech.A3200.Commands.WaitOption.InPosition, 1, 2000) && myController.Commands.Motion.WaitForMotionDone(Aerotech.A3200.Commands.WaitOption.InPosition, 2, 2000))
                    {
                        if (Motion_X && Motion_Y && Motion_Z)
                        {
                            AT_focus_flag = 0;
                        }
                    }
                    break;

                case 11:
                    break;
                case 12:
                    break;
                case 13:
                    break;
                case 14:
                    break;
            }
        }






        /// <summary>
        /// 2CUT 加工執行緒主體，持續呼叫 <c>DEMO_TEST_2CUT()</c> 執行加工流程。
        /// 用於非同步執行雷射加工邏輯。
        /// </summary>
        private void _DEMO_TEST_2CUT()
        {
            try
            {
                while (_isDemo_Test_2CUT)
                {
                    DEMO_TEST_2CUT();
                }
            }
            finally
            {
                endtimeflag = true;
                pin_time_average.Clear();
                DEMO_flag_2CUT = 0;
                _isProcessing = false;//加工亮綠燈
            }



        }
        /// <summary>
        /// 執行 2CUT 加工流程主體，依據 <c>DEMO_flag_2CUT</c> 狀態進行加工邏輯切換。
        /// 包含加工初始化、功率設定、雷射參數確認、振鏡連線、功率補償、光源控制、功率量測與結果記錄等流程。
        /// 支援 ShortPitch 模式與 NG/PRR 補償條件判斷。
        /// </summary>
        private void DEMO_TEST_2CUT()//2切動作流程
        {
            double LP_Gain = _ConfigProcess._LaserParam_Convert.Gain;
            double LP_Offset = _ConfigProcess._LaserParam_Convert.Offset;
            double PowerCheck_USL = _ConfigSystem._AutoPowerCheck_USL;
            double PowerCheck_LSL = _ConfigSystem._AutoPowerCheck_LSL;
            double PowerCheck_value = _ConfigSystem._AutoPowerCheck_value;

            //=========計時工具
            /* Stopwatch stopwatch_Warmup = new Stopwatch();
             Stopwatch stopwatch_Suspend = new Stopwatch();
             Stopwatch stopwatch_Hold = new Stopwatch();*/
            //=========計時工具


            switch (DEMO_flag_2CUT)
            {
                case -2:
                    //DELAY 延遲機制（約等待數十毫秒），確保硬體端有足夠時間接收訊號並拉起 Busy 狀態。延遲後進入 Case 2。
                    if (Counter > 6)
                    {
                        Counter = 0;
                        DEMO_flag_2CUT = 2;
                    }
                    else
                    {
                        Counter++;
                        Thread.Sleep(10);
                        DEMO_flag_2CUT = -2;
                    }
                    break;
                case 0:
                    prog_status = "2切加工結束";
                    _isDemo_Test_2CUT = false;
                    break;
                case 1:
                    //確認home完成/severon
                    if (En && Home && ProcessFileRead_flag_2CUT  /*&& _rotationStage.GetIsHomed()*/)
                    {
                        prog_status = "2切加工中";
                        WriteLog("Thread", "_thread.ini", $"2切加工流程開始");
                        pin_time_average.Clear();
                        endtimeflag = true;
                        if (checkBox_Diff_Len.Checked)//20210629
                        {
                            if (!RB_NS_ShortPitch.Checked && !RB_BR_ShortPitch.Checked)
                            {
                                process_2CUT_i = process_2CUT_TIP_i = Range_minmun * ReginPinNum;
                                process_2CUT_END = process_2CUT_TIP_END = (Range_maxmum + 1) * ReginPinNum;
                            }
                            else
                            {
                                if (RB_Short2Cut_Odd.Checked)
                                {
                                    process_2CUT_i = process_2CUT_TIP_i = Range_minmun * ReginPinNum;
                                    process_2CUT_END = process_2CUT_TIP_END = (Range_maxmum + 1) * ReginPinNum;
                                }
                                else if (RB_Short2Cut_Even.Checked)
                                {
                                    process_2CUT_i = process_2CUT_TIP_i = (Range_minmun * ReginPinNum) + 1;
                                    process_2CUT_END = process_2CUT_TIP_END = (Range_maxmum + 1) * ReginPinNum;
                                }
                            }

                        }
                        else
                        {
                            if (!RB_NS_ShortPitch.Checked && !RB_BR_ShortPitch.Checked)
                            {
                                process_2CUT_i = 0;
                                process_2CUT_TIP_i = 0;
                                process_2CUT_END = pin_TotalNumber_2CUT * ReginPinNum / 2;
                                process_2CUT_TIP_END = pin_TotalNumber_2CUT * ReginPinNum / 2;
                            }
                            else
                            {
                                //短間距二切 參數檔不變 透過位置設定
                                if (RB_Short2Cut_Odd.Checked)
                                {
                                    process_2CUT_i = 0;
                                    process_2CUT_TIP_i = 0;
                                    process_2CUT_END = pin_TotalNumber_2CUT * ReginPinNum / 2;
                                    process_2CUT_TIP_END = pin_TotalNumber_2CUT * ReginPinNum / 2;
                                }
                                else if (RB_Short2Cut_Even.Checked)
                                {
                                    process_2CUT_i = 1;
                                    process_2CUT_TIP_i = 1;
                                    process_2CUT_END = pin_TotalNumber_2CUT * ReginPinNum / 2;
                                    process_2CUT_TIP_END = pin_TotalNumber_2CUT * ReginPinNum / 2;
                                }

                            }
                        }

                        counter_pin_num = 0;
                        currentTime = DateTime.Now;
                        process_smallbox_ng = 0;
                        process_smallbox_i = 0;



                        WriteLog("Thread", "_thread.ini", $"2切加工開始");


                        double setPower = 0;

                        //[BM:LCH二切功能-與LCN不同被註解掉，換成LCH功率量測流程]
                        /*  if (double.TryParse(txt_SetPower_2.Text, out setPower))
                          {

                              if (setPower < p_min || setPower > p_max)
                              {
                                  MessageBox.Show("請輸入介於" + p_min.ToString() + "~" + p_max.ToString() + "之間的數值!");
                                  DEMO_flag_2CUT = 0;
                              }
                              else
                              {
                                  //double angle = setPower * _angle_A + _angle_B;//* 0.011 + 3.442;//20210305
                                  //_rotationStage.MoveAbs((decimal)angle, 0);


                                  Carbide_PowerSet(setPower);

                              }
                          }
                          if (Carbide_PowerSet(setPower))
                              DEMO_flag_2CUT = 100;
                        */

                        if (double.TryParse(txt_SetPower_2.Text, out setPower))
                        {
                            if (setPower < p_min || setPower > p_max)
                            {
                                MessageBox.Show("請輸入介於" + p_min + "~" + p_max + "之間的數值!");
                                DEMO_flag_2CUT = 0;
                            }
                            else
                            {
                                //[BM:LCH二切功能-與LCN不同被註解掉，要換成功率檢測流程]
                                /*  if (Carbide_PowerSet(setPower))
                                      DEMO_flag_2CUT = 100;*/
                                //加工前確認雷射功率

                                var result = PowerSet(setPower);

                                if (result.Item1 != 0 && result.Item2 == true)
                                {
                                    laserPowerPct = result.Item1;
                                    DEMO_flag_2CUT = 100;
                                }
                                else
                                {
                                    MessageBox.Show("功率設定錯誤 !");
                                    DEMO_flag_2CUT = 0;
                                }
                            }
                        }
                    }
                    else
                    {
                        if (!En)
                        {
                            DEMO_flag_2CUT = 0;
                            MessageBox.Show("Please Check Servo ON !");

                        }

                        if (!Home)
                        {
                            DEMO_flag_2CUT = 0;
                            MessageBox.Show("Please Check Homed !");

                        }

                        ////[BM:LCH二切功能-與LCN不同]
                        //if (!_isDoorLock)
                        //{
                        //    DEMO_flag_2CUT = 0;
                        //    MessageBox.Show("Please Check Door_Lock !");
                        //}

                        if (!ProcessFileRead_flag_2CUT)
                        {
                            DEMO_flag_2CUT = 0;
                            MessageBox.Show("未載入檔案 !");
                        }
                        //if (!_rotationStage.GetIsHomed())
                        //{
                        //	DEMO_flag_2CUT = 0;
                        //	MessageBox.Show("旋轉馬達未回HOME !");
                        //}
                    }
                    break;


                case 100:
                    //[BM:LCH二切功能-與LCN不同] 
                    // if (flag_HeadConected)
                    if (_LaserScanner.arges_connect)
                    {


                        if (SetLaserPowerPercentage(laserPowerPct))//更改功率值  // Set Laser Output Power
                        {
                            DEMO_flag_2CUT = 200;
                        }

                        else
                        {
                            MessageBox.Show($"雷射功率輸出設定失敗");

                            DEMO_flag_2CUT = 0;

                        }


                    }
                    else
                    {
                        DEMO_flag_2CUT = 0;
                        MessageBox.Show("未連接振鏡!");
                    }
                    break;

                case 200:
                    //移動到power test 位置
                    if (myController.Commands.Motion.WaitForMotionDone(Aerotech.A3200.Commands.WaitOption.InPosition, 0, 2000) && myController.Commands.Motion.WaitForMotionDone(Aerotech.A3200.Commands.WaitOption.InPosition, 1, 2000) && myController.Commands.Motion.WaitForMotionDone(Aerotech.A3200.Commands.WaitOption.InPosition, 2, 2000))
                    {
                        {
                            if (Motion_X && Motion_Y && Motion_Z)
                            {
                                ABS_X = Convert.ToDouble(point_position[5, 0]);
                                ABS_Y = Convert.ToDouble(point_position[5, 1]);
                                ABS_Z = Convert.ToDouble(point_position[5, 2]);
                                Allow_X = Allow_Y = Allow_Z = true;
                                //Allow_Z = false;
                                //MessageBox.Show(i.ToString()+","+ ABS_X.ToString() + ";" + j.ToString()+","+ABS_Y.ToString());
                                //Aero_thMotionRun_Tick(Motion_Num.Motion_ABS);
                                if (ABS_Z > zlimit)
                                {
                                    if (Allow_X)
                                    {
                                        this.myController.Commands[this.taskIndex].Motion.MoveAbs(0, ABS_X, 40);
                                    }
                                    if (Allow_Y)
                                    {
                                        this.myController.Commands[this.taskIndex].Motion.MoveAbs(1, ABS_Y, 40);
                                    }
                                    if (Allow_Z)
                                    {
                                        this.myController.Commands[this.taskIndex].Motion.MoveAbs(2, ABS_Z, 20);
                                    }

                                }
                                else
                                {

                                    MessageBox.Show($"z軸高度計算後超出安全高度({zlimit}): {ABS_Z}", "z軸高度軟體限制",
                                                 MessageBoxButtons.OK, MessageBoxIcon.Error);
                                    WriteLog("Thread", "_thread.ini", $"z軸高度計算後超出安全高度({zlimit}): { ABS_Z}");
                                    DEMO_flag_2CUT = 0;
                                }




                                enableDustcover(true);//開啟防塵蓋



                                OutputPower.Clear();//記錄前清除值

                                _isReadPowerMeter = true;//開始獲取功率值





                                DEMO_flag_2CUT = 201;
                            }
                        }
                    }
                    break;

                case 201:
                    //判斷軸控是否到定位
                    if (myController.Commands.Motion.WaitForMotionDone(Aerotech.A3200.Commands.WaitOption.InPosition, 0, 2000) && myController.Commands.Motion.WaitForMotionDone(Aerotech.A3200.Commands.WaitOption.InPosition, 1, 2000) && myController.Commands.Motion.WaitForMotionDone(Aerotech.A3200.Commands.WaitOption.InPosition, 2, 2000))
                    {
                        if (Motion_X && Motion_Y && Motion_Z)
                        {

                            #region 載入加工刀具
                            try
                            {
                                bool FileJobxCheck = false;
                                bool JobxNamesCheck = false;
                                string filePath = "";
                                string[] filxes;
                                string JobxName = "Powermeter";

                                _isLaserScannerBusy = true;

                                //清除振鏡上刀具
                                _LaserScanner.ClearJobs();

                                filePath = Path.Combine(C_Path, "LCNjob", "Powermeter_Jobx", JobxName + ".jobx");
                                filxes = Directory.GetFiles(Path.Combine(C_Path, "LCNjob", "Powermeter_Jobx"), "*.jobx");//子翔設定的 持續輸出10秒打在Powermeter上量測功率

                                //確認指定路徑是否有此專案刀具
                                foreach (var file in filxes)
                                {
                                    if (file == filePath)
                                    {
                                        FileJobxCheck = true;
                                        break;
                                    }
                                }
                                if (FileJobxCheck == false)
                                {
                                    _AutoDwring_flag = 0;
                                    writeError("載入刀具錯誤", "找尋不到刀具名稱！！刀具名稱： " + JobxName);
                                    throw new Exception("載入刀具錯誤");
                                }

                                //載入刀具
                                _LaserScanner.LoadJobFromFile(filePath);
                                Thread.Sleep(100);

                                //讀取振鏡上Jobx刀具名稱，與專案刀具進行檢查
                                if (_ConfigProcess._IsAutoProcessCheckJobx)
                                {
                                    //讀取振鏡上所有刀具
                                    List<string> JobxNames = new List<string>();
                                    _LaserScanner.GetJobNames(out JobxNames);

                                    //檢查振鏡上刀具是否跟專案刀具一樣                             
                                    foreach (var _jobnames in JobxNames)
                                    {
                                        string jobSubnames = _jobnames.Substring(8);
                                        if (jobSubnames == JobxName)
                                        {
                                            JobxNamesCheck = true;
                                            break;
                                        }
                                    }

                                    if (JobxNamesCheck == false)
                                    {
                                        _AutoDwring_flag = 0;
                                        writeError("振鏡刀具錯誤", "振鏡上刀具與專案刀具不符！！刀具名稱： " + JobxName);
                                        throw new Exception("振鏡刀具錯誤");
                                    }
                                }

                                //_LaserScanner.SelectJobByName(JobxName);
                                _isLaserScannerBusy = false;
                            }
                            catch (Exception)
                            {
                                _AutoDwring_flag = 0;
                                MessageBox.Show("載入刀具錯誤，請確認是否有這項刀具。", "Error！！");
                                return;

                            }
                            #endregion




                            Thread.Sleep(10);

                            if (!_isLaserScannerBusy)
                            {
                                if (!DoLaserProcessing()) // 執行一次並取得回傳結果是true 或是false
                                {

                                    DoLaserReconnect();//重新連線
                                }

                            }


                            if (!_isLaserScannerBusy && _FormLaserScanner.States.PLC_JOB_COMPLETED)//加工完成且雷射狀態為true
                            {
                                Thread.Sleep(10);

                                DEMO_flag_2CUT = 203;

                            }


                        }
                    }
                    else//若軸還沒到位
                    {
                        DEMO_flag_2CUT = 201;
                    }
                    break;

                case 202:
                    //[BM:LCH二切功能-與LCN不同-202這段直接跳過]
                    //DELAY
                    if (Counter > 100)
                    {
                        Counter = 0;
                        /*//START復位
                        DO_4_OFF();*/
                        DEMO_flag_2CUT = 203;
                    }
                    else
                    {
                        Counter++;
                        Thread.Sleep(10);
                        DEMO_flag_2CUT = 202;
                    }
                    break;

                case 203:
                    //計算實際功率值與人員輸入 mw是否在可接受範圍

                    _isReadPowerMeter = false;//停止紀錄功率量測值


                    if (OutputPower.Count == 0)
                    {
                        DEMO_flag_2CUT = 300; //紀錄&存檔
                    }
                    else
                    {
                        _OutputPower = OutputPower.Average() * 1000;

                        if (Math.Abs(_OutputPower - Convert.ToDouble(txt_SetPower_2.Text)) < 50)//若量測值與實際值<50mW
                        {
                            DEMO_flag_2CUT = 300; //紀錄&存檔
                        }
                        else
                        {
                            DEMO_flag_2CUT = 209;//進入補償流程
                        }

                    }
                    break;





                case 209: //重新計算功率百分比並設定 再次量測

                    PowerError++;
                    try
                    {
                        if (PowerError < 3)
                        {
                            if (_OutputPower < Convert.ToDouble(txt_SetPower_2.Text))//實際功率小於人員設定值(所以要算出提高多少mW，在計算出是多少百分比)
                            {
                                double mW = Convert.ToDouble(txt_SetPower_2.Text) - _OutputPower;//計算出差多少mW
                                mW += Convert.ToDouble(txt_SetPower_2.Text);//差值+人原員輸入值
                                var result = PowerSet(mW);

                                if (result.Item1 != 0 && result.Item2 == true)
                                {
                                    laserPowerPct = result.Item1;

                                    if (SetLaserPowerPercentage(laserPowerPct))
                                    {

                                        OutputPower.Clear();//再次量測前清除先前的值
                                        _isReadPowerMeter = true;//再次啟用紀錄功率值

                                        DEMO_flag_2CUT = 201;//載刀具、出光
                                    }
                                }

                                else
                                {
                                    MessageBox.Show($"雷射源功率百分比設定異常，2切流程終止");
                                    enableDustcover(false);//關閉防塵蓋

                                    DEMO_flag_2CUT = 0;
                                }
                            }
                            else//實際功率大於人員設定值(所以要算出降低多少mW，在計算出是多少百分比)
                            {
                                double mW = _OutputPower - Convert.ToDouble(txt_SetPower_2.Text);//計算出差多少mW
                                mW = Convert.ToDouble(txt_SetPower_2.Text) - mW;//人原員輸入值-差值
                                var result = PowerSet(mW);

                                if (result.Item1 != 0 && result.Item2 == true)
                                {
                                    laserPowerPct = result.Item1;

                                    if (SetLaserPowerPercentage(laserPowerPct))
                                    {

                                        OutputPower.Clear();//再次量測前清除先前的值
                                        _isReadPowerMeter = true;//再次啟用紀錄功率值

                                        DEMO_flag_2CUT = 201;//載刀具、出光
                                    }
                                }

                                else
                                {
                                    MessageBox.Show($"雷射源功率百分比設定異常，2切流程終止");
                                    enableDustcover(false);//關閉防塵蓋

                                    DEMO_flag_2CUT = 0;
                                }
                            }
                        }
                        else//超過重新量測容許次數
                        {
                            PowerError = 0;
                            DEMO_flag_2CUT = 204;
                        }
                    }
                    catch (Exception ex)
                    {
                        DEMO_flag_2CUT = 0;
                        enableDustcover(false);//關閉防塵蓋

                        MessageBox.Show("雷射源功率百分比設定異常，2切流程終止: " + ex.Message);
                    }
                    break;

                case 204:
                    MessageBox.Show($"雷射源功率設定異常，已嘗試3次失敗，2切流程終止");
                    enableDustcover(false);//關閉防塵蓋

                    DEMO_flag_2CUT = 0;
                    break;

                case 205:
                    break;
                case 206:
                    break;



                case 300:
                    currentTime = DateTime.Now;
                    LogTime = DateTime.Now;

                    WriteLog("Power", "_power.ini", $"power_2cut={_OutputPower.ToString()},功率計功率={_OutputPower}");
                    DEMO_flag_2CUT = 301;
                    break;

                case 301:
                    //DELAY
                    //if (Counter > 70)
                    //{
                    //    Counter = 0;
                    enableDustcover(false);//關閉防塵蓋

                    DEMO_flag_2CUT = 302;
                    //}
                    //else
                    //{
                    //    Counter++;
                    //    Thread.Sleep(10);
                    //    DEMO_flag_2CUT = 301;
                    //}
                    break;
                case 302://載入切針頭檔案
                         //停止復位
                         //  DO_7_OFF();
                    enableProcessGas(true);

                    #region 載入加工刀具 (針頭)
                    try
                    {
                        bool FileJobxCheck = false;
                        bool JobxNamesCheck = false;
                        string filePath = $"{TB_LoadFilePath_HeadJobx.Text}";
                        string[] filxes;
                        string JobxName = Path.GetFileNameWithoutExtension(filePath);   //"Powermeter";

                        _isLaserScannerBusy = true;

                        //清除振鏡上刀具
                        _LaserScanner.ClearJobs();

                        filePath = Path.Combine(C_Path, "LCNjob", "Powermeter_Jobx", JobxName + ".jobx");
                        filxes = Directory.GetFiles(Path.GetDirectoryName(filePath), "*.jobx");

                        //確認指定路徑是否有此專案刀具
                        foreach (var file in filxes)
                        {
                            if (file == filePath)
                            {
                                FileJobxCheck = true;
                                break;
                            }
                        }
                        if (FileJobxCheck == false)
                        {
                            DEMO_flag_2CUT = 0;
                            writeError("載入刀具錯誤", "找尋不到刀具名稱！！刀具名稱： " + JobxName);
                            throw new Exception("載入刀具錯誤");
                        }

                        //載入刀具
                        _LaserScanner.LoadJobFromFile(filePath);
                        Thread.Sleep(100);

                        //讀取振鏡上Jobx刀具名稱，與專案刀具進行檢查
                        if (_ConfigProcess._IsAutoProcessCheckJobx)
                        {
                            //讀取振鏡上所有刀具
                            List<string> JobxNames = new List<string>();
                            _LaserScanner.GetJobNames(out JobxNames);

                            //檢查振鏡上刀具是否跟專案刀具一樣                             
                            foreach (var _jobnames in JobxNames)
                            {
                                string jobSubnames = _jobnames.Substring(8);
                                if (jobSubnames == JobxName)
                                {
                                    JobxNamesCheck = true;
                                    break;
                                }
                            }

                            if (JobxNamesCheck == false)
                            {
                                DEMO_flag_2CUT = 0;
                                writeError("振鏡刀具錯誤", "振鏡上刀具與專案刀具不符！！刀具名稱： " + JobxName);
                                throw new Exception("振鏡刀具錯誤");
                            }
                        }

                        //_LaserScanner.SelectJobByName(JobxName);
                        _isLaserScannerBusy = false;

                    }
                    catch (Exception)
                    {
                        DEMO_flag_2CUT = 0;
                        MessageBox.Show("載入刀具錯誤，請確認是否有這項刀具。", "Error！！");
                        return;
                    }
                    #endregion

                    DEMO_flag_2CUT = 1000;
                    break;

                case 1000:
                    //軸控//移動到第一個加工位置
                    //this.Invoke(new Action<NewDiagPacketArrivedEventArgs>(SetAxisState),e);
                    if (myController.Commands.Motion.WaitForMotionDone(Aerotech.A3200.Commands.WaitOption.InPosition, 0, 2000) && myController.Commands.Motion.WaitForMotionDone(Aerotech.A3200.Commands.WaitOption.InPosition, 1, 2000) && myController.Commands.Motion.WaitForMotionDone(Aerotech.A3200.Commands.WaitOption.InPosition, 2, 2000))
                    {

                        if (Motion_X && Motion_Y && Motion_Z)
                        {
                            //ABS_X = Original_X - Convert.ToDouble(point_position[21, 0]) + Convert.ToDouble(process_X[process_i]);
                            //ABS_Y = Original_Y - Convert.ToDouble(point_position[21, 1]) + Convert.ToDouble(process_Y[process_i]);
                            if (image_error_all[process_2CUT_i] == 1)
                            {
                                //二切連動
                                if (CB_PRRLCN_Switch.Checked && !n_PRR_List.ProbeResult[process_2CUT_i] || CB_NG2Cut_Switch.Checked && NG2Cut[process_2CUT_i])
                                {
                                    DEMO_flag_2CUT = 20;
                                }
                                else//若沒有二切連動 從第一根針開始切
                                {
                                    ABS_X = HeadPOS_X[process_2CUT_i] - Convert.ToDouble(point_position[20, 0]) - Convert.ToDouble(lb_LCC_X.Text) + 0.0015; // + 0.003
                                    ABS_Y = HeadPOS_Y[process_2CUT_i] - Convert.ToDouble(point_position[20, 1]) - Convert.ToDouble(lb_LCC_Y.Text);
                                    //z越負,測高儀越負
                                    if (process_compensateZ_2CUT[process_2CUT_i] == "")
                                    {
                                        process_compensateZ_2CUT[process_2CUT_i] = " 0";
                                    }

                                    ABS_Z = Convert.ToDouble(point_position[22, 0]) + Convert.ToDouble(process_compensateZ_2CUT[process_2CUT_i]);
                                    Allow_X = Allow_Y = true;


                                    if (Allow_X)
                                    {
                                        this.myController.Commands[this.taskIndex].Motion.MoveAbs(0, ABS_X, 40);
                                    }
                                    if (Allow_Y)
                                    {
                                        this.myController.Commands[this.taskIndex].Motion.MoveAbs(1, ABS_Y, 40);
                                    }







                                    DEMO_flag_2CUT = 1001;
                                }
                            }
                            else
                            {
                                DEMO_flag_2CUT = 20;
                            }
                        }
                    }
                    break;
                case 1001:
                    //判斷是否到定位
                    //this.Invoke(new Action<NewDiagPacketArrivedEventArgs>(SetAxisState));
                    if (myController.Commands.Motion.WaitForMotionDone(Aerotech.A3200.Commands.WaitOption.InPosition, 0, 2000) && myController.Commands.Motion.WaitForMotionDone(Aerotech.A3200.Commands.WaitOption.InPosition, 1, 2000))
                    {

                        if (ABS_Z > zlimit)//軸移動
                        {

                            Allow_Z = true;


                            if (Allow_Z)
                            {
                                this.myController.Commands[this.taskIndex].Motion.MoveAbs(2, ABS_Z, 20);
                                DEMO_flag_2CUT = 1002;
                            }

                        }//軸移動
                        else
                        {
                            MessageBox.Show($"z軸高度計算後超出安全高度({zlimit}): {ABS_Z}", "z軸高度軟體限制",
                                         MessageBoxButtons.OK, MessageBoxIcon.Error);
                            WriteLog("Thread", "_thread.ini", $"z軸高度計算後超出安全高度({ zlimit}): { ABS_Z}");
                            DEMO_flag_2CUT = 0;
                        }



                    }
                    else//持續等待
                    {
                        DEMO_flag_2CUT = 1001;
                    }
                    break;

                case 1002:
                    //判斷是否到定位
                    //this.Invoke(new Action<NewDiagPacketArrivedEventArgs>(SetAxisState));
                    if (myController.Commands.Motion.WaitForMotionDone(Aerotech.A3200.Commands.WaitOption.InPosition, 0, 2000) && myController.Commands.Motion.WaitForMotionDone(Aerotech.A3200.Commands.WaitOption.InPosition, 1, 2000) && myController.Commands.Motion.WaitForMotionDone(Aerotech.A3200.Commands.WaitOption.InPosition, 2, 2000))
                    {


                        if (Motion_X && Motion_Y && Motion_Z)
                        {

                            DEMO_flag_2CUT = 101;
                        }

                    }
                    else//持續等待
                    {
                        DEMO_flag_2CUT = 1002;
                    }
                    break;

                case 101:
                    //出光切割
                    Thread.Sleep(1000);

                    if (!_isLaserScannerBusy)
                    {
                        if (!DoLaserProcessing()) // 執行一次並取得回傳結果是true 或是false
                        {

                            DoLaserReconnect();//重新連線
                        }

                    }


                    if (!_isLaserScannerBusy && _FormLaserScanner.States.PLC_JOB_COMPLETED)//加工完成且雷射狀態為true
                    {
                        Thread.Sleep(10);

                        DEMO_flag_2CUT = 102;//切完下一步
                    }


                    break;

                case 102:
                    DEMO_flag_2CUT = 2;//DELAY
                    break;

                case 2:
                    Thread.Sleep(10);

                    DEMO_flag_2CUT = 20;

                    break;



                case 20:
                    if (!RB_NS_ShortPitch.Checked && !RB_BR_ShortPitch.Checked)
                    {
                        process_2CUT_i++;
                    }
                    else
                    {
                        process_2CUT_i += 2;
                    }



                    if (process_2CUT_i >= process_2CUT_END)//如果針頭都切完了
                    {
                        //開始切尾
                        #region 載入加工刀具 (針尾)
                        try
                        {
                            bool FileJobxCheck = false;
                            bool JobxNamesCheck = false;
                            string filePath = $"{TB_LoadFilePath_EndJobx.Text}";
                            string[] filxes;
                            string JobxName = Path.GetFileNameWithoutExtension(filePath);   //"Powermeter";

                            _isLaserScannerBusy = true;

                            //清除振鏡上刀具
                            _LaserScanner.ClearJobs();

                            filePath = Path.Combine(C_Path, "LCNjob", "Powermeter_Jobx", JobxName + ".jobx");
                            filxes = Directory.GetFiles(Path.GetDirectoryName(filePath), "*.jobx");

                            //確認指定路徑是否有此專案刀具
                            foreach (var file in filxes)
                            {
                                if (file == filePath)
                                {
                                    FileJobxCheck = true;
                                    break;
                                }
                            }
                            if (FileJobxCheck == false)
                            {
                                DEMO_flag_2CUT = 0;
                                writeError("載入刀具錯誤", "找尋不到刀具名稱！！刀具名稱： " + JobxName);
                                throw new Exception("載入刀具錯誤");
                            }

                            //載入刀具
                            _LaserScanner.LoadJobFromFile(filePath);
                            Thread.Sleep(100);

                            //讀取振鏡上Jobx刀具名稱，與專案刀具進行檢查
                            if (_ConfigProcess._IsAutoProcessCheckJobx)
                            {
                                //讀取振鏡上所有刀具
                                List<string> JobxNames = new List<string>();
                                _LaserScanner.GetJobNames(out JobxNames);

                                //檢查振鏡上刀具是否跟專案刀具一樣                             
                                foreach (var _jobnames in JobxNames)
                                {
                                    string jobSubnames = _jobnames.Substring(8);
                                    if (jobSubnames == JobxName)
                                    {
                                        JobxNamesCheck = true;
                                        break;
                                    }
                                }

                                if (JobxNamesCheck == false)
                                {
                                    DEMO_flag_2CUT = 0;
                                    writeError("振鏡刀具錯誤", "振鏡上刀具與專案刀具不符！！刀具名稱： " + JobxName);
                                    throw new Exception("振鏡刀具錯誤");
                                }
                            }

                            //_LaserScanner.SelectJobByName(JobxName);
                            _isLaserScannerBusy = false;

                        }
                        catch (Exception)
                        {
                            DEMO_flag_2CUT = 0;
                            MessageBox.Show("載入刀具錯誤，請確認是否有這項刀具。", "Error！！");
                            return;
                        }
                        #endregion
                        DEMO_flag_2CUT = 21;
                    }


                    else//如果針頭還沒切完
                    {
                        counter_pin_num++;

                        if (counter_pin_num >= Convert.ToDouble(tb_PowerFix_Num_2CUT.Text))//加工次數達到功率檢查針數門檻，進入功率量測
                        {
                            counter_pin_num = 0;
                            //power 補償
                            DEMO_flag_2CUT = 200;
                        }
                        else
                        {
                            DEMO_flag_2CUT = 1000; //回到軸控,到下一個座標
                        }


                    }
                    break;



                case 21:
                    //移動到尾端
                    if (myController.Commands.Motion.WaitForMotionDone(Aerotech.A3200.Commands.WaitOption.InPosition, 0, 2000) && myController.Commands.Motion.WaitForMotionDone(Aerotech.A3200.Commands.WaitOption.InPosition, 1, 2000) && myController.Commands.Motion.WaitForMotionDone(Aerotech.A3200.Commands.WaitOption.InPosition, 2, 2000))
                    {

                        if (Motion_X && Motion_Y && Motion_Z)
                        {
                            //ABS_X = Original_X - Convert.ToDouble(point_position[21, 0]) + Convert.ToDouble(process_X[process_i]);
                            //ABS_Y = Original_Y - Convert.ToDouble(point_position[21, 1]) + Convert.ToDouble(process_Y[process_i]);
                            if (image_error_all[process_2CUT_TIP_i] == 1)
                            {
                                if (CB_PRRLCN_Switch.Checked && !n_PRR_List.ProbeResult[process_2CUT_TIP_i] ||
                                    CB_NG2Cut_Switch.Checked && NG2Cut[process_2CUT_TIP_i])
                                {
                                    DEMO_flag_2CUT = 26;
                                }
                                else
                                {
                                    ABS_X = TipPOS_X[process_2CUT_TIP_i] - Convert.ToDouble(point_position[20, 0]) - Convert.ToDouble(lb_LCC_X.Text);
                                    ABS_Y = TipPOS_Y[process_2CUT_TIP_i] - Convert.ToDouble(point_position[20, 1]) - Convert.ToDouble(lb_LCC_Y.Text);
                                    //z越負,測高儀越負
                                    if (process_compensateZ_2CUT[process_2CUT_TIP_i] == "")
                                    {
                                        process_compensateZ_2CUT[process_2CUT_TIP_i] = " 0";
                                    }
                                    ABS_Z = Convert.ToDouble(point_position[22, 0]) + Convert.ToDouble(process_compensateZ_2CUT[process_2CUT_TIP_i]);
                                    Allow_X = Allow_Y = Allow_Z = true;

                                    if (ABS_Z > zlimit)
                                    {

                                        if (Allow_X)
                                        {
                                            this.myController.Commands[this.taskIndex].Motion.MoveAbs(0, ABS_X, 40);
                                        }
                                        if (Allow_Y)
                                        {
                                            this.myController.Commands[this.taskIndex].Motion.MoveAbs(1, ABS_Y, 40);
                                        }
                                        if (Allow_Z)
                                        {
                                            this.myController.Commands[this.taskIndex].Motion.MoveAbs(2, ABS_Z, 20);
                                        }
                                        DEMO_flag_2CUT = 22;
                                    }
                                    else
                                    {

                                        MessageBox.Show($"z軸高度計算後超出安全高度({zlimit}): {ABS_Z}", "z軸高度軟體限制",
                                                     MessageBoxButtons.OK, MessageBoxIcon.Error);
                                        WriteLog("Thread", "_thread.ini", $"z軸高度計算後超出安全高度({ zlimit}): { ABS_Z}");
                                        DEMO_flag_2CUT = 0;

                                    }



                                }
                            }
                            else
                            {
                                DEMO_flag_2CUT = 26;
                            }
                        }
                    }

                    break;
                case 22:
                    //判斷值控是否到定位
                    //this.Invoke(new Action<NewDiagPacketArrivedEventArgs>(SetAxisState));
                    if (myController.Commands.Motion.WaitForMotionDone(Aerotech.A3200.Commands.WaitOption.InPosition, 0, 2000) && myController.Commands.Motion.WaitForMotionDone(Aerotech.A3200.Commands.WaitOption.InPosition, 1, 2000) && myController.Commands.Motion.WaitForMotionDone(Aerotech.A3200.Commands.WaitOption.InPosition, 2, 2000))
                    {

                        if (Motion_X && Motion_Y && Motion_Z)
                        {

                            Thread.Sleep(10);

                            DEMO_flag_2CUT = 23;
                        }
                    }
                    else
                    {
                        DEMO_flag_2CUT = 22;
                    }
                    break;
                case 23:

                    Thread.Sleep(10);

                    //尾部圖層
                    if (!_isLaserScannerBusy)
                    {
                        if (!DoLaserProcessing()) // 執行一次並取得回傳結果是true 或是false
                        {
                            DoLaserReconnect();//重新連線
                        }

                    }


                    if (!_isLaserScannerBusy && _FormLaserScanner.States.PLC_JOB_COMPLETED)//加工完成且雷射狀態為true
                    {
                        DEMO_flag_2CUT = 24;
                    }


                    break;
                case 24:
                    DEMO_flag_2CUT = 25;//DELAY
                    break;

                case 25:
                    //DELAY

                    DEMO_flag_2CUT = 26;

                    break;
                case 26:
                    Thread.Sleep(10);

                    DEMO_flag_2CUT = 3;
                    break;

                case 3:
                    //判斷是否切完
                    if (!RB_NS_ShortPitch.Checked && !RB_BR_ShortPitch.Checked)
                    {
                        process_2CUT_TIP_i++;
                    }
                    else
                    {
                        process_2CUT_TIP_i += 2;
                    }

                    if (process_2CUT_TIP_i >= process_2CUT_TIP_END)
                    {
                        //DEMO_flag_2CUT = 5;//出料

                        if (cb_smallbox_switch.Checked == true)
                        {
                            if (small_TotalNumber_2CUT == 0)
                                DEMO_flag_2CUT = 5;
                            else
                                DEMO_flag_2CUT = 4;//出料
                        }
                        else
                        {
                            DEMO_flag_2CUT = 5;//出料
                        }
                    }
                    else
                    {
                        DEMO_flag_2CUT = 21;//回到軸控,針尾到下一個座標
                    }




                    break;
                case 4:
                    DEMO_flag_2CUT = 400;
                    break;

                case 5:
                    //結束,出料
                    //this.Invoke(new Action<NewDiagPacketArrivedEventArgs>(SetAxisState));
                    if (myController.Commands.Motion.WaitForMotionDone(Aerotech.A3200.Commands.WaitOption.InPosition, 0, 2000) && myController.Commands.Motion.WaitForMotionDone(Aerotech.A3200.Commands.WaitOption.InPosition, 1, 2000) && myController.Commands.Motion.WaitForMotionDone(Aerotech.A3200.Commands.WaitOption.InPosition, 2, 2000))
                    {
                        if (Motion_X && Motion_Y && Motion_Z)
                        {
                            enableProcessGas(false);


                            //ABS_X = Convert.ToDouble(point_position[3, 0]);
                            //ABS_Y = Convert.ToDouble(point_position[3, 1]);
                            //ABS_Z = Convert.ToDouble(point_position[3, 2]);
                            //Allow_X = Allow_Y = Allow_Z = true;
                            //if (ABS_Z> zlimit)
                            //{

                            //    if (Allow_X)
                            //    {
                            //        this.myController.Commands[this.taskIndex].Motion.MoveAbs(0, ABS_X, 40);
                            //    }
                            //    if (Allow_Y)
                            //    {
                            //        this.myController.Commands[this.taskIndex].Motion.MoveAbs(1, ABS_Y, 40);
                            //    }
                            //    if (Allow_Z)
                            //    {
                            //        this.myController.Commands[this.taskIndex].Motion.MoveAbs(2, ABS_Z, 15);
                            //    }

                            //}
                            //else
                            //{

                            //    MessageBox.Show($"z軸高度計算後超出安全高度(-260): {ABS_Z}", "z軸高度軟體限制",
                            //                 MessageBoxButtons.OK, MessageBoxIcon.Error);
                            //    DEMO_flag_2CUT = 0;

                            //}


                            WriteLog("Thread", "_thread.ini", $"2切加工完成");



                            //參數紀錄
                            record_update.End();

                            record_update.Save_Log();

                            record_update.Clear();

                            //MES上報
                            // MES_Waiting(chpt_mes.Description_Message[(int)MES_Description.ProcessEnd]);

                            Thread.Sleep(500);

                            prog_status = "2切完成";
                            START_flag_2CUT = false;
                            this.Invoke(new dGP_Relese(GP_relese));
                            DEMO_flag_2CUT = 0;

                            NG2Cut.Clear();

                            if (cb_smallbox_switch.Checked == true && process_smallbox_ng > 0)
                                MessageBox.Show("方框辨識共有:" + (process_smallbox_ng).ToString() + "個NG");


                            if (Demo_Test_2CUT != null)
                            {
                                Auto_Load = false;//將掃碼自動載檔旗標取消

                                //   tb_time_R.Text = "0";
                                // textBox_HoleRemain.Text = "0";


                                //20260324冠璋要求重置按鈕按下時路徑都不清除，除非重新刷barcode代入
                                /*TB_LoadFilePath.Clear();//清除一切路徑檔
                                TB_LoadFilePath_2CUT.Clear();//清除二切路徑檔
                                tb_PRRLCN.Clear();//清除二切連棟檔路徑*/

                                //[BM:LCH二切功能-嘗試優化安全退出執行續而不是強制退出]
                                //Demo_Test_2CUT.Abort();
                                _isDemo_Test_2CUT = false;
                            }
                        }
                    }

                    break;
                case 6:
                    break;
                case 7:
                    break;
                case 8:
                    break;
                case 9:
                    break;


            }
        }


        #endregion

        #region class
        public class Buffer_Xml_Element
        {
            public string Sub_Data = "銅箔參數";
            public string Max_Column = "銅箔行數";
            public string Max_Row = "銅箔列數";
            public string Max_Pin = "每區針數";
            public string Total_Pin = "總針數";
            public string Save_Time = "紀錄時間";

            public string Data = "二切NG針";
            //public string No = "編號";
            public string Column = "行";
            public string Row = "列";
            public string Side = "正反面";
            public string Pin_Number = "第幾根針";
            public string LNC_Run_Pin = "LCN切割位置";
        }

        public class N_PRRLCN
        {
            public List<bool> ProbeResult;
            public List<string> ProbeNumber;
            public int TotalNumber;
            public int OKPinNumber;

            public N_PRRLCN()
            {
                ProbeNumber = new List<string>();
                ProbeResult = new List<bool>();
                TotalNumber = 0;
                OKPinNumber = 0;
            }

            public void Claer()
            {
                if (ProbeResult != null)
                    ProbeResult.Clear();

                if (ProbeNumber != null)
                    ProbeNumber.Clear();

                TotalNumber = 0;
                OKPinNumber = 0;
            }
        }
        class classSystem
        {
            //[DllImport("ColorFilter", SetLastError = true, CharSet = CharSet.Auto)]
            //public static extern double ColorReg(IntPtr lngImageAddress, IntPtr lngImageSizeX, IntPtr lngImageSizeY, IntPtr lngXs, IntPtr lngYs, IntPtr lngXe, IntPtr lngYe, ref GetColorExtract GetColor);
            //[DllImport("ColorFilter", SetLastError = true, CharSet = CharSet.Auto)]
            //public static extern double ColorExtract(IntPtr lngImageAddress1, IntPtr lngImageAddress2, IntPtr lngImageSizeX, IntPtr lngImageSizeY, IntPtr lngXs, IntPtr lngYs, IntPtr lngXe, IntPtr lngYe, ref GetColorExtract GetColor);



            //unsafe public struct GetColorExtract
            //{
            //    public long lRedMax;
            //    public long lRedMin;
            //    public long lGreenMax;
            //    public long lGreenMin;
            //    public long lBlueMax;
            //    public long lBlueMin;
            //}

            //public class GetColorExtract
            //{

            //    public long lRedMax ;//{ get; set; }
            //    public long lRedMin ;//{ get; set; }
            //    public long lGreenMax ;//{ get; set; }
            //    public long lGreenMin ;//{ get; set; }
            //    public long lBlueMax ;//{ get; set; }
            //    public long lBlueMin ;//{ get; set; }
            //}

            public struct ColorResult
            {
                public long lRed;
                public long lGreen;
                public long lBlue;
            }

            public struct RECT
            {
                public long Xs;
                public long Ys;
                public long Xe;
                public long Ye;
            }

            public struct Point
            {
                public long X;
                public long Y;
            }

            public static long tempZoro1 { get; set; }
            public static long tempZoro2 { get; set; }
            public static long tempXe { get; set; }
            public static long tempYe { get; set; }

            //public static GetColorExtract[] GetColor = new GetColorExtract[5];
            //public static GetColorExtract SetColor ;
            // public static FvRectangle RegColorRect = new FvRectangle();

            public static long[] ImageSize = new long[6];
            public static long[] ImageSizeX = new long[6];
            public static long[] ImageSizeY = new long[6];
            // public static FvPoint[] ImageCent = new FvPoint[6];

            public static double[] DispSize = new double[6];
            public static double[] DispSize2 = new double[6];
            public static int ComportN;
            public static int varDigitalShift;

            public static long i;
            public static long j;
            // public static FvRectangle[,] SearchArea = new FvRectangle[6,9];

            //public static FileSystemObject FSO; //temp

            //影像框顯示文字
            // public static FvPoint DrawPos = new FvPoint();
            public static string DrawText;
            //public static FvRectangle DrawRect = new FvRectangle();

            //滑鼠控制
            // public static FvPoint ControlPoint= new FvPoint();
            // public static FvPoint[] MousePos = new FvPoint[3];
            public static bool MouseDown;

            public static int RegAreaType; //登錄框樣式
                                           //public static FvRectangle[] SetArea = new FvRectangle[10];
            public static int SetAreaPos;
            // public static FvPoint SetAreaOrigin = new FvPoint();
            public static long RetVal;
            public static double ScanTime;
            public static bool[] PatReg = new bool[6];

            //public static FvRectangle PatArea = new FvRectangle();
            //public static FvRectangle PatArea2 = new FvRectangle();
            public static bool IsLightOn;

            public static MessageBoxButtons buttons = MessageBoxButtons.YesNo;
            public static DialogResult result = new DialogResult();

            //影像前處理
            public static double[] GammaVal = new double[6];
            public static double[] BrightVal = new double[6];
            public static double[] ContrastVal = new double[6];

            public static int CameraNo;
            public static bool RegMode;
            public static int RegType;
            public static int CamPos;
            public static int PatPos;
            public static int PatNum;
            public static int PatPosTMP;
            public static int ColorCVPos;
            public static bool VideoOpen;

            //顯示
            //public static FvLineSegment[] DrawLine = new FvLineSegment[2];
            //public static FvPoint[] DrawPoint = new FvPoint[6];
            public static bool Check_LoadBMP_state;
            public static bool Check_GigE_state;


            //檢查
            public static int[] BinLevel = new int[6];
            public static int BinLevel2;
            public static int[] BinLevelSave = new int[6];
            public static int[] ColorRange = new int[6];
            public static int[,] GetColorMax = new int[5, 5];
            public static int[,] GetColorMin = new int[5, 5];
            public static long[] PatScore = new long[6];
            public static long[] PatSize = new long[6];
            public static long[] PatAngle = new long[6];


            public static int[] BinColor = new int[6];
            public static int BinColor2;
            public static long[] BinAreaMax = new long[6];
            public static long[] BinAreaMin = new long[6];
            public static long[] BinAreaMaxSave = new long[6];
            public static long[] BinAreaMinSave = new long[6];
            public static long BinAreaMax2;
            public static long BinAreaMin2;
            public static long[] BinJudgeMax = new long[6];
            public static long[] BinJudgeMin = new long[6];
            public static long[] BinJudgeNum = new long[6];

            public static int EdgeLineWidth;
            //public static FvBlobResult GetBlobResult = new FvBlobResult();
            //public static FvBlobResult GetBlobResultTMP = new FvBlobResult();
            //public static FvBlobResultGroup GetBlobResultGroup = new FvBlobResultGroup();
            //public static FvBlobResultGroup[] GetBlobResultGroupSave = new FvBlobResultGroup[6];

            //public static FvPoint[] GetPoint = new FvPoint[4] ;
            public static double[,] GetPointTMP = new double[3, 3];

            public static long nCount;
            public static long[] nCountSave = new long[6];

            public static long[,] EdgeColor = new long[6, 3];
            public static long[,] EdgeThresh = new long[6, 3];

            public static bool[,] SearchOK = new bool[6, 5];
            public static bool CamShutChange;

            //public static FvLineSegment CheckLine = new FvLineSegment();

            //public static FvEdgeResultGroup[] EdgeResult = new FvEdgeResultGroup[6];
            //public static FvLine[,] GetEdgeLine = new FvLine[6,7];
            //public static FvLine[] GetEdgeLineTMP = new FvLine[2];
            //public static FvEdgeResult CheckResult = new FvEdgeResult();

            public static int EdgePos;
            public static bool[] SearchEdgeOK = new bool[3];
            //public static FvSearchResult[] SearchResult = new FvSearchResult[13];
            //public static FvSearchResult[] SearchResultTMP = new FvSearchResult[6];

            //public static FvCircle GetCir = new FvCircle();
            public static int[] BinJudgePos = new int[6];


            public static int EdgeDir;

            public static double GetDistLim;
            public static double GetDistMax;
            public static double[] GetDist = new double[3];

            //對位
            //public static FvPoint[] TargetPos = new FvPoint[6];
            //public static FvPoint[] TargetPos_ = new FvPoint[6];
            //public static FvPoint[] TargetPos2 = new FvPoint[6];
            //public static FvPoint[,] ObjectPos = new FvPoint[6,1501];

            //檔案
            public static int TypeNo;
            public static string TypeName;
            public static bool LoadState;
            public static string LabTMP;

            public static int ret;
            public static StringBuilder buff1;
            public static string FilePath;

            public static string PatPath;
            public static string FolderPath;
            public static long SUCCESS;
            public static string[] TmpData = new string[51];
            public static string FilePath_2;
            public static string FilePath_Log;
            public static string FilePath_Via_num;
            public static string CamFilePath;
            public static string path, path_SetUp, path_ori, path_DoneNum;
            public static string path_thickness, path_Data;

            public static string System_Path, sys_path_setup, sys_path_ori, sys_path_point;
            public static string CarbidePowerList;

            //稼動率統計20200810
            public static string path_WorkList;

            public static string path_cal_pos;
            //通信
            public static string[] SendData = new string[12];
            public static string[] SendData2 = new string[11];
            public static byte[] SendData3 = new byte[17];
            //public static byte[] SendData4 = new byte[1];
            public static byte SendData4;
            public static string[] SendData5 = new string[17];
            public static string SendData6;
            public static bool ComOpen;
            public static int ServerState; // closed:0, open:1 
            public static bool[] ComOpen2 = new bool[3];
            public static string[] ParaData = new string[11];
            public static bool Pended;

            //Winsock
            public static string ConnectIP;
            public static long ConnectPort;
            public static long ConnectTimeout;
            public static int ConnectState;
            public static bool ConnectOpen;
            public static int ConnectMode;
            public static bool ConnectTimer;

            //Winsock接收Data
            public static string eResverData;
            public static string receive;
            public static string StrData;
            public static int receiveCount;

            public static string[] ComBufferPos = new string[4];
            public static string[] ComBuffer = new string[5];
            public static string BalanceWhiteRaw;
            public static string FeatureName;
            public static string val1;


            public static string[] CommList = new string[21];
            public static int CommListPos;
            public static int CommListNum;
            public static int CommNum;

            //public static FvPoint[,] RegCalcPos = new FvPoint[6,7];
            //public static FvPoint[] RegCompPos =  new FvPoint[6];

            public static double[] CV = new double[10];
            public static double[] CV_Pixel = new double[10];
            public static double[] CV_Size = new double[10];
            public static double[] GetAngle = new double[6];

            public static bool[] RegTargetOK = new bool[6];

            public static int GetPinPos;
            //public static FvPoint[] GetPinOffset = new FvPoint[6];

            public static string[] OutData = new string[5];

            public static Boolean pass_flag;
        }
        public class Record_Update
        {
            public string Log_Date;                         //日期紀錄
            public string Process;                          //加工製程
            public string Mathine_Name;                     //機台代碼
            public string Part_Number;                      //料號
            public string Batch_Number;                     //批號
            public string Serial_Number;                    //批號-序號
            public string Product_Name;                     //品名
            public string Pin_Length;                       //針長
            public string Pin_Length_Unit;                  //針長單位
            public DateTime Start_Time;                     //加工開始時間
            public DateTime End_Time;                       //加工結束時間
            public double Total_Time;                       //加工時間
            public string Total_Time_Unit;                  //加工時間單位
            public string Total_Pin;                        //加工總數
            public string Total_Pin_Unit;                   //加工總數單位
            public string Laser_Process_File;               //雷射加工檔案
            public string Laser_Pos_File;                   //雷射座標檔
            public string Laser_Power;                      //雷射功率
            public string Laser_Power_Unit;                 //雷射功率單位

            private string[] process_l = new string[6];     //加工製程List
            private string buffer_file;                     //buffer存檔位置
            private string buffer_path;                     //buffer檔名
            private string Record_File;                     //Log存檔位置

            public Record_Update()
            {
                //加工製程
                process_l[0] = "雷射成型";
                process_l[1] = "雷射切針";
                process_l[2] = "測高";
                process_l[3] = "視覺";
                process_l[4] = "撈外框";
                process_l[5] = "導版序號";

                //暫存檔路徑
                buffer_file = Application.StartupPath + "\\RecordBuffer\\";
                buffer_path = "record_buffer.ini";
                //Log路徑
                //Record_File = Application.StartupPath + "\\Production_Record\\";
                //Record_File = Environment.GetFolderPath(Environment.SpecialFolder.Desktop) + "\\Production_Record\\";//LOG存放於桌面
                Record_File = "D:\\mes\\mo_log\\";//LOG存放於D槽

                //針長單位
                Pin_Length_Unit = "mm";
                //加工時間單位
                Total_Time_Unit = "Min";
                //加工總數單位
                Total_Pin_Unit = "PCS";
                //雷射功率單位
                Laser_Power_Unit = "W";
            }

            public void Clear()
            {
                Log_Date = "";
                Mathine_Name = "";
                Part_Number = "";
                Batch_Number = "";
                Serial_Number = "";
                Product_Name = "";
                Pin_Length = "";
                //Pin_Length_Unit = "";
                Total_Time = 0;
                //Total_Time_Unit = "";
                Total_Pin = "";
                Laser_Process_File = "";
                Laser_Pos_File = "";
                Laser_Power = "";
                //Laser_Power_Unit = "";
            }

            public void Start(int process, string mathine_name, string part_number, string batch_number, string serial_number, string product_name, string pin_length, string total_pin, string laser_Process_file, string laser_Pos_file, string laser_power)
            {
                //紀錄日期
                Log_Date = DateTime.Now.ToString("yyyy/MM/dd");
                //加工製程
                Process = process_l[process];
                //機台代碼
                Mathine_Name = mathine_name;
                //料號
                Part_Number = part_number;
                //批號
                Batch_Number = batch_number;
                //批號-序號
                Serial_Number = serial_number;
                //品名
                Product_Name = product_name;
                //針長
                Pin_Length = pin_length;
                //開始時間
                Start_Time = DateTime.Now;
                //加工總數
                Total_Pin = total_pin;
                //雷射加工檔案
                Laser_Process_File = laser_Process_file;
                //雷射加工座標
                Laser_Pos_File = laser_Pos_file;
                //功率設定
                Laser_Power = laser_power;
            }

            public void End()
            {
                //結束時間
                End_Time = DateTime.Now;
                //加工時間
                TimeSpan tt = End_Time - Start_Time;
                Total_Time = tt.TotalMinutes;
            }

            public bool Save_Buffer()
            {
                try
                {
                    if (!File.Exists(buffer_file))
                    {
                        Directory.CreateDirectory(buffer_file);
                    }
                    WritePrivateProfileString("Record", "日期紀錄", Log_Date, buffer_file + buffer_path);
                    WritePrivateProfileString("Record", "加工製程", Process, buffer_file + buffer_path);
                    WritePrivateProfileString("Record", "機台碼", Mathine_Name, buffer_file + buffer_path);
                    WritePrivateProfileString("Record", "料號", Part_Number, buffer_file + buffer_path);
                    WritePrivateProfileString("Record", "批號", Batch_Number, buffer_file + buffer_path);
                    WritePrivateProfileString("Record", "批號-序號", Serial_Number, buffer_file + buffer_path);
                    WritePrivateProfileString("Record", "品名", Product_Name, buffer_file + buffer_path);
                    WritePrivateProfileString("Record", "針長度", Pin_Length, buffer_file + buffer_path);
                    WritePrivateProfileString("Record", "加工開始時間", Start_Time.ToString("o"), buffer_file + buffer_path);
                    WritePrivateProfileString("Record", "加工總數", Total_Pin, buffer_file + buffer_path);
                    WritePrivateProfileString("Record", "雷射加工檔案", Laser_Process_File, buffer_file + buffer_path);
                    WritePrivateProfileString("Record", "雷射座標檔", Laser_Pos_File, buffer_file + buffer_path);
                    WritePrivateProfileString("Record", "雷射加工功率", Laser_Power, buffer_file + buffer_path);

                    return true;
                }
                catch
                {
                    return false;
                }
            }

            public void Load_Buffer()
            {
                Log_Date = IniReadValue("Record", "日期紀錄", buffer_file + buffer_path);
                Process = IniReadValue("Record", "加工製程", buffer_file + buffer_path);
                Mathine_Name = IniReadValue("Record", "機台碼", buffer_file + buffer_path);
                Part_Number = IniReadValue("Record", "料號", buffer_file + buffer_path);
                Batch_Number = IniReadValue("Record", "批號", buffer_file + buffer_path);
                Serial_Number = IniReadValue("Record", "批號-序號", buffer_file + buffer_path);
                Product_Name = IniReadValue("Record", "品名", buffer_file + buffer_path);
                Pin_Length = IniReadValue("Record", "針長度", buffer_file + buffer_path);

                string s_t;
                s_t = IniReadValue("Record", "加工開始時間", buffer_file + buffer_path);
                Start_Time = DateTime.Parse(s_t, null, DateTimeStyles.RoundtripKind);

                Total_Pin = IniReadValue("Record", "加工總數", buffer_file + buffer_path);
                Laser_Process_File = IniReadValue("Record", "雷射加工檔案", buffer_file + buffer_path);
                Laser_Pos_File = IniReadValue("Record", "雷射座標檔", buffer_file + buffer_path);
                Laser_Power = IniReadValue("Record", "雷射加工功率", buffer_file + buffer_path);
            }

            public void Save_Log()
            {
                //設定日期檔案
                string now_day_name;
                string before_day_name;

                now_day_name = End_Time.ToString("yyyyMMdd") + ".txt";
                before_day_name = Start_Time.ToString("yyyyMMdd") + ".txt";

                if (now_day_name == before_day_name)
                {
                    string log;

                    log = Log_Date + "," +
                          Process + "," +
                          Mathine_Name + "," +
                          Part_Number + "," +
                          Batch_Number + "," +
                          Serial_Number + "," +
                          Product_Name + "," +
                          Pin_Length + "," +
                          Pin_Length_Unit + "," +
                          Start_Time.ToString("yyyy/MM/dd HH:mm") + "," +
                          End_Time.ToString("yyyy/MM/dd HH:mm") + "," +
                          Convert.ToUInt16(Total_Time) + "," +
                          Total_Time_Unit + "," +
                          Total_Pin + "," +
                          Total_Pin_Unit + "," +
                          Laser_Process_File + "," +
                          Laser_Pos_File + "," +
                          Laser_Power + "," +
                          Laser_Power_Unit;

                    if (!File.Exists(Record_File))
                    {
                        Directory.CreateDirectory(Record_File);
                    }

                    StreamWriter sw = new StreamWriter(Record_File + now_day_name, true);
                    sw.WriteLine(log);
                    sw.Close();
                }
                else
                {
                    string log;

                    log = Log_Date + "," +
                          Process + "," +
                          Mathine_Name + "," +
                          Part_Number + "," +
                          Batch_Number + "," +
                          Serial_Number + "," +
                          Product_Name + "," +
                          Pin_Length + "," +
                          Pin_Length_Unit + "," +
                          Start_Time.ToString("yyyy/MM/dd HH:mm") + "," +
                          End_Time.ToString("yyyy/MM/dd HH:mm") + "," +
                          Convert.ToUInt16(Total_Time) + "," +
                          Total_Time_Unit + "," +
                          Total_Pin + "," +
                          Total_Pin_Unit + "," +
                          Laser_Process_File + "," +
                          Laser_Pos_File + "," +
                          Laser_Power + "," +
                          Laser_Power_Unit;

                    if (!File.Exists(Record_File))
                    {
                        Directory.CreateDirectory(Record_File);
                    }

                    //結束日期的Log
                    StreamWriter sw1 = new StreamWriter(Record_File + now_day_name, true);
                    sw1.WriteLine(log);
                    sw1.Close();

                    //開始日期的Log
                    StreamWriter sw2 = new StreamWriter(Record_File + before_day_name, true);
                    sw2.WriteLine(log);
                    sw2.Close();
                }
            }


            [DllImport("kernel32", CharSet = CharSet.Unicode)]
            private static extern long WritePrivateProfileString(string section, string key, string val, string filePath);
            [DllImport("kernel32", CharSet = CharSet.Unicode)]
            private static extern int GetPrivateProfileString(string section, string key, string def, StringBuilder retVal, int size, string filePath);
            private static string IniReadValue(string Section, string Key, string path)
            {
                StringBuilder temp = new StringBuilder(255);
                int i = GetPrivateProfileString(Section, Key, "", temp, 255, path);
                return temp.ToString();
            }
        }
        private CancellationTokenSource cts;


        class classFile
        {
            [DllImport("kernel32", CharSet = CharSet.Unicode)]
            private static extern long WritePrivateProfileString(string section, string key, string val, string filePath);
            [DllImport("kernel32", CharSet = CharSet.Unicode)]
            private static extern int GetPrivateProfileString(string section, string key, string def, StringBuilder retVal, int size, string filePath);

            public static void LoadFile()
            {

                classSystem.System_Path = @"C:\LCH_system";
                if (!File.Exists(classSystem.System_Path)) { Directory.CreateDirectory(classSystem.System_Path); } //判斷system資料夾
                classSystem.FolderPath = Application.StartupPath + "\\Files\\";
                if (!File.Exists(classSystem.FolderPath)) { Directory.CreateDirectory(classSystem.FolderPath); } //如果File資料夾不存在
                classSystem.FolderPath = Application.StartupPath + "\\Image\\";
                if (!File.Exists(classSystem.FolderPath)) { Directory.CreateDirectory(classSystem.FolderPath); } //如果Image資料夾不存在
                classSystem.FolderPath = Application.StartupPath + "\\Log\\";
                if (!File.Exists(classSystem.FolderPath)) { Directory.CreateDirectory(classSystem.FolderPath); } //如果Log資料夾不存在
                classSystem.FolderPath = Application.StartupPath + "\\System\\";
                if (!File.Exists(classSystem.FolderPath)) { Directory.CreateDirectory(classSystem.FolderPath); } //如果System資料夾不存在
                classSystem.FolderPath = Application.StartupPath + "\\CAM\\";
                if (!File.Exists(classSystem.FolderPath)) { Directory.CreateDirectory(classSystem.FolderPath); } //如果CAM資料夾不存在
                classSystem.FolderPath = Application.StartupPath + "\\Data\\";
                if (!File.Exists(classSystem.FolderPath)) { Directory.CreateDirectory(classSystem.FolderPath); } //如果CAM資料夾不存在

                classSystem.FolderPath = Application.StartupPath + "\\稼動率\\";
                if (!File.Exists(classSystem.FolderPath)) { Directory.CreateDirectory(classSystem.FolderPath); } //如果 稼動率 資料夾不存在

                classSystem.path_thickness = Application.StartupPath + "\\Log\\";
                classSystem.path_Data = Application.StartupPath + "\\Data\\";
                classSystem.path = Application.StartupPath + "\\System\\";
                classSystem.path_SetUp = Application.StartupPath + "\\System\\";


                classSystem.path_cal_pos = Application.StartupPath + "\\System\\cal_pos.ini";

                classSystem.CamFilePath = Application.StartupPath + "\\CAM\\";
                classSystem.FilePath = Application.StartupPath + "\\System\\System.ini";
                classSystem.buff1 = new StringBuilder(256);
                classSystem.ret = GetPrivateProfileString("Type", "TypeNo", "1", classSystem.buff1, 256, classSystem.FilePath);
                classSystem.TypeNo = int.Parse(classSystem.buff1.ToString()) - 1;
                classSystem.FilePath_2 = Application.StartupPath + "\\System\\";
                classSystem.FilePath_Log = Application.StartupPath + "\\Log\\";
                classSystem.FilePath_Via_num = Application.StartupPath + "\\Log\\Via_lose.ini";

                classSystem.path_ori = Application.StartupPath + "\\System\\origin.ini";
                classSystem.path_DoneNum = Application.StartupPath + "\\System\\已加工.ini";


                //20230207修改成路徑預設為桌面  DC
                //classSystem.path_WorkList = Application.StartupPath + "\\稼動率\\";
                classSystem.path_WorkList = Environment.GetFolderPath(Environment.SpecialFolder.Desktop) + "\\稼動率\\";
                if (!File.Exists(classSystem.path_WorkList)) { Directory.CreateDirectory(classSystem.path_WorkList); }

                classSystem.sys_path_setup = "SetUp.ini";
                classSystem.sys_path_point = "point_save.ini";
                classSystem.sys_path_ori = "origin.ini";
                classSystem.CarbidePowerList = "CarbidePowerList.ini";

                //for ( int i = 0 ; i<=5 ; i++ ) 
                //{
                //    classSystem.ret = GetPrivateProfileString("System", "CamRot(" + i + ")", "0", classSystem.buff1, 256, classSystem.FilePath) ;
                //    classGigImage.CamRot[i] = double.Parse(classSystem.buff1.ToString() ) ;
                //    classArray.CamRot_Set[i].Text = Convert.ToString(classGigImage.CamRot[i]);
                //} // for

                //檔案路徑o
                if (classSystem.TypeNo < 9)
                    classSystem.FilePath = Application.StartupPath + "\\Files\\File00" + (classSystem.TypeNo + 1) + ".ini";
                if (classSystem.TypeNo >= 9 && classSystem.TypeNo < 99)
                    classSystem.FilePath = Application.StartupPath + "\\Files\\File0" + (classSystem.TypeNo + 1) + ".ini";
                if (classSystem.TypeNo >= 99)
                    classSystem.FilePath = Application.StartupPath + "\\Files\\File" + (classSystem.TypeNo + 1) + " .ini";

                classSystem.ret = GetPrivateProfileString("Check", "BinLevel2", "128", classSystem.buff1, 256, classSystem.FilePath); // 檢查方式
                classSystem.BinLevel2 = int.Parse(classSystem.buff1.ToString());
                classSystem.ret = GetPrivateProfileString("Check", "BinColor2", "0", classSystem.buff1, 256, classSystem.FilePath); // 檢查方式
                classSystem.BinColor2 = int.Parse(classSystem.buff1.ToString());
                classSystem.ret = GetPrivateProfileString("Check", "BinAreaMax2", "10000", classSystem.buff1, 256, classSystem.FilePath);// 檢查方式
                classSystem.BinAreaMax2 = long.Parse(classSystem.buff1.ToString());
                classSystem.ret = GetPrivateProfileString("Check", "BinAreaMin2", "10", classSystem.buff1, 256, classSystem.FilePath);// 檢查方式
                classSystem.BinAreaMin2 = long.Parse(classSystem.buff1.ToString());


                classSystem.ret = GetPrivateProfileString("Check", "SearchArea(3,8).xs", "270", classSystem.buff1, 256, classSystem.FilePath); // 檢查方式
                                                                                                                                               // classSystem.SearchArea[3, 8].xs = double.Parse(classSystem.buff1.ToString());
                classSystem.ret = GetPrivateProfileString("Check", "SearchArea(3,8).ys", "190", classSystem.buff1, 256, classSystem.FilePath); // 檢查方式
                                                                                                                                               // classSystem.SearchArea[3, 8].ys = double.Parse(classSystem.buff1.ToString());
                classSystem.ret = GetPrivateProfileString("Check", "SearchArea(3,8).xe", "370", classSystem.buff1, 256, classSystem.FilePath); // 檢查方式
                                                                                                                                               // classSystem.SearchArea[3, 8].xe = double.Parse(classSystem.buff1.ToString());
                classSystem.ret = GetPrivateProfileString("Check", "SearchArea(3,8).ye", "290", classSystem.buff1, 256, classSystem.FilePath); // 檢查方式
                                                                                                                                               // classSystem.SearchArea[3, 8].ye = double.Parse(classSystem.buff1.ToString());

                for (int i = 0; i <= 5; i++)
                {
                    classSystem.ret = GetPrivateProfileString("Align", "TargetPos(" + i + ").x", Convert.ToString(classSystem.ImageSizeX[i] / 2), classSystem.buff1, 256, classSystem.FilePath); //檢查方式
                                                                                                                                                                                                 //  classSystem.TargetPos[i].x = double.Parse( classSystem.buff1.ToString() );
                    classSystem.ret = GetPrivateProfileString("Align", "TargetPos(" + i + ").y", Convert.ToString(classSystem.ImageSizeY[i] / 2), classSystem.buff1, 256, classSystem.FilePath); //檢查方式
                                                                                                                                                                                                 // classSystem.TargetPos[i].y = double.Parse( classSystem.buff1.ToString() );

                    classSystem.ret = GetPrivateProfileString("Align", "TargetPos2(" + i + ").x", Convert.ToString(classSystem.ImageSizeX[i] / 2), classSystem.buff1, 256, classSystem.FilePath);//檢查方式
                                                                                                                                                                                                 //classSystem.TargetPos2[i].x = Convert.ToDouble( classSystem.buff1.ToString() );
                    classSystem.ret = GetPrivateProfileString("Align", "TargetPos2(" + i + ").y", Convert.ToString(classSystem.ImageSizeY[i] / 2), classSystem.buff1, 256, classSystem.FilePath); //檢查方式
                                                                                                                                                                                                  // classSystem.TargetPos2[i].y = Convert.ToDouble( classSystem.buff1.ToString() );

                    classSystem.ret = GetPrivateProfileString("Check", "RegCompPos(" + i + ").X", "0", classSystem.buff1, 256, classSystem.FilePath);//檢查方式
                                                                                                                                                     //classSystem.RegCompPos[i].x = double.Parse( classSystem.buff1.ToString() );
                    classSystem.ret = GetPrivateProfileString("Check", "RegCompPos(" + i + ").Y", "0", classSystem.buff1, 256, classSystem.FilePath); // 檢查方式
                                                                                                                                                      // classSystem.RegCompPos[i].y = double.Parse( classSystem.buff1.ToString() );

                    classSystem.ret = GetPrivateProfileString("Check", "BinLevel(" + i + ")", "128", classSystem.buff1, 256, classSystem.FilePath); // 檢查方式
                    classSystem.BinLevel[i] = int.Parse(classSystem.buff1.ToString());
                    classSystem.ret = GetPrivateProfileString("Check", "BinColor(" + i + ")", "0", classSystem.buff1, 256, classSystem.FilePath); // 檢查方式
                    classSystem.BinColor[i] = int.Parse(classSystem.buff1.ToString());
                    classSystem.ret = GetPrivateProfileString("Check", "BinAreaMax(" + i + ")", "10000", classSystem.buff1, 256, classSystem.FilePath);// 檢查方式
                    classSystem.BinAreaMax[i] = long.Parse(classSystem.buff1.ToString());
                    classSystem.ret = GetPrivateProfileString("Check", "BinAreaMin(" + i + ")", "10", classSystem.buff1, 256, classSystem.FilePath);// 檢查方式
                    classSystem.BinAreaMin[i] = long.Parse(classSystem.buff1.ToString());
                    classSystem.ret = GetPrivateProfileString("Check", "BinJudgeMax(" + i + ")", "10000", classSystem.buff1, 256, classSystem.FilePath);// 檢查方式
                    classSystem.BinJudgeMax[i] = long.Parse(classSystem.buff1.ToString());
                    classSystem.ret = GetPrivateProfileString("Check", "BinJudgeMin(" + i + ")", "10", classSystem.buff1, 256, classSystem.FilePath);// 檢查方式
                    classSystem.BinJudgeMin[i] = long.Parse(classSystem.buff1.ToString());
                    classSystem.ret = GetPrivateProfileString("Check", "BinJudgeNum(" + i + ")", "1000", classSystem.buff1, 256, classSystem.FilePath);// 檢查方式
                    classSystem.BinJudgeNum[i] = long.Parse(classSystem.buff1.ToString());
                    classSystem.ret = GetPrivateProfileString("Check", "BinJudgePos(" + i + ")", "0", classSystem.buff1, 256, classSystem.FilePath); // 檢查方式
                    classSystem.BinJudgePos[i] = int.Parse(classSystem.buff1.ToString());

                    for (int j = 0; j <= 2; j++)
                    {

                        classSystem.ret = GetPrivateProfileString("Check", "SearchArea(" + i + "," + j + ").xs", "270", classSystem.buff1, 256, classSystem.FilePath); // 檢查方式
                                                                                                                                                                       // classSystem.SearchArea[i, j].xs = double.Parse(classSystem.buff1.ToString() ) ;
                        classSystem.ret = GetPrivateProfileString("Check", "SearchArea(" + i + "," + j + ").ys", "190", classSystem.buff1, 256, classSystem.FilePath); // 檢查方式
                                                                                                                                                                       // classSystem.SearchArea[i, j].ys = double.Parse(classSystem.buff1.ToString() ) ;
                        classSystem.ret = GetPrivateProfileString("Check", "SearchArea(" + i + "," + j + ").xe", "370", classSystem.buff1, 256, classSystem.FilePath); // 檢查方式
                                                                                                                                                                       // classSystem.SearchArea[i, j].xe = double.Parse(classSystem.buff1.ToString() ) ;
                        classSystem.ret = GetPrivateProfileString("Check", "SearchArea(" + i + "," + j + ").ye", "290", classSystem.buff1, 256, classSystem.FilePath); // 檢查方式
                                                                                                                                                                       // classSystem.SearchArea[i, j].ye = double.Parse(classSystem.buff1.ToString() ) ;

                        //if ( classSystem.SearchArea[i, j].xs > classSystem.ImageSizeX[i] )
                        //     classSystem.SearchArea[i, j].xs = classSystem.ImageSizeX[i] - 1 ;
                        //if ( classSystem.SearchArea[i, j].ys > classSystem.ImageSizeY[i] )
                        //     classSystem.SearchArea[i, j].ys = classSystem.ImageSizeY[i] - 1 ;
                        //if ( classSystem.SearchArea[i, j].xe > classSystem.ImageSizeX[i] )
                        //     classSystem.SearchArea[i, j].xe = classSystem.ImageSizeX[i] - 1 ;
                        //if ( classSystem.SearchArea[i, j].ye > classSystem.ImageSizeY[i] )
                        //     classSystem.SearchArea[i, j].ye = classSystem.ImageSizeY[i] - 1 ;


                        classSystem.ret = GetPrivateProfileString("Check", "EdgeColor(" + i + "," + j + ")", "0", classSystem.buff1, 256, classSystem.FilePath); // 檢查方式
                        classSystem.EdgeColor[i, j] = long.Parse(classSystem.buff1.ToString());
                        classSystem.ret = GetPrivateProfileString("Check", "EdgeThresh(" + i + "," + j + ")", "30", classSystem.buff1, 256, classSystem.FilePath); // 檢查方式
                        classSystem.EdgeThresh[i, j] = long.Parse(classSystem.buff1.ToString());

                        classSystem.ret = GetPrivateProfileString("Check", "RegCalcPos(" + i + "," + j + ").X", "0", classSystem.buff1, 256, classSystem.FilePath); // 檢查方式
                                                                                                                                                                    // classSystem.RegCalcPos[i, j].x = double.Parse( classSystem.buff1.ToString() );
                        classSystem.ret = GetPrivateProfileString("Check", "RegCalcPos(" + i + "," + j + ").Y", "0", classSystem.buff1, 256, classSystem.FilePath); // 檢查方式
                                                                                                                                                                    //classSystem.RegCalcPos[i, j].y = double.Parse( classSystem.buff1.ToString() );
                    } // for
                } // for

                for (int i = 0; i <= 9; i++)
                {
                    //解析度
                    classSystem.ret = GetPrivateProfileString("Check", "CV(" + i + ")", "1", classSystem.buff1, 256, classSystem.FilePath);  //檢查方式
                    classSystem.CV[i] = double.Parse(classSystem.buff1.ToString());
                    classSystem.ret = GetPrivateProfileString("Check", "CV_Pixel(" + i + ")", "1", classSystem.buff1, 256, classSystem.FilePath);  //檢查方式
                    classSystem.CV_Pixel[i] = double.Parse(classSystem.buff1.ToString());
                    classSystem.ret = GetPrivateProfileString("Check", "CV_Size(" + i + ")", "1", classSystem.buff1, 256, classSystem.FilePath);  //檢查方式
                    classSystem.CV_Size[i] = double.Parse(classSystem.buff1.ToString());
                } // for

                classSystem.ret = GetPrivateProfileString("Check", "GetDistLim", "1000", classSystem.buff1, 256, classSystem.FilePath);
                classSystem.GetDistLim = double.Parse(classSystem.buff1.ToString());

                for (int i = 0; i <= 4; i++)
                {
                    classSystem.BinLevel[i] = 128;

                    classSystem.ret = GetPrivateProfileString("Check", "ColorRange(" + i + ")", "0", classSystem.buff1, 256, classSystem.FilePath); //檢查方式
                    classSystem.ColorRange[i] = int.Parse(classSystem.buff1.ToString());

                    for (int j = 0; j <= 2; j++)
                    {
                        classSystem.ret = GetPrivateProfileString("Check", "GetColorMax(" + i + "," + j + ")", "255", classSystem.buff1, 256, classSystem.FilePath);  //檢查方式
                        classSystem.GetColorMax[i, j] = int.Parse(classSystem.buff1.ToString());
                        classSystem.ret = GetPrivateProfileString("Check", "GetColorMin(" + i + "," + j + ")", "0", classSystem.buff1, 256, classSystem.FilePath);  //檢查方式
                        classSystem.GetColorMin[i, j] = int.Parse(classSystem.buff1.ToString());
                    } // for

                } // for
            } // void LoadFile()

            public static void SaveSet()
            {

                // 檔案路徑
                if (classSystem.TypeNo < 9)
                    classSystem.FilePath = Application.StartupPath + "\\Files\\File00" + (classSystem.TypeNo + 1) + ".ini";
                if (classSystem.TypeNo >= 9 && classSystem.TypeNo < 99)
                    classSystem.FilePath = Application.StartupPath + "\\Files\\File0" + (classSystem.TypeNo + 1) + ".ini";
                if (classSystem.TypeNo >= 99)
                    classSystem.FilePath = Application.StartupPath + "\\Files\\File" + (classSystem.TypeNo + 1) + " .ini";

                classSystem.TmpData[0] = Convert.ToString(classSystem.BinLevel2);
                classSystem.TmpData[1] = Convert.ToString(classSystem.BinColor2);
                classSystem.TmpData[2] = Convert.ToString(classSystem.BinAreaMax2);
                classSystem.TmpData[3] = Convert.ToString(classSystem.BinAreaMin2);

                classSystem.SUCCESS = WritePrivateProfileString("Check", "BinLevel2", classSystem.TmpData[0], classSystem.FilePath);
                classSystem.SUCCESS = WritePrivateProfileString("Check", "BinColor2", classSystem.TmpData[1], classSystem.FilePath);
                classSystem.SUCCESS = WritePrivateProfileString("Check", "BinAreaMax2", classSystem.TmpData[2], classSystem.FilePath);
                classSystem.SUCCESS = WritePrivateProfileString("Check", "BinAreaMin2", classSystem.TmpData[3], classSystem.FilePath);

                for (int i = 0; i <= 5; i++)
                {
                    classSystem.TmpData[0] = Convert.ToString(classSystem.BinLevel[i]);
                    classSystem.TmpData[1] = Convert.ToString(classSystem.BinColor[i]);
                    classSystem.TmpData[2] = Convert.ToString(classSystem.BinAreaMax[i]);
                    classSystem.TmpData[3] = Convert.ToString(classSystem.BinAreaMin[i]);
                    classSystem.TmpData[4] = Convert.ToString(classSystem.BinJudgeMax[i]);
                    classSystem.TmpData[5] = Convert.ToString(classSystem.BinJudgeMin[i]);
                    classSystem.TmpData[6] = Convert.ToString(classSystem.BinJudgeNum[i]);
                    classSystem.TmpData[7] = Convert.ToString(classSystem.BinJudgePos[i]);

                    classSystem.SUCCESS = WritePrivateProfileString("Check", "BinLevel(" + i + ")", classSystem.TmpData[0], classSystem.FilePath);
                    classSystem.SUCCESS = WritePrivateProfileString("Check", "BinColor(" + i + ")", classSystem.TmpData[1], classSystem.FilePath);
                    classSystem.SUCCESS = WritePrivateProfileString("Check", "BinAreaMax(" + i + ")", classSystem.TmpData[2], classSystem.FilePath);
                    classSystem.SUCCESS = WritePrivateProfileString("Check", "BinAreaMin(" + i + ")", classSystem.TmpData[3], classSystem.FilePath);
                    classSystem.SUCCESS = WritePrivateProfileString("Check", "BinJudgeMax(" + i + ")", classSystem.TmpData[4], classSystem.FilePath);
                    classSystem.SUCCESS = WritePrivateProfileString("Check", "BinJudgeMin(" + i + ")", classSystem.TmpData[5], classSystem.FilePath);
                    classSystem.SUCCESS = WritePrivateProfileString("Check", "BinJudgeNum(" + i + ")", classSystem.TmpData[6], classSystem.FilePath);
                    classSystem.SUCCESS = WritePrivateProfileString("Check", "BinJudgePos(" + i + ")", classSystem.TmpData[7], classSystem.FilePath);

                    // classSystem.TmpData[0] = Convert.ToString(classSystem.RegCompPos[i].x) ;
                    // classSystem.TmpData[1] = Convert.ToString(classSystem.RegCompPos[i].y) ;

                    classSystem.SUCCESS = WritePrivateProfileString("Check", "RegCompPos(" + i + ").X", classSystem.TmpData[0], classSystem.FilePath);
                    classSystem.SUCCESS = WritePrivateProfileString("Check", "RegCompPos(" + i + ").Y", classSystem.TmpData[1], classSystem.FilePath);

                    for (int j = 0; j <= 2; j++)
                    {
                        //TmpData(0) = SearchScore(i, j)
                        //classSystem.TmpData[1] = Convert.ToString(classSystem.SearchArea[i, j].xs) ;
                        //classSystem.TmpData[2] = Convert.ToString(classSystem.SearchArea[i, j].ys) ;
                        //classSystem.TmpData[3] = Convert.ToString(classSystem.SearchArea[i, j].xe) ;
                        //classSystem.TmpData[4] = Convert.ToString(classSystem.SearchArea[i, j].ye) ;

                        //SUCCESS = WritePrivateProfileString("Check", "SearchScore(" & i & "," & j & ")", TmpData(0), FilePath)
                        classSystem.SUCCESS = WritePrivateProfileString("Check", "SearchArea(" + i + "," + j + ").xs", classSystem.TmpData[1], classSystem.FilePath);
                        classSystem.SUCCESS = WritePrivateProfileString("Check", "SearchArea(" + i + "," + j + ").ys", classSystem.TmpData[2], classSystem.FilePath);
                        classSystem.SUCCESS = WritePrivateProfileString("Check", "SearchArea(" + i + "," + j + ").xe", classSystem.TmpData[3], classSystem.FilePath);
                        classSystem.SUCCESS = WritePrivateProfileString("Check", "SearchArea(" + i + "," + j + ").ye", classSystem.TmpData[4], classSystem.FilePath);

                        classSystem.TmpData[0] = Convert.ToString(classSystem.EdgeColor[i, j]);
                        classSystem.TmpData[1] = Convert.ToString(classSystem.EdgeThresh[i, j]);

                        classSystem.SUCCESS = WritePrivateProfileString("Check", "EdgeColor(" + i + "," + j + ")", classSystem.TmpData[0], classSystem.FilePath);
                        classSystem.SUCCESS = WritePrivateProfileString("Check", "EdgeThresh(" + i + "," + j + ")", classSystem.TmpData[1], classSystem.FilePath);

                    } // for

                    //classSystem.TmpData[1] = Convert.ToString(classSystem.SearchArea[3, 8].xs);
                    //classSystem.TmpData[2] = Convert.ToString(classSystem.SearchArea[3, 8].ys);
                    //classSystem.TmpData[3] = Convert.ToString(classSystem.SearchArea[3, 8].xe);
                    //classSystem.TmpData[4] = Convert.ToString(classSystem.SearchArea[3, 8].ye);

                    classSystem.SUCCESS = WritePrivateProfileString("Check", "SearchArea(3,8).xs", classSystem.TmpData[1], classSystem.FilePath);
                    classSystem.SUCCESS = WritePrivateProfileString("Check", "SearchArea(3,8).ys", classSystem.TmpData[2], classSystem.FilePath);
                    classSystem.SUCCESS = WritePrivateProfileString("Check", "SearchArea(3,8).xe", classSystem.TmpData[3], classSystem.FilePath);
                    classSystem.SUCCESS = WritePrivateProfileString("Check", "SearchArea(3,8).ye", classSystem.TmpData[4], classSystem.FilePath);


                    if (i < 3)
                    {
                        classSystem.TmpData[0] = Convert.ToString(classSystem.ColorRange[i]);

                        classSystem.SUCCESS = WritePrivateProfileString("Check", "ColorRange(" + i + ")", classSystem.TmpData[0], classSystem.FilePath);

                    } // if

                    for (int j = 0; j <= 1; j++)
                    {
                        //classSystem.TmpData[0] = Convert.ToString(classSystem.RegCalcPos[i, j].x) ; 
                        //classSystem.TmpData[1] = Convert.ToString(classSystem.RegCalcPos[i, j].y) ;

                        classSystem.SUCCESS = WritePrivateProfileString("Check", "RegCalcPos(" + i + "," + j + ").X", classSystem.TmpData[0], classSystem.FilePath);
                        classSystem.SUCCESS = WritePrivateProfileString("Check", "RegCalcPos(" + i + "," + j + ").Y", classSystem.TmpData[1], classSystem.FilePath);
                    }


                } // for i++

                for (int i = 0; i <= 9; i++)
                {
                    classSystem.TmpData[0] = Convert.ToString(classSystem.CV[i]);
                    classSystem.TmpData[1] = Convert.ToString(classSystem.CV_Pixel[i]);
                    classSystem.TmpData[2] = Convert.ToString(classSystem.CV_Size[i]);

                    classSystem.SUCCESS = WritePrivateProfileString("Check", "CV(" + i + ")", classSystem.TmpData[0], classSystem.FilePath);
                    classSystem.SUCCESS = WritePrivateProfileString("Check", "CV_Pixel(" + i + ")", classSystem.TmpData[1], classSystem.FilePath);
                    classSystem.SUCCESS = WritePrivateProfileString("Check", "CV_Size(" + i + ")", classSystem.TmpData[2], classSystem.FilePath);
                } // for



                classSystem.TmpData[0] = Convert.ToString(classSystem.GetDistLim);
                classSystem.SUCCESS = WritePrivateProfileString("Check", "GetDistLim", classSystem.TmpData[0], classSystem.FilePath);


                classSystem.FilePath = Application.StartupPath + "\\System\\System.ini";

                for (int i = 0; i <= 5; i++)
                {
                    //classSystem.TmpData[0] = Convert.ToString(classGigImage.CamShutter[i]);
                    //classSystem.TmpData[1] = Convert.ToString(classGigImage.CamRot[i]);

                    classSystem.SUCCESS = WritePrivateProfileString("System", "CamShutter(" + i + ")", classSystem.TmpData[0], classSystem.FilePath);
                    classSystem.SUCCESS = WritePrivateProfileString("System", "CamRot(" + i + ")", classSystem.TmpData[1], classSystem.FilePath);

                } // for
            } // void SaveSet()

            public static void LoadPat()
            {
                int temp;


                //檔案路徑
                if (classSystem.TypeNo < 9)
                    classSystem.FilePath = Application.StartupPath + "\\Files\\File00" + (classSystem.TypeNo + 1) + ".ini";
                if (classSystem.TypeNo >= 9 && classSystem.TypeNo < 99)
                    classSystem.FilePath = Application.StartupPath + "\\Files\\File0" + (classSystem.TypeNo + 1) + ".ini";
                if (classSystem.TypeNo >= 99)
                    classSystem.FilePath = Application.StartupPath + "\\Files\\File" + (classSystem.TypeNo + 1) + " .ini";



                for (int i = 0; i <= 5; i++)
                {
                    //圖形登錄
                    classSystem.ret = GetPrivateProfileString("Pattern", "PatReg(" + i + ")", "False", classSystem.buff1, 256, classSystem.FilePath); //檢查方式
                    classSystem.PatReg[i] = Convert.ToBoolean(classSystem.buff1.ToString());

                    //尋找條件
                    classSystem.ret = GetPrivateProfileString("Pattern", "PatScore(" + i + ")", "60", classSystem.buff1, 256, classSystem.FilePath); //檢查方式
                    classSystem.PatScore[i] = long.Parse(classSystem.buff1.ToString());
                    classSystem.ret = GetPrivateProfileString("Pattern", "PatSize(" + i + ")", "0", classSystem.buff1, 256, classSystem.FilePath); //檢查方式
                    classSystem.PatSize[i] = long.Parse(classSystem.buff1.ToString());
                    classSystem.ret = GetPrivateProfileString("Pattern", "PatAngle(" + i + ")", "0", classSystem.buff1, 256, classSystem.FilePath); //檢查方式
                    classSystem.PatAngle[i] = long.Parse(classSystem.buff1.ToString());

                }

                //*************************************************** 載入圖檔 ***************************************************
                //載入登錄圖檔
                classSystem.FilePath = Application.StartupPath + "\\Files\\";
                for (int i = 0; i <= 5; i++)
                {
                    if (classSystem.PatReg[i] == true)
                    {
                        classSystem.PatPath = classSystem.FilePath + (i + 1).ToString() + ".pat";
                        //classArray.FvxPattern2[i].LoadPattrenFileName = classSystem.PatPath;
                        //classArray.FvxPattern2[i].Load();

                        //classArray.FvxPattern3[i].LoadPattrenFileName = classSystem.PatPath;
                        //classArray.FvxPattern3[i].Load();

                        temp = (int)classSystem.RetVal;
                        //classArray.FvxPattern2[i].GetErrReport(out temp);
                        classSystem.RetVal = temp;

                        if (File.Exists(classSystem.PatPath) == true)  //如果File資料夾不存在                    
                                                                       // classArray.Image1[i].Load(classSystem.PatPath);

                            if (classSystem.RetVal != 0)
                            {
                                classSystem.PatReg[i] = false;
                                return;
                            }

                        //classArray.FvxFormRotator1[i].MarkType = FVXCOMFORMROTATORLib.MARK_PARAMETER_TYPE.GNRL_TYPE;
                        //classArray.FvxFormRotator1[i].ScaleMax = 100 + (int)classSystem.PatSize[i];
                        //classArray.FvxFormRotator1[i].ScaleMin = 100 - (int)classSystem.PatSize[i];
                        //classArray.FvxFormRotator1[i].AngleMax = (int)classSystem.PatAngle[i];
                        //classArray.FvxFormRotator1[i].AngleMin = -1 * (int)classSystem.PatAngle[i];
                        //classArray.FvxFormRotator1[i].EdgeMethod = 2;
                        //classArray.FvxFormRotator1[i].SearchNum = 1;

                        //classArray.FvxFormRotator1[i].SetPattern(classArray.FvxPattern2[i].GetOcx());
                        //classArray.FvxFormRotator1[i].ScoreThresh = (int)classSystem.PatScore[i];

                        //if (i < 2)
                        //    classArray.FvxFormRotator1[i].SetInspectArea(classSystem.SearchArea[1, 0]);
                        //else if (i > 3)
                        //    classArray.FvxFormRotator1[i].SetInspectArea(classSystem.SearchArea[3, 1]);
                        //else
                        //    classArray.FvxFormRotator1[i].SetInspectArea(classSystem.SearchArea[2, 0]);

                        temp = (int)classSystem.RetVal;
                        // classArray.FvxFormRotator1[i].GetErrReport(out temp);
                        classSystem.RetVal = temp;

                        if (classSystem.RetVal != 0)
                            MessageBox.Show("登入圖形" + (i + 1).ToString() + "載入失敗");
                    }

                }


            } //LoadPat

            public static void SavePat()
            {
                int temp;
                try
                {
                    // 檔案路徑
                    if (classSystem.TypeNo < 9)
                        classSystem.FilePath = Application.StartupPath + "\\Files\\File00" + (classSystem.TypeNo + 1) + ".ini";
                    if (classSystem.TypeNo >= 9 && classSystem.TypeNo < 99)
                        classSystem.FilePath = Application.StartupPath + "\\Files\\File0" + (classSystem.TypeNo + 1) + ".ini";
                    if (classSystem.TypeNo >= 99)
                        classSystem.FilePath = Application.StartupPath + "\\Files\\File" + (classSystem.TypeNo + 1) + " .ini";

                    for (int i = 0; i <= 5; i++)
                    {
                        classSystem.TmpData[0] = Convert.ToString(classSystem.PatReg[i]);
                        classSystem.TmpData[1] = Convert.ToString(classSystem.PatScore[i]);
                        classSystem.TmpData[2] = Convert.ToString(classSystem.PatSize[i]);
                        classSystem.TmpData[3] = Convert.ToString(classSystem.PatAngle[i]);

                        classSystem.SUCCESS = WritePrivateProfileString("Pattern", "PatReg(" + i + ")", classSystem.TmpData[0], classSystem.FilePath);
                        classSystem.SUCCESS = WritePrivateProfileString("Pattern", "PatScore(" + i + ")", classSystem.TmpData[1], classSystem.FilePath);
                        classSystem.SUCCESS = WritePrivateProfileString("Pattern", "PatSize(" + i + ")", classSystem.TmpData[2], classSystem.FilePath);
                        classSystem.SUCCESS = WritePrivateProfileString("Pattern", "PatAngle(" + i + ")", classSystem.TmpData[3], classSystem.FilePath);

                    }

                    for (int i = 0; i <= 5; i++)
                    {
                        //classArray.FvxFormRotator1[i].MarkType = FVXCOMFORMROTATORLib.MARK_PARAMETER_TYPE.GNRL_TYPE;
                        //classArray.FvxFormRotator1[i].ScaleMax = 100 + (int)classSystem.PatSize[i];
                        //classArray.FvxFormRotator1[i].ScaleMin = 100 - (int)classSystem.PatSize[i];
                        //classArray.FvxFormRotator1[i].AngleMax = (int)classSystem.PatAngle[i];
                        //classArray.FvxFormRotator1[i].AngleMin = -1 * (int)classSystem.PatAngle[i];
                        //classArray.FvxFormRotator1[i].EdgeMethod = 2;
                        //classArray.FvxFormRotator1[i].SearchNum = 1;

                        //classArray.FvxFormRotator1[i].SetPattern(classArray.FvxPattern3[i].GetOcx());
                        //classArray.FvxFormRotator1[i].ScoreThresh = (int)classSystem.PatScore[i];

                        //if (i < 2)
                        //    classArray.FvxFormRotator1[i].SetInspectArea(classSystem.SearchArea[1, 0]);
                        //else if (i > 3)
                        //    classArray.FvxFormRotator1[i].SetInspectArea(classSystem.SearchArea[3, 1]);
                        //else
                        //    classArray.FvxFormRotator1[i].SetInspectArea(classSystem.SearchArea[2, 0]);

                        //temp = (int)classSystem.RetVal;
                        //classArray.FvxFormRotator1[i].GetErrReport(out temp);
                        // classSystem.RetVal = temp;

                        if (classSystem.RetVal != 0)
                            MessageBox.Show("登入圖形" + (i + 1).ToString() + "載入失敗");
                    }


                    classSystem.FilePath = Application.StartupPath + "\\Files\\";
                    for (int i = 0; i <= 5; i++)
                    {
                        if (classSystem.PatReg[i] == true)
                        {
                            classSystem.PatPath = classSystem.FilePath + (i + 1).ToString() + ".pat";
                            // classArray.FvxPattern3[i].SavePattrenFileName = classSystem.PatPath;
                            // classArray.FvxPattern3[i].Save();

                            //if (File.Exists(classSystem.PatPath) == true)  //如果File資料夾不存在                    
                            //    classArray.Image1[i].Load(classSystem.PatPath);
                        }
                    }
                }
                catch
                {
                    MessageBox.Show("檔案儲存失敗");
                }
            } //SavePat

            public static void SavePoint()
            {
                classSystem.FilePath = Application.StartupPath + "\\Files\\Camera" + classSystem.CamPos + "_Point.ini";

                // classSystem.TmpData[21] = Convert.ToString( classSystem.GetBlobResultGroupSave[classSystem.CamPos].Count ) ;
                classSystem.SUCCESS = WritePrivateProfileString("GroupPoint", "GetBlobResultGroupSave(" + classSystem.CamPos + ").Count", classSystem.TmpData[21], classSystem.FilePath);

                for (int i = 0; i <= classSystem.nCount - 1; i++)
                {
                    //    classSystem.TmpData[0] = Convert.ToString( classSystem.GetBlobResultGroupSave[classSystem.CamPos].Item2(i).area ) ;
                    //    classSystem.TmpData[1] = Convert.ToString( classSystem.GetBlobResultGroupSave[classSystem.CamPos].Item2(i).hole_num ) ;
                    //    classSystem.TmpData[2] = Convert.ToString( classSystem.GetBlobResultGroupSave[classSystem.CamPos].Item2(i).perim ) ;
                    //    classSystem.TmpData[3] = Convert.ToString( classSystem.GetBlobResultGroupSave[classSystem.CamPos].Item2(i).ellipse_long );
                    //    classSystem.TmpData[4] = Convert.ToString( classSystem.GetBlobResultGroupSave[classSystem.CamPos].Item2(i).ellipse_short );
                    //    classSystem.TmpData[5] = Convert.ToString( classSystem.GetBlobResultGroupSave[classSystem.CamPos].Item2(i).ellipse_angle );
                    //    classSystem.TmpData[6] = Convert.ToString( classSystem.GetBlobResultGroupSave[classSystem.CamPos].Item2(i).center_x );
                    //    classSystem.TmpData[7] = Convert.ToString( classSystem.GetBlobResultGroupSave[classSystem.CamPos].Item2(i).center_y );
                    //    classSystem.TmpData[8] = Convert.ToString( classSystem.GetBlobResultGroupSave[classSystem.CamPos].Item2(i).x_min );
                    //    classSystem.TmpData[9] = Convert.ToString( classSystem.GetBlobResultGroupSave[classSystem.CamPos].Item2(i).x_max );
                    //    classSystem.TmpData[10] = Convert.ToString( classSystem.GetBlobResultGroupSave[classSystem.CamPos].Item2(i).y_min );
                    //    classSystem.TmpData[11] = Convert.ToString( classSystem.GetBlobResultGroupSave[classSystem.CamPos].Item2(i).y_max );
                    //    classSystem.TmpData[12] = Convert.ToString( classSystem.GetBlobResultGroupSave[classSystem.CamPos].Item2(i).total_area );
                    //    classSystem.TmpData[13] = Convert.ToString( classSystem.GetBlobResultGroupSave[classSystem.CamPos].Item2(i).bounding_top_x );
                    //    classSystem.TmpData[14] = Convert.ToString( classSystem.GetBlobResultGroupSave[classSystem.CamPos].Item2(i).bounding_top_y );
                    //    classSystem.TmpData[15] = Convert.ToString( classSystem.GetBlobResultGroupSave[classSystem.CamPos].Item2(i).bounding_right_x );
                    //    classSystem.TmpData[16] = Convert.ToString( classSystem.GetBlobResultGroupSave[classSystem.CamPos].Item2(i).bounding_right_y );
                    //    classSystem.TmpData[17] = Convert.ToString( classSystem.GetBlobResultGroupSave[classSystem.CamPos].Item2(i).bounding_bottom_x );
                    //    classSystem.TmpData[18] = Convert.ToString( classSystem.GetBlobResultGroupSave[classSystem.CamPos].Item2(i).bounding_bottom_y );
                    //    classSystem.TmpData[19] = Convert.ToString( classSystem.GetBlobResultGroupSave[classSystem.CamPos].Item2(i).bounding_left_x );
                    //    classSystem.TmpData[20] = Convert.ToString( classSystem.GetBlobResultGroupSave[classSystem.CamPos].Item2(i).bounding_left_y );


                    classSystem.SUCCESS = WritePrivateProfileString("GroupPoint", "GetBlobResultGroupSave(" + classSystem.CamPos + ")(" + i + ").area", classSystem.TmpData[0], classSystem.FilePath);
                    classSystem.SUCCESS = WritePrivateProfileString("GroupPoint", "GetBlobResultGroupSave(" + classSystem.CamPos + ")(" + i + ").hole_num", classSystem.TmpData[1], classSystem.FilePath);
                    classSystem.SUCCESS = WritePrivateProfileString("GroupPoint", "GetBlobResultGroupSave(" + classSystem.CamPos + ")(" + i + ").perim", classSystem.TmpData[2], classSystem.FilePath);
                    classSystem.SUCCESS = WritePrivateProfileString("GroupPoint", "GetBlobResultGroupSave(" + classSystem.CamPos + ")(" + i + ").ellipse_long", classSystem.TmpData[3], classSystem.FilePath);
                    classSystem.SUCCESS = WritePrivateProfileString("GroupPoint", "GetBlobResultGroupSave(" + classSystem.CamPos + ")(" + i + ").ellipse_short", classSystem.TmpData[4], classSystem.FilePath);
                    classSystem.SUCCESS = WritePrivateProfileString("GroupPoint", "GetBlobResultGroupSave(" + classSystem.CamPos + ")(" + i + ").ellipse_angle", classSystem.TmpData[5], classSystem.FilePath);
                    classSystem.SUCCESS = WritePrivateProfileString("GroupPoint", "GetBlobResultGroupSave(" + classSystem.CamPos + ")(" + i + ").center_x", classSystem.TmpData[6], classSystem.FilePath);
                    classSystem.SUCCESS = WritePrivateProfileString("GroupPoint", "GetBlobResultGroupSave(" + classSystem.CamPos + ")(" + i + ").center_y", classSystem.TmpData[7], classSystem.FilePath);
                    classSystem.SUCCESS = WritePrivateProfileString("GroupPoint", "GetBlobResultGroupSave(" + classSystem.CamPos + ")(" + i + ").x_min", classSystem.TmpData[8], classSystem.FilePath);
                    classSystem.SUCCESS = WritePrivateProfileString("GroupPoint", "GetBlobResultGroupSave(" + classSystem.CamPos + ")(" + i + ").x_max", classSystem.TmpData[9], classSystem.FilePath);
                    classSystem.SUCCESS = WritePrivateProfileString("GroupPoint", "GetBlobResultGroupSave(" + classSystem.CamPos + ")(" + i + ").y_min", classSystem.TmpData[10], classSystem.FilePath);
                    classSystem.SUCCESS = WritePrivateProfileString("GroupPoint", "GetBlobResultGroupSave(" + classSystem.CamPos + ")(" + i + ").y_max", classSystem.TmpData[11], classSystem.FilePath);
                    classSystem.SUCCESS = WritePrivateProfileString("GroupPoint", "GetBlobResultGroupSave(" + classSystem.CamPos + ")(" + i + ").total_area", classSystem.TmpData[12], classSystem.FilePath);
                    classSystem.SUCCESS = WritePrivateProfileString("GroupPoint", "GetBlobResultGroupSave(" + classSystem.CamPos + ")(" + i + ").bounding_top_x", classSystem.TmpData[13], classSystem.FilePath);
                    classSystem.SUCCESS = WritePrivateProfileString("GroupPoint", "GetBlobResultGroupSave(" + classSystem.CamPos + ")(" + i + ").bounding_top_y", classSystem.TmpData[14], classSystem.FilePath);
                    classSystem.SUCCESS = WritePrivateProfileString("GroupPoint", "GetBlobResultGroupSave(" + classSystem.CamPos + ")(" + i + ").bounding_right_x", classSystem.TmpData[15], classSystem.FilePath);
                    classSystem.SUCCESS = WritePrivateProfileString("GroupPoint", "GetBlobResultGroupSave(" + classSystem.CamPos + ")(" + i + ").bounding_right_y", classSystem.TmpData[16], classSystem.FilePath);
                    classSystem.SUCCESS = WritePrivateProfileString("GroupPoint", "GetBlobResultGroupSave(" + classSystem.CamPos + ")(" + i + ").bounding_bottom_y", classSystem.TmpData[18], classSystem.FilePath);
                    classSystem.SUCCESS = WritePrivateProfileString("GroupPoint", "GetBlobResultGroupSave(" + classSystem.CamPos + ")(" + i + ").bounding_left_x", classSystem.TmpData[19], classSystem.FilePath);
                    classSystem.SUCCESS = WritePrivateProfileString("GroupPoint", "GetBlobResultGroupSave(" + classSystem.CamPos + ")(" + i + ").bounding_left_y", classSystem.TmpData[20], classSystem.FilePath);

                } // for i++



            } // void SavePoint()

            public static void LoadPoint()
            {
                //On Error GoTo a1

                classSystem.FilePath = Application.StartupPath + "\\Files\\Camera" + classSystem.CamPos + "_Point.ini";

                classSystem.ret = GetPrivateProfileString("GroupPoint", "GetBlobResultGroupSave(" + classSystem.CamPos + ").Count", "0", classSystem.buff1, 256, classSystem.FilePath);  //檢查方式
                classSystem.TmpData[21] = Convert.ToString(classSystem.buff1);
                classSystem.nCountSave[classSystem.CamPos] = Convert.ToInt64(Math.Round(Convert.ToDecimal(classSystem.TmpData[21])));


                for (int i = 0; i <= classSystem.nCountSave[classSystem.CamPos]; i++)
                {
                    classSystem.ret = GetPrivateProfileString("GroupPoint", "GetBlobResultGroupSave(" + classSystem.CamPos + ")(" + i + ").area", "0", classSystem.buff1, 256, classSystem.FilePath);  //檢查方式
                    classSystem.TmpData[0] = Convert.ToString(classSystem.buff1);
                    classSystem.ret = GetPrivateProfileString("GroupPoint", "GetBlobResultGroupSave(" + classSystem.CamPos + ")(" + i + ").hole_num", "0", classSystem.buff1, 256, classSystem.FilePath);  //檢查方式
                    classSystem.TmpData[1] = Convert.ToString(classSystem.buff1);
                    classSystem.ret = GetPrivateProfileString("GroupPoint", "GetBlobResultGroupSave(" + classSystem.CamPos + ")(" + i + ").perim", "0", classSystem.buff1, 256, classSystem.FilePath);  //檢查方式
                    classSystem.TmpData[2] = Convert.ToString(classSystem.buff1);
                    classSystem.ret = GetPrivateProfileString("GroupPoint", "GetBlobResultGroupSave(" + classSystem.CamPos + ")(" + i + ").ellipse_long", "0", classSystem.buff1, 256, classSystem.FilePath);  //檢查方式
                    classSystem.TmpData[3] = Convert.ToString(classSystem.buff1);
                    classSystem.ret = GetPrivateProfileString("GroupPoint", "GetBlobResultGroupSave(" + classSystem.CamPos + ")(" + i + ").ellipse_short", "0", classSystem.buff1, 256, classSystem.FilePath);  //檢查方式
                    classSystem.TmpData[4] = Convert.ToString(classSystem.buff1);
                    classSystem.ret = GetPrivateProfileString("GroupPoint", "GetBlobResultGroupSave(" + classSystem.CamPos + ")(" + i + ").ellipse_angle", "0", classSystem.buff1, 256, classSystem.FilePath);  //檢查方式
                    classSystem.TmpData[5] = Convert.ToString(classSystem.buff1);
                    classSystem.ret = GetPrivateProfileString("GroupPoint", "GetBlobResultGroupSave(" + classSystem.CamPos + ")(" + i + ").center_x", "0", classSystem.buff1, 256, classSystem.FilePath);  //檢查方式
                    classSystem.TmpData[6] = Convert.ToString(classSystem.buff1);
                    classSystem.ret = GetPrivateProfileString("GroupPoint", "GetBlobResultGroupSave(" + classSystem.CamPos + ")(" + i + ").center_y", "0", classSystem.buff1, 256, classSystem.FilePath);  //檢查方式
                    classSystem.TmpData[7] = Convert.ToString(classSystem.buff1);
                    classSystem.ret = GetPrivateProfileString("GroupPoint", "GetBlobResultGroupSave(" + classSystem.CamPos + ")(" + i + ").x_min", "0", classSystem.buff1, 256, classSystem.FilePath);  //檢查方式
                    classSystem.TmpData[8] = Convert.ToString(classSystem.buff1);
                    classSystem.ret = GetPrivateProfileString("GroupPoint", "GetBlobResultGroupSave(" + classSystem.CamPos + ")(" + i + ").x_max", "0", classSystem.buff1, 256, classSystem.FilePath);  //檢查方式
                    classSystem.TmpData[9] = Convert.ToString(classSystem.buff1);
                    classSystem.ret = GetPrivateProfileString("GroupPoint", "GetBlobResultGroupSave(" + classSystem.CamPos + ")(" + i + ").y_min", "0", classSystem.buff1, 256, classSystem.FilePath);  //檢查方式
                    classSystem.TmpData[10] = Convert.ToString(classSystem.buff1);
                    classSystem.ret = GetPrivateProfileString("GroupPoint", "GetBlobResultGroupSave(" + classSystem.CamPos + ")(" + i + ").y_max", "0", classSystem.buff1, 256, classSystem.FilePath);  //檢查方式
                    classSystem.TmpData[11] = Convert.ToString(classSystem.buff1);
                    classSystem.ret = GetPrivateProfileString("GroupPoint", "GetBlobResultGroupSave(" + classSystem.CamPos + ")(" + i + ").total_area", "0", classSystem.buff1, 256, classSystem.FilePath);  //檢查方式
                    classSystem.TmpData[12] = Convert.ToString(classSystem.buff1);
                    classSystem.ret = GetPrivateProfileString("GroupPoint", "GetBlobResultGroupSave(" + classSystem.CamPos + ")(" + i + ").bounding_top_x", "0", classSystem.buff1, 256, classSystem.FilePath);  //檢查方式
                    classSystem.TmpData[13] = Convert.ToString(classSystem.buff1);
                    classSystem.ret = GetPrivateProfileString("GroupPoint", "GetBlobResultGroupSave(" + classSystem.CamPos + ")(" + i + ").bounding_top_y", "0", classSystem.buff1, 256, classSystem.FilePath);  //檢查方式
                    classSystem.TmpData[14] = Convert.ToString(classSystem.buff1);
                    classSystem.ret = GetPrivateProfileString("GroupPoint", "GetBlobResultGroupSave(" + classSystem.CamPos + ")(" + i + ").bounding_right_x", "0", classSystem.buff1, 256, classSystem.FilePath);  //檢查方式
                    classSystem.TmpData[15] = Convert.ToString(classSystem.buff1);
                    classSystem.ret = GetPrivateProfileString("GroupPoint", "GetBlobResultGroupSave(" + classSystem.CamPos + ")(" + i + ").bounding_right_y", "0", classSystem.buff1, 256, classSystem.FilePath);  //檢查方式
                    classSystem.TmpData[16] = Convert.ToString(classSystem.buff1);
                    classSystem.ret = GetPrivateProfileString("GroupPoint", "GetBlobResultGroupSave(" + classSystem.CamPos + ")(" + i + ").bounding_bottom_x", "0", classSystem.buff1, 256, classSystem.FilePath);  //檢查方式
                    classSystem.TmpData[17] = Convert.ToString(classSystem.buff1);
                    classSystem.ret = GetPrivateProfileString("GroupPoint", "GetBlobResultGroupSave(" + classSystem.CamPos + ")(" + i + ").bounding_bottom_y", "0", classSystem.buff1, 256, classSystem.FilePath);  //檢查方式
                    classSystem.TmpData[18] = Convert.ToString(classSystem.buff1);
                    classSystem.ret = GetPrivateProfileString("GroupPoint", "GetBlobResultGroupSave(" + classSystem.CamPos + ")(" + i + ").bounding_left_x", "0", classSystem.buff1, 256, classSystem.FilePath);  //檢查方式
                    classSystem.TmpData[19] = Convert.ToString(classSystem.buff1);
                    classSystem.ret = GetPrivateProfileString("GroupPoint", "GetBlobResultGroupSave(" + classSystem.CamPos + ")(" + i + ").bounding_left_y", "0", classSystem.buff1, 256, classSystem.FilePath);  //檢查方式
                    classSystem.TmpData[20] = Convert.ToString(classSystem.buff1);


                    //classSystem.GetBlobResultTMP.area = int.Parse(classSystem.TmpData[0] ) ;
                    //classSystem.GetBlobResultTMP.hole_num = int.Parse(classSystem.TmpData[1] ) ;
                    //classSystem.GetBlobResultTMP.perim = int.Parse(classSystem.TmpData[2] );
                    //classSystem.GetBlobResultTMP.ellipse_long = int.Parse(classSystem.TmpData[3] );
                    //classSystem.GetBlobResultTMP.ellipse_short = int.Parse(classSystem.TmpData[4] );
                    //classSystem.GetBlobResultTMP.ellipse_angle = int.Parse(classSystem.TmpData[5] );
                    //classSystem.GetBlobResultTMP.center_x = int.Parse(classSystem.TmpData[6] );
                    //classSystem.GetBlobResultTMP.center_y = int.Parse(classSystem.TmpData[7] );
                    //classSystem.GetBlobResultTMP.x_min = int.Parse(classSystem.TmpData[8] );
                    //classSystem.GetBlobResultTMP.x_max = int.Parse(classSystem.TmpData[9] );
                    //classSystem.GetBlobResultTMP.y_min = int.Parse(classSystem.TmpData[10] );
                    //classSystem.GetBlobResultTMP.y_max = int.Parse(classSystem.TmpData[11] );
                    //classSystem.GetBlobResultTMP.total_area = int.Parse(classSystem.TmpData[12] );
                    //classSystem.GetBlobResultTMP.bounding_top_x = int.Parse(classSystem.TmpData[13] );
                    //classSystem.GetBlobResultTMP.bounding_top_y = int.Parse(classSystem.TmpData[14] );
                    //classSystem.GetBlobResultTMP.bounding_right_x = int.Parse(classSystem.TmpData[15] );
                    //classSystem.GetBlobResultTMP.bounding_right_y = int.Parse(classSystem.TmpData[16] );
                    //classSystem.GetBlobResultTMP.bounding_bottom_x = int.Parse(classSystem.TmpData[17] );
                    //classSystem.GetBlobResultTMP.bounding_bottom_y = int.Parse(classSystem.TmpData[18] );
                    //classSystem.GetBlobResultTMP.bounding_left_x = int.Parse( classSystem.TmpData[19] );
                    //classSystem.GetBlobResultTMP.bounding_left_y = int.Parse(classSystem.TmpData[20] );

                    //classSystem.GetBlobResultGroupSave[classSystem.CamPos].Add( classSystem.GetBlobResultTMP ); 
                } // for

                // a1:

            } // void LoadPoint()

            public static void LoadData()
            {
                //檔案路徑o
                if (classSystem.TypeNo < 9)
                    classSystem.FilePath = Application.StartupPath + "\\Files\\File00" + (classSystem.TypeNo + 1) + ".ini";
                if (classSystem.TypeNo >= 9 && classSystem.TypeNo < 99)
                    classSystem.FilePath = Application.StartupPath + "\\Files\\File0" + (classSystem.TypeNo + 1) + ".ini";
                if (classSystem.TypeNo >= 99)
                    classSystem.FilePath = Application.StartupPath + "\\Files\\File" + (classSystem.TypeNo + 1) + " .ini";

                classSystem.ret = GetPrivateProfileString("Image", "GammaVal(" + classSystem.CamPos + ")", "1", classSystem.buff1, 256, classSystem.FilePath); // 檢查方式
                classSystem.GammaVal[classSystem.CamPos] = double.Parse(classSystem.buff1.ToString());
                classSystem.ret = GetPrivateProfileString("Image", "BrightVal(" + classSystem.CamPos + ")", "0", classSystem.buff1, 256, classSystem.FilePath); // 檢查方式
                classSystem.BrightVal[classSystem.CamPos] = int.Parse(classSystem.buff1.ToString());
                classSystem.ret = GetPrivateProfileString("Image", "ContrastVal(" + classSystem.CamPos + ")", "0", classSystem.buff1, 256, classSystem.FilePath); // 檢查方式
                classSystem.ContrastVal[classSystem.CamPos] = int.Parse(classSystem.buff1.ToString());

            } // void LoadData()

            public static void SaveData()
            {
                // 檔案路徑
                if (classSystem.TypeNo < 9)
                    classSystem.FilePath = Application.StartupPath + "\\Files\\File00" + (classSystem.TypeNo + 1) + ".ini";
                if (classSystem.TypeNo >= 9 && classSystem.TypeNo < 99)
                    classSystem.FilePath = Application.StartupPath + "\\Files\\File0" + (classSystem.TypeNo + 1) + ".ini";
                if (classSystem.TypeNo >= 99)
                    classSystem.FilePath = Application.StartupPath + "\\Files\\File" + (classSystem.TypeNo + 1) + " .ini";

                classSystem.TmpData[0] = Convert.ToString(classSystem.GammaVal[classSystem.CamPos]);
                classSystem.TmpData[1] = Convert.ToString(classSystem.BrightVal[classSystem.CamPos]);
                classSystem.TmpData[2] = Convert.ToString(classSystem.ContrastVal[classSystem.CamPos]);


                classSystem.SUCCESS = WritePrivateProfileString("Image", "GammaVal(" + classSystem.CamPos + ")", classSystem.TmpData[0], classSystem.FilePath);
                classSystem.SUCCESS = WritePrivateProfileString("Image", "BrightVal(" + classSystem.CamPos + ")", classSystem.TmpData[1], classSystem.FilePath);
                classSystem.SUCCESS = WritePrivateProfileString("Image", "ContrastVal(" + classSystem.CamPos + ")", classSystem.TmpData[2], classSystem.FilePath);

            } // void SaveData()
        }

        #endregion

        #region Aerotech_motion
        public enum Motion_Num : int
        {
            //Executtion = 0,
            X_Positive_Motion = 1,
            Y_Positive_Motion = 2,
            Z_Positive_Motion = 3,

            X_Negative_Motion = 4,
            Y_Negative_Motion = 5,
            Z_Negative_Motion = 6,
            Home = 7,
            Linear = 8,
            Circle = 9,
            Circle_CW = 10,
            Rapid = 11,
            Home_X = 12,
            Home_Y = 13,
            Home_Z = 14,
            Motion_ABS = 15,
            CloseLaser = 16,
            OpenLaser = 17,
            autofocus = 18,
        }

        private void Aero_thMotionRun_Tick(Motion_Num motion_num)
        {
            if (Thread_Enabled)
            {
                Thread_Enabled = false;
                Aero_thMotionRun = new Thread(() =>
                {
                    try
                    {
                        switch (motion_num)
                        {
                            //--------------------------全機動作---------------------------------
                            //case Motion_Num.Executtion:
                            //    Motion_run();
                            //    Thread_Enabled = true;
                            //    G_thMotionRun.Abort();
                            //    break;

                            //--------------------------正移動---------------------------------
                            case Motion_Num.X_Positive_Motion:
                                //X_Positive();
                                Thread_Enabled = true;
                                Aero_thMotionRun.Abort();
                                break;
                            case Motion_Num.Y_Positive_Motion:
                                //Y_Positive();
                                Thread_Enabled = true;
                                Aero_thMotionRun.Abort();
                                break;
                            case Motion_Num.Z_Positive_Motion:
                                //; Z_Positive();
                                Thread_Enabled = true;
                                Aero_thMotionRun.Abort();
                                break;


                            //--------------------------負移動---------------------------------
                            case Motion_Num.X_Negative_Motion:
                                // X_Negative();
                                Thread_Enabled = true;
                                Aero_thMotionRun.Abort();
                                break;
                            case Motion_Num.Y_Negative_Motion:
                                //Y_Negative();
                                Thread_Enabled = true;
                                Aero_thMotionRun.Abort();
                                break;
                            case Motion_Num.Z_Negative_Motion:
                                // Z_Negative();
                                Thread_Enabled = true;
                                Aero_thMotionRun.Abort();
                                break;

                            //-------------------------HOME-----------------------------------------
                            case Motion_Num.Home:
                                this.myController.Commands.Axes[0, 1, 2].Motion.Home();
                                //this.myController.Commands.Axes[1].Motion.Home();
                                //this.myController.Commands.Axes[2].Motion.Home();

                                //_rotationStage.Home(0);
                                Thread_Enabled = true;
                                Aero_thMotionRun.Abort();
                                break;
                            //-----------------------linear--------------------
                            case Motion_Num.Linear:
                                try
                                {

                                    int[] a = { 0, 1 };
                                    double[] b = { 50, 50 };
                                    double[] c = { -50, -50 };

                                    this.myController.Commands[this.taskIndex].Motion.Linear(a, b, 5);
                                    this.myController.Commands[this.taskIndex].Motion.Linear(a, c, 5);
                                }
                                catch (A3200Exception exception)
                                {
                                    txt_Motion_ErrorMsg.Text = exception.Message;
                                }
                                Thread_Enabled = true;

                                break;

                            case Motion_Num.Circle:
                                try
                                {
                                    int[] a = { 0, 1 };
                                    double[] b = { 5, 5 };
                                    double[] c = { -5, -5 };
                                    //this.myController.Commands[this.taskIndex].Motion.Linear(a, b, 5);
                                    this.myController.Commands[this.taskIndex].Motion.CCWRadius(0, 50, 1, 50, 50, 5);

                                }
                                catch (A3200Exception exception)
                                {
                                    txt_Motion_ErrorMsg.Text = exception.Message;
                                }
                                Thread_Enabled = true;
                                break;
                            case Motion_Num.Circle_CW:
                                try
                                {
                                    int[] a = { 0, 1 };
                                    double[] b = { 5, 5 };
                                    double[] c = { -5, -5 };
                                    //this.myController.Commands[this.taskIndex].Motion.Linear(a, b, 5);
                                    this.myController.Commands[this.taskIndex].Motion.CWRadius(0, 50, 1, 50, 50, 5);

                                }
                                catch (A3200Exception exception)
                                {
                                    txt_Motion_ErrorMsg.Text = exception.Message;
                                }
                                Thread_Enabled = true;
                                break;

                            case Motion_Num.Rapid:

                                try
                                {

                                    double[] Speed = { 50, 50 };
                                    double[] Distance = { Distance_X, Distance_Y };
                                    //myController.Commands.Axes[0, 1].Motion.Rapid(Distance, Speed);
                                    this.myController.Commands[this.taskIndex].Motion.MoveInc(0, Distance_X, 50);
                                    this.myController.Commands[this.taskIndex].Motion.MoveInc(1, Distance_Y, 50);
                                }
                                catch (A3200Exception exception)
                                {
                                    txt_Motion_ErrorMsg.Text = exception.Message;
                                }
                                Thread_Enabled = true;
                                Aero_thMotionRun.Abort();

                                break;
                            case Motion_Num.Home_X:
                                try
                                {
                                    this.myController.Commands.Axes[0].Motion.Home();
                                }
                                catch (A3200Exception exception)
                                {
                                    txt_Motion_ErrorMsg.Text = exception.Message;
                                }
                                Thread_Enabled = true;
                                Aero_thMotionRun.Abort();
                                break;
                            case Motion_Num.Home_Y:
                                try
                                {
                                    this.myController.Commands.Axes[1].Motion.Home();
                                }
                                catch (A3200Exception exception)
                                {
                                    txt_Motion_ErrorMsg.Text = exception.Message;
                                }
                                Thread_Enabled = true;
                                Aero_thMotionRun.Abort();
                                break;
                            case Motion_Num.Home_Z:
                                try
                                {
                                    this.myController.Commands.Axes[2].Motion.Home();
                                }
                                catch (A3200Exception exception)
                                {
                                    txt_Motion_ErrorMsg.Text = exception.Message;
                                }
                                Thread_Enabled = true;
                                Aero_thMotionRun.Abort();
                                break;
                            case Motion_Num.Motion_ABS:
                                try
                                {

                                    if (Allow_X)
                                    {
                                        this.myController.Commands[this.taskIndex].Motion.MoveAbs(0, ABS_X, double.Parse(VSet_X.Text));
                                    }
                                    if (Allow_Y)
                                    {
                                        this.myController.Commands[this.taskIndex].Motion.MoveAbs(1, ABS_Y, double.Parse(VSet_Y.Text));
                                    }
                                    if (Allow_Z)
                                    {
                                        this.myController.Commands[this.taskIndex].Motion.MoveAbs(2, ABS_Z, double.Parse(VSet_Z.Text));
                                    }

                                }
                                catch (A3200Exception exception)
                                {
                                    txt_Motion_ErrorMsg.Text = exception.Message;
                                }
                                Thread_Enabled = true;
                                //Aero_thMotionRun.Abort();
                                break;
                            case Motion_Num.CloseLaser:
                                //DO_7_ON();
                                Thread.Sleep(800);
                                //DO_7_OFF();
                                Thread_Enabled = true;
                                Aero_thMotionRun.Abort();
                                break;
                            case Motion_Num.OpenLaser:
                                //byte[] p = LaserDesk.LaserDesk.HexToByte("");
                                //_sock.Send(LaserDesk.LaserDesk.ParameterCommand(2, p));
                                //Thread.Sleep(10);
                                //_sock.Send(LaserDesk.LaserDesk.ParameterCommand(1, p));
                                //Thread.Sleep(10);
                                //_sock.Send(LaserDesk.LaserDesk.ParameterCommand(5, p));
                                //Thread.Sleep(10);
                                //_sock.Send(LaserDesk.LaserDesk.ParameterCommand(21, p));
                                //instantDoCtrl1.Write(1, (byte)Convert.ToByte(255));
                                Thread.Sleep(50);
                                //DO_4_ON();

                                Thread.Sleep(800);
                                //START復位
                                //DO_4_OFF();
                                Thread_Enabled = true;
                                Aero_thMotionRun.Abort();
                                break;
                            case Motion_Num.autofocus:

                                break;
                        }
                    }
                    catch (Exception ex)
                    {
                        // MessageBox.Show("動作完畢");
                        //MessageBox.Show(ex.ToString());
                    }
                });
                Aero_thMotionRun.IsBackground = true;
                Aero_thMotionRun.Priority = ThreadPriority.Normal;
                Aero_thMotionRun.Start();
            }

        }
        #endregion thread_motion

    }

}

