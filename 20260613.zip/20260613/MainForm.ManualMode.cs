﻿using ConfocalLaser_Interface;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;
using System.Text.RegularExpressions; // 引入正則表達式命名空間，用於處理字串模式匹配
using NCScriptParser_Interface;//data
using System.Drawing;//color
using static NCScriptParser_Interface.NCScriptParser;// QueueCmd
using System.Diagnostics;//計時器

namespace LaserProcess_LCH
{
    public partial class MainForm
    {
        private enum AutoFocusType
        {
            Default,
            Camera,
            Laser,
            AutoProcess
        }
        private enum GH_Type
        {
            GH_2500,
            GH_2000
        }
        private double _lastExecTime;
        private bool _isN2Enable = false;
        private bool _isLaserEnable = false;
        private bool _isDustcoverEnable = false;
        private string[] _jobxFilePath = new string[4];
        private string _GH_jobxFilePath;
        private string AllJobxFilefoldPath;
        private Queue<string> _AllJobxFileQueue = new Queue<string>();

        #region GUI Event Method

        private void btn_ManualMode_AutoFocus2Camera_Click(object sender, EventArgs e)
        {
            //Skip if isSimulated
            if (_isSysSimulated)
                return;

            // Disable GUI Controls
            //EnableGUIMotionControls(false);

            // Disable UI control
            enableUIGroup(false);

            // Call BackgroundWorker to do asynchronous operation
            if (!BW_AutoFocus.IsBusy)
            {
                // Start the asynchronous operation.
                BW_AutoFocus.RunWorkerAsync(AutoFocusType.Camera);
            }

            // Update panel
            updatePnlStepState(pnl_ManualMode_AutoFocus_Status, StepState.inactive);
        }

        private void btn_ManualMode_AutoFocus2Laser_Click(object sender, EventArgs e)
        {
            //Skip if isSimulated
            if (_isSysSimulated)
                return;

            // Disable GUI Controls
            //EnableGUIMotionControls(false);

            // Disable UI control
            enableUIGroup(false);

            // Call BackgroundWorker to do asynchronous operation
            if (!BW_AutoFocus.IsBusy)
            {
                // Start the asynchronous operation.
                BW_AutoFocus.RunWorkerAsync(AutoFocusType.Laser);
            }

            // Update panel
            updatePnlStepState(pnl_ManualMode_AutoFocus_Status, StepState.inactive);

        }

        private void btn_ManualMode_MoveZ_Click(object sender, EventArgs e)
        {
            // Read Current ConfocalLaser result
            _isConfocalLaserBusy = true;
            ConfocalLaser.evalResult result = _ConfocalLaser.Trigger(1, out _ConfocalLaser_Output, 0);
            _isConfocalLaserBusy = false;
            double currentDistance = 0;
            if (_ConfocalLaser_Output < -99999)
            {
                // Write Event
                writeEvent("UserEvent", "Out of Compensate zone.");
                MessageBox.Show("請先移動Z軸至測高計量測範圍!");
                return;
            }
            else
            {
                currentDistance = -1 * _ConfocalLaser_Output * 0.001; //Since confocal laser result unit: um
            }

            // Update axisIndex depends on Control.Name of the sender
            Button button = (Button)sender;
            int axisIndex = (int)MotionAxis.Z;
            double distance = 0;
            double speed = _ConfigEquip._Velocity_Default.Z;
            string msg = "";
            try
            {
                switch (button.Name)
                {
                    case "btn_ManualMode_MoveZToLaser":
                        msg = "Move Z to Laser Focal Plane.";
                        distance = currentDistance - _ConfigEquip._Height_Equip.Laser;
                        break;
                    case "btn_ManualMode_MoveZToCamera":
                        msg = "Move Z to Camera Focal Plane.";
                        distance = currentDistance - _ConfigEquip._Height_Equip.Camera;
                        break;
                    case "btn_ManualMode_MoveZToConfocalLaser":
                        msg = "Move Z to ConfocalLaser Focal Plane.";
                        distance = currentDistance - _ConfigEquip._Height_Equip.ConfocalLaser;
                        break;
                    default:
                        MessageBox.Show("Unknown btn_ManualMode_MoveZ_Click." + Environment.NewLine + button.Name);
                        return;
                }
            }
            catch (Exception ex)
            {
                writeError("MainForm.MotionControl", msg + " failed!"  + ex);
                updateControlTxtWithString(txt_Motion_ErrorMsg, ex.ToString());
                return;
            }

            //Write Event
            writeEvent("UserEvent", msg);

            //Skip if isSimulated
            if (_isSysSimulated)
                return;

            // Update Status
            updatePnlStepState(pnl_ManualMode_MoveZ_Status, StepState.inactive);

            try
            {
                // MotionAxis.Z direction is reversed
                distance = -1 * distance;

                moveRel(axisIndex, distance, speed);

                // Update Status
                updatePnlStepState(pnl_ManualMode_MoveZ_Status, StepState.OK);
            }
            catch (Exception ex)
            {
                // Update Status
                updatePnlStepState(pnl_ManualMode_MoveZ_Status, StepState.NO);
                writeError("MainForm.MotionControl", msg + " failed!" + ex);
                updateControlTxtWithString(txt_Motion_ErrorMsg, ex.ToString());
                return;
            }
        }

        private void btn_ManualMode_CameraCVX_SelectFolder_Click(object sender, EventArgs e)
        {
            //Write Event
            writeEvent("UserEvent", "Select Image FodlerPath");

            if (FolderBrowserDialog.ShowDialog() == DialogResult.OK)
            {
                updateControlTxtWithString(txt_ManualMode_CameraCVX_FolderPath, FolderBrowserDialog.SelectedPath);
                _ConfigSystem._CameraImagesFolderPath = FolderBrowserDialog.SelectedPath;

                // Write parameters back to the ini file
                _ConfigSystem.WriteIntoIniFile();

                //Write Event
                writeEvent("UserEvent", "Image FolderPath selected =" + FolderBrowserDialog.SelectedPath);
            }
        }

        private void btn_ManualMode_CameraCVX_SaveImage_Click(object sender, EventArgs e)
        {
            //Write Event
            writeEvent("UserEvent", "Save Image");

            string fileFormat = ".bmp";
            string filePath = _ConfigSystem._CameraImagesFolderPath+ "\\"  + txt_ManualMode_CameraCVX_FileName.Text + fileFormat;

            int result = _ManualMode_axCVX.CaptureRemoteDesktop(filePath);

            if (result == 0)
            {
                //Write Event
                writeEvent("UserEvent", "Image save success, FilePath =" + filePath);
            }
            else
            {
                //Write Error
                writeError("UserEvent", "Image save Failed =" + filePath);
            }
        }

        private void btn_ManualMode_SelectFile_Click(object sender, EventArgs e)
        {

            if (!chk_ManualMode_AllJobxFile.Checked)
            {
                OpenFileDialog_jobx.DefaultExt = "jobx";
                OpenFileDialog_jobx.Filter = "加工檔 (*.jobx)|*.jobx";
                if (OpenFileDialog_jobx.ShowDialog() == DialogResult.OK)
                {

                    _jobxFilePath[0] = OpenFileDialog_jobx.FileName;

                    int index1 = OpenFileDialog_jobx.FileName.LastIndexOf('\\') + 1;
                    int index2 = OpenFileDialog_jobx.FileName.LastIndexOf('.');

                    char[] fileName = new char[index2 - index1];
                    // Get project directory
                    OpenFileDialog_jobx.FileName.CopyTo(index1, fileName, 0, fileName.Length);
                    string sFileName = new string(fileName);
                    updateControlTxtWithString(lbl_ManualMode_SampleMatrix_FileName, "檔案1名稱: " + sFileName);

                    // Write Process
                    writeProcess("小樣微孔試打", "檔案1已選擇");
                    btn_ManualMode_SelectFile2.Enabled = true;
                }
            }
            else
            {

                int count = 0;
                FolderBrowserDialog dialog = new FolderBrowserDialog();
                dialog.Description = "請選擇檔案路徑";
                if (dialog.ShowDialog() == DialogResult.OK)
                {
                    AllJobxFilefoldPath = dialog.SelectedPath;
                    string[] files = Directory.GetFiles(AllJobxFilefoldPath, "*.jobx");
                    foreach (var file in files)
                    {
                        //資料夾內的jobx全部刀具檔案塞入_AllJobxFileQueue
                        //_AllJobxFileQueue.Enqueue(files[count]);
                        count++;


                        int index1 = file.LastIndexOf('\\') + 1;
                        int index2 = file.LastIndexOf('.');

                        char[] fileName = new char[index2 - index1];
                        // Get project directory
                        file.CopyTo(index1, fileName, 0, fileName.Length);
                        string sFileName = new string(fileName);


                        // Write Process
                        writeProcess("小樣微孔試打-全部刀具模式", "檔案" + count + "-" + sFileName);
                    }
                    updateControlTxtWithString(lbl_ManualMode_SampleMatrix_FileName, "資料夾內刀具總數 " + count + " 組");
                    chk_ManualMode_SampleMatrix_Cut.Enabled = false;
                }
            }
        }
        private void btn_ManualMode_SelectFile2_Click(object sender, EventArgs e)
        {
            OpenFileDialog_jobx.DefaultExt = "jobx";
            OpenFileDialog_jobx.Filter = "加工檔 (*.jobx)|*.jobx";
            if (OpenFileDialog_jobx.ShowDialog() == DialogResult.OK)
            {

                _jobxFilePath[1] = OpenFileDialog_jobx.FileName;

                int index1 = OpenFileDialog_jobx.FileName.LastIndexOf('\\') + 1;
                int index2 = OpenFileDialog_jobx.FileName.LastIndexOf('.');

                char[] fileName = new char[index2 - index1];
                // Get project directory
                OpenFileDialog_jobx.FileName.CopyTo(index1, fileName, 0, fileName.Length);
                string sFileName = new string(fileName);
                updateControlTxtWithString(lbl_ManualMode_SampleMatrix_FileName2, "檔案2名稱: " + sFileName);

                // Write Process
                writeProcess("小樣微孔試打", "檔案2已選擇");               
                btn_ManualMode_SelectFile3.Enabled = true;
                chk_ManualMode_AllJobxFile.Enabled = false;
                txt_ManualMode_SampleX.Enabled = false;
                txt_ManualMode_SampleY.Enabled = false;
                txt_ManualMode_SampleX.Text = "5";
                txt_ManualMode_SampleY.Text = "5";
            }
        }

        private void btn_ManualMode_SelectFile3_Click(object sender, EventArgs e)
        {
            OpenFileDialog_jobx.DefaultExt = "jobx";
            OpenFileDialog_jobx.Filter = "加工檔 (*.jobx)|*.jobx";
            if (OpenFileDialog_jobx.ShowDialog() == DialogResult.OK)
            {

                _jobxFilePath[2] = OpenFileDialog_jobx.FileName;

                int index1 = OpenFileDialog_jobx.FileName.LastIndexOf('\\') + 1;
                int index2 = OpenFileDialog_jobx.FileName.LastIndexOf('.');

                char[] fileName = new char[index2 - index1];
                // Get project directory
                OpenFileDialog_jobx.FileName.CopyTo(index1, fileName, 0, fileName.Length);
                string sFileName = new string(fileName);
                updateControlTxtWithString(lbl_ManualMode_SampleMatrix_FileName3, "檔案3名稱: " + sFileName);

                // Write Process
                writeProcess("小樣微孔試打", "檔案3已選擇");
                btn_ManualMode_SelectFile4.Enabled = true;
            }
        }

        private void btn_ManualMode_SelectFile4_Click(object sender, EventArgs e)
        {
            OpenFileDialog_jobx.DefaultExt = "jobx";
            OpenFileDialog_jobx.Filter = "加工檔 (*.jobx)|*.jobx";
            if (OpenFileDialog_jobx.ShowDialog() == DialogResult.OK)
            {

                _jobxFilePath[3] = OpenFileDialog_jobx.FileName;

                int index1 = OpenFileDialog_jobx.FileName.LastIndexOf('\\') + 1;
                int index2 = OpenFileDialog_jobx.FileName.LastIndexOf('.');

                char[] fileName = new char[index2 - index1];
                // Get project directory
                OpenFileDialog_jobx.FileName.CopyTo(index1, fileName, 0, fileName.Length);
                string sFileName = new string(fileName);
                updateControlTxtWithString(lbl_ManualMode_SampleMatrix_FileName4, "檔案4名稱: " + sFileName);

                // Write Process
                writeProcess("小樣微孔試打", "檔案4已選擇");
            }
        }
        private void btn_ManualMode_ClearSelectFile_Click(object sender, EventArgs e)
        {
            //清除顯示路徑資料
            updateControlTxtWithString(lbl_ManualMode_SampleMatrix_FileName, "檔案1名稱: " + "");
            updateControlTxtWithString(lbl_ManualMode_SampleMatrix_FileName2, "檔案2名稱: " + "");
            updateControlTxtWithString(lbl_ManualMode_SampleMatrix_FileName3, "檔案3名稱: " + "");
            updateControlTxtWithString(lbl_ManualMode_SampleMatrix_FileName4, "檔案4名稱: " + "");

            //清除記憶體路徑資料
            for (int i = 0; i < 3; i++)
            {
                _jobxFilePath[i] = "";
            }

            // Write Process
            writeProcess("小樣微孔試打", "檔案重新選擇");
            chk_ManualMode_SampleMatrix_Cut.Enabled = true;
            txt_ManualMode_SampleX.Enabled = true;
            txt_ManualMode_SampleY.Enabled = true;
            chk_ManualMode_AllJobxFile.Enabled = true;
            btn_ManualMode_SelectFile2.Enabled = false;
            btn_ManualMode_SelectFile3.Enabled = false;
            btn_ManualMode_SelectFile4.Enabled = false;
        }
        private void btn_ManualMode_MoveZ_Move_Click(object sender, EventArgs e)
        {
            btn_Move_Position_Camera_Click("AutoProcess", null);

            //[BM:手動模式Cagila檔給LCH加工-移動至焦點校正位置]
            Button clickedButton = sender as Button;
            if (clickedButton != null)
            {
                switch (clickedButton.Name)
                {
                    case "btn_ManualMode_Cagila_MoveZ_Move":
                        // Write Process
                        writeProcess("Cagila檔試打-Step3", "移動至校正位置");
                        break;
                    case "btn_ManualMode_GH_MoveZ_Move":
                        // Write Process
                        writeProcess("小樣試打GH-Step2", "移動至校正位置");
                        break;
                    case "btn_ManualMode_MoveZ_Move":
                        // Write Process
                        writeProcess("小樣試打微孔-Step2", "移動至校正位置");
                        break;
                }
            }
        }

        private void btn_ManualMode_MoveZ_Start_Click(object sender, EventArgs e)
        {
            //[BM:手動模式Cagila檔給LCH加工-焦點校正]
            Button clickedButton = sender as Button;
            if (clickedButton != null)
            {
                switch (clickedButton.Name)
                {
                    case "btn_ManualMode_Cagila_MoveZ_Start":
                        // Write Process
                        writeProcess("Cagila檔試打-Step3", "焦點校正");
                        break;
                    case "btn_ManualMode_GH_MoveZ_Start":
                        // Write Process
                        writeProcess("小樣試打GH-Step2", "焦點校正");
                        break;
                    case "btn_ManualMode_GH_MoveZ_Move":
                        // Write Process
                        writeProcess("小樣試打微孔-Step2", "焦點校正");
                        break;
                }
            }

            //Skip if isSimulated
            if (_isSysSimulated)
                return;

            // Disable GUI Controls
            //EnableGUIMotionControls(false);

            // Disable UI control
            enableUIGroup(false);

            // Call BackgroundWorker to do asynchronous operation
            if (!BW_AutoFocus.IsBusy)
            {
                // Start the asynchronous operation.
                BW_AutoFocus.RunWorkerAsync(AutoFocusType.AutoProcess);
            }
        }

        private void btn_ManualMode_Chuck_ON_Click(object sender, EventArgs e)
        {
            // Enable Chuck vacuum
            if (!_isSysSimulated)
            {
                enableChuckVacuum(true);
            }

            //[BM:手動模式Cagila檔給LCH加工-吸附加工物件]
            Button clickedButton = sender as Button;
            if (clickedButton != null)
            {
                switch (clickedButton.Name)
                {
                    case "btn_ManualMode_Cagila_Chuck_ON":
                        // Write Process
                        writeProcess("Cagila檔試打-Step2", "樣品已吸附");
                        break;
                    case "btn_ManualMode_GH_Chuck_ON":
                        // Write Process
                        writeProcess("小樣試打GH-Step4", "樣品已吸附");
                        break;
                    case "btn_ManualMode_Chuck_ON":
                        // Write Process
                        writeProcess("小樣試打微孔-Step4", "樣品已吸附");
                        break;
                }
            }
            // Check already done or not
            //if (_stepFlags[(int)Step.s4])
            //    return;

            // Start Step Check Timer with checkAutoModeProgress
            //autoMode_StartStepWithTimer(Step.s4);

            
        }
        private void btn_ManualMode_OrgPoint_Set_Click(object sender, EventArgs e)
        {
            if (!_isSysSimulated)
            {
                // EngineerMode operation
                _orgPoint[(int)MotionAxis.X] = Math.Round(_positionFeedback[(int)MotionAxis.X], 4);
                _orgPoint[(int)MotionAxis.Y] = Math.Round(_positionFeedback[(int)MotionAxis.Y], 4);
                _orgPoint[(int)MotionAxis.Z] = Math.Round(_positionFeedback[(int)MotionAxis.Z], 4);

                //Write Event
                string msg = string.Format("OrgPoint:{3}({0:0.##}, {1:0.##}, {2:0.##})", _orgPoint[(int)MotionAxis.X], _orgPoint[(int)MotionAxis.Y], _orgPoint[(int)MotionAxis.Z], Environment.NewLine);
                lbl_ManualMode_OrgPoint.Text = msg;
                lbl_ManualMode_GH_OrgPoint.Text = msg;
                writeEvent("UserEvent", "Set " + msg);

                // Check already done or not
                //if (_stepFlags[(int)Step.s3])
                //    return;

                // Start Step Check Timer with checkAutoModeProgress
                //autoMode_StartStepWithTimer(Step.s3);

                updatePnlStepState(pnl_AutoMode_OrgPoint_Status, StepState.OK);

                // No need to check
                _stepTimers[(int)Step.s4].Set();
            }

            //[BM:手動模式Cagila檔給LCH加工-加工原點設定]
            Button clickedButton = sender as Button;
            if (clickedButton != null)
            {
                switch (clickedButton.Name)
                {
                    case "btn_ManualMode_Cagila_OrgPoint_Set":
                        // Write Process
                        writeProcess("Cagila檔試打-Step4", "加工原點已設定");
                        break;
                    case "btn_ManualMode_GH_OrgPoint_Set":
                        // Write Process
                        writeProcess("小樣試打GH-Step3", "加工原點已設定");
                        break;
                    case "btn_ManualMode_OrgPoint_Set":
                        // Write Process
                        writeProcess("小樣試打微孔-Step3", "加工原點已設定");
                        break;
                }
            }
        }

        private void btn_ManualMode_OrgPoint_MoveTo_Click(object sender, EventArgs e)
        {
            // Write Event
            writeEvent("UserEvent", "Move to Origin Point.");

            try
            {
                //this.moveTo("OrgPoint", _ConfigEquip._OrgPoint.X, _ConfigEquip._OrgPoint.Y, _ConfigEquip._Position_FeedIn.Z, _ConfigEquip._Velocity_Default.Z);
                this.moveTo("OrgPoint", _orgPoint[(int)MotionAxis.X], _orgPoint[(int)MotionAxis.Y], _orgPoint[(int)MotionAxis.Z], _ConfigEquip._Velocity_Default.Z);
            }
            catch (Exception ex)
            {
                // Update Status
                writeError("MainForm.AutoProcess", "MoveToOrgPoint failed!" + ex);
                updateControlTxtWithString(txt_Motion_ErrorMsg, ex.ToString());
            }

            // Write Process
            writeProcess("小樣試打", "移動至加工原點");
        }
        private void btn_ManualMode_Chuck_OFF_Click(object sender, EventArgs e)
        {
            if (!_isSysSimulated)
            {
                // Enable Chuck vacuum
                enableChuckVacuum(false);
            }

            //_stepFlags[(int)Step.s4] = false;
            //[BM:手動模式Cagila檔給LCH加工-解除吸附加工物件]
            Button clickedButton = sender as Button;
            if (clickedButton != null)
            {
                switch (clickedButton.Name)
                {
                    case "btn_ManualMode_Cagila_Chuck_OFF":
                        // Write Process
                        writeProcess("Cagila檔試打-Step2", "樣品已解除吸附");
                        break;
                    case "btn_ManualMode_GH_Chuck_OFF":
                        // Write Process
                        writeProcess("小樣試打GH-Step4", "樣品已解除吸附");
                        break;
                    case "btn_ManualMode_Chuck_OFF":
                        // Write Process
                        writeProcess("小樣試打微孔-Step4", "樣品已解除吸附");
                        break;
                }
            }
        }
        private void btn_ManualMode_StartSampleProcess_Click(object sender, EventArgs e)
        {
            double orgX = Math.Round(_positionFeedback[(int)MotionAxis.X], 4);
            double orgY = Math.Round(_positionFeedback[(int)MotionAxis.Y], 4);
            bool flag1 = double.TryParse(txt_ManualMode_SamplePitch.Text, out double samplePitch);       //陣列間隔(mm)
            bool flag2 = int.TryParse(txt_ManualMode_SampleX.Text, out int sampleNumber);                //X個數
            bool flag3 = int.TryParse(txt_ManualMode_SampleY.Text, out int loopNumber);                  //Y個數
            bool flag4 = double.TryParse(txt_ManualMode_CutSamplePitch.Text, out double cutsamplePitch); //加工檔偏移量(mm)
            bool flag5 = int.TryParse(txt_ManualMode_Divider.Text, out int laserdivider);                //雷射除頻Divider
            bool cutFlag = chk_ManualMode_SampleMatrix_Cut.Checked;                                      //切邊功能
            Tuple<int> argm = new Tuple<int>(laserdivider);

            //Send MES 更改狀態為測試
            if (_ConfigSystem._ConnectSetting.ChptMES)
            {
                if (ComboBox_TestSector.Text == "製造單位")
                {
                    Description = "測機";
                    //[BM:將機台資訊傳送給MES]
                    _CHPT_MES.Send_MES_Data(EquipmentNo, (int)EquipmentState.Test, UserNo, Description, IsEQPTrigger, LotNo);
                }
                else if (ComboBox_TestSector.Text == "工程部或研發")
                {
                    Description = "實驗與借機";
                    //[BM:將機台資訊傳送給MES]
                    _CHPT_MES.Send_MES_Data(EquipmentNo, (int)EquipmentState.Experiment, UserNo, Description, IsEQPTrigger, LotNo);
                }
            }

            if (flag1 && flag2 && flag3 && flag4 && flag5)
            {
                Tuple<double, double, double, int, int, double, bool, Tuple<int>> arguments = new Tuple<double, double, double, int, int, double, bool, Tuple<int>>(orgX, orgY, samplePitch, sampleNumber, loopNumber, cutsamplePitch,  cutFlag, argm);
                if (!BW_SampleMatrix.IsBusy)
                {
                    BW_SampleMatrix.RunWorkerAsync(arguments);

                    updateControlTxtWithString(lbl_ManualMode_SampleMatrixStatus, "Progress...");

                    // Write Process
                    writeProcess("小樣微孔試打", "加工流程已開始");
                }
            }
            else
            {
                MessageBox.Show("Please key-in valid number!");
            }
        }

        private void btn_ManualMode_StopSampleProcess_Click(object sender, EventArgs e)
        {
            if (BW_SampleMatrix.WorkerSupportsCancellation == true)
            {
                // Cancel the asynchronous operation.
                BW_SampleMatrix.CancelAsync();
            }
        }

        private void btn_ManualMode_GH_SelectFile_Click(object sender, EventArgs e)
        {
            OpenFileDialog_jobx.DefaultExt = "jobx";
            OpenFileDialog_jobx.Filter = "加工檔 (*.jobx)|*.jobx";
            if (OpenFileDialog_jobx.ShowDialog() == DialogResult.OK)
            {

                _GH_jobxFilePath = OpenFileDialog_jobx.FileName;

                int index1 = OpenFileDialog_jobx.FileName.LastIndexOf('\\') + 1;
                int index2 = OpenFileDialog_jobx.FileName.LastIndexOf('.');

                char[] fileName = new char[index2 - index1];
                // Get project directory
                OpenFileDialog_jobx.FileName.CopyTo(index1, fileName, 0, fileName.Length);
                string sFileName = new string(fileName);
                updateControlTxtWithString(lbl_ManualMode_GH_SampleMatrix_FileName, "檔案名稱: " + sFileName);
                // Write Process
                writeProcess("小樣GH試打-Step1", "檔案已選擇");
            }
        }

        private void btn_ManualMode_StartGHSampleProcess_Click(object sender, EventArgs e)
        {
            double orgX = Math.Round(_positionFeedback[(int)MotionAxis.X], 4);
            double orgY = Math.Round(_positionFeedback[(int)MotionAxis.Y], 4);
            bool flag1 = double.TryParse(txt_ManualMode_GH_SamplePitch.Text, out double samplePitch);
            bool flag2 = int.TryParse(txt_ManualMode_GH_SampleX.Text, out int sampleNumber);
            bool flag3 = int.TryParse(txt_ManualMode_GH_SampleY.Text, out int loopNumber);
            bool flag4 = double.TryParse(txt_ManualMode_GH_Power.Text, out double power);
            bool flag5 = double.TryParse(txt_ManualMode_GH_Speed.Text, out double speed);
            bool flag6 = int.TryParse(txt_ManualMode_GH_CutLoop.Text, out int cutLoop);
            Tuple<int> argm = new Tuple<int>(cutLoop);

            //Send MES 更改狀態為測試
            if (_ConfigSystem._ConnectSetting.ChptMES)
            {

                if (ComboBox_GH_TestSector.Text == "製造單位")
                {
                    Description = "測機";
                    //[BM:將機台資訊傳送給MES]
                    _CHPT_MES.Send_MES_Data(EquipmentNo, (int)EquipmentState.Test, UserNo, Description, IsEQPTrigger, LotNo);

                }
                else if (ComboBox_GH_TestSector.Text == "工程部或研發")
                {
                    Description = "實驗與借機";
                    //[BM:將機台資訊傳送給MES]
                    _CHPT_MES.Send_MES_Data(EquipmentNo, (int)EquipmentState.Experiment, UserNo, Description, IsEQPTrigger, LotNo);
                }
            }

            if (flag1 && flag2 && flag3 && flag4 && flag5 && flag6)
            {
                Tuple<double, double, double, int, int, double, double, Tuple<int>> arguments = new Tuple<double, double, double, int, int, double, double, Tuple<int>>(orgX, orgY, samplePitch, sampleNumber, loopNumber, power, speed, argm);
                if (!BW_GH_SampleMatrix.IsBusy)
                {
                    BW_GH_SampleMatrix.RunWorkerAsync(arguments);

                    updateControlTxtWithString(lbl_ManualMode_GH_SampleMatrixStatus, "Progress...");

                    // Write Process
                    writeProcess("小樣GH試打", "加工流程已開始");
                }
            }
            else
            {
                MessageBox.Show("Please key-in valid number!");
            }
        }

        private void btn_ManualMode_StopGHSampleProcess_Click(object sender, EventArgs e)
        {
            if (BW_GH_SampleMatrix.WorkerSupportsCancellation == true)
            {
                // Cancel the asynchronous operation.
                BW_GH_SampleMatrix.CancelAsync();
            }
        }

        private void btn_N2_Control_Click(object sender, EventArgs e)
        {
            if (!_isN2Enable)
            {
                btn_N2_Control.Text = "氮氣ON";
                enableProcessGas(true);
            }
            else
            {
                btn_N2_Control.Text = "氮氣OFF";
                enableProcessGas(false);
            }
            _isN2Enable = !_isN2Enable;
        }

        private void btn_ManualMode_LaserControl_Click(object sender, EventArgs e)
        {
            if (!_isLaserEnable)
            {
                btn_ManualMode_LaserControl.Text = "雷射ON";
                this.doLasing(true);

                // Switch flag of Lasing UI
                switchLasingFlag(true);
            }
            else
            {
                btn_ManualMode_LaserControl.Text = "雷射OFF";
                this.doLasing(false);

                // Switch flag of Lasing UI
                switchLasingFlag(false);
            }
            _isLaserEnable = !_isLaserEnable;
        }
        private void btn_dustcover_Click(object sender, EventArgs e)
        {
            if (!_isDustcoverEnable)
            {
                btn_dustcover.Text = "防塵蓋-開";
                enableDustcover(true);
            }
            else
            {
                btn_dustcover.Text = "防塵蓋-關";
                enableDustcover(false);
            }
            _isDustcoverEnable = !_isDustcoverEnable;
        }
        private void btn_ManualMode_SetPower_Click(object sender, EventArgs e)
        {
            if (double.TryParse(txt_ManualMode_SetPower.Text, out double setPower))
            {
                if (setPower >= 100 && setPower <= 8000)
                {
                    // Disable GUI Controls
                    //EnableGUIMotionControls(false);

                    // Disable UI control
                    enableUIGroup(false);

                    // Call BackgroundWorker to do asynchronous operation
                    if (!BW_SetPower.IsBusy)
                    {
                        // Start the asynchronous operation.
                        BW_SetPower.RunWorkerAsync(setPower);
                    }

                    // Update panel
                    updatePnlStepState(pnl_ManualMode_SetPower_Status, StepState.inactive);
                }
                //SetLaserOutputPowerWithoutCheck(setPower);
                else
                {
                    MessageBox.Show("Please key-in valid number between 100~8000!!!");
                }
            }
            else
            {
                MessageBox.Show("Please key-in valid number!!!");
            }
        }
        //[BM:手動模式Cagila檔給LCH加工-選擇檔案]
        private void btn_ManualMode_Cagila_SelectFile_Click(object sender, EventArgs e)
        {
            try
            {
                OpenFileDialog openFileDialog = new OpenFileDialog                                         // 建立檔案選擇視窗
                {
                    DefaultExt = "mlproj",                                                                 // 設定預設副檔名
                    Filter = "project files (*.mlproj)|*.mlproj"                                           // 限制檔案類型為 mlproj
                };

                if (openFileDialog.ShowDialog() != DialogResult.OK) return;                                // 若未選擇檔案則結束處理

                string fileName = openFileDialog.FileName;                                                 // 取得使用者選取的檔案路徑
                string Folder_Name = Path.GetDirectoryName(fileName);                                      // 取得資料夾路徑
                string NCName = Path.GetFileNameWithoutExtension(fileName);                                // 擷取不含副檔名的檔名
                lbl_ManualMode_Cagila_FileName.Text = $"檔案名稱: {NCName}";                                //ui介面顯示此次選擇之檔案名稱
                string ncFilePath = Path.Combine(Folder_Name, "Programs", NCName + ".nc");                 // 組合對應的 NC 檔案路徑
                string _NCCode = File.ReadAllText(ncFilePath, Encoding.UTF8);                              // 讀取 NC 程式內容

                Regex regex = new Regex(@"#\d+ (\d.+)");                                                   // 擷取工具標記後的完整資訊
                MatchCollection matches = regex.Matches(_NCCode);                                          // 執行比對，擷取符合項目
                int count = matches.Count;                                                                 // 記錄#標記數量

                List<string> Tool_And_Area_Name = new List<string>();                                      // 建立刀具與區域名稱清單
                List<string> Tool_Name = new List<string>();                                               // 建立刀具名稱清單

                foreach (Match match in matches)                                                           // 遍歷所有比對結果
                {
                    string toolInfo = match.Groups[1].Value.Trim();                                        // 擷取群組並移除前後空白
                    Tool_And_Area_Name.Add(toolInfo);                                                      // 加入刀具與區域清單
                }

                foreach (string info in Tool_And_Area_Name)
                {
                    string toolNameOnly = info.Split('-')[0];                                              // 取得 "-" 前的部分
                    Tool_Name.Add(toolNameOnly);
                }

                Console.WriteLine($"共找到 {count} 個 '#數字 空格 數字' 標記");                              // 顯示工具標記數量
                Console.WriteLine($"已儲存 {Tool_And_Area_Name.Count} 筆工具資訊至 Tool_Name 清單");         // 顯示工具儲存確認

                List<string> operationBlocks = new List<string>();                                         // 建立 Operation 區塊清單
                for (int i = 0; i < matches.Count; i++)                                                    // 遍歷每個 Operation 區段
                {
                    string opStart = $"//--------- Operation {i} ----------";                              // 定義區段起始標記
                    string opEnd = $"//--------- Operation {i + 1} ----------";                            // 定義區段結尾標記
                    int startIndex = _NCCode.IndexOf(opStart);                                             // 取得起始索引位置
                    int endIndex = _NCCode.IndexOf(opEnd);                                                 // 取得結束索引位置

                    if (startIndex >= 0 && endIndex > startIndex)                                          // 確保位置有效
                    {
                        string opContent = _NCCode.Substring(startIndex, endIndex - startIndex);           // 擷取區塊內容
                        operationBlocks.Add(opContent);                                                    // 加入至區塊清單
                    }
                    else if (startIndex >= 0 && i == matches.Count - 1)                                    // 處理最後一段區塊（無結尾標記）
                    {
                        string opContent = _NCCode.Substring(startIndex);                                  // 擷取區塊至檔案結尾
                        operationBlocks.Add(opContent);                                                    // 加入區塊清單
                    }
                    else
                    {
                        operationBlocks.Add("");                                                           // 若擷取失敗則補空白以維持索引一致
                    }
                }
                //================生成所有微孔檔案
                List<int> MicroHole_Count_List = new List<int>();                                          //單一刀具之加工微孔數量
                List<double> ZprobePositionX_List = new List<double>();                                    //儲存單一刀具之加工微孔第一筆座標為測高座標
                List<double> ZprobePositionY_List = new List<double>();                                    //儲存單一刀具之加工微孔第一筆座標為測高座標

                for (int t = 0; t < operationBlocks.Count; t++)                                            // 逐段處理每個 Operation 區塊
                {
                    Regex xyRegex = new Regex(@"G01\s+X(-?\d+(?:\.\d+)?)\s+Y(-?\d+(?:\.\d+)?)", RegexOptions.IgnoreCase);  // 建立座標比對格式
                    List<double> X_List = new List<double>();                                                               // 建立 X 座標清單
                    List<double> Y_List = new List<double>();                                                                // 建立 Y 座標清單

                    MatchCollection xyMatches = xyRegex.Matches(operationBlocks[t]);                       // 執行比對座標指令
                    foreach (Match match in xyMatches)                                                     // 遍歷符合的座標項目
                    {
                        double x = double.Parse(match.Groups[1].Value);                                    // 擷取並轉換 X 值為 double
                        double y = double.Parse(match.Groups[2].Value);                                    // 擷取並轉換 Y 值為 double
                        X_List.Add(x);                                                                     // 加入 X 座標清單
                        Y_List.Add(y);                                                                     // 加入 Y 座標清單
                    }

                    string MicroHole_CsvPath = Path.Combine(Folder_Name, "ProgramObjects", Tool_And_Area_Name[t] + ".csv");   // 組合對應的微孔CSV儲存路徑
                    using (StreamWriter stream = new StreamWriter(MicroHole_CsvPath, false))                                // 建立輸出串流並覆寫模式開啟檔案
                    {
                        stream.WriteLine($"x,y");
                        for (int i = 0; i < X_List.Count; i++)                                                               // 逐筆寫入座標資料
                        {
                            stream.WriteLine($"{X_List[i]},{Y_List[i]}");                                                    // 將 X 與 Y 格式化寫入一行
                        }
                    }
                    
                    //進入下一個迴圈前先儲存後須需要用到的資料，進入迴圈後此次單一刀具微孔座標資料會被清除
                    MicroHole_Count_List.Add(X_List.Count);             //儲存此刀具微孔數量
                    ZprobePositionX_List.Add(X_List[0]);                //儲存此刀具獨立區域之測高座標
                    ZprobePositionY_List.Add(Y_List[0]);                //儲存此刀具獨立區域之測高座標
                }
                //================生成所有微孔檔案

                //================依據微孔區域排序(色卡名=區域名)，家維會給
                List<string> data1 = new List<string>();   // 用來儲存最終排序完成的刀具座標資料
                // 將所有刀具資料整合成字串並根據色卡名稱進行排序
                var sortedData = Enumerable.Range(0, Tool_And_Area_Name.Count) // 依據資料筆數建立索引範圍
                    .Select(i => new
                    {                                        
                        Raw = $"{Tool_Name[i]},{MicroHole_Count_List[i]},{ZprobePositionX_List[i]},{ZprobePositionY_List[i]},{Tool_And_Area_Name[i]}", // 組合成原始輸出字串格式
                        ColorKey = Tool_And_Area_Name[i].Contains("-")                                                                                 // 判斷是否含色卡名稱分隔符號 '-'
                                   ? Tool_And_Area_Name[i].Split('-').Last()                                                                           // 若有 '-'，取分隔後的最後一段作為排序色卡名稱
                                   : Tool_And_Area_Name[i]                                                                                             // 否則直接使用整個名稱作為排序鍵值
                    })
                    .OrderBy(entry => entry.ColorKey)                                                                                                  // 依據色卡名稱進行排序，使相同色卡資料連續
                    .Select(entry => entry.Raw)                                                                                                        // 將排序後結構轉回原始字串形式
                    .ToList();                                                                                                                         // 轉為 List<string> 結構以利後續使用

                data1.Clear();                                                                                                                         // 移除原先儲存內容，準備重新填入排序結果
                data1.AddRange(sortedData);                                                                                                            // 將排序後的刀具資料逐筆填入 data 清單中
                //================依據微孔區域排序(色卡名=區域名)

                //================生成DrillDataSet檔案
                string DrillDataSet_CsvPath = Path.Combine(Folder_Name, "ProgramObjects", "DrillDataSet.csv");       // 組合完整的 CSV 儲存路徑：在 ProgramObjects 資料夾下生成 DrillDataSet.csv
                using (StreamWriter stream = new StreamWriter(DrillDataSet_CsvPath, false))                          // 使用 StreamWriter 建立輸出串流，第二參數為 false 表示覆寫模式
                {
                    stream.WriteLine("LoadData,LaserPowerPct,LaserDivider,ScanheadFilePath|#S,NbrOfFeatures,ZProbe,ZprobePositionX,ZprobePositionY,pZ,ArrayName|#S,FilePath|#S"); // ⇦ 表頭固定格式
                    string lastColorName = "";                                                                        // 用來儲存上一筆的色卡名稱，用以判斷是否需更新 colorFlag
                    for (int i = 0; i < operationBlocks.Count; i++)                                                   // 依照操作區塊數量逐筆處理資料
                    {
                        var parts = data1[i].Split(',');                                                               // 解析每筆刀具字串成欄位陣列

                        string toolName = parts[0];                                                                   // 第 1 欄：刀具名稱
                        string microHoleCount = parts[1];                                                             // 第 2 欄：微孔數量
                        string zprobePositionX = parts[2];                                                            // 第 3 欄：Z 探針 X 座標
                        string zprobePositionY = parts[3];                                                            // 第 4 欄：Z 探針 Y 座標
                        string toolAreaName = parts[4];                                                               // 第 5 欄：刀具與區域組合名稱（可能含色卡）

                        string colorName = toolAreaName.Contains("-")                                                 // 判斷名稱中是否有色卡分隔符號
                                         ? toolAreaName.Split('-').Last()                                             // 若有 '-'，取最後段做為色卡名稱
                                         : "";                                                                        // 否則為空白（防止錯誤）

                        int colorFlag = (i == 0 || colorName != lastColorName) ? 1 : 0;                               // 若為首筆或色卡名稱改變，設為 1（表示段落變更）
                        lastColorName = colorName;                                                                    // 更新上一筆色卡名稱以供下筆比較

                        // 將所有欄位組合成一行寫入 CSV，包含雷射參數、探針座標、色卡標記等
                        stream.WriteLine($"1,43,2,{toolName},{microHoleCount},{colorFlag},{zprobePositionX},{zprobePositionY},0,{toolAreaName},./ProgramObjects/{toolAreaName}.csv"); // ⇦ 寫入加工參數列，檔案路徑為相對位置
                    }
                }
                //================生成DrillDataSet檔案

                //================生成Operation檔案
                string Operation_CsvPath = Path.Combine(Folder_Name, "ProgramObjects", "Operation" + ".csv");                // 組合對應的 CSV 儲存路徑
                using (StreamWriter stream = new StreamWriter(Operation_CsvPath, false))                                    // 建立輸出串流並覆寫模式開啟檔案
                {
                    stream.WriteLine($"Execute,Status,LaserParamSet,MotionParamSet,Offset,CutRepeat,Probe,Note|#s");
                    for (int i = 0; i < operationBlocks.Count; i++)                                                             // 逐筆寫入座標資料
                    {
                        stream.WriteLine($"1,0,1,0,0,1,1,MicroHole");                                                                   //確認是否都固定
                    }
                                                                                                                                         //要問重複切割次數之問題、及數值是否都固定(2025/7/25討論後因為是實驗案，通常只做到微孔結束，所以後面依據原先格式生成，後續智慧設計會在更細節處裡轉檔問題)
                    stream.WriteLine($"1,0,0,0,0,30,1,GH");
                    stream.WriteLine($"1,0,0,0,0,30,1,LAM_GH");
                    stream.WriteLine($"1,0,0,1,0,30,1,others");
                    stream.WriteLine($"1,0,0,1,0,20,1,edge");
                }
                //================生成Operation檔案

                //================補齊LaserParam檔案
                string LaserParam_CsvPath = Path.Combine(Folder_Name, "ProgramObjects", "LaserParam" + ".csv");   // 組合對應的 CSV 儲存路徑
                string[] lines = File.ReadAllLines(LaserParam_CsvPath);
                int rowCount = lines.Length - 1;                                                                                // 資料行數（排除表頭）
                int colCount = lines.Length > 1 ? lines[1].Split(',').Length : 0;                                            // 欄位數量（抓第一行標題或第二行內容都可以）
                if (colCount!=3)
                {
                    if (rowCount > 3)                                                                             //智慧設計產出給LCH之LaserParam.csv檔欄位為3欄，因此跳出此異常
                    {
                        MessageBox.Show($"此路徑{LaserParam_CsvPath}之檔案內容欄位異常");
                        return;
                    }
                    using (StreamWriter stream = new StreamWriter(LaserParam_CsvPath, false))                         // 建立輸出串流並覆寫模式開啟檔案
                    {
                        stream.WriteLine($"Divider,PowerPct,PulseWidth");

                        for (int i = 1; i < lines.Length; i++)                                                      // 從第2行開始處理資料列，排除原始標題列
                        {
                            stream.WriteLine(lines[i] + ",0");                                                          // 補上 PulseWidth 欄位預設值
                        }
                    }
                }
                if (rowCount!=8)
                {
                    if (rowCount > 8)                                                                           //智慧設計產出給LCH之LaserParam.csv檔資料數都為8筆，因此跳出此異常
                    {
                        MessageBox.Show($"此路徑{LaserParam_CsvPath}之檔案內容筆數異常");
                        return;
                    }
                                                                                                                 // ✅ 等寫入完成後再重新讀取，避免檔案使用衝突
                    lines = File.ReadAllLines(LaserParam_CsvPath);
                    for (int i = 0; i < 8 - (lines.Length - 1); i++)                                             // -1 是排除表頭，將資料補齊
                    {
                        File.AppendAllText(LaserParam_CsvPath, lines[lines.Length - 1] + Environment.NewLine);  // 加複製行
                    }
                }
                //================補齊LaserParam檔案

                int index1 = fileName.LastIndexOf('\\');              // ⇦ 取得檔案路徑最後一個反斜線的位置，代表資料夾與檔名的分界點
                char[] projectDir = new char[index1];                 // ⇦ 建立一個字元陣列，用來儲存路徑資料（不含檔名）
                fileName.CopyTo(0, projectDir, 0, projectDir.Length); // ⇦ 將 fileName 字串從第0字元起，複製到 projectDir，長度為 index1（只取資料夾部分）
                //=============設定刀具路徑
                _ConfigSystem._JobxFolderPath = Path.Combine(new string(projectDir), "LCH_job");
                _ConfigSystem.WriteIntoIniFile();
                //=============設定刀具路徑

                _NCParser._ProjectDirectory = new string(projectDir);
                _NCParser._InitialDirectory = new string(projectDir);
                _NCParser._NCName = NCName;
                //LCH開始讀取檔案
                _NCParser.ParseData_Cagila_setting(count);

                if (_isSysSimulated)//模擬模式下檢查解析完後哪些欄位是null，將null內容寫入csv檔，可與LCH正式自動模式解析檔案進行比較是否缺少解析內容
                {
                    NCScriptParser data = _NCParser;
                    string NCParser_Cagila_CsvPath = Path.Combine(Environment.CurrentDirectory, "xuan", "Comparing Automation and Cagila", "NCParser_Cagila" + ".csv");   // 組合對應的解析結果CSV儲存路徑
                    using (StreamWriter stream = new StreamWriter(NCParser_Cagila_CsvPath, false))                         // 建立輸出串流並覆寫模式開啟檔案
                    {
                        stream.WriteLine("PropertyName,Value"); // ⇦ 表頭列：屬性名稱與對應值

                        var props = data.GetType().GetProperties(); // ⇦ 取得 data 物件的所有屬性（public）

                        foreach (var prop in props)
                        {
                            object value = prop.GetValue(data); // ⇦ 取出屬性值

                            if (value == null)
                            {
                                stream.WriteLine($"{prop.Name},null"); // ⇦ 若為 null 則記錄屬性名稱與 null 字串
                            }
                        }

                        var fields = data.GetType().GetFields(System.Reflection.BindingFlags.Instance | System.Reflection.BindingFlags.NonPublic | System.Reflection.BindingFlags.Public); // ⇦ 若你還要抓取欄位（不是屬性）

                        stream.WriteLine("FieldName,Value"); // ⇦ 表頭列：只抓欄位（Fields）

                        foreach (var field in fields)
                        {
                            object value = field.GetValue(data); // ⇦ 取出欄位值

                            if (value == null)
                            {
                                stream.WriteLine($"{field.Name},null"); // ⇦ 若欄位為 null 則記錄
                            }
                        }
                    }
                }

                writeProcess("Cagila檔試打-Step1", "載檔完成");

                //開始檢查cagila資料夾中否有刀具資料夾
                if (!Directory.Exists(Path.Combine(new string(projectDir), "LCH_job")))
                {
                    Directory.CreateDirectory(Path.Combine(new string(projectDir), "LCH_job"));
                    Console.WriteLine("已建立 LCH_job 資料夾！");
                }
                //=============再檢查資料夾中是否有此案件需使用之刀具.jobx
                List<string> missingFiles = new List<string>();//儲存缺少之檔案名稱
                for(int i=0;i< Tool_Name.Count; i++)//檢查微孔刀具
                {
                    string filePath = Path.Combine(Path.Combine(new string(projectDir), "LCH_job"), $"{Tool_Name[i]}.jobx");
                    if (!File.Exists(filePath))
                        missingFiles.Add($"{Tool_Name[i]}.jobx");
                }

                if (!File.Exists(Path.Combine(Path.Combine(new string(projectDir), "LCH_job"), $"DryRunJob.jobx")))//單獨檢查是否有暖機檔
                    missingFiles.Add($"DryRunJob.jobx");

                if (missingFiles.Count > 0) // 顯示缺少結果
                {  // 建立訊息內容
                    string message;
                    message = $"{Path.Combine(new string(projectDir), "LCH_job")}內缺少以下檔案：\n";
                    foreach (string missing in missingFiles)
                        message += $" - {missing}\n";
                    message += "請檢查刀具檔是否存在，並重新嘗試載入檔案";
                    MessageBox.Show(message, "檔案檢查結果", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    lbl_ManualMode_Cagila_FileName.Text = "";
                    writeProcess("Cagila檔試打-Step1", "刀具缺失");
                    return;
                }
                //=============再檢查資料夾中是否有此案件需使用之刀具.jobx
                btn_ManualMode_Cagila_Thick_Start.Enabled = true;//以上內容都沒問題就啟用自動測高功能
                btn_ManualMode_Cagila_Thick_Stop.Enabled = true;//以上內容都沒問題就啟用自動測高功能
            }
            catch (Exception ex)                                                                           // 捕捉例外錯誤
            {
                MessageBox.Show($"NC 檔案載入失敗：{ex.Message}\n\n位置：{ex.StackTrace}",                  // 顯示錯誤訊息與追蹤
                                "錯誤",
                                MessageBoxButtons.OK,
                                MessageBoxIcon.Error);
            }
        }

        private void btn_ManualMode_Cagila_Thick_Start_Click(object sender, EventArgs e)
        {
            if (BW_CagilaThickProcess.IsBusy != true)
            {
                // Start the asynchronous operation.
                BW_CagilaThickProcess.RunWorkerAsync();
            }
            // Write Process
            writeProcess("Cagila檔試打-Step5", "測高流程已開始");
        }

        private void btn_ManualMode_Cagila_Thick_Stop_Click(object sender, EventArgs e)
        {
            if (BW_CagilaThickProcess.WorkerSupportsCancellation == true)
            {
                // Cancel the asynchronous operation.
                BW_CagilaThickProcess.CancelAsync();
            }
            // Write Process
            writeProcess("Cagila檔試打-Step5", "中斷測高流程");
        }
        private void btn_ManualMode_Cagila_AutoProcess_Start_Click(object sender, EventArgs e)
        {
            //Write Event
            writeEvent("UserEvent", "Start processing.");
            chk_Distance.Checked = false;
            btn_ManualMode_Cagila_AutoProcess_Stop.Enabled = true;

            //Initialize status
            Cagila_AutoProcess_Panel.BackColor = Color.DarkGray;
            Cagila_AutoProcess_Label.Text = string.Format("Progress = {0}% ({1}/{2})", 0, 0, _NbrOfFeature_Total);
            Cagila_AutoProcess_progressBar.Value = 0;

            if (BW_CagilaAutoProcess.IsBusy != true)
            {
                // Start the asynchronous operation.
                BW_CagilaAutoProcess.RunWorkerAsync();
            }
            // Write Process
            writeProcess("Cagila檔試打-Step6", "加工流程已開始");
        }

        private void btn_ManualMode_Cagila_AutoProcess_Stop_Click(object sender, EventArgs e)
        {
            //Write Event
            writeEvent("UserEvent", "Abort processing.");
            if (BW_CagilaAutoProcess.WorkerSupportsCancellation == true)
            {
                // Cancel the asynchronous operation.
                BW_CagilaAutoProcess.CancelAsync();
                if (!_isSysSimulated)
                {
                    // Stop the Laser scanner job
                    _LaserScanner.AbortJob();
                    // Stop Process Elapsed Time
                    _stopwatch_ElapsedTime.Stop();
                }
            }
            // Write Process
            writeProcess("Cagila檔試打-Step6", "中斷加工流程");
        }
        private void tabControl_Selecting(object sender, TabControlCancelEventArgs e)
        {
            if (e.TabPage.Tag != null && (bool)e.TabPage.Tag == true)
            {
                e.Cancel = true;
                MessageBox.Show("此功能還未啟用");
            }
        }
        #endregion

        #region Private Method
        /// <summary>
        /// LCH2切功能設定功率並且檢查調整後的功率
        /// </summary>
        /// <param name="mW"></param>
        private void LCH2CutSetLaserPower(double mW)
        {
            int[] axisIndexes = { (int)MotionAxis.X, (int)MotionAxis.Y, (int)MotionAxis.Z };

            moveTo("未使用此屬性", _positionFeedback[(int)MotionAxis.X], _positionFeedback[(int)MotionAxis.Y], _ConfigEquip._Position_PowerMonitor.Z + 20, _ConfigEquip._Velocity_Default.Z);//當前位置上台2CM Z往上抬高會越來越正值
            moveTo(_pointName9, _ConfigEquip._Position_PowerMonitor.X, _ConfigEquip._Position_PowerMonitor.Y, _ConfigEquip._Position_PowerMonitor.Z, _ConfigEquip._Velocity_Default.Z);//移動到功率檢查位置
            waitMotionDone(axisIndexes, 60000);
            #region 載入加工刀具
            try
            {
                bool FileJobxCheck = false;
                bool JobxNamesCheck = false;
                string filePath = "";
                string[] filxes;
                string JobxName = "Powermeter";

                _isLaserScannerBusy = true;

                //清除振鏡上刀具
                _LaserScanner.ClearJobs();

                filePath = Path.Combine(C_Path, "Warmup_File", "Powermeter_Jobx", JobxName + ".jobx");
                filxes = Directory.GetFiles(Path.Combine(C_Path, "Warmup_File", "Powermeter_Jobx"), "*.jobx");

                //確認指定路徑是否有此專案刀具
                foreach (var file in filxes)
                {
                    if (file == filePath)
                    {
                        FileJobxCheck = true;
                        break;
                    }
                }
                if (FileJobxCheck == false)
                {
                    writeError("載入刀具錯誤", "找尋不到刀具名稱！！刀具名稱： " + JobxName);
                    throw new Exception("載入刀具錯誤");
                }

                //載入刀具
                _LaserScanner.LoadJobFromFile(filePath);
                Thread.Sleep(100);

                //讀取振鏡上Jobx刀具名稱，與專案刀具進行檢查
                if (_ConfigProcess._IsAutoProcessCheckJobx)
                {
                    //讀取振鏡上所有刀具
                    List<string> JobxNames = new List<string>();
                    _LaserScanner.GetJobNames(out JobxNames);

                    //檢查振鏡上刀具是否跟專案刀具一樣                             
                    foreach (var _jobnames in JobxNames)
                    {
                        string jobSubnames = _jobnames.Substring(8);
                        if (jobSubnames == JobxName)
                        {
                            JobxNamesCheck = true;
                            break;
                        }
                    }

                    if (JobxNamesCheck == false)
                    {
                        writeError("振鏡刀具錯誤", "振鏡上刀具與專案刀具不符！！刀具名稱： " + JobxName);
                        throw new Exception("振鏡刀具錯誤");
                    }
                }

                //_LaserScanner.SelectJobByName(JobxName);
                _isLaserScannerBusy = false;
            }
            catch (Exception)
            {
                MessageBox.Show("載入刀具錯誤，請確認是否有這項刀具。", "Error！！");
                return;
            }
            #endregion

            StartGetPowermeterData();//開始量測功率
            DoLaserCuttingWithoutCheckProcessLimits();            // Switch-ON laser via calling Do Laser cutting

            var result = PowerSet(mW);
            double Power_percentage = result.Item1;
            bool PowerSetState = result.Item2;
            if (PowerSetState)
            {
                SetLaserPowerPercentage(Power_percentage);//更改功率值  // Set Laser Output Power
            }
            else
            {
                MessageBox.Show($"功率mW轉換%失敗");
            }
            

            // Switch-OFF laser via calling Stop Laser cutting
            StopLaserCutting();



            StopGetPowermeterData();//停止量測功率
            moveTo("未使用此屬性", _positionFeedback[(int)MotionAxis.X], _positionFeedback[(int)MotionAxis.Y], _ConfigEquip._Position_PowerMonitor.Z + 20, _ConfigEquip._Velocity_Default.Z);//測功率完之後Z上台2CM Z往上抬高會越來越正值

        }


        private void CheckAndSetLaserPower(double laserPowerPct)
        {
            // Record the last position for later move back
            double lastPosition_X = _positionFeedback[(int)MotionAxis.X];
            double lastPosition_Y = _positionFeedback[(int)MotionAxis.Y];
            double lastPosition_Z = _positionFeedback[(int)MotionAxis.Z];
            int[] axisIndexes = { (int)MotionAxis.X, (int)MotionAxis.Y };

            // Move to Power measurement zone to avoid reflection light damaged
            // Set Positioning to Absolute Mode
            string code = "G90";
            executeGCode(code);

            // Do Motion Movement to specified target position
            //this.rapidMoveTo(_ConfigEquip._Position_PowerMonitor.X, _ConfigEquip._Position_PowerMonitor.Y, _ConfigEquip._Position_PowerMonitor.Z, _ConfigEquip._Velocity_Default.Z);
            linearMove(_ConfigEquip._Position_PowerMonitor.X, _ConfigEquip._Position_PowerMonitor.Y, _ConfigEquip._Velocity_Default.X);

            // Wait in position
            waitMotionDone(axisIndexes, 60000);

            // Upload Scanner XML file
            string jobName = _ConfigProcess._Sample_JobName;
            uploadJob(jobName);

            // Switch-ON laser via calling Do Laser cutting
            DoLaserCuttingWithoutCheckProcessLimits();

            // Set Laser Output Power
            SetLaserOutputPower(laserPowerPct);

            // Switch-OFF laser via calling Stop Laser cutting
            StopLaserCutting();

            // Move back to last position
            // Do Motion Movement to specified target position
            //this.rapidMoveTo(lastPosition_X, lastPosition_Y, lastPosition_Z, _ConfigEquip._Velocity_Default.Z);
            linearMove(lastPosition_X, lastPosition_Y, _ConfigEquip._Velocity_Default.X);
        }

        private void SetLaserOutputPower(double setPower)
        {
            // setPower unit = mW
            // double calGain = 0.004;
            // double calOffset = 65.754;

            double rotGain = _ConfigEquip._RotationCalibration.Gain;
            double rotOffset = _ConfigEquip._RotationCalibration.Offset;
            double setAngle = setPower * rotGain + rotOffset;
            _RotationStage.MoveAbs((decimal)setAngle);

            //Thread.Sleep(500);

            // Wait while it completed
            //while (!_RotationStage.GetIsMotionDone())
            //{
            //    Thread.Sleep(1000);
            //}
            Thread.Sleep(5000);

            int count = 0;
            int limit = 10;
            double pwrDeviation = 0;
            double pwrCompensate = 0;
            double pwrDeviationThreshold = _ConfigProcess._Power_DeviationThreshold;
            double pwrGain = _ConfigEquip._PowerCalibration.Gain;
            double pwrOffset = _ConfigEquip._PowerCalibration.Offset;

            while (true)
            {
                if (count >= limit)
                {
                    // Time-out exception
                    throw new Exception(string.Format("SetLaserOutputPower failed. SetPower = {0:0.##}, Practical_OutputPower = {1:0.##}", setPower, _Practical_OutputPower));
                }

                // Time delay for stable measurement
                Thread.Sleep(1000);

                // Check current OutputPower from Powermeter
                _isPowermeterBusy = true;
                //_Powermeter_OutputPower = 1000 * _Powermeter.GetPower();    // Convert Unit from W to mW
                _Powermeter_OutputPower = _Powermeter.measurementStr;
                _isPowermeterBusy = false;

                _Practical_OutputPower = pwrGain * _Powermeter_OutputPower + pwrOffset;

                // Check the power deviation which shall be smaller than the threshold
                pwrDeviation = setPower - _Practical_OutputPower;
                
                if (pwrDeviation < 0)
                    pwrDeviation = -1 * pwrDeviation;
                if (pwrDeviation < pwrDeviationThreshold)
                {
                    // Write Log
                    string msg = string.Format( "Powermeter = {0:0.###}", _Practical_OutputPower);
                    writeDataQueue("SetLaserPower", msg);

                    // Meet the criteria then break the loop
                    break;
                }

                // Else, do the compensation
                pwrDeviation = setPower - _Practical_OutputPower;
                pwrCompensate = pwrCompensate + pwrDeviation;
                setAngle = (setPower + pwrCompensate) * rotGain + rotOffset;
                _RotationStage.MoveAbs((decimal)setAngle);

                //Thread.Sleep(500);
                //
                // Wait while it completed
                //while (!_RotationStage.GetIsMotionDone())
                //{
                //    Thread.Sleep(1000);
                //}
                Thread.Sleep(5000);

                count++;
            }
        }


        /// <summary>
        /// 設定雷射功率百分比，並等待確認設定成功
        /// </summary>
        /// <param name="powerPct">想要設定的功率百分比</param>
        /// <returns>設定成功回傳 true，失敗回傳 false</returns>
        private bool SetLaserPowerPercentage(double powerPct)
        {
            try
            {
                var roundPowerPct = (double)decimal.Round((decimal)powerPct, 1);

                _Laser.SetAttenuatorPercentage(roundPowerPct);

                const int maxAttempts = 120; // 最多等待 60 秒 (120 * 0.5s)
                int attempts = 0;

                while (attempts < maxAttempts)
                {
                    Thread.Sleep(500);
                    attempts++;

                    var status = _Laser.GetLaserStatus();
                    var sAttenuatorPercentage = status.AttenuatorPercentage;
                    var dAttenuatorPercentage = decimal.Round(decimal.Parse(sAttenuatorPercentage), 1);

                    bool isPass = false;

                    if (roundPowerPct <= 3)
                    {
                        if ((double)dAttenuatorPercentage <= 3)
                            isPass = true;
                    }
                    else
                    {
                        var roundPowerPctH = Math.Round(roundPowerPct + 0.1, 1);
                        var roundPowerPctL = Math.Round(roundPowerPct - 0.1, 1);

                        if ((double)dAttenuatorPercentage == roundPowerPct ||
                            (double)dAttenuatorPercentage == roundPowerPctH ||
                            (double)dAttenuatorPercentage == roundPowerPctL)
                        {
                            isPass = true;
                        }
                    }

                    if (isPass)
                        return true;   // ← 成功就立刻返回 true
                }

                // 超過最大等待時間仍失敗
                Console.WriteLine($"[Warning] SetLaserPowerPercentage 逾時！目標 {roundPowerPct}%");
                return false;
            }
            catch (Exception ex)
            {
                Console.WriteLine($"[Error] SetLaserPowerPercentage 發生例外: {ex.Message}");
                return false;
            }
        }

        ////以下為LCH原先之方法
        //private void SetLaserPowerPercentage(double powerPct)
        //{
        //    var roundPowerPct = (double)decimal.Round((decimal)powerPct, 1);
        //    var passFlag = false;

        //    _Laser.SetAttenuatorPercentage(roundPowerPct);

        //    while (!passFlag)
        //    {
        //        Thread.Sleep(500);

        //        var sAttenuatorPercentage = _Laser.GetLaserStatus().AttenuatorPercentage;
        //        var dAttenuatorPercentage = decimal.Round(decimal.Parse(sAttenuatorPercentage), 1);
        //        if (roundPowerPct <= 3)
        //        {
        //            if ((double)dAttenuatorPercentage <= 3)
        //                passFlag = true;
        //        }
        //        else
        //        {
        //            //雷射功率設定值確認，從振鏡讀取到的功率與設定值介於±0.1都算可以(雷射原內部比對百分比而已)
        //            var roundPowerPctH = Math.Round(roundPowerPct + 0.1, 1);
        //            var roundPowerPctL = Math.Round(roundPowerPct - 0.1, 1);
        //            if ((double)dAttenuatorPercentage == roundPowerPct || (double)dAttenuatorPercentage == roundPowerPctH || (double)dAttenuatorPercentage == roundPowerPctL)
        //                passFlag = true;
        //        }
        //    }
        //}
        //[BM:Arges研究-建立重新連線方法]
        /// <summary>
        /// 重新連線
        /// </summary>
        private void DoLaserReconnect()//重新連線
        {
            /*
             * 設計邏輯
             * 一開始會直接執行連線動作，若連線成功直接返回做自動加工。
             * 若連線失敗後會執行斷線再進行連線，若連線成功直接返回做自動加工。
             * 若再次失敗就會直接急停 並顯示異常
             */
            try
            {
                if (_AutoProcessLog_flag)
                    writeEventLog_Automatic_processing($"開始重新連線", $"");



                if (_LaserScanner.ConnectWrapper())//執行連線並回傳是否連線
                {
                    if (_AutoProcessLog_flag)
                        writeEventLog_Automatic_processing($"連線成功", $"返回自動加工流程");

                    BW_AutoProcess.RunWorkerAsync();//回去自動加工流程加工
                    _isReconnectDialogShown = false;//讓下次可以再顯示重連對話框
                }

                else
                {
                    if (_AutoProcessLog_flag)
                        writeEventLog_Automatic_processing($"重新連線失敗", $"下一步執行斷線");

                    if (_LaserScanner.DeinitializeWrapper())
                    {
                        if (_AutoProcessLog_flag)
                            writeEventLog_Automatic_processing($"斷線成功", $"等待0.5秒準備進行連線");
                        Thread.Sleep(500);
                        if (_LaserScanner.ConnectWrapper())//執行連線並回傳是否連線
                        {
                            if (_AutoProcessLog_flag)
                                writeEventLog_Automatic_processing($"連線成功", $"返回自動加工流程");

                            BW_AutoProcess.RunWorkerAsync();//回去自動加工流程加工
                            _isReconnectDialogShown = false;//讓下次可以再顯示重連對話框

                        }
                        else
                        {
                            if (_AutoProcessLog_flag)
                                writeEventLog_Automatic_processing($"斷線後重連失敗", $"顯示異常跳故障");

                            setEmergencyStopLock();//起動急停顯示異常
                           
                            return;
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                // 捕獲異常並記錄
                if (_AutoProcessLog_flag)
                    writeEventLog_Automatic_processing($"重新連線過程中發生異常: {ex.Message}", $"");

                setEmergencyStopLock(); // 發生異常時啟動急停
            }
        }
        private bool DoLaserProcessing()
        {
            _isLaserScannerBusy = true;
            scannerCheckStatus(); // Check Queue list status is ready to go or not 檢查隊列清單狀態是否已準備好
            checkProcessLimits(); //Check motion position is located in processing zone or not 檢查運動位置是否位於加工區域內
            switchLasingFlag(true);  // Switch flag of Lasing UI 雷射 UI 開關標誌
                                     // Start LaserScanner Job // 啟動雷射掃描器作業
                                     //_LaserScanner.StartJob(); //原始內容

            //[BM:振鏡加工]
            var Ls_Status =  _LaserScanner.StartJob();//回復是否進行加工
                                                      // var Ls_Status1 = _LaserScanner.startJob();

            //[BM:振鏡加工-失敗後重新嘗試2次，並記錄log]
            if (!Ls_Status)//若回false
            {
                const int retryCount = 3;            // 第一次失敗才進入重試

                for (int i = 1; i <= retryCount; i++)
                {
                    Ls_Status = _LaserScanner.StartJob();

                    //[BM:自訂Log紀錄內容-振鏡加工-振鏡回復狀態有誤紀錄重新嘗試次數]
                    if (_AutoProcessLog_flag)
                        writeEventLog_Automatic_processing($"振鏡回復狀態有誤", $"第{i}次嘗試加工 ");

                    if (Ls_Status)
                    {
                        //[BM:自訂Log紀錄內容-振鏡加工-振鏡回復狀態有誤紀錄重新嘗試後成功]
                        if (_AutoProcessLog_flag)
                            writeEventLog_Automatic_processing($"振鏡回復狀態有誤", $"第{i}次嘗試加工後成功繼續後續流程 ");
                        break; // 成功就跳出重試
                    }
                }

                if (!Ls_Status)
                {
                    //[BM:自訂Log紀錄內容-振鏡加工-振鏡回復狀態有誤紀錄重新嘗試後失敗中斷加工]
                    if (_AutoProcessLog_flag)
                        writeEventLog_Automatic_processing($"振鏡加工失敗", $"StartJob狀態:{Ls_Status}（已重試 {retryCount} 次） ");

                    writeError("振鏡加工失敗", $"StartJob狀態:{Ls_Status}（已重試 {retryCount} 次）");
                    MessageBox.Show($"StartJob狀態為:{Ls_Status}，振鏡異常自動流程終止。");
                    return Ls_Status;
                }
            }

            Thread.Sleep(500);

            while (!_FormLaserScanner.States.PLC_JOB_READY)
            {
                Thread.Sleep(100);
            }

            _isLaserScannerBusy = false;
       
            switchLasingFlag(false);     // Switch flag of Lasing UI
            return Ls_Status;
        }

        private void DoLaserCutting()
        {
            _isLaserScannerBusy = true;

            // Check Queue list status is ready to go or not
            scannerCheckStatus();

            //  Check motion position is located in processing zone or not
            checkProcessLimits();

            // Switch flag of Lasing UI
            switchLasingFlag(true);

            // Execute the Job and leave it alone
            _LaserScanner.StartJob();
        }

        private void DoLaserCuttingWithoutCheckProcessLimits()
        {
            _isLaserScannerBusy = true;

            // Check Queue list status is ready to go or not
            scannerCheckStatus();

            // Switch flag of Lasing UI
            switchLasingFlag(true);

            // Execute the Job and leave it alone
            _LaserScanner.StartJob();
        }

        private void StopLaserCutting()
        {
            // Stop the Laser scanner job
            _LaserScanner.AbortJob();

            while (!_FormLaserScanner.States.PLC_JOB_READY)
            {
                Thread.Sleep(100);
            }

            // Switch flag of Lasing UI
            switchLasingFlag(false);

            _isLaserScannerBusy = false;
        }

        private void EmergencyStopLaserCutting()
        {
            // Stop the Laser scanner job
            _LaserScanner.AbortJob();

            //while (!_FormLaserScanner.States.PLC_JOB_READY)
            //{
            //    Thread.Sleep(100);
            //}

            // Switch flag of Lasing UI
            switchLasingFlag(false);

            _isLaserScannerBusy = false;
        }

        #endregion

        #region BackgroundWorker

        private void BW_AutoFocus_DoWork(object sender, DoWorkEventArgs e)
        {
            AutoFocusType type = (AutoFocusType)e.Argument;

            switch (type)
            {
                case AutoFocusType.Camera:
                    int[] axisIndexZ = new int[] { (int)MotionAxis.Z };
                    int[] axisIndexes = new int[] { (int)MotionAxis.X, (int)MotionAxis.Y };
                    double[] speeds = new double[] { _ConfigEquip._Velocity_Default.X, _ConfigEquip._Velocity_Default.Y };
                    double[] distances = new double[] { _ConfigEquip._RelPosition_Laser2ConfocalLaser.X - _ConfigEquip._RelPosition_Laser2Camera.X, _ConfigEquip._RelPosition_Laser2ConfocalLaser.Y - _ConfigEquip._RelPosition_Laser2Camera.Y };

                    // Set Positioning to Relative Mode
                    string code = "G91";
                    executeGCode(code);

                    // Move from Camera to ConfocalLaser
                    // Do Motion Movement to specified target position
                    this.rapidMove(axisIndexes, distances, speeds);

                    // Wait for Motion completed
                    waitMotionDone(axisIndexes, 10000);

                    // Read Current ConfocalLaser result
                    _isConfocalLaserBusy = true;
                    ConfocalLaser.evalResult result = _ConfocalLaser.Trigger(1, out _ConfocalLaser_Output, 0);
                    _isConfocalLaserBusy = false;
                    double currentDistance = 0;
                    if (_ConfocalLaser_Output < -99999)
                    {
                        // Write Event
                        writeEvent("UserEvent", "Out of Compensate zone.");
                        MessageBox.Show("請先移動Z軸至測高計量測範圍!", "Error！！");
                        return;
                    }
                    else
                    {
                        currentDistance = -1 * _ConfocalLaser_Output * 0.001; //Since confocal laser result unit: um
                    }

                    distances = new double[] { _ConfigEquip._RelPosition_Laser2Camera.X - _ConfigEquip._RelPosition_Laser2ConfocalLaser.X, _ConfigEquip._RelPosition_Laser2Camera.Y - _ConfigEquip._RelPosition_Laser2ConfocalLaser.Y };

                    // Move from ConfocalLaser to Camera
                    // Do Motion Movement to specified target position
                    this.rapidMove(axisIndexes, distances, speeds);

                    //
                    //msg = "Move Z to Camera Focal Plane.";
                    double distance = currentDistance - _ConfigEquip._Height_Equip.Camera;

                    // MotionAxis.Z direction is reversed
                    distance = -1 * distance;
                    moveRel((int)MotionAxis.Z, distance, _ConfigEquip._Velocity_Default.Z);

                    break;
                case AutoFocusType.Laser:
                    axisIndexZ = new int[] { (int)MotionAxis.Z };
                    axisIndexes = new int[] { (int)MotionAxis.X, (int)MotionAxis.Y};
                    speeds = new double[] { _ConfigEquip._Velocity_Default.X, _ConfigEquip._Velocity_Default.Y};
                    distances = new double[] { _ConfigEquip._RelPosition_Laser2ConfocalLaser.X - _ConfigEquip._RelPosition_Laser2Camera.X, _ConfigEquip._RelPosition_Laser2ConfocalLaser.Y - _ConfigEquip._RelPosition_Laser2Camera.Y};


                    // Set Positioning to Relative Mode
                    code = "G91";
                    executeGCode(code);

                    // Move from Camera to ConfocalLaser
                    // Do Motion Movement to specified target position
                    this.rapidMove(axisIndexes, distances, speeds);

                    // Wait for Motion completed
                    waitMotionDone(axisIndexes, 10000);

                    code = "G90";
                    executeGCode(code);
                    this.moveAbs((int)MotionAxis.Z, _ConfigEquip._Position_ConfocalLaser.Z, _ConfigEquip._Velocity_Default.Z);

                    // Wait for Motion completed
                    waitMotionDone(axisIndexZ, 10000);

                    // Read Current ConfocalLaser result
                    _isConfocalLaserBusy = true;
                    result = _ConfocalLaser.Trigger(1, out _ConfocalLaser_Output, 0);                  
                    _isConfocalLaserBusy = false;
                    currentDistance = 0;
                    if (_ConfocalLaser_Output < -99999)
                    {
                        // Write Event
                        writeEvent("UserEvent", "Out of Compensate zone.");
                        MessageBox.Show("請先移動Z軸至測高計量測範圍!", "Error！！");
                        return;
                    }
                    else
                    {
                        currentDistance = -1 * _ConfocalLaser_Output * 0.001; //Since confocal laser result unit: um
                        writeEvent("Manual.LaserDistance", currentDistance.ToString());
                    }

                    distances = new double[] { -_ConfigEquip._RelPosition_Laser2ConfocalLaser.X, -_ConfigEquip._RelPosition_Laser2ConfocalLaser.Y };

                    // Set Positioning to Relative Mode
                    code = "G91";
                    executeGCode(code);

                    // Do Motion Movement to specified target position
                    this.rapidMove(axisIndexes, distances, speeds);

                    //
                    //msg = "Move Z to Camera Focal Plane.";
                    distance = currentDistance - _ConfigEquip._Height_Equip.Laser;

                    // MotionAxis.Z direction is reversed
                    distance = -1 * distance;
                    moveRel((int)MotionAxis.Z, distance, _ConfigEquip._Velocity_Default.Z);

                    // Wait for Motion completed
                    waitMotionDone(axisIndexZ, 10000);


                    break;
                case AutoFocusType.AutoProcess:
                    string msg = "Move Z to Camera Focal Plane.";

                    //Write Event
                    writeEvent("UserEvent", msg);

                    //Skip if isSimulated
                    if (_isSysSimulated)
                        return;

                    try
                    {
                        // Update Status
                        updatePnlStepState(pnl_AutoMode_MoveZ_Status, StepState.inactive);

                        axisIndexes = new int[] { (int)MotionAxis.X, (int)MotionAxis.Y };
                        speeds = new double[] { _ConfigEquip._Velocity_Default.X, _ConfigEquip._Velocity_Default.Y };
                        distances = new double[] { _ConfigEquip._RelPosition_Laser2ConfocalLaser.X - _ConfigEquip._RelPosition_Laser2Camera.X, _ConfigEquip._RelPosition_Laser2ConfocalLaser.Y - _ConfigEquip._RelPosition_Laser2Camera.Y };

                        // Set Positioning to Relative Mode
                        code = "G91";
                        executeGCode(code);

                        // Move from Camera to ConfocalLaser
                        // Do Motion Movement to specified target position
                        this.rapidMove(axisIndexes, distances, speeds);

                        // Wait for Motion completed
                        waitMotionDone(axisIndexes, 10000);

                        // Read Current ConfocalLaser result
                        _isConfocalLaserBusy = true;
                        result = _ConfocalLaser.Trigger(1, out _ConfocalLaser_Output, 0);
                        _isConfocalLaserBusy = false;
                        currentDistance = 0;
                        if (_ConfocalLaser_Output < -99999)
                        {
                            // Write Event
                            writeEvent("UserEvent", "Out of Compensate zone.");
                            MessageBox.Show("請先移動Z軸至測高計量測範圍!", "Error！！");
                            return;
                        }
                        else
                        {
                            currentDistance = -1 * _ConfocalLaser_Output * 0.001; //Since confocal laser result unit: um
                        }

                        distances = new double[] { _ConfigEquip._RelPosition_Laser2Camera.X - _ConfigEquip._RelPosition_Laser2ConfocalLaser.X, _ConfigEquip._RelPosition_Laser2Camera.Y - _ConfigEquip._RelPosition_Laser2ConfocalLaser.Y };

                        // Move from ConfocalLaser to Camera
                        // Do Motion Movement to specified target position
                        this.rapidMove(axisIndexes, distances, speeds);

                        //
                        //msg = "Move Z to Camera Focal Plane.";
                        distance = currentDistance - _ConfigEquip._Height_Equip.Camera;

                        // MotionAxis.Z direction is reversed
                        distance = -1 * distance;
                        moveRel((int)MotionAxis.Z, distance, _ConfigEquip._Velocity_Default.Z);

                        // Check already done or not
                        if (_stepFlags[(int)Step.s3])
                            return;

                        // Start Step Check Timer with checkAutoModeProgress
                        autoMode_StartStepWithTimer(Step.s3);

                        // Update Status
                        updatePnlStepState(pnl_AutoMode_MoveZ_Status, StepState.OK);

                        // No need to check
                        _stepTimers[(int)Step.s3].Set();

                        // Write Process
                        writeProcess("Step3", "已移動至測高焦平面");
                    }
                    catch (Exception ex)
                    {
                        // Update Status
                        writeError("MainForm.AutoProcess", "MoveZToCameraFocalPlane failed!" + ex);
                    }
                    break;
                default:
                    throw new Exception("Unexpected AutoFocusType");
            }
        }

        private void BW_AutoFocus_RunWorkerCompleted(object sender, RunWorkerCompletedEventArgs e)
        {
            // Enable GUI Controls
            //EnableGUIMotionControls(true);

            // Disable UI control
            enableUIGroup(true);

            if (e.Error != null)
            {
                // Error
                writeError("MainForm.ManualMode", "AutoFocus failed." + e.Error);

                // Update panel
                updatePnlStepState(pnl_ManualMode_AutoFocus_Status, StepState.NO);
            }
            else//正常結束
            {
                // Update panel
                updatePnlStepState(pnl_ManualMode_AutoFocus_Status, StepState.OK);

                if (_is_Alignment_Auto_FindHole)
                {
                    _Alignment_Auto_FindHole = new Thread(_Alignment_AT_FindHole);
                    _Alignment_Auto_FindHole.Start();
                    _Alignment_AT_FindHole_flag = 1;
                }
            }
        }

        private void BW_SetPower_DoWork(object sender, DoWorkEventArgs e)
        {
            double setPower = (double)e.Argument;

            // Check and set laser power
            CheckAndSetLaserPower(setPower);
        }

        private void BW_SetPower_RunWorkerCompleted(object sender, RunWorkerCompletedEventArgs e)
        {
            // Enable GUI Controls
            //EnableGUIMotionControls(true);

            // Disable UI control
            enableUIGroup(true);

            if (e.Error != null)
            {
                // Error
                writeError("MainForm.ManualMode", "SetPower failed." + e.Error);

                // Update panel
                updatePnlStepState(pnl_ManualMode_SetPower_Status, StepState.NO);
            }
            else
            {
                // Update panel
                updatePnlStepState(pnl_ManualMode_SetPower_Status, StepState.OK);
            }
        }
        private void BW_SampleMatrix_DoWork(object sender, DoWorkEventArgs e)
        {
            // Disable GUI Controls
            //EnableGUIMotionControls(false);

            // Disable UI control
            enableUIGroup(false);

            //Parse arguments
            Tuple<double, double, double, int, int, double, bool, Tuple<int>> arguments = (Tuple<double, double, double, int, int, double, bool, Tuple<int>>)e.Argument;
            double orgX = arguments.Item1;  //原點X
            double orgY = arguments.Item2;  //原點Y
            double samplePitch = arguments.Item3;    //陣列微孔間隔(mm)
            int sampleNumber = arguments.Item4;      //X個數
            int loopNumber = arguments.Item5;        //Y個數
            double cutsamplePitch = arguments.Item6; //切割加工檔偏移量(mm)
            bool cutFlag = arguments.Item7;          //切邊功能
            Tuple<int> argm = arguments.Rest;
            int laserdivider = argm.Item1;           //雷射除頻 Divider
                                          
            int totalNumber = sampleNumber * loopNumber; //總孔數
            int count = 0;
            int progressPercentage = 0;
            int[] axisIndexes = { (int)MotionAxis.X, (int)MotionAxis.Y };
            int File_Count = 0;

            double[,,] fixZ_cuthole_move_x = new double[4, 2, 5], fixZ_cuthole_move_y = new double[4, 2, 5];
            double[,,] fixZ_cuthole_array_move_x = new double[4, 2, 5], fixZ_cuthole_array_move_y = new double[4, 2, 5];
            int fixZ_num_cuthole_array_x = 5;     //中間陣列最大數量 X向
            int fixZ_num_cuthole_array_y = 2;     //中間陣列最大數量 Y向


            // 0. Initial setup
            //G00:Rapid position
            //G90: Absolute mode
            //G21: Units selection = millimeter 
            //G17: XY plane

            // IO display flag
            _isProcessing = true;


            try
            {
                string code = "G00 G90 G17";    //G21 failed???
                executeGCode(code);

                // Write Process
                writeProcess("小樣試打", "微孔試打流程已開始");

                // Set Laser Output Power
                double laserPower = _ConfigProcess._Power_Feature;  //Unit: mW
                //SetLaserOutputPowerWithoutCheck(laserPower);
                //Thread.Sleep(5000);
                //CheckAndSetLaserPower(laserPower);

                // Change Laser Divider
                _Laser.ChangePPDivider(laserdivider);

                Thread.Sleep(50);

                //微孔小樣雷射功率
                SetLaserPowerPercentage(laserPower);

                //一般載入一個到四個刀具模式
                if (!chk_ManualMode_AllJobxFile.Checked)
                {
                    // Upload Scanner jobx file 選擇載入多少刀具檔案
                    if (_jobxFilePath[0].Length == 0 && _jobxFilePath[1].Length == 0 && _jobxFilePath[2].Length == 0 && _jobxFilePath[3].Length == 0 && _AllJobxFileQueue.Count == 0)
                    {
                        MessageBox.Show("未選擇刀具.jobx檔！！", "Error！！");
                        e.Cancel = true;
                        return;
                    }
                    if (_jobxFilePath[0].Length != 0)
                    {
                        File_Count = 1;
                    }
                    if (_jobxFilePath[0].Length != 0 && _jobxFilePath[1].Length != 0)
                    {
                        File_Count = 2;
                    }
                    if (_jobxFilePath[0].Length != 0 && _jobxFilePath[1].Length != 0 && _jobxFilePath[2].Length != 0)
                    {
                        File_Count = 3;
                    }
                    if (_jobxFilePath[0].Length != 0 && _jobxFilePath[1].Length != 0 && _jobxFilePath[2].Length != 0 && _jobxFilePath[3].Length != 0)
                    {
                        File_Count = 4;
                    }


                    //刀具檔只載入一組
                    if (File_Count == 1)
                    {
                        // Upload Scanner jobx file
                        if (_jobxFilePath.Length == 0)
                        {
                            MessageBox.Show("Please select the .jobx first!");
                            e.Cancel = true;
                            return;
                        }
                        uploadJobWithSpecifiedFilePath(_jobxFilePath[0]);

                        double featureSpeed = _ConfigProcess._Speed_Feature;

                        // ProcessGas ON 開啟氮氣
                        enableProcessGas(true);

                        //X向打完打Y向
                        // Y direction 從上到下(往正移動)
                        for (int i = 0; i < loopNumber; i++)
                        {
                            // X direction 從左到右(往負移動)
                            for (int j = 0; j < sampleNumber; j++)
                            {

                                // Check cancelled or not
                                if (BW_SampleMatrix.CancellationPending)
                                {
                                    e.Cancel = true;
                                    return;
                                }

                                // Do Linear Movement 移動打孔位置
                                this.linearMove(orgX - j * samplePitch, orgY + i * samplePitch, featureSpeed);

                                // Wait in position 等待軸到位
                                waitMotionDone(axisIndexes, 10000);

                                // Do Laser Processing 開啟雷射
                                DoLaserProcessing();

                                // Stop Laser cutting
                                //StopLaserCutting();

                               

                                //完成進度
                                if (!cutFlag)
                                {
                                    count++;
                                    progressPercentage = (count * 100) / totalNumber;
                                    BW_SampleMatrix.ReportProgress(progressPercentage);
                                }
                                else
                                {
                                    count++;
                                    progressPercentage = (count * 100) / (totalNumber + _ConfigProcess._Sample_CutLoop);
                                    BW_SampleMatrix.ReportProgress(progressPercentage);
                                }


                            }
                        }
                    }

                    //刀具檔載入超過一組
                    else
                    {
                        //完成進度                   
                        progressPercentage = 1;
                        BW_SampleMatrix.ReportProgress(progressPercentage);

                        sampleNumber = 5;
                        loopNumber = 5;

                        //依加工檔案計算全部路徑 
                        for (int i = 0; i < File_Count; i++)
                        {

                            //計算切割 X向 微孔路徑
                            for (int j = 0; j < sampleNumber; j++)
                            {
                                fixZ_cuthole_move_x[i, 0, j] = orgX -
                                                                ((samplePitch * j) +
                                                                (cutsamplePitch * (i + 1)) +
                                                                (i * (samplePitch * sampleNumber)));

                                fixZ_cuthole_move_y[i, 0, j] = orgY;
                            }

                            //計算切割 Y向 微孔路徑
                            for (int j = 0; j < loopNumber; j++)
                            {
                                fixZ_cuthole_move_x[i, 1, j] = orgX;

                                fixZ_cuthole_move_y[i, 1, j] = orgY +
                                                                (samplePitch * j) +
                                                                (cutsamplePitch * (i + 1)) +
                                                                (i * (samplePitch * loopNumber));
                            }

                            //計算中間陣列 微孔路徑
                            for (int j = 0; j < fixZ_num_cuthole_array_y; j++)
                            {
                                for (int k = 0; k < fixZ_num_cuthole_array_x; k++)
                                {
                                    fixZ_cuthole_array_move_x[i, j, k] = orgX -
                                                                         (cutsamplePitch +
                                                                         (samplePitch * k));

                                    fixZ_cuthole_array_move_y[i, j, k] = orgY +
                                                                         (cutsamplePitch * (i + 1)) +
                                                                         (samplePitch * j) +
                                                                         (i * (samplePitch * fixZ_num_cuthole_array_y));
                                }
                            }
                        }



                        //依加工檔案 跑路徑打微孔
                        for (int i = 0; i < File_Count; i++)
                        {

                            //振鏡載入刀具
                            uploadJobWithSpecifiedFilePath(_jobxFilePath[i]);

                            //軸移動速度
                            double featureSpeed = _ConfigProcess._Speed_Feature;

                            // ProcessGas ON 開啟氮氣
                            enableProcessGas(true);

                            // X 個數
                            for (int j = 0; j < sampleNumber; j++)
                            {

                                // Check cancelled or not
                                if (BW_SampleMatrix.CancellationPending)
                                {
                                    e.Cancel = true;
                                    return;
                                }

                                // Do Linear Movement 移動X向打孔位置
                                //this.linearMove(orgX - j * samplePitch, orgY + i * samplePitch, featureSpeed);
                                this.linearMove(fixZ_cuthole_move_x[i, 0, j], fixZ_cuthole_move_y[i, 0, j], featureSpeed);

                                // Wait in position 等待軸到位
                                waitMotionDone(axisIndexes, 10000);

                                // Do Laser Processing 開啟雷射
                                DoLaserProcessing();

                                // Stop Laser cutting
                                //StopLaserCutting();

                            }
                            //Y
                            for (int j = 0; j < loopNumber; j++)
                            {

                                // Check cancelled or not
                                if (BW_SampleMatrix.CancellationPending)
                                {
                                    e.Cancel = true;
                                    return;
                                }

                                // Do Linear Movement 移動Y向打孔位置
                                //this.linearMove(orgX - j * samplePitch, orgY + i * samplePitch, featureSpeed);
                                this.linearMove(fixZ_cuthole_move_x[i, 1, j], fixZ_cuthole_move_y[i, 1, j], featureSpeed);

                                // Wait in position 等待軸到位
                                waitMotionDone(axisIndexes, 10000);

                                // Do Laser Processing 開啟雷射
                                DoLaserProcessing();

                                // Stop Laser cutting
                                //StopLaserCutting();


                            }

                            //中間
                            for (int j = 0; j < fixZ_num_cuthole_array_y; j++)
                            {

                                for (int k = 0; k < fixZ_num_cuthole_array_x; k++)
                                {

                                    // Check cancelled or not
                                    if (BW_SampleMatrix.CancellationPending)
                                    {
                                        e.Cancel = true;
                                        return;
                                    }

                                    // Do Linear Movement 移動中間打孔位置
                                    //this.linearMove(orgX - j * samplePitch, orgY + i * samplePitch, featureSpeed);
                                    this.linearMove(fixZ_cuthole_array_move_x[i, j, k], fixZ_cuthole_array_move_y[i, j, k], featureSpeed);

                                    // Wait in position 等待軸到位
                                    waitMotionDone(axisIndexes, 10000);

                                    // Do Laser Processing 開啟雷射
                                    DoLaserProcessing();

                                    // Stop Laser cutting
                                    //StopLaserCutting();


                                }
                            }
                            //完成進度
                            if (!cutFlag)
                            {
                                count++;
                                progressPercentage = (count * 100) / File_Count;
                                BW_SampleMatrix.ReportProgress(progressPercentage);
                            }
                            else
                            {
                                count++;
                                progressPercentage = (count * 100) / (File_Count + _ConfigProcess._Sample_CutLoop);
                                BW_SampleMatrix.ReportProgress(progressPercentage);
                            }
                        }
                    }

                    //微孔切割
                    if (cutFlag)
                    {
                        // Write Process
                        writeProcess("小樣試打", "切割流程已開始");

                        double fastSpeed = _ConfigProcess._Speed_Fast;
                        double cutSpeed = _ConfigProcess._Speed_Others;
                        string jobName = _ConfigProcess._Sample_JobName;
                        int cutLoop = _ConfigProcess._Sample_CutLoop;
                        double cutWidth = _ConfigProcess._Sample_CutWidth;   //Unit: mm
                        double cutLength = _ConfigProcess._Sample_CutLength;  //Unit: mm
                        double offsetX = _ConfigProcess._Sample_OffsetX; //Unit: mm
                        double offsetY = _ConfigProcess._Sample_OffsetY; //Unit: mm
                        double X_1 = orgX + offsetX;
                        double Y_1 = orgY - offsetY;
                        double X_2 = X_1 - cutWidth;
                        double Y_2 = Y_1;
                        double X_3 = X_2;
                        double Y_3 = Y_2 + cutLength;
                        double X_4 = X_1;
                        double Y_4 = Y_3;
                        //laserPower = _ConfigProcess._Power_Others;  //Unit: mW
                        laserPower = _ConfigProcess._Power_Feature;
                        progressPercentage = 0;

                        // Set Laser Output Power
                        //SetLaserOutputPowerWithoutCheck(laserPower);
                        //Thread.Sleep(5000);
                        //CheckAndSetLaserPower(laserPower);

                        // Change Laser Divider
                        _Laser.ChangePPDivider(1);

                        Thread.Sleep(50);

                        SetLaserPowerPercentage(laserPower);

                        // Upload Scanner Jobx file
                        uploadJob(jobName);

                        //Move to First point
                        this.linearMove(X_1, Y_1, fastSpeed);

                        // Wait in position
                        waitMotionDone(axisIndexes, 10000);

                        // Do Laser cutting
                        DoLaserCutting();

                        for (int i = 0; i < cutLoop; i++)
                        {
                            // Check cancelled or not
                            if (BW_SampleMatrix.CancellationPending)
                            {
                                e.Cancel = true;
                                return;
                            }

                            this.linearMove(X_2, Y_2, cutSpeed);

                            this.linearMove(X_3, Y_3);

                            this.linearMove(X_4, Y_4);

                            this.linearMove(X_1, Y_1);

                            if (File_Count == 1)
                            {
                                count++;
                                progressPercentage = (count * 100) / (totalNumber + _ConfigProcess._Sample_CutLoop);
                                BW_SampleMatrix.ReportProgress(progressPercentage);
                            }
                            else
                            {
                                count++;
                                progressPercentage = (count * 100) / (File_Count + _ConfigProcess._Sample_CutLoop);
                                BW_SampleMatrix.ReportProgress(progressPercentage);

                            }
                        }

                        // Wait in position
                        waitMotionDone(axisIndexes, 60000);

                        // Stop Laser cutting
                        StopLaserCutting();

                        // Write Process
                        writeProcess("小樣試打", "切割流程已完畢");
                    }
                }
                //載入資料夾內，全部刀具模式
                else
                {
                    double featureSpeed = _ConfigProcess._Speed_Feature;
                    int JobxFileCount;
                    int _count = 0;
                        
                    string[] files = Directory.GetFiles(AllJobxFilefoldPath, "*.jobx");
                    foreach (var file in files)
                    {
                        //資料夾內的jobx全部刀具檔案塞入_AllJobxFileQueue
                        _AllJobxFileQueue.Enqueue(files[_count]);
                        _count++;
                    }
                    JobxFileCount = _AllJobxFileQueue.Count;

                    //判斷_AllJobxFileQueue是否有資料
                    if (_AllJobxFileQueue.Count > 0)
                    {
                        
                        //判斷_AllJobxFileQueue內有幾組刀具
                        for (int k = 0; k < JobxFileCount; k++)
                        {
                            // Upload Scanner jobx file
                            if (_AllJobxFileQueue.Count == 0)
                            {
                                MessageBox.Show("Please select the .jobx first!");
                                e.Cancel = true;
                                return;
                            }
                            uploadJobWithSpecifiedFilePath(_AllJobxFileQueue.Dequeue());
                           
                            // ProcessGas ON 開啟氮氣
                            enableProcessGas(true);

                            //X向打完打Y向
                            // Y direction 從上到下(往正移動)
                            for (int i = 0; i < loopNumber; i++)
                            {
                                // X direction 從左到右(往負移動)
                                for (int j = 0; j < sampleNumber; j++)
                                {

                                    // Check cancelled or not
                                    if (BW_SampleMatrix.CancellationPending)
                                    {
                                        e.Cancel = true;
                                        return;
                                    }

                                    // Do Linear Movement 移動打孔位置
                                    this.linearMove(orgX - (j * samplePitch) - (k * cutsamplePitch), orgY + i * samplePitch, featureSpeed);

                                    // Wait in position 等待軸到位
                                    waitMotionDone(axisIndexes, 10000);

                                    // Do Laser Processing 開啟雷射
                                    DoLaserProcessing();

                                    // Stop Laser cutting
                                    //StopLaserCutting();

                                }
                            }
                            count++;
                            progressPercentage = (count * 100) / JobxFileCount;
                            BW_SampleMatrix.ReportProgress(progressPercentage);
                        }
                    }                   
                }

                // ProcessGas OFF
                enableProcessGas(false);
            }
            catch (Exception ex)
            {
                e.Cancel = true;
                writeError("MainForm.ManualMode", "SampleMatrix failed!" + ex);
                return;
            }
        }

        private void BW_SampleMatrix_ProgressChanged(object sender, ProgressChangedEventArgs e)
        {
            string sProgress = string.Format("已完成 : {0:0}%", e.ProgressPercentage);
            updateControlTxtWithString(lbl_ManualMode_SampleMatrixStatus, sProgress);
            updateControlTxtWithString(txt_ManualMode_LastExecTime, _lastExecTime.ToString());
        }

        private void BW_SampleMatrix_RunWorkerCompleted(object sender, RunWorkerCompletedEventArgs e)
        {
            if (e.Cancelled)
            {
                updateControlTxtWithString(lbl_ManualMode_SampleMatrixStatus, "Stopped!");
            }
            else
            {
                updateControlTxtWithString(lbl_ManualMode_SampleMatrixStatus, "100%");
            }
            // IO display flag
            _isProcessing = false;

            // Write Process
            writeProcess("小樣試打", "微孔試打流程已結束。");

            // Disable GUI Controls
            //EnableGUIMotionControls(true);

            // Disable UI control
            enableUIGroup(true);

            //MES 待料狀態
            if (_ConfigSystem._ConnectSetting.ChptMES)
            {
                Description = "待料";
                //[BM:將機台資訊傳送給MES]
                _CHPT_MES.Send_MES_Data(EquipmentNo, (int)EquipmentState.Waitmaterial, UserNo, Description, IsEQPTrigger, LotNo);
            }
        }

        private void BW_GH_SampleMatrix_DoWork(object sender, DoWorkEventArgs e)
        {
            // Disable GUI Controls
            //EnableGUIMotionControls(false);

            // Disable UI control
            enableUIGroup(false);

            //Parse arguments
            Tuple<double, double, double, int, int, double, double, Tuple<int>> arguments = (Tuple<double, double, double, int, int, double, double, Tuple<int>>)e.Argument;
            double orgX = arguments.Item1;
            double orgY = arguments.Item2;
            double samplePitch = arguments.Item3;
            int sampleNumber = arguments.Item4;
            int loopNumber = arguments.Item5;
            double power = arguments.Item6;
            double speed = arguments.Item7;
            Tuple<int> argm = arguments.Rest;
            int cutLoop = argm.Item1;

            int totalNumber = sampleNumber * loopNumber;
            int count = 0;
            int progressPercentage = 0;
            int[] axisIndexes = { (int)MotionAxis.X, (int)MotionAxis.Y };
            double speedFast = _ConfigProcess._Speed_Fast;
            double targetPositionX = 0.0;
            double targetPositionY = 0.0;
            double processPositionX = 0.0;
            double processPositionY = 0.0;


            // 0. Initial setup
            //G00:Rapid position
            //G90: Absolute mode
            //G21: Units selection = millimeter
            //G17: XY plane

            // IO display flag
            _isProcessing = true;


            try
            {
                string code = "G00 G90 G17";    //G21 failed???
                executeGCode(code);

                // Write Process
                writeProcess("小樣試打", "GH試打流程已開始");

                // Set Laser Output Power
                double laserPower = power;  //Unit: mW
                //SetLaserOutputPowerWithoutCheck(laserPower);
                //Thread.Sleep(5000);
                //CheckAndSetLaserPower(laserPower);

                // Change Laser Divider
                _Laser.ChangePPDivider(1);

                Thread.Sleep(50);

                ///SetLaserPowerPercentage(100);
                SetLaserPowerPercentage(laserPower);

                // Upload Scanner XML file
                if (_GH_jobxFilePath.Length == 0)
                {
                    MessageBox.Show("未選擇刀具.jobx檔！！", "Error！！");
                    e.Cancel = true;
                    return;
                }
                uploadJobWithSpecifiedFilePath(_GH_jobxFilePath);

                // ProcessGas ON
                enableProcessGas(true);

                //完成進度                   
                progressPercentage = 1;
                BW_GH_SampleMatrix.ReportProgress(progressPercentage);

                // Y direction 從上到下(往正移動)
                for (int i = 0; i < loopNumber; i++)
                {
                    // X direction 從左到右(往負移動)
                    for (int j = 0; j < sampleNumber; j++)
                    {
                        
                        // Check cancelled or not
                        if (BW_GH_SampleMatrix.CancellationPending)
                        {
                            e.Cancel = true;
                            return;
                        }

                        processPositionX = orgX - j * samplePitch;
                        processPositionY = orgY + i * samplePitch;


                        /*// Probe required
                        // Move to ConfocalLaser point
                        double targetPositionX =  processPositionX + _ConfigEquip._RelPosition_Laser2ConfocalLaser.X;
                        double targetPositionY =  processPositionY + _ConfigEquip._RelPosition_Laser2ConfocalLaser.Y;

                        // Wait in position
                        waitMotionDone(axisIndexes, 10000);

                        // Move to target position
                        linearMove(targetPositionX, targetPositionY, speedFast);

                        // Wait in position
                        waitMotionDone(axisIndexes, 10000);

                        // Set Positioning to Absolute Mode
                        code = "G90";
                        executeGCode(code);
                        this.moveAbs((int)MotionAxis.Z, _ConfigEquip._Position_ConfocalLaser.Z, _ConfigEquip._Velocity_Default.Z);

                        // Wait for Motion completed
                        waitMotionDone(axisIndexZ, 10000);

                        // Get compensage position
                        double compensatePosition = getCompesatePosition();

                        //// Evaluate the offsetZ
                        //double offsetZ = compensatePosition - _positionFeedback[(int)MotionAxis.Z];
                        //string formatOffsetZ = string.Format("{0:0.####}", offsetZ);
                        //double.TryParse(formatOffsetZ, out offsetZ);

                        //// Upload JobList with Compensate offsetZ by changing JobList
                        //uploadJobListWithCompensateZWithSpecifiedFilePath(_GH_jobxFilePath, offsetZ);

                        // Change Compensate offsetZ
                        // Evaluate the offsetZ
                        double offsetZ = compensatePosition - _positionFeedback[(int)MotionAxis.Z];
                        //string formatOffsetZ = string.Format("{0:0.####}", offsetZ);
                        moveRel((int)MotionAxis.Z, offsetZ, _ConfigEquip._Velocity_Default.Z);

                        // Wait in position
                        waitMotionDone(axisIndexZ, 10000);*/

                        // 4. Move to Process point
                        targetPositionX =  processPositionX;
                        targetPositionY =  processPositionY;

                        // Write Data log
                        writeDataQueue("小樣GH位置參數", string.Format("中心X.{0} 中心Y.{1} 間隔.{2} processX.{3} processY.{4} targetX.{5} targetY.{6}", orgX, orgY, samplePitch, processPositionX, processPositionY, targetPositionX, targetPositionY));


                        // Wait in position
                        waitMotionDone(axisIndexes, 10000);

                        // Move to target position
                        linearMove(targetPositionX, targetPositionY, speedFast);

                        // 5. Start Laser ablation
                        // Wait in position
                        waitMotionDone(axisIndexes, 10000);

                        // Do Laser cutting
                        try
                        {
                            DoLaserCutting();
                        }
                        catch (Exception ex)
                        {
                            throw ex;
                        }

                        // 6. Start CP
                        ccwMove(processPositionX -0.2, processPositionY -0.2, -0.2, 0, speed);

                        // 7. Do Loop CP in loop of (Operation6)
                        for (int k = 0; k < cutLoop; k++)
                        {
                            // Check cancel
                            if (BW_GH_SampleMatrix.CancellationPending)
                            {
                                // Stop Laser cutting
                                StopLaserCutting();

                                e.Cancel = true;
                                return;
                            }

                            ccwMove( processPositionX - 0.2, processPositionY - 0.2, 0, 0.982, speed);
                        }

                        // 8. End CP
                        ccwMove( processPositionX,  processPositionY, 0, 0.2, speed);

                        // 9. Stop Laser ablation
                        // Wait in position
                        waitMotionDone(axisIndexes, 600000);

                        // Stop Laser cutting
                        StopLaserCutting();

                        // 10. Completed
                        BW_GH_SampleMatrix.ReportProgress(0);

                        count++;
                        progressPercentage = (count * 100) / totalNumber;
                        BW_GH_SampleMatrix.ReportProgress(progressPercentage);
                    }
                }

                // ProcessGas OFF
                enableProcessGas(false);
            }
            catch (Exception ex)
            {
                e.Cancel = true;
                writeError("MainForm.ManualMode", "GH_SampleMatrix failed!" + ex);
                return;
            }
        }

        private void BW_GH_SampleMatrix_ProgressChanged(object sender, ProgressChangedEventArgs e)
        {
            string sProgress = string.Format("已完成 : {0:0}%", e.ProgressPercentage);
            updateControlTxtWithString(lbl_ManualMode_GH_SampleMatrixStatus, sProgress);
        }

        private void BW_GH_SampleMatrix_RunWorkerCompleted(object sender, RunWorkerCompletedEventArgs e)
        {
            if (e.Cancelled)
            {
                updateControlTxtWithString(lbl_ManualMode_GH_SampleMatrixStatus, "Stopped!");
            }
            else
            {
                updateControlTxtWithString(lbl_ManualMode_GH_SampleMatrixStatus, "100%");
            }

            // IO display flag
            _isProcessing = false;


            // Write Process
            writeProcess("小樣試打", "GH試打流程已結束。");

            // Disable GUI Controls
            //EnableGUIMotionControls(true);

            // Disable UI control
            enableUIGroup(true);
            //MES 待料狀態
            if (_ConfigSystem._ConnectSetting.ChptMES)
            {
                Description = "待料";
                //[BM:將機台資訊傳送給MES]
                _CHPT_MES.Send_MES_Data(EquipmentNo, (int)EquipmentState.Waitmaterial, UserNo, Description, IsEQPTrigger, LotNo);
            }
        }




        private void BW_CagilaThickProcess_DoWork(object sender, DoWorkEventArgs e)
        {
            // IO display flag
            _isProcessing = true;

            _formNCParser = new FormNCParser(_NCParser);
            NCScriptParser data = _formNCParser.data;
            _process_Offset_X = _ConfigEquip._OrgPoint.X - _ConfigEquip._RelPosition_Laser2Camera.X;
            _process_Offset_Y = _ConfigEquip._OrgPoint.Y - _ConfigEquip._RelPosition_Laser2Camera.Y;
            //if (_isSysSimulated) return;
            // Evaluate total number of Measurement
            int count = data._DDS_RowCount;
            for (int i = 0; i < count; i++)
            {
                // Check LoadData or not
                if (data._DDS_LoadData[i])
                {
                    // Check ZProbe or not
                    if (data._DDS_ZProbe[i])
                    {
                        _NbrOfThickProcess_Total++;
                        _nbrOfThickProcess_Total++;
                    }
                }
            }

            // Write Process
            writeProcess("Cagila檔試打-Step5", "測高流程總數 = " + _NbrOfThickProcess_Total);

            if (!_isSysSimulated)//不是模擬模式=正式模式，會走這裡
            {


                // 0. Initial setup
                //G00:Rapid position
                //G90: Absolute mode
                //G21: Units selection = millimeter
                //G17: XY plane
                string code = "G00 G90 G17";    //G21 failed???
                executeGCode(code);

                executeGCode(code);
                this.moveAbs((int)MotionAxis.Z, _ConfigEquip._Position_ConfocalLaser.Z, _ConfigEquip._Velocity_Default.Z);
                int[] axisIndexZ = { (int)MotionAxis.Z };
                // Wait for Motion completed
                waitMotionDone(axisIndexZ, 10000);

                // Process parameters
                int[] axisIndexes = { (int)MotionAxis.X, (int)MotionAxis.Y };
                _ThickResult = new double[count];
                _CompensatePosition = new double[count];
                //測高加工前後比對功能
                ThickProcess = new double[count];
                AutoThickProcess = new double[count];

                // Start ThickProcess
                for (int i = 0; i < count; i++)
                {
                    // Check LoadData or not
                    if (data._DDS_LoadData[i])//看要不要測高
                    {
                        // Check cancel
                        if (BW_CagilaThickProcess.CancellationPending)
                        {
                            e.Cancel = true;
                            return;
                        }

                        // Check ZProbe or not
                        if (data._DDS_ZProbe[i])
                        {
                            double targetPositionX = _process_Offset_X + data._DDS_ZprobePositionX[i] + _ConfigEquip._RelPosition_Laser2ConfocalLaser.X;
                            double targetPositionY = _process_Offset_Y + data._DDS_ZprobePositionY[i] + _ConfigEquip._RelPosition_Laser2ConfocalLaser.Y;

                            // Wait in position
                            waitMotionDone(axisIndexes, 10000);

                            // Move to target position
                            double speed = _ConfigProcess._Speed_Fast;
                            linearMove(targetPositionX, targetPositionY, speed);

                            // Wait in position
                            waitMotionDone(axisIndexes, 10000);

                            // Get the CompensatePosition from ConfocalLaser
                            try
                            {
                                _CompensatePosition[i] = getCompesatePosition();

                                //測高比對-加工前測高紀錄                            
                                ThickProcess[i] = Math.Round(_positionFeedback[(int)MotionAxis.Z] - _CompensatePosition[i] + _ConfigEquip._Height_Equip.Laser, 4);
                            }
                            catch (Exception)
                            {
                                MessageBox.Show("測厚異常，請確認是否已擺放樣品並完成光學對焦。", "Error！！");
                                e.Cancel = true;
                                return;
                            }

                            // Write Log
                            string msg = string.Format("Get Compensate position[{0}] (z) = {1:0.###}", i, _CompensatePosition[i]);
                            writeDataQueue("ConfocalLaser", msg);

                            //進度條
                            progressPercentage = (++_NbrOfThickProcess_Done * 100) / _NbrOfThickProcess_Total;
                            updateControlTxtWithString(Cagila_Thick_Label, string.Format("Progress = {0}% ({1}/{2})", progressPercentage, _NbrOfThickProcess_Done, _NbrOfThickProcess_Total));
                        }
                    }
                    // Wait processing completed
                    BW_CagilaThickProcess.ReportProgress(0);
                }
            }
            else//模擬模式會走這，觀看ui介面是否正常，及背景作業是否正常
            {
                for (int i = 0; i < count; i++)
                {
                  
                    if (data._DDS_ZProbe[i])

                    { // Check cancel
                        if (BW_CagilaThickProcess.CancellationPending)
                        {
                            e.Cancel = true;
                            return;
                        }
                        //進度條
                        progressPercentage = (++_NbrOfThickProcess_Done * 100) / _NbrOfThickProcess_Total;
                        updateControlTxtWithString(Cagila_Thick_Label, string.Format("Progress = {0}% ({1}/{2})", progressPercentage, _NbrOfThickProcess_Done, _NbrOfThickProcess_Total));
                    }
                    // Wait processing completed
                    BW_CagilaThickProcess.ReportProgress(0);
                    Thread.Sleep(5);
                }
            }
        }
        private void BW_CagilaThickProcess_ProgressChanged(object sender, ProgressChangedEventArgs e)
        {
            Cagila_Thick_progressBar.Value = progressPercentage/100f;
        }
        private void BW_CagilaThickProcess_RunWorkerCompleted(object sender, RunWorkerCompletedEventArgs e)
        {
            // IO display flag
            _isProcessing = false;

            _NbrOfThickProcess_Done = 0;
            _NbrOfThickProcess_Total = 0;

            if (e.Cancelled == true)
            {
                // Cancelled
                Cagila_Thick_Panel.BackColor = Color.Red;

                updateControlTxtWithString(Cagila_Thick_Label, string.Format("Progress = {0}% ({1}/{2})", 0, 0, 0));
                Cagila_Thick_progressBar.Value = 0f;

                // Write Process
                writeProcess("Cagila檔試打-Step5", "測高流程已中斷");
            }
            else if (e.Error != null)
            {
                // Error
                Cagila_Thick_Panel.BackColor = Color.Red;
                writeError("Cagila檔試打-Step5", "測高過程失敗." + e.Error);
                // Write Process
                writeProcess("Cagila檔試打-Step5", "錯誤發生致測高流程已中斷");
            }
            else
            {
                Cagila_Thick_Panel.BackColor = Color.Green;
                Cagila_Thick_progressBar.Value = 100;
                // Write Process
                writeProcess("Cagila檔試打-Step5", "測高流程已完成");
                btn_ManualMode_Cagila_AutoProcess_Start.Enabled = true;
            }
        }

        private void BW_CagilaAutoProcess_DoWork(object sender, DoWorkEventArgs e)
        {
            if (!_isSysSimulated)
            {
                #region Check before Processing

                //// Check LockDoor
                //if (!_stepFlags[(int)Step.s5])
                //{
                //    if (_isSafetyInterlock)
                //    {
                //        MessageBox.Show("電子門鎖狀態異常，請確認門板是否正確闔上並啟動上鎖。", "Error！！");
                //        e.Cancel = true;
                //        return;
                //    }
                //}

                //// Check ThickProcess
                //if (!_stepFlags[(int)Step.s6])
                //{
                //    MessageBox.Show("測導板厚度狀態異常，請確認是否已執行過。", "Error！！");
                //    e.Cancel = true;
                //    return;
                //}

                //// Check MonitorStatus
                //if (_isSysMonitorFailed)
                //{
                //    MessageBox.Show("系統監控狀態異常，請確認設備裝置功能，並點擊「重置 Reset」。", "Error！！");
                //    e.Cancel = true;

                //    //MES 故障狀態
                //    if (_ConfigSystem._ConnectSetting.ChptMES && SendErr_ToMES_Req)
                //    {
                //        SendErr_ToMES_Req = false;
                //        //[BM:修改重複上報異常-更新狀態4]
                //        _ConfigSystem._MES_State = "Error";
                //        _ConfigSystem.WriteMES_State();
                //        Description = "故障與維修";
                //        _CHPT_MES.Send_MES_Data(EquipmentNo, (int)EquipmentState.Error, UserNo, Description, IsEQPTrigger, _CHPT_MES.Batch_Number);
                //    }
                //    return;
                //}

                #endregion

                #region Initialization


                // Disable GUI Controls
                //EnableGUIMotionControls(false);

                // Disable UI control
                //enableUIGroup(false);

                // Get NC code data
                NCScriptParser data = _NCParser;

                // Evaluate total number of feature
                // int count = data._DDS_RowCount;
                _NbrOfProcess_Total = 0;
                _NbrOfProcess_Done = 0;
                _NbrOfFeature_Total = 0;
                _NbrOfFeature_Done = 0;

                //解析NC檔
                _NbrOfFeature_Total = data._NewDrillFeatures.Length;

                if (!Cagila_AutoProcess_Checkbox.Checked)//如果全部加工
                {
                    _NbrOfProcess_Total = _NbrOfFeature_Total + data._QueueCmds.Count;//微孔+微孔以外的加工數
                }
                else//如果只加工微孔
                {
                    _NbrOfProcess_Total = _NbrOfFeature_Total;
                }

                // Process parameters
                int[] axisIndexZ = { (int)MotionAxis.Z };
                int[] axisIndexXY = { (int)MotionAxis.X, (int)MotionAxis.Y };
                // int[] axisAllIndexes = { (int)MotionAxis.X, (int)MotionAxis.Y, (int)MotionAxis.Z };
                double targetPositionX;
                double targetPositionY;
                double LP_Gain = _ConfigProcess._LaserParam_Convert.Gain;
                double LP_Offset = _ConfigProcess._LaserParam_Convert.Offset;
                double MP_Gain = _ConfigProcess._MotionParam_Convert.Gain;
                double MP_Offset = _ConfigProcess._MotionParam_Convert.Offset;
                //bool enableWarmup = _ConfigProcess._IsAutoProcessWarmup;
                bool enableSuspend = _ConfigProcess._IsAutoProcessSuspend;
                bool enableHold = _ConfigProcess._IsAutoProcessHold;
                bool enblePowerCheck = _ConfigSystem._ConnectSetting.Powermeter;
                double PowerCheck_USL = _ConfigSystem._AutoPowerCheck_USL;
                double PowerCheck_LSL = _ConfigSystem._AutoPowerCheck_LSL;
                double PowerCheck_value = _ConfigSystem._AutoPowerCheck_value;
                int AutoPowerCheck_count = _ConfigSystem._AutoPowerCheck_count;

                double PowerCheck_Ofs = 0;

                int warmup_TimeToWait = _ConfigProcess._Warmup_TimeToWait * 1000;   // Convert sec to ms
                int suspend_IntervalTime = _ConfigProcess._Suspend_IntervalTime * 1000;   // Convert sec to ms
                int hold_IntervalTime = _ConfigProcess._Hold_IntervalTime * 1000;   // Convert sec to ms
                int suspend_TimeToWait = _ConfigProcess._Suspend_TimeToWait * 1000;   // Convert sec to ms
                                                                                      // int hold_TimeToWait = _ConfigProcess._Hold_TimeToWait * 1000;   // Convert sec to ms

                int retrycount = 0;

                double laserPowerPct = 0;
                double CutSpeed = 0;
                double FastSpeed = 0;
                double _offsetZ = 0;
                double resultdistance = 0.0;
                double _OutputPower = 0.0;
                bool ProbeFinish = false;
                bool LinearZFinish = false;




                Stopwatch stopwatch_Warmup = new Stopwatch();
                Stopwatch stopwatch_Suspend = new Stopwatch();
                Stopwatch stopwatch_Hold = new Stopwatch();
                //double lastPosition_X, lastPosition_Y, lastPosition_Z;

                _process_Offset_X = _ConfigEquip._OrgPoint.X - _ConfigEquip._RelPosition_Laser2Camera.X;
                _process_Offset_Y = _ConfigEquip._OrgPoint.Y - _ConfigEquip._RelPosition_Laser2Camera.Y;


                // Initialization process
                // IO display flag
                _isProcessing = true;


                // Start Process Elapsed Time
                _stopwatch_ElapsedTime.Start();

                // ProcessGas ON 開啟氮氣
                //enableProcessGas(true);

                // Open Vacuum 開啟真空
                enableChuckVacuum(true);

                // 0. Initial setup
                // G00:Rapid position
                // G90: Absolute mode
                // G21: Units selection = millimeter
                // G17: XY plane
                string code = "G00 G90 G17";    //G21 failed???
                executeGCode(code);

                //[BM:暖機流程，家維要求不暖機]
                //if (enableWarmup) // Check Warm-up or not 加工前暖機
                //{
                //    // Write Process
                //    writeProcess("Step7", "加工流程暖機開始");

                //    _Laser.ChangePPDivider(1);
                //    Thread.Sleep(100);

                //    // Change Laser power
                //    //雷射功率補償功能開啟
                //    if (enblePowerCheck)
                //        laserPowerPct = laserParamConvert(data._LP_PowerPct[data._Op_LaserParamSet[0]], LP_Gain, LP_Offset);
                //    else
                //        laserPowerPct = 2;

                //    // Set Laser Output Power
                //    SetLaserPowerPercentage(laserPowerPct);

                //    // Change LaserScanner File 讀取振鏡DryRunJob.jobx檔案
                //    try
                //    {
                //        //雷射功率補償功能開啟
                //        if (enblePowerCheck)
                //            uploadJob("Powermeter");
                //        else
                //            uploadJob("DryRunJob");
                //    }
                //    catch (Exception)
                //    {
                //        MessageBox.Show("載入刀具錯誤，請確認是否有這項刀具。", "Error！！");
                //        e.Cancel = true;
                //        return;
                //    }

                //    // Move to PowerMonitor position                
                //    linearMove(_ConfigEquip._Position_PowerMonitor.X, _ConfigEquip._Position_PowerMonitor.Y, 50);

                //    // Wait in position
                //    waitMotionDone(axisIndexXY, 10000);

                //    btn_Move_Position_PowerMonitor_Click(this, null);

                //    // Wait in position
                //    waitMotionDone(axisIndexXY, 10000);

                //    // Do Laser cutting
                //    DoLaserCutting();

                //    // Start stopwatch
                //    stopwatch_Warmup.Start();

                //    while (stopwatch_Warmup.ElapsedMilliseconds < warmup_TimeToWait)
                //    {
                //        // Check cancel
                //        if (BW_AutoProcess.CancellationPending)
                //        {
                //            e.Cancel = true;
                //            return;
                //        }
                //        Thread.Sleep(1000);
                //    }


                //    // Write Process
                //    writeProcess("Step7", "加工流程暖機結束");
                //}
                // Disable UI control
                //enableUIGroup(false);

                //加工前確認雷射功率
                if (enblePowerCheck)
                {
                    // Write Process
                    writeProcess("Cagila檔試打-Step6", "雷射功率檢查開始");

                    //暖機功能未開啟
                    //if (!enableWarmup)
                    //{
                    //    _Laser.ChangePPDivider(1);
                    //    Thread.Sleep(100);

                    //    // Change Laser power
                    //    laserPowerPct = laserParamConvert(data._LP_PowerPct[data._Op_LaserParamSet[0]], LP_Gain, LP_Offset);

                    //    // Set Laser Output Power
                    //    SetLaserPowerPercentage(laserPowerPct);

                    //    // Change LaserScanner File 讀取振鏡DryRunJob.jobx檔案
                    //    try
                    //    {
                    //        uploadJob("Powermeter");
                    //    }
                    //    catch (Exception)
                    //    {
                    //        MessageBox.Show("載入刀具錯誤，請確認是否有這項刀具。", "Error！！");
                    //        e.Cancel = true;
                    //        return;
                    //    }

                    //    // Move to PowerMonitor position

                    //    linearMove(_ConfigEquip._Position_PowerMonitor.X, _ConfigEquip._Position_PowerMonitor.Y, 50);

                    //    // Wait in position
                    //    waitMotionDone(axisIndexXY, 10000);

                    //    btn_Move_Position_PowerMonitor_Click(this, null);

                    //    // Wait in position
                    //    waitMotionDone(axisIndexXY, 10000);

                    //    // Do Laser cutting
                    //    DoLaserCutting();

                    //    // Disable UI control
                    //    enableUIGroup(false);

                    //    // Start stopwatch
                    //    stopwatch_Warmup.Start();
                    //}

                    //取得雷射功率(W)
                    _isPowermeterBusy = true;
                    _OutputPower = _Powermeter.measurementStr;    // Convert Unit from W              
                    _isPowermeterBusy = false;


                    //功率量測實際值小於設定值進行功率補償(W)  
                    while (_OutputPower < PowerCheck_value)
                    {
                        if (laserPowerPct <= PowerCheck_USL && laserPowerPct >= PowerCheck_LSL)
                        {
                            //換算功率補償% = 預設值(W) - 量測值(W) / 0.06W(大約功率1% =0.06W)
                            PowerCheck_Ofs = (PowerCheck_value - _OutputPower) / 0.06;
                            //四捨五入為整數
                            PowerCheck_Ofs = Math.Round(PowerCheck_Ofs, 1);
                            //雷射功率補償
                            laserPowerPct = Math.Round(laserPowerPct + PowerCheck_Ofs, 1);
                            // Set Laser Output Power
                            SetLaserPowerPercentage(laserPowerPct);

                            Thread.Sleep(5000);

                            //功率計取得雷射功率(W)
                            _OutputPower = _Powermeter.measurementStr;    // Convert Unit from W

                            // Write Log
                            writeEvent("AutoPowerCheck", "補償完雷射功率(W)： " + _OutputPower.ToString());
                        }
                        else
                        {
                            //Stop Laser cutting
                            StopLaserCutting();
                            MessageBox.Show("雷射功率補償異常，補償完後超出上下限，請確認雷射功率。", "Error！！");
                            e.Cancel = true;
                            return;
                        }

                        // Check cancel
                        if (BW_CagilaAutoProcess.CancellationPending)
                        {
                            e.Cancel = true;
                            return;
                        }
                        Thread.Sleep(1000);
                    }

                    if (laserPowerPct >= PowerCheck_USL || laserPowerPct <= PowerCheck_LSL)
                    {
                        //Stop Laser cutting
                        StopLaserCutting();
                        MessageBox.Show("雷射功率補償異常，補償完後超出上下限，請確認雷射功率。", "Error！！");
                        e.Cancel = true;
                        return;
                    }

                    // Write Process
                    writeProcess("Cagila檔試打-Step6", "雷射功率檢查結束");
                }

                //Stop Laser cutting
                StopLaserCutting();

                // ProcessGas ON 開啟氮氣
                enableProcessGas(true);

                // Set software origin based on offset
                //小數點後四位四捨五入
                targetPositionX = Math.Round(_process_Offset_X, 4);
                targetPositionY = Math.Round(_process_Offset_Y, 4);

                // Move to target position
                linearMove(targetPositionX, targetPositionY, _ConfigEquip._Velocity_Default.X);

                // Wait in position
                waitMotionDone(axisIndexXY, 10000);

                // Set current position as Software origin (Offset)
                code = "G92 X0 Y0";
                executeGCode(code);

                #endregion

                #region Feature Process

                // [Feature process]
                if (_NbrOfFeature_Total == 0)//如果微孔數為0
                {
                    //解析NC檔 RD手動模式
                    if (!chk_RD_NCfile.Checked)
                    {
                        // Write Log
                        writeEvent("自動流程", "加工微孔略過");
                        // Write Process
                        writeProcess("Cagila檔試打-Step6", "加工流程微孔略過因為 (總數 = 0)");
                        //[BM:自訂Log紀錄內容-Cagila-手動研發模式微孔越過]
                        if (_AutoProcessLog_flag)
                            writeEventLog_Automatic_processing("Cagila加工流程微孔會被略過", $"研發手動NC檔已被勾選");
                    }
                }
                else//如果有微孔任務
                {
                    // Check cancel
                    if (BW_CagilaAutoProcess.CancellationPending)
                    {
                        e.Cancel = true;
                        return;
                    }


                    // Write Process
                    writeProcess("Cagila檔試打-Step6", "微孔加工(總數 = " + _NbrOfFeature_Total + ")");
                    writeProcess("Cagila檔試打-Step6", "微孔以外加工(總數 = " + data._QueueCmds.Count + ")");



                    //[BM:自訂Log紀錄內容-Cagila-微孔加工開始]
                    if (_AutoProcessLog_flag)
                        writeEventLog_Automatic_processing("Cagila檔試打-Step6加工流程微孔開始", $"微孔加工總數 =  ({_NbrOfFeature_Total  })");

                    // Start stopwatch
                    stopwatch_Suspend.Start();
                    stopwatch_Hold.Start();

                    // Start processing
                    double featureX = 0;
                    double featureY = 0;
                    int zoneType = -1;
                    //雷射休息計數
                    int LaserRunCount = 0;

                    writeProcess("Cagila檔試打-Step6", "微孔加工開始");
                    writeEvent("Cagila檔試打-Step6", "微孔加工開始");
                    for (int i = 0; i < data._NewDrillFeatures.Length; i++)
                    {
                        // Check cancel
                        if (BW_CagilaAutoProcess.CancellationPending)
                        {
                            e.Cancel = true;
                            return;
                        }

                        // Parse data
                        featureX = data._NewDrillFeatures[i].X;
                        featureY = data._NewDrillFeatures[i].Y;

                        //雷射自動補償Z軸
                        // If type changed, change Z compensate and power
                        if (zoneType != data._NewDrillFeatures[i].Type)
                        {
                            zoneType = data._NewDrillFeatures[i].Type;

                            // Change Laser power
                            laserPowerPct = laserParamConvert(data._LP_PowerPct[data._Op_LaserParamSet[zoneType]], LP_Gain, LP_Offset);
                            laserPowerPct = laserPowerPct + PowerCheck_Ofs;

                            //Change Laser Divider
                            //_Laser.ChangePPDivider(1);
                            _Laser.ChangePPDivider(data._DDS_LaserDivider[zoneType]);
                            Thread.Sleep(500);
                            var _status = _Laser.GetLaserStatus();
                            writeEvent("LaserDivider", _status.PpDivider);

                            //while (_status.PpDivider != "1")
                            while (_status.PpDivider != data._DDS_LaserDivider[zoneType].ToString())
                            {
                                retrycount++;

                                //_Laser.ChangePPDivider(1);
                                _Laser.ChangePPDivider(data._DDS_LaserDivider[zoneType]);
                                Thread.Sleep(500);
                                _status = _Laser.GetLaserStatus();
                                writeEvent("LaserDivider", _status.PpDivider + "; retrycount " + retrycount);

                                if (retrycount > 50)
                                {
                                    MessageBox.Show("微孔 LaserDivider設定異常，請確認雷射振鏡。", "Error！！");
                                    e.Cancel = true;
                                    return;
                                }
                            }
                            retrycount = 0;

                            // Set Laser Output Power
                            //CheckAndSetLaserPower(laserPowerPct);
                            SetLaserPowerPercentage(laserPowerPct);

                            //MES LOG記錄
                            _CHPT_MES.Laser_Power = laserPowerPct.ToString();
                            //MES LOG微孔總數記錄
                            _CHPT_MES.Total_Hole = _NbrOfFeature_Total;

                            // Change LaserScanner File 讀取刀具檔案
                            try
                            {
                                uploadJob(data._DDS_ScanheadFilePath[zoneType]);
                            }
                            catch (Exception)
                            {
                                MessageBox.Show("載入刀具錯誤，請確認是否有這項刀具。", "Error！！");
                                e.Cancel = true;
                                return;
                            }

                            // Change Motion param
                            CutSpeed = data._MP_CutSpeed[data._Op_MotionParamSet[zoneType]];
                            FastSpeed = data._MP_FastSpeed[data._Op_MotionParamSet[zoneType]];

                            // Check ZProbe or not 測高補償雷射Z軸
                            if (data._DDS_ZProbe[zoneType])
                            {
                                // Set Positioning to Absolute Mode
                                code = "G90";
                                executeGCode(code);
                                this.moveAbs((int)MotionAxis.Z, _ConfigEquip._Position_ConfocalLaser.Z, _ConfigEquip._Velocity_Default.Z);

                                // Wait for Motion completed
                                waitMotionDone(axisIndexZ, 10000);

                                targetPositionX = data._DDS_ZprobePositionX[zoneType] + _ConfigEquip._RelPosition_Laser2ConfocalLaser.X;
                                targetPositionY = data._DDS_ZprobePositionY[zoneType] + _ConfigEquip._RelPosition_Laser2ConfocalLaser.Y;

                                // Wait in position
                                waitMotionDone(axisIndexXY, 10000);

                                // Move to target position
                                double speed = _ConfigProcess._Speed_Fast;
                                linearMove(targetPositionX, targetPositionY, speed);

                                // Wait in position
                                waitMotionDone(axisIndexXY, 10000);


                                //微孔加工數大於設定數量，雷射休息
                                if (_ConfigProcess._IsAutoLaserSleep)
                                {
                                    if (LaserRunCount >= _ConfigProcess._LaserSleep_Count)
                                    {
                                        Thread.Sleep(_ConfigProcess._LaserSleep_Time * 1000);
                                        LaserRunCount = 0;
                                    }
                                }

                                // Get the CompensatePosition from ConfocalLaser
                                try
                                {
                                    // Wait for Motion completed
                                    waitMotionDone(axisIndexZ, 10000);
                                    Thread.Sleep(50);
                                    _CompensatePosition[zoneType] = getCompesatePosition();

                                    //測高比對-加工中測高紀錄                               
                                    AutoThickProcess[zoneType] = Math.Round(_positionFeedback[(int)MotionAxis.Z] - _CompensatePosition[zoneType] + _ConfigEquip._Height_Equip.Laser, 4);

                                }
                                catch (Exception)
                                {
                                    MessageBox.Show("測厚異常，請確認是否已擺放樣品並完成光學對焦。", "Error！！");
                                    e.Cancel = true;
                                    return;
                                }

                                //[BM:Cagila測高加工前、後比對功能]
                                if (_ConfigProcess._IsThickComparison)
                                {

                                    double _ThickComparison = Math.Round(ThickProcess[zoneType] - AutoThickProcess[zoneType], 4);
                                    double max = +_ConfigProcess._ThickComparison;
                                    double min = -_ConfigProcess._ThickComparison;

                                    writeEvent("加工前測高No." + (zoneType + 1).ToString(), ThickProcess[zoneType].ToString());
                                    writeEvent("加工中測高No." + (zoneType + 1).ToString(), AutoThickProcess[zoneType].ToString());
                                    writeEvent("測高差值No." + (zoneType + 1).ToString(), _ThickComparison.ToString());

                                    //[BM:Cagila測高高度限制]
                                    //測高比對超出預設差值設備跳Err停止
                                    if (_ThickComparison < min || _ThickComparison > max)
                                    {
                                        writeError("測高比對超出預設值", "測高差值No." + (zoneType + 1).ToString() + "：" + _ThickComparison.ToString());

                                        targetPositionX = Math.Round(_ConfigProcess._Check_ThickLaserX - _process_Offset_X, 4);
                                        targetPositionY = Math.Round(_ConfigProcess._Check_ThickLaserY - _process_Offset_Y, 4);
                                        //移動到測高檢查基準點
                                        linearMove(targetPositionX, targetPositionY, speed);
                                        waitMotionDone(axisIndexXY, 100000);
                                        this.moveAbs((int)MotionAxis.Z, _ConfigProcess._Check_ThickLaserZ, _ConfigEquip._Velocity_Default.Z);
                                        waitMotionDone(axisIndexZ, 10000);

                                        //記錄基測高檢查基準點的測高數值
                                        try
                                        {
                                            Thread.Sleep(50);
                                            _CompensatePosition[zoneType] = getCompesatePosition();
                                            writeError("測高比對超出預設值", "測高檢查基準點： " + Math.Round(_positionFeedback[(int)MotionAxis.Z] - _CompensatePosition[zoneType] + _ConfigEquip._Height_Equip.Laser, 4).ToString());
                                        }
                                        catch (Exception)
                                        {
                                            MessageBox.Show("測厚異常，請確認是否已擺放樣品並完成光學對焦。", "Error！！");
                                            e.Cancel = true;
                                            return;
                                        }

                                        //異常急停
                                        setEmergencyStopLock();
                                        e.Cancel = true;
                                        return;
                                    }
                                }


                                // Change Compensate offsetZ
                                // Evaluate the offsetZ
                                _offsetZ = _CompensatePosition[zoneType] - _positionFeedback[(int)MotionAxis.Z];

                                //string formatOffsetZ = string.Format("{0:0.####}", offsetZ);
                                moveRel((int)MotionAxis.Z, _offsetZ, _ConfigEquip._Velocity_Default.Z);//依據需補償高度值進行移動

                                // Wait in position
                                waitMotionDone(axisIndexZ, 10000);
                            }

                            // Wait in position
                            waitMotionDone(axisIndexZ, 10000);
                        }

                        //targetPositionX = _process_Offset_X + featureX;
                        //targetPositionY = _process_Offset_Y + featureY;
                        targetPositionX = featureX;
                        targetPositionY = featureY;

                        // Wait in position
                        waitMotionDone(axisIndexXY, 10000);

                        // Move to target position
                        double fastSpeed = motionParamConvert(FastSpeed, MP_Gain, MP_Offset);
                        linearMove(targetPositionX, targetPositionY, fastSpeed);

                        // Wait in position
                        waitMotionDone(axisIndexXY, 10000);

                        //[BM:自訂Log紀錄內容-Cagila-微孔加工確認到達微孔位置]

                        if (_AutoProcessLog_flag)
                            writeEventLog_Automatic_processing($"第{i}比座標位置", $"X={targetPositionX},Y={targetPositionY}已確實到達");

                        // Do Laser processing 雷射開啟
                        try
                        {
                            DoLaserProcessing();
                            //[BM:自訂Log紀錄內容-Cagila-微孔加工單筆完成]
                            if (_AutoProcessLog_flag)
                                writeEventLog_Automatic_processing($"第{LaserRunCount}比雷射加工完成", $" ");
                            LaserRunCount++;
                        }
                        catch (Exception ex)
                        {
                            //[BM:自訂Log紀錄內容-Cagila-微孔加工單筆出現問題]
                            if (_AutoProcessLog_flag)
                                writeEventLog_Automatic_processing($"第{LaserRunCount}比雷射加工出問題", $"問題內容:{ex} ");
                            throw ex;
                        }

                        // Report progress
                        BW_CagilaAutoProcess.ReportProgress(0);

                        // Check Suspend or not
                        if (enableSuspend)
                        {
                            if (stopwatch_Suspend.ElapsedMilliseconds > suspend_IntervalTime)
                            {
                                //[BM:自訂Log紀錄內容-Cagila-微孔加工單筆正常執行暫停]
                                if (_AutoProcessLog_flag)
                                    writeEventLog_Automatic_processing($"第{i}筆加工流程完成後有執行暫停", $" ");
                                // Write Data log
                                writeDataQueue("AutoProcess", "Suspend(ms) = " + suspend_TimeToWait);
                                stopwatch_Suspend.Restart();

                                while (stopwatch_Suspend.ElapsedMilliseconds < suspend_TimeToWait)
                                {
                                    // Check cancel
                                    if (BW_CagilaAutoProcess.CancellationPending)
                                    {
                                        e.Cancel = true;
                                        return;
                                    }
                                    Thread.Sleep(1000);
                                }
                                stopwatch_Suspend.Restart();
                            }
                        }

                        // Check Hold or not
                        if (enableHold)
                        {
                            if (stopwatch_Hold.ElapsedMilliseconds > hold_IntervalTime)
                            {
                                // Write Data log
                                writeDataQueue("AutoProcess", "Calibrate Power = " + laserPowerPct); ;

                                //// Check and set laser power
                                //CheckAndSetLaserPower(laserPowerPct);

                                // Re-upload JobList
                                // Evaluate the offsetZ
                                double offsetZ = _CompensatePosition[zoneType] - _positionFeedback[(int)MotionAxis.Z];
                                string formatOffsetZ = string.Format("{0:0.####}", offsetZ);
                                double.TryParse(formatOffsetZ, out offsetZ);

                                // Upload JobList with Compensate offsetZ by changing JobList
                                string fileName = data._DDS_ScanheadFilePath[zoneType];
                                uploadJobListWithCompensateZ(fileName, offsetZ);

                                stopwatch_Hold.Restart();
                            }
                        }

                    }
                    // Stop stopwatch
                    stopwatch_Warmup.Stop();
                    stopwatch_Suspend.Stop();
                    stopwatch_Hold.Stop();
                    //Write Log
                    writeEvent("Cagila檔試打-Step6", "微孔加工結束");
                    // Write Process
                    writeProcess("Cagila檔試打-Step6", "微孔加工結束");
                }
                #endregion

                if (!Cagila_AutoProcess_Checkbox.Checked)
                {
                    #region Else Process
                    writeProcess("Cagila檔試打-Step6", "微孔以外加工開始");
                    writeEvent("Cagila檔試打-Step6", "微孔以外加工開始");
                    Queue<QueueCmd> queueCmds = data._QueueCmds;
                    string jobName = "";
                    double setLaserPower = 0;
                    int setLaserDivider = 0;
                    //ControllerDiagPacket ctrlDiagPacket = _MC_Controller.DataCollection.RetrieveDiagnostics();
                    int opType = -1;
                    while (queueCmds.Count != 0)
                    {
                        // Check cancel
                        if (BW_CagilaAutoProcess.CancellationPending)
                        {
                            e.Cancel = true;
                            return;
                        }
                        //[BM:Cagila-微孔外之命令排程(依次取出命令使用即消失1條命令)]
                        QueueCmd cmd = queueCmds.Dequeue();

                        switch (cmd.CmdModule)
                        {
                            case NCScriptParser.Module.Annotation:
                                switch (cmd.Command)
                                {
                                    case AnnotCmd.Operation:
                                        logAnnotOperation((string)cmd.Arguments);
                                        opType = (int)cmd.Else;

                                        // Write Data log
                                        writeDataQueue("AnnotCmd", "opType = " + opType);
                                        break;
                                }
                                break;
                            case NCScriptParser.Module.Laser:
                                switch (cmd.Command)
                                {
                                    case LaserCmd.SetLaserPower:
                                        // Parse Laser power
                                        setLaserPower = (int)cmd.Arguments;
                                        setLaserPower = laserParamConvert(setLaserPower, LP_Gain, LP_Offset);
                                        // If Laser power changed, do process
                                        if (laserPowerPct != setLaserPower)
                                        {
                                            laserPowerPct = setLaserPower;
                                            // Set Laser Output Power
                                            //CheckAndSetLaserPower(laserPowerPct);
                                            SetLaserPowerPercentage(laserPowerPct);

                                            //MES LOG記錄
                                            _CHPT_MES.Laser_Power = laserPowerPct.ToString();
                                            // Reupload the JobFile
                                            //uploadJob(jobName);

                                            // Write Data log
                                            writeDataQueue("LaserCmd", "setLaserPower = " + setLaserPower);
                                        }

                                        break;

                                    case LaserCmd.SetLaserDivider:
                                        //Change Laser Divider
                                        //_Laser.ChangePPDivider(1);
                                        setLaserDivider = (int)cmd.Arguments;
                                        _Laser.ChangePPDivider(setLaserDivider);
                                        Thread.Sleep(500);
                                        var _otherstatus = _Laser.GetLaserStatus();
                                        writeEvent("LaserDivider", _otherstatus.PpDivider);

                                        while (_otherstatus.PpDivider != setLaserDivider.ToString())
                                        {
                                            retrycount++;

                                            //_Laser.ChangePPDivider(1);
                                            _Laser.ChangePPDivider(setLaserDivider);
                                            Thread.Sleep(500);
                                            _otherstatus = _Laser.GetLaserStatus();
                                            writeEvent("LaserDivider", _otherstatus.PpDivider + "; retrycount " + retrycount);

                                            if (retrycount > 50)
                                            {
                                                MessageBox.Show("GH LaserDivider設定異常，請確認雷射振鏡。", "Error！！");
                                                e.Cancel = true;
                                                return;
                                            }
                                        }
                                        retrycount = 0;

                                        break;
                                }
                                break;
                            case NCScriptParser.Module.Scanner:
                                switch (cmd.Command)
                                {
                                    case ScannerCmd.SelectJobByName:
                                        jobName = (string)cmd.Arguments;
                                        uploadJob(jobName);

                                        // Write Data log
                                        writeDataQueue("ScannerCmd", "uploadJob = " + jobName);
                                        break;

                                    case ScannerCmd.GasOnOff:
                                        bool flag = (bool)cmd.Arguments;
                                        enableProcessGas(flag);

                                        // Write Data log
                                        writeDataQueue("ScannerCmd", "enableProcessGas = " + flag);
                                        break;

                                    case ScannerCmd.StartJob:
                                        DoLaserCutting();

                                        // Write Data log
                                        writeDataQueue("ScannerCmd", "DoLaserCutting");
                                        break;

                                    case ScannerCmd.AbortJob:
                                        StopLaserCutting();

                                        //MES LOG微孔總數+其他孔總數記錄
                                        _CHPT_MES.Total_Hole++;

                                        // Write Data log
                                        writeDataQueue("ScannerCmd", "StopLaserCutting");
                                        break;

                                    //研發手動NC檔 打微孔模式
                                    case ScannerCmd.ExecuteJob:
                                        try
                                        {
                                            // Do Laser processing 雷射開啟
                                            DoLaserProcessing();

                                            // Write Data log
                                            writeDataQueue("ScannerCmd", "DoLaserProcessing");
                                        }
                                        catch (Exception ex)
                                        {
                                            throw ex;
                                        };
                                        break;
                                }
                                break;
                            case NCScriptParser.Module.Equipment:
                                switch (cmd.Command)
                                {
                                    case EquipCmd.VacuumOnOff:
                                        bool flag = (bool)cmd.Arguments;

                                        //[BM:不放開吸附功能(所有程式只有UI介面的取消吸附才可以解除吸附)]
                                        //  enableChuckVacuum(flag);
                                        // Write Data log
                                        // writeDataQueue("EquipCmd", "enableChuckVacuum = " + flag);
                                        break;
                                }
                                break;
                            //測高
                            case NCScriptParser.Module.Probe:
                                switch (cmd.Command)
                                {
                                    case ProbeCmd.ProbeSurface:
                                        //// Get current position command X, Y
                                        ////double posCmdX = ctrlDiagPacket[(int)MotionAxis.X].PositionCommand;
                                        ////double posCmdY = ctrlDiagPacket[(int)MotionAxis.Y].PositionCommand;
                                        ////double speed = data._MP_FastSpeed[data._Op_MotionParamSet[opType]];
                                        ////speed = motionParamConvert(speed, MP_Gain, MP_Offset);
                                        //// Profe surface and upload the JobFile
                                        ////probeSurfaceAndUploadCompensateJobList(posCmdX, posCmdY, speed, jobName);

                                        // Probe surface and compensate the difference
                                        try
                                        {
                                            probeSurfaceAndCompensateDifference(out resultdistance);
                                            //拍攝功能-開門關閉雷射二次加工計數
                                            AutoThickProcess_Video_Count++;
                                            //測高完成
                                            ProbeFinish = true;
                                        }
                                        catch (Exception)
                                        {
                                            MessageBox.Show("測厚異常，請確認是否已擺放樣品並完成光學對焦。", "Error！！");
                                            e.Cancel = true;
                                            return;
                                        }

                                        // Write Data log
                                        writeDataQueue("ProbeCmd", "probeSurfaceAndCompensateDifference");
                                        break;
                                }
                                break;
                            case NCScriptParser.Module.GCode:
                                switch (cmd.Command)
                                {
                                    case GCodeCmd.Set:
                                        code = (string)cmd.Arguments;
                                        executeGCode(code);
                                        break;

                                    //Z軸下降
                                    case GCodeCmd.LinearZ2ProcessPlane:
                                        //測高完成 或 Z軸上升完成
                                        if (ProbeFinish || LinearZFinish)
                                        {
                                            // Due to Gantry instable issues, abandon GCode related to axis-Z
                                            code = "G91";
                                            executeGCode(code);

                                            moveRel((int)MotionAxis.Z, resultdistance, _ConfigEquip._Velocity_Default.Z);


                                            // Wait for Motion completed
                                            waitMotionDone(axisIndexZ, 10000);

                                            // Write Data log
                                            writeDataQueue("LinearZ2ProcessPlane", "Move DownZ = " + code + " " + resultdistance.ToString());

                                            code = "G90";
                                            executeGCode(code);
                                            ProbeFinish = false;
                                            LinearZFinish = false;
                                        }
                                        break;

                                    case GCodeCmd.CircleXY:
                                    case GCodeCmd.LinearXY:
                                        code = (string)cmd.Arguments;
                                        if (cmd.Else != null)
                                        {
                                            // Parse Motion speed
                                            double speed = (int)cmd.Else;
                                            speed = motionParamConvert(speed, MP_Gain, MP_Offset);
                                            // Replace GCode Motion speed
                                            Regex regex = new Regex(".*F");
                                            Match match = regex.Match(code);
                                            code = match.Value + string.Format("{0:0.###}", speed);
                                        }
                                        executeGCode(code);
                                        break;

                                    //Z軸上升
                                    case GCodeCmd.LinearZ:
                                        //case GCodeCmd.RapidZ:
                                        // Due to Gantry instable issues, abandon GCode related to axis-Z
                                        // Otherwise, these cmds are the same as CircleXY & LinearXY
                                        code = "G90";
                                        executeGCode(code);
                                        this.moveAbs((int)MotionAxis.Z, _ConfigEquip._Position_ConfocalLaser.Z, _ConfigEquip._Velocity_Default.Z);

                                        // Wait for Motion completed
                                        waitMotionDone(axisIndexZ, 10000);

                                        //Z軸上升完成
                                        LinearZFinish = true;

                                        // Write Data log
                                        writeDataQueue("LinearZ & RapidZ", "Move UpZ " + code);
                                        break;
                                }
                                break;
                        }

                        // Report progress
                        BW_CagilaAutoProcess.ReportProgress(0);
                    }
                    writeProcess("Cagila檔試打-Step6", "微孔以外加工結束");
                    writeEvent("Cagila檔試打-Step6", "微孔以外加工結束");
                    #endregion
                }

                // Report progress
                BW_CagilaAutoProcess.ReportProgress(0);

            }
            else
            {
                // Disable GUI Controls
                //EnableGUIMotionControls(false);

                // Disable UI control
                //enableUIGroup(false);

                // Get NC code data
                NCScriptParser data = _NCParser;

                // Evaluate total number of feature
                // int count = data._DDS_RowCount;
                _NbrOfProcess_Total = 0;
                _NbrOfProcess_Done = 0;
                _NbrOfFeature_Total = 0;
                _NbrOfFeature_Done = 0;

                //解析NC檔
                _NbrOfFeature_Total = data._NewDrillFeatures.Length;







                if (!Cagila_AutoProcess_Checkbox.Checked)//如果全部加工
                {
                    _NbrOfProcess_Total = _NbrOfFeature_Total + data._QueueCmds.Count;
                }
                else//如果只加工微孔
                {
                    _NbrOfProcess_Total = _NbrOfFeature_Total;
                }

                // Process parameters
                int[] axisIndexZ = { (int)MotionAxis.Z };
                int[] axisIndexXY = { (int)MotionAxis.X, (int)MotionAxis.Y };
                // int[] axisAllIndexes = { (int)MotionAxis.X, (int)MotionAxis.Y, (int)MotionAxis.Z };
                double targetPositionX;
                double targetPositionY;
                double LP_Gain = _ConfigProcess._LaserParam_Convert.Gain;
                double LP_Offset = _ConfigProcess._LaserParam_Convert.Offset;
                double MP_Gain = _ConfigProcess._MotionParam_Convert.Gain;
                double MP_Offset = _ConfigProcess._MotionParam_Convert.Offset;
                //bool enableWarmup = _ConfigProcess._IsAutoProcessWarmup;
                bool enableSuspend = _ConfigProcess._IsAutoProcessSuspend;
                bool enableHold = _ConfigProcess._IsAutoProcessHold;
                bool enblePowerCheck = _ConfigSystem._ConnectSetting.Powermeter;
                double PowerCheck_USL = _ConfigSystem._AutoPowerCheck_USL;
                double PowerCheck_LSL = _ConfigSystem._AutoPowerCheck_LSL;
                double PowerCheck_value = _ConfigSystem._AutoPowerCheck_value;
                int AutoPowerCheck_count = _ConfigSystem._AutoPowerCheck_count;

                double PowerCheck_Ofs = 0;

                int warmup_TimeToWait = _ConfigProcess._Warmup_TimeToWait * 1000;   // Convert sec to ms
                int suspend_IntervalTime = _ConfigProcess._Suspend_IntervalTime * 1000;   // Convert sec to ms
                int hold_IntervalTime = _ConfigProcess._Hold_IntervalTime * 1000;   // Convert sec to ms
                int suspend_TimeToWait = _ConfigProcess._Suspend_TimeToWait * 1000;   // Convert sec to ms
                                                                                      // int hold_TimeToWait = _ConfigProcess._Hold_TimeToWait * 1000;   // Convert sec to ms

                int retrycount = 0;

                double laserPowerPct = 0;
                double CutSpeed = 0;
                double FastSpeed = 0;
                double _offsetZ = 0;
                double resultdistance = 0.0;
                double _OutputPower = 0.0;
                bool ProbeFinish = false;
                bool LinearZFinish = false;




                Stopwatch stopwatch_Warmup = new Stopwatch();
                Stopwatch stopwatch_Suspend = new Stopwatch();
                Stopwatch stopwatch_Hold = new Stopwatch();
                //double lastPosition_X, lastPosition_Y, lastPosition_Z;

                _process_Offset_X = _ConfigEquip._OrgPoint.X - _ConfigEquip._RelPosition_Laser2Camera.X;
                _process_Offset_Y = _ConfigEquip._OrgPoint.Y - _ConfigEquip._RelPosition_Laser2Camera.Y;


                // Initialization process
                // IO display flag
                //_isProcessing = true;
                //取得雷射功率(W)
                _isPowermeterBusy = true;
                _OutputPower = _Powermeter.measurementStr;    // Convert Unit from W              
                _isPowermeterBusy = false;

                //Write Log
                writeProcess("Cagila檔試打-Step6", "微孔加工(總數 = " + _NbrOfFeature_Total + ")");
                writeProcess("Cagila檔試打-Step6", "微孔以外加工(總數 = " + data._QueueCmds.Count+ ")");

                writeProcess("Cagila檔試打-Step6", "微孔加工開始");
                writeEvent("Cagila檔試打-Step6", "微孔加工開始");
                for (int i = 0; i < data._NewDrillFeatures.Length; i++)
                {

                    // Check cancel
                    if (BW_CagilaAutoProcess.CancellationPending)
                    {
                        e.Cancel = true;
                        return;
                    }

                    // Report progress
                    BW_CagilaAutoProcess.ReportProgress(0);
                    Thread.Sleep(5);
                }
                //Write Log
                writeProcess("Cagila檔試打-Step6", "微孔加工結束");
                writeEvent("Cagila檔試打-Step6", "微孔加工結束");


                if (!Cagila_AutoProcess_Checkbox.Checked)
                {
                    writeProcess("Cagila檔試打-Step6", "微孔以外加工開始");
                    writeEvent("Cagila檔試打-Step6", "微孔以外加工開始");

                    #region Else Process
                    Queue<QueueCmd> queueCmds = data._QueueCmds;
                    string jobName = "";
                    double setLaserPower = 0;
                    int setLaserDivider = 0;
                    //ControllerDiagPacket ctrlDiagPacket = _MC_Controller.DataCollection.RetrieveDiagnostics();
                    int opType = -1;
                    while (queueCmds.Count != 0)
                    {
                        // Check cancel
                        if (BW_CagilaAutoProcess.CancellationPending)
                        {
                            e.Cancel = true;
                            return;
                        }

                        //[BM:Cagila-微孔外之命令排程(依次取出命令使用即消失1條命令)]
                        QueueCmd cmd = queueCmds.Dequeue();


                        // Report progress
                        BW_CagilaAutoProcess.ReportProgress(0);
                    }
                    writeProcess("Cagila檔試打-Step6", "微孔以外加工結束");
                    writeEvent("Cagila檔試打-Step6", "微孔以外加工結束");

                    #endregion
                }
                BW_CagilaAutoProcess.ReportProgress(0);
            }
        }
        private void BW_CagilaAutoProcess_ProgressChanged(object sender, ProgressChangedEventArgs e)
        {
            int progressPercentage = (++_NbrOfProcess_Done * 100) / _NbrOfProcess_Total;
            if(_NbrOfProcess_Done<= _NbrOfProcess_Total)
            {
                Cagila_AutoProcess_Label.Text = string.Format("Progress = {0}% ({1}/{2})", progressPercentage, _NbrOfProcess_Done, _NbrOfProcess_Total);
            }
            Cagila_AutoProcess_progressBar.Value = progressPercentage / 100f; //進度值（介於 0 到 1）
        }
        private void BW_CagilaAutoProcess_RunWorkerCompleted(object sender, RunWorkerCompletedEventArgs e)
        {
            if (!_isSysSimulated)
            {
                // IO display flag
                _isProcessing = false;

                _NbrOfProcess_Done = 0;
                _NbrOfProcess_Total = 0;

                // Deinitialization process
                // Stop Process Elapsed Time
                _stopwatch_ElapsedTime.Stop();
                _stopwatch_ElapsedTime.Reset();

                // Close Process Gas
                enableProcessGas(false);
                //[BM:Cagila-防呆-自動流程完成後保持吸附]
                //[BM:不放開吸附功能(所有程式只有UI介面的取消吸附才可以解除吸附)]
                // Close Vacuum
                //enableChuckVacuum(false);
                // Clear software origin
                string code = "G82";
                executeGCode(code);
            }

            if (e.Cancelled == true)
            {
                // Cancelled
                Cagila_AutoProcess_Panel.BackColor = Color.Red;

                Cagila_AutoProcess_progressBar.Value = 0f;
                Cagila_AutoProcess_Label.Text = string.Format("Progress = {0}% ({1}/{2})",0,0, 0);

                // Write Process
                writeProcess("Cagila檔試打-Step6", "加工流程已中斷");
            }
            else if (e.Error != null)
            {
                // Error
                Cagila_AutoProcess_Panel.BackColor = Color.Red;
                writeError("自動流程", "自動過程失敗." + e.Error);
                // Write Process
                writeProcess("Cagila檔試打-Step6", "錯誤發生致加工流程已中斷");
            }
            else
            {
                // Completed
                Cagila_AutoProcess_Panel.BackColor = Color.Green;
                Cagila_AutoProcess_progressBar.Value = 1f;
                if (!_isSysSimulated)
                {
                    //[BM:不放開吸附功能(所有程式只有UI介面的取消吸附才可以解除吸附)]
                    // enableChuckVacuum(false);

                }
                // Write Process
                writeProcess("Cagila檔試打-Step6", "加工流程已完成");
            }
        }
        #endregion
    }
}
