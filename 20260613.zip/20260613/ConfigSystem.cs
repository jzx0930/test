﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;

namespace LaserProcess_LCH
{
    public class ConfigSystem : Module_Interface.Module
    {
        private Dictionary<string, string> _iniDic;
        /// /// <summary>
        ///安全範圍門檻值結構。
        /// </summary>
        public struct SafetyThreshold
        {
            /// <summary>
            ///門檻值上限
            /// </summary>
            public double High;
            /// <summary>
            ///門檻值下限
            /// </summary>
            public double Low;
        }
        ///  <summary>
        /// 於配置檔讀取-輸入電壓範圍
        /// </summary>
        public SafetyThreshold _UPS_InputVoltage;
        ///  <summary>
        /// 於配置檔讀取-輸出電壓範圍
        /// </summary>
        public SafetyThreshold _UPS_OutputVoltage;
        ///  <summary>
        /// 於配置檔讀取-溫度範圍
        /// </summary>
        public SafetyThreshold _Temperature;
        ///  <summary>
        /// 於配置檔讀取-濕度範圍
        /// </summary>
        public SafetyThreshold _Humidity;

        /// /// <summary>
        /// 定義各項設備模組是否啟用的連線設定結構。
        /// 依據配置檔內容(ConfigSystem.ini)
        /// 用於初始化系統連線、顯示設備狀態或儲存組態資料。
        /// </summary>
        public struct ConnectSetting
        {
            public bool MotionControl;
            public bool Laser;
            public bool LaserScanner;
            public bool CameraCVX;
            public bool ConfocalLaser;
            public bool PositionAligner;
            public bool RotationStage;
            public bool Powermeter;
            public bool Autocorrelator;
            public bool Beamprofiler;
            public bool THSensor;
            public bool LaserChiller;
            public bool ScannerChiller;
            public bool UPS;
            public bool IOCard;
            ///  <summary>
            /// 是否啟用上報功能
            /// </summary>
            public bool ChptMES;
        }
        /// <summary>
        ///定義各項設備模組是否啟用的連線設定結構。
        /// </summary>
        public ConnectSetting _ConnectSetting;

        ///  <summary>
        /// 於配置檔讀取-設備編號
        /// </summary>
        public string _EquipmentNo;
        ///  <summary>
        /// 於配置檔讀取-版本號
        /// </summary>
        public string _Version;
        ///  <summary>
        /// 於配置檔讀取-影像存放位置
        /// </summary>
        public string _CameraImagesFolderPath;
       
        public string _PowerCalibrationDataFolderPath;
        ///  <summary>
        /// 於配置檔讀取-刀具檔路徑
        /// </summary>
        public string _JobxFolderPath;
        ///  <summary>
        /// 於配置檔讀取-刀具檔通解變數工具
        /// </summary>
        //[BM:刀具檔讀取通解-宣告變數]
        public string _JobxFolderPath1;
        public string _RDJobxFolderPath;
        public double _AutoPowerCheck_USL;
        public double _AutoPowerCheck_LSL;
        public double _AutoPowerCheck_value;
        public int _AutoPowerCheck_count;

        //[BM:修改重複上報異常-宣告變數]
        /// <summary>
        ///儲存機台MES上報狀態
        /// </summary>
        public string _MES_State;
        private static char _seperator = ',';

        /// <summary>
        /// 讀取配置檔中的路徑
        /// </summary>
        public string _FilePath;

        /// <summary>
        /// 上報資訊之目標IP
        /// </summary>
        public string _Server_IP;
        /// <summary>
        /// 上報資訊之目標Port
        /// </summary>
        public int _Server_Port;
        /// <summary>
        /// Festo目標IP
        /// </summary>
        public string _Festo_IO_Link_IP;
        /// <summary>
        /// Festo目標Port
        /// </summary>
        public int _Festo_IO_Link_Port;
        /// <summary>
        /// 比例閥
        /// </summary>
        public string _FESTO_PPC_Valve_Port;


        public ConfigSystem(string name) : base(name)
        {
            // Update _iniDic and private parameters
            _iniDic = this.GetIniDic();
            this.UpdatePublicParams();
        }

        ~ConfigSystem()
        {
            Destruction();
        }

        private void Destruction()
        {
            // Write back ini file
            this.WriteIniFile(_iniDic);
        }
    
        public void UpdatePublicParams()
        {
            try
            {
                _EquipmentNo = _iniDic["EquipmentNo"];
                _Version = _iniDic["Version"];
                _UPS_InputVoltage = parseStringToSafetyThreshold(_iniDic["SafetyThreshold_UPS_InputVoltage"]);
                _UPS_OutputVoltage = parseStringToSafetyThreshold(_iniDic["SafetyThreshold_UPS_OutputVoltage"]);
                _Temperature = parseStringToSafetyThreshold(_iniDic["SafetyThreshold_Temperature"]);
                _Humidity = parseStringToSafetyThreshold(_iniDic["SafetyThreshold_Humidity"]);
                _ConnectSetting.MotionControl = Convert.ToBoolean(_iniDic["MotionControl"]);
                _ConnectSetting.Laser = Convert.ToBoolean(_iniDic["Laser"]);
                _ConnectSetting.LaserScanner = Convert.ToBoolean(_iniDic["LaserScanner"]);
                _ConnectSetting.CameraCVX = Convert.ToBoolean(_iniDic["CameraCVX"]);
                _ConnectSetting.ConfocalLaser = Convert.ToBoolean(_iniDic["ConfocalLaser"]);
                _ConnectSetting.PositionAligner = Convert.ToBoolean(_iniDic["PositionAligner"]);
                _ConnectSetting.RotationStage = Convert.ToBoolean(_iniDic["RotationStage"]);
                _ConnectSetting.Powermeter = Convert.ToBoolean(_iniDic["Powermeter"]);
                _ConnectSetting.Autocorrelator = Convert.ToBoolean(_iniDic["Autocorrelator"]);
                _ConnectSetting.Beamprofiler = Convert.ToBoolean(_iniDic["Beamprofiler"]);
                _ConnectSetting.THSensor = Convert.ToBoolean(_iniDic["THSensor"]);
                _ConnectSetting.LaserChiller = Convert.ToBoolean(_iniDic["LaserChiller"]);
                _ConnectSetting.ScannerChiller = Convert.ToBoolean(_iniDic["ScannerChiller"]);
                _ConnectSetting.UPS = Convert.ToBoolean(_iniDic["UPS"]);
                _ConnectSetting.IOCard = Convert.ToBoolean(_iniDic["IOCard"]);
                _ConnectSetting.ChptMES = Convert.ToBoolean(_iniDic["ChptMES"]);
                _CameraImagesFolderPath = _iniDic["CameraImagesFolderPath"];
                _PowerCalibrationDataFolderPath = _iniDic["PowerCalibrationDataFolderPath"];
                //[BM:刀具檔讀取通解-讀取配置檔內容(供組合後加工使用路徑)會變動]
                _JobxFolderPath = _iniDic["JobxFolderPath"];
                //[BM:刀具檔讀取通解-讀取配置檔內容(存放機台刀具檔資料夾位置)不變動]
                _JobxFolderPath1 = _iniDic["JobxFolderPath1"];
                _AutoPowerCheck_USL = double.Parse(_iniDic["AutoPowerCheck_USL"]);
                _AutoPowerCheck_LSL = double.Parse(_iniDic["AutoPowerCheck_LSL"]);
                _AutoPowerCheck_value = double.Parse(_iniDic["AutoPowerCheck_value"]);
                _AutoPowerCheck_count = int.Parse(_iniDic["AutoPowerCheck_count"]);

             //[BM:掃碼載檔-讀取配置檔的路徑]
             _FilePath = _iniDic["FilePath"];

                _Server_IP = _iniDic["Server_IP"];
                _Server_Port = int.Parse(_iniDic["Server_Port"]);

                _Festo_IO_Link_IP = _iniDic["Festo_IO_Link_IP"];
                _Festo_IO_Link_Port = int.Parse(_iniDic["Festo_IO_Link_Port"]);


                _FESTO_PPC_Valve_Port=_iniDic["FESTO_PPC_Valve_Port"];

            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        
        private SafetyThreshold parseStringToSafetyThreshold(string data)
        {
            string sLow, sHigh;
            parseStringToTwoSubString(data, _seperator, out sLow, out sHigh);
            return new SafetyThreshold { Low = double.Parse(sLow), High = double.Parse(sHigh) };
        }

        public void WriteIntoIniFile()
        {
            try
            {
                // Update dictionary list
                _iniDic["EquipmentNo"] = _EquipmentNo;
                _iniDic["Version"] = _Version;
                _iniDic["SafetyThreshold_UPS_InputVoltage"] = parseTwoDoubleToString(_UPS_InputVoltage.Low, _UPS_InputVoltage.High, _seperator);
                _iniDic["SafetyThreshold_UPS_OutputVoltage"] = parseTwoDoubleToString(_UPS_OutputVoltage.Low, _UPS_OutputVoltage.High, _seperator);
                _iniDic["SafetyThreshold_Temperature"] = parseTwoDoubleToString(_Temperature.Low, _Temperature.High, _seperator);
                _iniDic["SafetyThreshold_Humidity"] = parseTwoDoubleToString(_Humidity.Low, _Humidity.High, _seperator);
                _iniDic["MotionControl"] = parseBoolToString(_ConnectSetting.MotionControl);
                _iniDic["Laser"] = parseBoolToString(_ConnectSetting.Laser);
                _iniDic["LaserScanner"] = parseBoolToString(_ConnectSetting.LaserScanner);
                _iniDic["CameraCVX"] = parseBoolToString(_ConnectSetting.CameraCVX);
                _iniDic["ConfocalLaser"] = parseBoolToString(_ConnectSetting.ConfocalLaser);
                _iniDic["PositionAligner"] = parseBoolToString(_ConnectSetting.PositionAligner);
                _iniDic["RotationStage"] = parseBoolToString(_ConnectSetting.RotationStage);
                _iniDic["Powermeter"] = parseBoolToString(_ConnectSetting.Powermeter);
                _iniDic["Autocorrelator"] = parseBoolToString(_ConnectSetting.Autocorrelator);
                _iniDic["Beamprofiler"] = parseBoolToString(_ConnectSetting.Beamprofiler);
                _iniDic["THSensor"] = parseBoolToString(_ConnectSetting.THSensor);
                _iniDic["LaserChiller"] = parseBoolToString(_ConnectSetting.LaserChiller);
                _iniDic["ScannerChiller"] = parseBoolToString(_ConnectSetting.ScannerChiller);
                _iniDic["UPS"] = parseBoolToString(_ConnectSetting.UPS);
                _iniDic["IOCard"] = parseBoolToString(_ConnectSetting.IOCard);
                _iniDic["ChptMES"] = parseBoolToString(_ConnectSetting.ChptMES);
                _iniDic["CameraImagesFolderPath"] = _CameraImagesFolderPath;
                _iniDic["PowerCalibrationDataFolderPath"] = _PowerCalibrationDataFolderPath;
                _iniDic["JobxFolderPath"] = _JobxFolderPath;
                _iniDic["AutoPowerCheck_USL"] = _AutoPowerCheck_USL.ToString();
                _iniDic["AutoPowerCheck_LSL"] = _AutoPowerCheck_LSL.ToString();
                _iniDic["AutoPowerCheck_value"] = _AutoPowerCheck_value.ToString();
                _iniDic["AutoPowerCheck_count"] = _AutoPowerCheck_count.ToString();


                // Write back ini file
                this.WriteIniFile(_iniDic);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        //[BM:修改重複上報異常-新增單獨寫入ini檔案狀態方法]
        //public void WriteMES_State()
        //{
        //    try
        //    {
        //        _iniDic["MES_State"] = _MES_State.ToString();
        //        this.WriteIniFile(_iniDic);
        //    }
        //    catch (Exception ex)
        //    {
        //        throw ex;
        //    }
        //}

        #region Private Static Method
        private static string parseBoolToString(bool enable)
        {
            if (enable)
                return "True";
            else
                return "False";
        }

        private static string parseTwoDoubleToString(double double1, double double2, char seperator)
        {
            return string.Format("{0}{2}{1}", double1, double2, seperator);
        }

        private static string parseThreeDoubleToString(double double1, double double2, double double3, char seperator)
        {
            return string.Format("{0}{3}{1}{3}{2}", double1, double2, double3, seperator);
        }

        private static void parseStringToTwoSubString(string data, char seperator, out string string1, out string string2)
        {
            int index = data.IndexOf(seperator);
            if (index != -1)
            {
                char[] char1 = new char[index];
                data.CopyTo(0, char1, 0, index);
                char[] char2 = new char[data.Length - index - 1];
                data.CopyTo(index + 1, char2, 0, data.Length - index - 1);
                string1 = new string(char1).Trim();
                string2 = new string(char2).Trim();
            }
            else
            {
                throw new Exception("Fail to parseStringToTwoSubString.\n" + data);
            }
        }

        private static void parseStringToThreeSubString(string data, char seperator, out string string1, out string string2, out string string3)
        {
            int index = data.IndexOf(seperator);
            if (index != -1)
            {
                char[] char1 = new char[index];
                data.CopyTo(0, char1, 0, index);
                char[] residue = new char[data.Length - index - 1];
                data.CopyTo(index + 1, residue, 0, data.Length - index - 1);
                string sResidue = new string(residue).Trim();
                index = sResidue.IndexOf(',');
                if (index != -1)
                {
                    char[] char2 = new char[index];
                    sResidue.CopyTo(0, char2, 0, index);
                    char[] char3 = new char[sResidue.Length - index - 1];
                    sResidue.CopyTo(index + 1, char3, 0, sResidue.Length - index - 1);
                    string1 = new string(char1).Trim();
                    string2 = new string(char2).Trim();
                    string3 = new string(char3).Trim();
                }
                else
                {
                    throw new Exception("Fail to parseStringToThreeSubString.\n" + data);
                }
            }
            else
            {
                throw new Exception("Fail to parseStringToThreeSubString.\n" + data);
            }
        }
        #endregion
    }
}
