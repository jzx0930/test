﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Windows.Forms.DataVisualization.Charting;

namespace LaserProcess_LCH
{
    public partial class MainForm
    {
        private int _pcCount;    //PowerCalibration count
        private double[] _pcAngles;  //PowerCalibration angles
        private double[] _pcPowers; //PowerCalibration powers
        private int[] _dgv_pcColumnWidths = { 50, 100, 200 };
        private string[] _dgv_pcHeader = { "#", "Angle ( °)", "Power (mW)" };

        #region User Event

        private void btn_PowerCalibration_Home_Click(object sender, EventArgs e)
        {
            //Write Event
            writeEvent("UserEvent", "Do PowerCalibration Homing.");

            // Do rotation stage homing
            _isRotationStageBusy = true;
            _RotationStage.Home();
            _isRotationStageBusy = false;
        }

        private void btn_PowerCalibration_Start_Click(object sender, EventArgs e)
        {
            //Write Event
            writeEvent("UserEvent", "Start PowerCalibration process.");

            // Check User setting
            if (!double.TryParse(txt_PowerCalibration_StartAngle.Text, out double startAngle) || startAngle < 0 || startAngle > 360) 
            {
                MessageBox.Show("起始角度:請輸入0~360範圍內之數值!");
                return;
            }
            if (!double.TryParse(txt_PowerCalibration_StepAngle.Text, out double stepAngle) || stepAngle < 0 || stepAngle > 360)
            {
                MessageBox.Show("間隔角度:請輸入0~360範圍內之數值!");
                return;
            }
            if (!double.TryParse(txt_PowerCalibration_EndAngle.Text, out double endAngle) || endAngle < 0 || endAngle > 360)
            {
                MessageBox.Show("最終角度:請輸入0~360範圍內之數值!");
                return;
            }
            if (!_rs_isHomed)
            {
                MessageBox.Show("請操作Home復歸!");
                return;
            }

            _pcCount = 1;
            double rampupAngle = startAngle;
            List<double> angleList = new List<double>();
            angleList.Add(startAngle);
            while (rampupAngle < endAngle)
            {
                rampupAngle += stepAngle;
                angleList.Add(rampupAngle);
                _pcCount++;
            }

            // RotationStage limits between 0~360
            if (rampupAngle > 360)
            {
                _pcCount--;
                angleList.Remove(angleList.Last());
            }

            // Update UI
            txt_PowerCalibration_NumberOfSample.Text = _pcCount.ToString();
            
            // Update local variable for BackgroundWorker
            _pcAngles = angleList.ToArray();
            _pcPowers = new double[_pcCount];

            // Initialize DataGridViewer
            dataGridView_PowerCalibration.Rows.Clear();
            dataGridViewHeaderInitialize(dataGridView_PowerCalibration, _dgv_pcColumnWidths, _dgv_pcHeader);

            if (!BW_PowerCalibration.IsBusy)
            {
                BW_PowerCalibration.RunWorkerAsync();
            }
        }

        private void btn_PowerCalibration_Stop_Click(object sender, EventArgs e)
        {
            //Write Event
            writeEvent("UserEvent", "Abort PowerCalibration measurement process.");

            if (BW_PowerCalibration.WorkerSupportsCancellation == true)
            {
                // Cancel the asynchronous operation.
                BW_PowerCalibration.CancelAsync();
            }
        }

        private void btn_PowerCalibration_Update_Click(object sender, EventArgs e)
        {
            //Write Event
            writeEvent("UserEvent", "Update PowerCalibration factors.");

            
        }

        private void btn_PowerCalibration_SelectFolder_Click(object sender, EventArgs e)
        {
            //Write Event
            writeEvent("UserEvent", "Select PowerCalibration FodlerPath");

            if (FolderBrowserDialog.ShowDialog() == DialogResult.OK)
            {
                updateControlTxtWithString(txt_PowerCalibration_FolderPath, FolderBrowserDialog.SelectedPath);
                _ConfigSystem._PowerCalibrationDataFolderPath = FolderBrowserDialog.SelectedPath;

                // Write parameters back to the ini file
                _ConfigSystem.WriteIntoIniFile();

                //Write Event
                writeEvent("UserEvent", "PowerCalibration FolderPath selected =" + FolderBrowserDialog.SelectedPath);
            }
        }

        private void btn_PowerCalibration_SaveData_Click(object sender, EventArgs e)
        {
            //Write Event
            writeEvent("UserEvent", "Save PowerCalibration Data");

            string fileName = txt_PowerCalibration_FileName.Text + ".csv";
            using (StreamWriter outputFile = new StreamWriter(Path.Combine(_ConfigSystem._PowerCalibrationDataFolderPath, fileName), true))
            {
                // Write Header
                string fileHeader = string.Format("{0}\t{1}\t{2}", _dgv_pcHeader[0], _dgv_pcHeader[1], _dgv_pcHeader[2]);
                outputFile.WriteLine(fileHeader);

                for (int i = 0; i < _pcCount; i++)
                {
                    outputFile.WriteLine(string.Format("{0}\t{1}\t{2}", i + 1, _pcAngles[i], _pcPowers[i]));
                }
            }
        }

        private void btn_PowerCalibration_LaserON_Click(object sender, EventArgs e)
        {
            //Write Event
            writeEvent("UserEvent", "Enable PowerCalibration LaserON.");

            // Enable Laser ON



        }

        private void btn_PowerCalibration_LaserOFF_Click(object sender, EventArgs e)
        {
            //Write Event
            writeEvent("UserEvent", "Enable PowerCalibration LaserOFF.");

            // Enable Laser OFF



        }

        #endregion

        #region BackgroundWorker

        private void BW_PowerCalibration_DoWork(object sender, DoWorkEventArgs e)
        {
            for (int i = 0; i < _pcCount; i++)
            {
                // Chech cancellation
                if (BW_PowerCalibration.CancellationPending)
                {
                    e.Cancel = true;
                    return;
                }

                // Move to specified target position
                _isRotationStageBusy = true;
                _RotationStage.MoveAbs((decimal)_pcAngles[i]);
                _isRotationStageBusy = false;

                // Delay for RotationStage change its status in module "monitorThread"
                Thread.Sleep(500);

                // Wait in position
                _isRotationStageBusy = true;
                while (!_RotationStage.GetIsMotionDone())
                {
                    Thread.Sleep(100);
                }
                _isRotationStageBusy = false;

                // Delay for Power Stabilization
                Thread.Sleep(1000);

                // Get the measure Laser Power
                _pcPowers[i] = _Powermeter_OutputPower;

                BW_PowerCalibration.ReportProgress(i);
            }
        }

        private void BW_PowerCalibration_ProgressChanged(object sender, ProgressChangedEventArgs e)
        {
            // Update UI
            int i = e.ProgressPercentage;
            double progress = (double)i / (double)_pcCount * 100;
            progressBar_PowerCalibration.Value = (int)progress;

            int number = i + 1;
            // Update DataGridViewer
            string[] text = { number.ToString(), _pcAngles[i].ToString("0.###"), _pcPowers[i].ToString("0.###") };
            addDataGridViewData(dataGridView_PowerCalibration, text);
        }

        private void BW_PowerCalibration_RunWorkerCompleted(object sender, RunWorkerCompletedEventArgs e)
        {
            if (e.Cancelled == true)
            {
                // Update UI
                this.chart_PowerCalibration.Series.Clear();
                this.chart_PowerCalibration.Titles.Clear();

                //Write Event
                writeEvent("UserEvent", "PowerCalibration process aborted.");
            }
            else
            {
                // Update UI
                progressBar_PowerCalibration.Value = 100;

                // Update Chart
                Series data = new Series("PowerCalibration");

                data.Color = Color.Blue;
                data.ChartType = SeriesChartType.Line;

                for (int i = 0; i < _pcCount; i++)
                {
                    data.Points.AddXY(_pcAngles[i], _pcPowers[i]);
                }

                this.chart_PowerCalibration.Series.Clear();
                this.chart_PowerCalibration.Series.Add(data);

                this.chart_PowerCalibration.Titles.Clear();
                this.chart_PowerCalibration.Titles.Add("Title");

                //Write Event
                writeEvent("UserEvent", "Complete PowerCalibration process.");
            }
        }

        #endregion
    }
}
