﻿using System;
using System.Collections.Generic;
using System.Net;             // 匯入通訊協定 
using System.Net.Sockets;     // 匯入網路插座功能函數 
using System.Threading;       // 匯入多執行緒功能函數
using System.Collections;     // 匯入集合物件功能
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace TCP_IP_Client
{
    public class TCPServerAP
    {
        public string IP
        {
            get;
            set;
        }
        public int Port
        {
            get;
            set;
        }
        public string ReadMsg
        {
            set;
            get;
        }
        public string SandMsg
        {
            set;
            get;
        }

        TcpClient tcpClient = new TcpClient();
        Thread m_thread;
        NetworkStream netStream;
        string ReadCode = "";
        string ReadDate = "";
        int m_cnt = 0;
        public TCPServerAP() { }
        private void Job()
        {
            //NetworkStream netStream;
            while (true)
            {
                // string ReadDate ="";
                netStream = tcpClient.GetStream();
                //if (SandMsg != "" && SandMsg != null)
                // {
                //WriteLine(netStream, String.Join("\n", SandMsg) + "\n");
                // WriteLine(netStream, SandMsg);
                // SandMsg = null;

                //string ReadCode = "";
                ReadCode = ReadLine(tcpClient, netStream, ReadCode);
                ReadMsg = ReadCode;
                Thread.Sleep(200);
                ReadDate = ReadLine(tcpClient, netStream, ReadDate);
                if (ReadDate != "" && ReadDate != null)
                {
                    ReadMsg = ReadDate;

                }
                // }


                Thread.Sleep(300);     // 不能省略, 否則UI來不及更新
            }
        }
        // public void WriteLine(NetworkStream netStream, string write)
        public void WriteLine(string write)
        {
            if (netStream.CanWrite)
            {

                //byte[] EndBytes = { 0x0d };
                //char[] CR = Encoding.ASCII.GetChars(EndBytes);
                byte[] writeData = Encoding.ASCII.GetBytes(write + '\r');
                netStream.Write(writeData, 0, writeData.Length);


                // 需等待資料真的已寫入 NetworkStream
                Thread.Sleep(300);

                // Console.WriteLine();
                //Console.WriteLine("Write: " + write);
                // Console.WriteLine("-------------------------");
            }
        }
        private static string ReadLine(TcpClient tcpClient, NetworkStream netStream,
            string output)
        {
            if (netStream.CanRead)
            {
                byte[] bytes = new byte[tcpClient.ReceiveBufferSize];
                int numBytesRead = netStream.Read(bytes, 0,
                    (int)tcpClient.ReceiveBufferSize);

                byte[] bytesRead = new byte[numBytesRead];
                Array.Copy(bytes, bytesRead, numBytesRead);

                string returndata = Encoding.ASCII.GetString(bytesRead);

                //output = String.Format("Read: Length: {0}, Data: \r\n{1}",returndata.Length, returndata);
                output = String.Format("{1}", returndata.Length, returndata);
            }

            //Console.WriteLine();
            // Console.WriteLine(output);
            // Console.WriteLine("-------------------------");

            return output.Trim();
        }
        public void Start()
        {
            string ipAddress = IP;
            int port = Port;

            //tcpClient = new TcpClient();


            while (!tcpClient.Connected)
            {
                tcpClient.Connect(ipAddress, port);
                tcpClient.NoDelay = false;
            }
            m_thread = new Thread(Job);
            m_thread.IsBackground = true;
            m_thread.Start();
        }
        public void Stop()
        {
            m_thread.Abort();
            tcpClient.Close();
        }
    }
}
