﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace LaserProcess_LCH
{
    public partial class MainForm
    {
        private const string _pointName1 = "ProcessingPoint";
        private const string _pointName2 = "CameraPoint";
        private const string _pointName3 = "ConfocalLaserPoint";
        private const string _pointName4 = "FeedInPoint";
        private const string _pointName5 = "FeedOutPoint";
        private const string _pointName6 = "ReservedPoint1";
        private const string _pointName7 = "ReservedPoint2";
        private const string _pointName8 = "ReservedPoint3";
        private const string _pointName9 = "功率量測區";

        /// <summary>
        /// Update GUI TextBox from ConfigSystem .ini file
        /// </summary>
        private void UpdateConfigSystem()
        {
            UpdateTextBox_Text(txt_ConfigSystem_UPS_InputVoltage_Low, _ConfigSystem._UPS_InputVoltage.Low);
            UpdateTextBox_Text(txt_ConfigSystem_UPS_InputVoltage_High, _ConfigSystem._UPS_InputVoltage.High);
            UpdateTextBox_Text(txt_ConfigSystem_UPS_OutputVoltage_Low, _ConfigSystem._UPS_OutputVoltage.Low);
            UpdateTextBox_Text(txt_ConfigSystem_UPS_OutputVoltage_High, _ConfigSystem._UPS_OutputVoltage.High);
            UpdateTextBox_Text(txt_ConfigSystem_Temperature_Low, _ConfigSystem._Temperature.Low);
            UpdateTextBox_Text(txt_ConfigSystem_Temperature_High, _ConfigSystem._Temperature.High);
            UpdateTextBox_Text(txt_ConfigSystem_Humidity_Low, _ConfigSystem._Humidity.Low);
            UpdateTextBox_Text(txt_ConfigSystem_Humidity_High, _ConfigSystem._Humidity.High);
            UpdateTextBox_Text(txt_ConfigSystem_PowerCheck_USL, _ConfigSystem._AutoPowerCheck_USL);
            UpdateTextBox_Text(txt_ConfigSystem_PowerCheck_LSL, _ConfigSystem._AutoPowerCheck_LSL);
            UpdateTextBox_Text(txt_ConfigSystem_PowerCheck_value, _ConfigSystem._AutoPowerCheck_value);
            UpdateTextBox_Text(txt_ConfigSystem_PowerCheck_Count, _ConfigSystem._AutoPowerCheck_count);


            chk_ConfigSystem_ConnectSetting_MotionControl.Checked = _ConfigSystem._ConnectSetting.MotionControl;
            chk_ConfigSystem_ConnectSetting_Laser.Checked = _ConfigSystem._ConnectSetting.Laser;
            chk_ConfigSystem_ConnectSetting_LaserScanner.Checked = _ConfigSystem._ConnectSetting.LaserScanner;
            chk_ConfigSystem_ConnectSetting_CameraCVX.Checked = _ConfigSystem._ConnectSetting.CameraCVX;
            chk_ConfigSystem_ConnectSetting_ConfocalLaser.Checked = _ConfigSystem._ConnectSetting.ConfocalLaser;
            chk_ConfigSystem_ConnectSetting_PositionAligner.Checked = _ConfigSystem._ConnectSetting.PositionAligner;
            chk_ConfigSystem_ConnectSetting_RotationStage.Checked = _ConfigSystem._ConnectSetting.RotationStage;
            chk_ConfigSystem_ConnectSetting_Powermeter.Checked = _ConfigSystem._ConnectSetting.Powermeter;
            chk_ConfigSystem_ConnectSetting_Autocorrelator.Checked = _ConfigSystem._ConnectSetting.Autocorrelator;
            chk_ConfigSystem_ConnectSetting_Beamprofiler.Checked = _ConfigSystem._ConnectSetting.Beamprofiler;
            chk_ConfigSystem_ConnectSetting_THSensor.Checked = _ConfigSystem._ConnectSetting.THSensor;
            chk_ConfigSystem_ConnectSetting_LaserChiller.Checked = _ConfigSystem._ConnectSetting.LaserChiller;
            chk_ConfigSystem_ConnectSetting_ScannerChiller.Checked = _ConfigSystem._ConnectSetting.ScannerChiller;
            chk_ConfigSystem_ConnectSetting_UPS.Checked = _ConfigSystem._ConnectSetting.UPS;
            chk_ConfigSystem_ConnectSetting_IOCard.Checked = _ConfigSystem._ConnectSetting.IOCard;
            chk_ConfigSystem_ConnectSetting_MES.Checked = _ConfigSystem._ConnectSetting.ChptMES;


            // Write Event Log
            writeEvent("MainForm.Config", "UpdateConfigSystem completed!");
        }

        /// <summary>
        /// Update GUI TextBox from ConfigEquip .ini file
        /// </summary>
        private void UpdateConfigEquip()
        {
            UpdateTextBox_Text(txt_ConfigEquip_Position_Processing_X, _ConfigEquip._Position_Processing.X);
            UpdateTextBox_Text(txt_ConfigEquip_Position_Processing_Y, _ConfigEquip._Position_Processing.Y);
            UpdateTextBox_Text(txt_ConfigEquip_Position_Processing_Z, _ConfigEquip._Position_Processing.Z);
            UpdateTextBox_Text(txt_ConfigEquip_Position_Camera_X, _ConfigEquip._Position_Camera.X);
            UpdateTextBox_Text(txt_ConfigEquip_Position_Camera_Y, _ConfigEquip._Position_Camera.Y);
            UpdateTextBox_Text(txt_ConfigEquip_Position_Camera_Z, _ConfigEquip._Position_Camera.Z);
            UpdateTextBox_Text(txt_ConfigEquip_Position_ConfocalLaser_X, _ConfigEquip._Position_ConfocalLaser.X);
            UpdateTextBox_Text(txt_ConfigEquip_Position_ConfocalLaser_Y, _ConfigEquip._Position_ConfocalLaser.Y);
            UpdateTextBox_Text(txt_ConfigEquip_Position_ConfocalLaser_Z, _ConfigEquip._Position_ConfocalLaser.Z);
            //UpdateTextBox_Text(Keyence_Height_textBox, _ConfigEquip._Position_ConfocalLaser.Z);
            UpdateTextBox_Text(txt_ConfigEquip_Position_FeedIn_X, _ConfigEquip._Position_FeedIn.X);
            UpdateTextBox_Text(txt_ConfigEquip_Position_FeedIn_Y, _ConfigEquip._Position_FeedIn.Y);
            UpdateTextBox_Text(txt_ConfigEquip_Position_FeedIn_Z, _ConfigEquip._Position_FeedIn.Z);
            UpdateTextBox_Text(txt_ConfigEquip_Position_FeedOut_X, _ConfigEquip._Position_FeedOut.X);
            UpdateTextBox_Text(txt_ConfigEquip_Position_FeedOut_Y, _ConfigEquip._Position_FeedOut.Y);
            UpdateTextBox_Text(txt_ConfigEquip_Position_FeedOut_Z, _ConfigEquip._Position_FeedOut.Z);
            UpdateTextBox_Text(txt_ConfigEquip_Position_Reserved1_X, _ConfigEquip._Position_Reserved1.X);
            UpdateTextBox_Text(txt_ConfigEquip_Position_Reserved1_Y, _ConfigEquip._Position_Reserved1.Y);
            UpdateTextBox_Text(txt_ConfigEquip_Position_Reserved1_Z, _ConfigEquip._Position_Reserved1.Z);
            UpdateTextBox_Text(txt_ConfigEquip_Position_Reserved2_X, _ConfigEquip._Position_Reserved2.X);
            UpdateTextBox_Text(txt_ConfigEquip_Position_Reserved2_Y, _ConfigEquip._Position_Reserved2.Y);
            UpdateTextBox_Text(txt_ConfigEquip_Position_Reserved2_Z, _ConfigEquip._Position_Reserved2.Z);
            UpdateTextBox_Text(txt_ConfigEquip_Position_Reserved3_X, _ConfigEquip._Position_Reserved3.X);
            UpdateTextBox_Text(txt_ConfigEquip_Position_Reserved3_Y, _ConfigEquip._Position_Reserved3.Y);
            UpdateTextBox_Text(txt_ConfigEquip_Position_Reserved3_Z, _ConfigEquip._Position_Reserved3.Z);
            UpdateTextBox_Text(txt_ConfigEquip_Position_PowerMonitor_X, _ConfigEquip._Position_PowerMonitor.X);
            UpdateTextBox_Text(txt_ConfigEquip_Position_PowerMonitor_Y, _ConfigEquip._Position_PowerMonitor.Y);
            UpdateTextBox_Text(txt_ConfigEquip_Position_PowerMonitor_Z, _ConfigEquip._Position_PowerMonitor.Z);

            UpdateTextBox_Text(txt_ConfigEquip_RelPosition_Laser2Camera_X, _ConfigEquip._RelPosition_Laser2Camera.X);
            UpdateTextBox_Text(txt_ConfigEquip_RelPosition_Laser2Camera_Y, _ConfigEquip._RelPosition_Laser2Camera.Y);
            UpdateTextBox_Text(txt_ConfigEquip_RelPosition_Laser2ConfocalLaser_X, _ConfigEquip._RelPosition_Laser2ConfocalLaser.X);
            UpdateTextBox_Text(txt_ConfigEquip_RelPosition_Laser2ConfocalLaser_Y, _ConfigEquip._RelPosition_Laser2ConfocalLaser.Y);

            UpdateTextBox_Text(txt_ConfigEquip_Height_Laser, _ConfigEquip._Height_Equip.Laser);
            UpdateTextBox_Text(txt_ConfigEquip_Height_Camera, _ConfigEquip._Height_Equip.Camera);
            UpdateTextBox_Text(txt_ConfigEquip_Height_ConfocalLaser, _ConfigEquip._Height_Equip.ConfocalLaser);

            UpdateTextBox_Text(txt_ConfigEquip_SWLimit_X_High, _ConfigEquip._SWLimit_X.High);
            UpdateTextBox_Text(txt_ConfigEquip_SWLimit_Y_High, _ConfigEquip._SWLimit_Y.High);
            UpdateTextBox_Text(txt_ConfigEquip_SWLimit_Z_High, _ConfigEquip._SWLimit_Z.High);
            UpdateTextBox_Text(txt_ConfigEquip_SWLimit_X_Low, _ConfigEquip._SWLimit_X.Low);
            UpdateTextBox_Text(txt_ConfigEquip_SWLimit_Y_Low, _ConfigEquip._SWLimit_Y.Low);
            UpdateTextBox_Text(txt_ConfigEquip_SWLimit_Z_Low, _ConfigEquip._SWLimit_Z.Low);

            UpdateTextBox_Text(txt_ConfigEquip_ProcessLimit_X_High, _ConfigEquip._ProcessLimit_X.High);
            UpdateTextBox_Text(txt_ConfigEquip_ProcessLimit_Y_High, _ConfigEquip._ProcessLimit_Y.High);
            UpdateTextBox_Text(txt_ConfigEquip_ProcessLimit_Z_High, _ConfigEquip._ProcessLimit_Z.High);
            UpdateTextBox_Text(txt_ConfigEquip_ProcessLimit_X_Low, _ConfigEquip._ProcessLimit_X.Low);
            UpdateTextBox_Text(txt_ConfigEquip_ProcessLimit_Y_Low, _ConfigEquip._ProcessLimit_Y.Low);
            UpdateTextBox_Text(txt_ConfigEquip_ProcessLimit_Z_Low, _ConfigEquip._ProcessLimit_Z.Low);

            UpdateTextBox_Text(txt_ConfigEquip_Velocity_X, _ConfigEquip._Velocity_Default.X);
            UpdateTextBox_Text(txt_ConfigEquip_Velocity_Y, _ConfigEquip._Velocity_Default.Y);
            UpdateTextBox_Text(txt_ConfigEquip_Velocity_Z, _ConfigEquip._Velocity_Default.Z);

            UpdateTextBox_Text(txt_ConfigEquip_Power_Gain, _ConfigEquip._PowerCalibration.Gain);
            UpdateTextBox_Text(txt_ConfigEquip_Power_Offset, _ConfigEquip._PowerCalibration.Offset);
            UpdateTextBox_Text(txt_ConfigEquip_Power_Cutoff, _ConfigEquip._PowerCalibration.Cutoff);

            UpdateTextBox_Text(txt_ConfigEquip_Rotation_Gain, _ConfigEquip._RotationCalibration.Gain);
            UpdateTextBox_Text(txt_ConfigEquip_Rotation_Offset, _ConfigEquip._RotationCalibration.Offset);

            // Write Event Log
            writeEvent("MainForm.Config", "UpdateConfigEquip completed!");
        }

        private void UpdateConfigProcess()
        {
            UpdateTextBox_Text(txt_ConfigProcess_DistanceZ, _ConfigProcess._Compensate_DistanceZ);
            UpdateTextBox_Text(txt_ConfigProcess_Fast_Speed, _ConfigProcess._Speed_Fast);
            UpdateTextBox_Text(txt_ConfigProcess_Feature_speed, _ConfigProcess._Speed_Feature);
            UpdateTextBox_Text(txt_ConfigProcess_GH_speed, _ConfigProcess._Speed_GuideHole);
            UpdateTextBox_Text(txt_ConfigProcess_LamGH_speed, _ConfigProcess._Speed_LamGH);
            UpdateTextBox_Text(txt_ConfigProcess_Others_Speed, _ConfigProcess._Speed_Others);
            UpdateTextBox_Text(txt_ConfigProcess_Power_Feature, _ConfigProcess._Power_Feature);
            UpdateTextBox_Text(txt_ConfigProcess_Power_GuideHole, _ConfigProcess._Power_GuideHole);
            UpdateTextBox_Text(txt_ConfigProcess_Power_LamGH, _ConfigProcess._Power_LamGH);
            UpdateTextBox_Text(txt_ConfigProcess_Power_Others, _ConfigProcess._Power_Others);
            UpdateTextBox_Text(txt_ConfigProcess_Power_DeviationThreshold, _ConfigProcess._Power_DeviationThreshold);
            updateControlTxtWithString(txt_ConfigProcess_Sample_JobName, _ConfigProcess._Sample_JobName);
            UpdateTextBox_Text(txt_ConfigProcess_Sample_CutLoop, _ConfigProcess._Sample_CutLoop);
            UpdateTextBox_Text(txt_ConfigProcess_Sample_CutWidth, _ConfigProcess._Sample_CutWidth);
            UpdateTextBox_Text(txt_ConfigProcess_Sample_CutLength, _ConfigProcess._Sample_CutLength);
            UpdateTextBox_Text(txt_ConfigProcess_Sample_OffsetX, _ConfigProcess._Sample_OffsetX);
            UpdateTextBox_Text(txt_ConfigProcess_Sample_OffsetY, _ConfigProcess._Sample_OffsetY);
            chk_ConfigProcess_IsAutoProcessSuspend.Checked = _ConfigProcess._IsAutoProcessSuspend;
            UpdateTextBox_Text(txt_ConfigProcess_Suspend_IntervalTime, _ConfigProcess._Suspend_IntervalTime);
            UpdateTextBox_Text(txt_ConfigProcess_Suspend_TimeToWait, _ConfigProcess._Suspend_TimeToWait);
            chk_ConfigProcess_IsAutoProcessHold.Checked = _ConfigProcess._IsAutoProcessHold;
            UpdateTextBox_Text(txt_ConfigProcess_Hold_IntervalTime, _ConfigProcess._Hold_IntervalTime);
            UpdateTextBox_Text(txt_ConfigProcess_Hold_TimeToWait, _ConfigProcess._Hold_TimeToWait);
            chk_ConfigProcess_IsAutoProcessWarmup.Checked = _ConfigProcess._IsAutoProcessWarmup;
            UpdateTextBox_Text(txt_ConfigProcess_Warnup_TimeToWait, _ConfigProcess._Warmup_TimeToWait);
            chk_ConfigProcess_IsAutoLaserSleep.Checked = _ConfigProcess._IsAutoLaserSleep;
            UpdateTextBox_Text(txt_ConfigProcess_LaserSleep_Count, _ConfigProcess._LaserSleep_Count);
            UpdateTextBox_Text(txt_ConfigProcess_LaserSleep_Time, _ConfigProcess._LaserSleep_Time);
            UpdateTextBox_Text(txt_ConfigProcess_LP_Gain, _ConfigProcess._LaserParam_Convert.Gain);
            UpdateTextBox_Text(txt_ConfigProcess_LP_Offset, _ConfigProcess._LaserParam_Convert.Offset);
            UpdateTextBox_Text(txt_ConfigProcess_MP_Gain, _ConfigProcess._MotionParam_Convert.Gain);
            UpdateTextBox_Text(txt_ConfigProcess_MP_Offset, _ConfigProcess._MotionParam_Convert.Offset);
            chk_ConfigProcess_IsAutoProcessCheckJobx.Checked = _ConfigProcess._IsAutoProcessCheckJobx;
            chk_ConfigProcess_IsThickComparison.Checked = _ConfigProcess._IsThickComparison;
            UpdateTextBox_Text(txt_ConfigProcess_ThickComparison, _ConfigProcess._ThickComparison);
            UpdateTextBox_Text(txt_ConfigProcess_Check_ThickLaserX, _ConfigProcess._Check_ThickLaserX);
            UpdateTextBox_Text(txt_ConfigProcess_Check_ThickLaserY, _ConfigProcess._Check_ThickLaserY);
            UpdateTextBox_Text(txt_ConfigProcess_Check_ThickLaserZ, _ConfigProcess._Check_ThickLaserZ);


            // Write Event Log
            writeEvent("MainForm.Config", "UpdateConfigProcess completed!");
        }

        private void UpdateTextBox_Text(TextBox textbox, double val)
        {
            textbox.Text = string.Format("{0:0.###}", val);
        }

        #region Reset & Save
        private void btn_ConfigSystem_Reset_Click(object sender, EventArgs e)
        {
            // Replace the params with _iniDic
            _ConfigSystem.UpdatePublicParams();
            // Update the GUI controls
            UpdateConfigSystem();
        }

        private void btn_ConfigSystem_Save_Click(object sender, EventArgs e)
        {
            // Write parameters back to the ini file
            _ConfigSystem.WriteIntoIniFile();
        }

        private void btn_ConfigEquip_Reset_Click(object sender, EventArgs e)
        {
            // Replace the params with _iniDic
            _ConfigEquip.UpdatePublicParams();

            // Update the GUI controls
            UpdateConfigEquip();
        }

        private void btn_ConfigEquip_Save_Click(object sender, EventArgs e)
        {
            // Write parameters back to the ini file
            _ConfigEquip.WriteIntoIniFile();
        }

        private void btn_ConfigProcess_Reset_Click(object sender, EventArgs e)
        {
            // Replace the params with _iniDic
            _ConfigProcess.UpdatePublicParams();

            // Update the GUI controls
            UpdateConfigProcess();
        }

        private void btn_ConfigProcess_Save_Click(object sender, EventArgs e)
        {
            // Write parameters back to the ini file
            _ConfigProcess.WriteIntoIniFile();
        }

        #endregion

        #region Else

        private void btn_ConfigSystem_Set_UPS_SafetyThreshold_Click(object sender, EventArgs e)
        {
            _ConfigSystem._UPS_InputVoltage.High = double.Parse(txt_ConfigSystem_UPS_InputVoltage_High.Text);
            _ConfigSystem._UPS_InputVoltage.Low = double.Parse(txt_ConfigSystem_UPS_InputVoltage_Low.Text);
            _ConfigSystem._UPS_OutputVoltage.High = double.Parse(txt_ConfigSystem_UPS_OutputVoltage_High.Text);
            _ConfigSystem._UPS_OutputVoltage.Low = double.Parse(txt_ConfigSystem_UPS_OutputVoltage_Low.Text);
        }

        private void btn_ConfigSystem_Set_THSensor_SafetyThreshold_Click(object sender, EventArgs e)
        {
            _ConfigSystem._Temperature.High = double.Parse(txt_ConfigSystem_Temperature_High.Text);
            _ConfigSystem._Temperature.Low = double.Parse(txt_ConfigSystem_Temperature_Low.Text);
            _ConfigSystem._Humidity.High = double.Parse(txt_ConfigSystem_Humidity_High.Text);
            _ConfigSystem._Humidity.Low = double.Parse(txt_ConfigSystem_Humidity_Low.Text);
        }
        private void btn_txt_Set_Power_Ofs_Click(object sender, EventArgs e)
        {
            _ConfigSystem._AutoPowerCheck_USL = double.Parse(txt_ConfigSystem_PowerCheck_USL.Text);
            _ConfigSystem._AutoPowerCheck_LSL = double.Parse(txt_ConfigSystem_PowerCheck_LSL.Text);
            _ConfigSystem._AutoPowerCheck_value = double.Parse(txt_ConfigSystem_PowerCheck_value.Text);


            _ConfigSystem._AutoPowerCheck_count = int.Parse(txt_ConfigSystem_PowerCheck_Count.Text);

            string msg = string.Format("雷射功率檢察; 上限(%) = {0:0.###}, 下限(%) = {1:0.###}, 設定值(W) = {2:0.###},執行多少微孔進檢查", _ConfigSystem._AutoPowerCheck_USL, _ConfigSystem._AutoPowerCheck_LSL, _ConfigSystem._AutoPowerCheck_value, _ConfigSystem._AutoPowerCheck_count);

            // Write Event
            writeEvent("UserEvent", msg);
        }
        private void btn_Set_ConnectSetting_Click(object sender, EventArgs e)
        {
            _ConfigSystem._ConnectSetting.MotionControl = chk_ConfigSystem_ConnectSetting_MotionControl.Checked;
            _ConfigSystem._ConnectSetting.Laser = chk_ConfigSystem_ConnectSetting_Laser.Checked;
            _ConfigSystem._ConnectSetting.LaserScanner = chk_ConfigSystem_ConnectSetting_LaserScanner.Checked;
            _ConfigSystem._ConnectSetting.CameraCVX = chk_ConfigSystem_ConnectSetting_CameraCVX.Checked;
            _ConfigSystem._ConnectSetting.ConfocalLaser = chk_ConfigSystem_ConnectSetting_ConfocalLaser.Checked;
            _ConfigSystem._ConnectSetting.PositionAligner = chk_ConfigSystem_ConnectSetting_PositionAligner.Checked;
            _ConfigSystem._ConnectSetting.RotationStage = chk_ConfigSystem_ConnectSetting_RotationStage.Checked;
            _ConfigSystem._ConnectSetting.Powermeter = chk_ConfigSystem_ConnectSetting_Powermeter.Checked;
            _ConfigSystem._ConnectSetting.Autocorrelator = chk_ConfigSystem_ConnectSetting_Autocorrelator.Checked;
            _ConfigSystem._ConnectSetting.Beamprofiler = chk_ConfigSystem_ConnectSetting_Beamprofiler.Checked;
            _ConfigSystem._ConnectSetting.THSensor = chk_ConfigSystem_ConnectSetting_THSensor.Checked;
            _ConfigSystem._ConnectSetting.LaserChiller = chk_ConfigSystem_ConnectSetting_LaserChiller.Checked;
            _ConfigSystem._ConnectSetting.ScannerChiller = chk_ConfigSystem_ConnectSetting_ScannerChiller.Checked;
            _ConfigSystem._ConnectSetting.UPS = chk_ConfigSystem_ConnectSetting_UPS.Checked;
            _ConfigSystem._ConnectSetting.IOCard = chk_ConfigSystem_ConnectSetting_IOCard.Checked;
            _ConfigSystem._ConnectSetting.ChptMES = chk_ConfigSystem_ConnectSetting_MES.Checked;
        }

        private void btn_ConfigEquip_Set_Position_Processing_Click(object sender, EventArgs e)
        {
            txt_ConfigEquip_Position_Processing_X.Text = txt_Motion_Position_X.Text;
            txt_ConfigEquip_Position_Processing_Y.Text = txt_Motion_Position_Y.Text;
            txt_ConfigEquip_Position_Processing_Z.Text = txt_Motion_Position_Z.Text;
            _ConfigEquip._Position_Processing.X = double.Parse(txt_ConfigEquip_Position_Processing_X.Text);
            _ConfigEquip._Position_Processing.Y = double.Parse(txt_ConfigEquip_Position_Processing_Y.Text);
            _ConfigEquip._Position_Processing.Z = double.Parse(txt_ConfigEquip_Position_Processing_Z.Text);

            string msg = string.Format("Set {0} = ({1:0.####}, {2:0.####}, {3:0.####})", _pointName1, _ConfigEquip._Position_Processing.X, _ConfigEquip._Position_Processing.Y, _ConfigEquip._Position_Processing.Z);
            // Write Event
            writeEvent("UserEvent", msg);
        }

        private void btn_ConfigEquip_Set_Position_Camera_Click(object sender, EventArgs e)
        {
            txt_ConfigEquip_Position_Camera_X.Text = txt_Motion_Position_X.Text;
            txt_ConfigEquip_Position_Camera_Y.Text = txt_Motion_Position_Y.Text;
            txt_ConfigEquip_Position_Camera_Z.Text = txt_Motion_Position_Z.Text;
            _ConfigEquip._Position_Camera.X = double.Parse(txt_ConfigEquip_Position_Camera_X.Text);
            _ConfigEquip._Position_Camera.Y = double.Parse(txt_ConfigEquip_Position_Camera_Y.Text);
            _ConfigEquip._Position_Camera.Z = double.Parse(txt_ConfigEquip_Position_Camera_Z.Text);

            string msg = string.Format("Set {0} = ({1:0.####}, {2:0.####}, {3:0.####})", _pointName2, _ConfigEquip._Position_Camera.X, _ConfigEquip._Position_Camera.Y, _ConfigEquip._Position_Camera.Z);
            // Write Event
            writeEvent("UserEvent", msg);
        }

        private void btn_ConfigEquip_Set_Position_ConfocalLaser_Click(object sender, EventArgs e)
        {
            txt_ConfigEquip_Position_ConfocalLaser_X.Text = txt_Motion_Position_X.Text;
            txt_ConfigEquip_Position_ConfocalLaser_Y.Text = txt_Motion_Position_Y.Text;
            txt_ConfigEquip_Position_ConfocalLaser_Z.Text = txt_Motion_Position_Z.Text;
            _ConfigEquip._Position_ConfocalLaser.X = double.Parse(txt_ConfigEquip_Position_ConfocalLaser_X.Text);
            _ConfigEquip._Position_ConfocalLaser.Y = double.Parse(txt_ConfigEquip_Position_ConfocalLaser_Y.Text);
            _ConfigEquip._Position_ConfocalLaser.Z = double.Parse(txt_ConfigEquip_Position_ConfocalLaser_Z.Text);

            string msg = string.Format("Set {0} = ({1:0.####}, {2:0.####}, {3:0.####})", _pointName3, _ConfigEquip._Position_ConfocalLaser.X, _ConfigEquip._Position_ConfocalLaser.Y, _ConfigEquip._Position_ConfocalLaser.Z);
            // Write Event
            writeEvent("UserEvent", msg);
        }

        private void btn_ConfigEquip_Set_Position_FeedIn_Click(object sender, EventArgs e)
        {
            txt_ConfigEquip_Position_FeedIn_X.Text = txt_Motion_Position_X.Text;
            txt_ConfigEquip_Position_FeedIn_Y.Text = txt_Motion_Position_Y.Text;
            txt_ConfigEquip_Position_FeedIn_Z.Text = txt_Motion_Position_Z.Text;
            _ConfigEquip._Position_FeedIn.X = double.Parse(txt_ConfigEquip_Position_FeedIn_X.Text);
            _ConfigEquip._Position_FeedIn.Y = double.Parse(txt_ConfigEquip_Position_FeedIn_Y.Text);
            _ConfigEquip._Position_FeedIn.Z = double.Parse(txt_ConfigEquip_Position_FeedIn_Z.Text);

            string msg = string.Format("Set {0} = ({1:0.####}, {2:0.####}, {3:0.####})", _pointName4, _ConfigEquip._Position_Processing.X, _ConfigEquip._Position_Processing.Y, _ConfigEquip._Position_Processing.Z);
            // Write Event
            writeEvent("UserEvent", msg);
        }

        private void btn_ConfigEquip_Set_Position_FeedOut_Click(object sender, EventArgs e)
        {
            txt_ConfigEquip_Position_FeedOut_X.Text = txt_Motion_Position_X.Text;
            txt_ConfigEquip_Position_FeedOut_Y.Text = txt_Motion_Position_Y.Text;
            txt_ConfigEquip_Position_FeedOut_Z.Text = txt_Motion_Position_Z.Text;
            _ConfigEquip._Position_FeedOut.X = double.Parse(txt_ConfigEquip_Position_FeedOut_X.Text);
            _ConfigEquip._Position_FeedOut.Y = double.Parse(txt_ConfigEquip_Position_FeedOut_Y.Text);
            _ConfigEquip._Position_FeedOut.Z = double.Parse(txt_ConfigEquip_Position_FeedOut_Z.Text);

            string msg = string.Format("Set {0} = ({1:0.####}, {2:0.####}, {3:0.####})", _pointName5, _ConfigEquip._Position_FeedOut.X, _ConfigEquip._Position_FeedOut.Y, _ConfigEquip._Position_FeedOut.Z);
            // Write Event
            writeEvent("UserEvent", msg);
        }

        private void btn_ConfigEquip_Set_Position_Reserved1_Click(object sender, EventArgs e)
        {
            txt_ConfigEquip_Position_Reserved1_X.Text = txt_Motion_Position_X.Text;
            txt_ConfigEquip_Position_Reserved1_Y.Text = txt_Motion_Position_Y.Text;
            txt_ConfigEquip_Position_Reserved1_Z.Text = txt_Motion_Position_Z.Text;
            _ConfigEquip._Position_Reserved1.X = double.Parse(txt_ConfigEquip_Position_Reserved1_X.Text);
            _ConfigEquip._Position_Reserved1.Y = double.Parse(txt_ConfigEquip_Position_Reserved1_Y.Text);
            _ConfigEquip._Position_Reserved1.Z = double.Parse(txt_ConfigEquip_Position_Reserved1_Z.Text);

            string msg = string.Format("Set {0} = ({1:0.####}, {2:0.####}, {3:0.####})", _pointName6, _ConfigEquip._Position_Reserved1.X, _ConfigEquip._Position_Reserved1.Y, _ConfigEquip._Position_Reserved1.Z);
            // Write Event
            writeEvent("UserEvent", msg);
        }

        private void btn_ConfigEquip_Set_Position_Reserved2_Click(object sender, EventArgs e)
        {
            txt_ConfigEquip_Position_Reserved2_X.Text = txt_Motion_Position_X.Text;
            txt_ConfigEquip_Position_Reserved2_Y.Text = txt_Motion_Position_Y.Text;
            txt_ConfigEquip_Position_Reserved2_Z.Text = txt_Motion_Position_Z.Text;
            _ConfigEquip._Position_Reserved2.X = double.Parse(txt_ConfigEquip_Position_Reserved2_X.Text);
            _ConfigEquip._Position_Reserved2.Y = double.Parse(txt_ConfigEquip_Position_Reserved2_Y.Text);
            _ConfigEquip._Position_Reserved2.Z = double.Parse(txt_ConfigEquip_Position_Reserved2_Z.Text);

            string msg = string.Format("Set {0} = ({1:0.####}, {2:0.####}, {3:0.####})", _pointName7, _ConfigEquip._Position_Reserved2.X, _ConfigEquip._Position_Reserved2.Y, _ConfigEquip._Position_Reserved2.Z);
            // Write Event
            writeEvent("UserEvent", msg);
        }

        private void btn_ConfigEquip_Set_Position_Reserved3_Click(object sender, EventArgs e)
        {
            txt_ConfigEquip_Position_Reserved3_X.Text = txt_Motion_Position_X.Text;
            txt_ConfigEquip_Position_Reserved3_Y.Text = txt_Motion_Position_Y.Text;
            txt_ConfigEquip_Position_Reserved3_Z.Text = txt_Motion_Position_Z.Text;
            _ConfigEquip._Position_Reserved3.X = double.Parse(txt_ConfigEquip_Position_Reserved3_X.Text);
            _ConfigEquip._Position_Reserved3.Y = double.Parse(txt_ConfigEquip_Position_Reserved3_Y.Text);
            _ConfigEquip._Position_Reserved3.Z = double.Parse(txt_ConfigEquip_Position_Reserved3_Z.Text);

            string msg = string.Format("Set {0} = ({1:0.####}, {2:0.####}, {3:0.####})", _pointName8, _ConfigEquip._Position_Reserved3.X, _ConfigEquip._Position_Reserved3.Y, _ConfigEquip._Position_Reserved3.Z);
            // Write Event
            writeEvent("UserEvent", msg);
        }

        private void btn_ConfigEquip_Set_Position_Reserved4_Click(object sender, EventArgs e)
        {
            txt_ConfigEquip_Position_PowerMonitor_X.Text = txt_Motion_Position_X.Text;
            txt_ConfigEquip_Position_PowerMonitor_Y.Text = txt_Motion_Position_Y.Text;
            txt_ConfigEquip_Position_PowerMonitor_Z.Text = txt_Motion_Position_Z.Text;
            _ConfigEquip._Position_PowerMonitor.X = double.Parse(txt_ConfigEquip_Position_PowerMonitor_X.Text);
            _ConfigEquip._Position_PowerMonitor.Y = double.Parse(txt_ConfigEquip_Position_PowerMonitor_Y.Text);
            _ConfigEquip._Position_PowerMonitor.Z = double.Parse(txt_ConfigEquip_Position_PowerMonitor_Z.Text);

            string msg = string.Format("Set {0} = ({1:0.####}, {2:0.####}, {3:0.####})", _pointName9, _ConfigEquip._Position_PowerMonitor.X, _ConfigEquip._Position_PowerMonitor.Y, _ConfigEquip._Position_PowerMonitor.Z);
            // Write Event
            writeEvent("UserEvent", msg);
        }

        private void btn_ConfigEquip_Set_Laser2Camera_Click(object sender, EventArgs e)
        {
            _ConfigEquip._RelPosition_Laser2Camera.X = double.Parse(txt_ConfigEquip_RelPosition_Laser2Camera_X.Text);
            _ConfigEquip._RelPosition_Laser2Camera.Y = double.Parse(txt_ConfigEquip_RelPosition_Laser2Camera_Y.Text);

            string msg = string.Format("Set Laser To Camera = ({0:0.####}, {1:0.####})", _ConfigEquip._RelPosition_Laser2Camera.X, _ConfigEquip._RelPosition_Laser2Camera.Y);
            // Write Event
            writeEvent("UserEvent", msg);
        }

        private void btn_ConfigEquip_Set_Laser2ConfocalLaser_Click(object sender, EventArgs e)
        {
            _ConfigEquip._RelPosition_Laser2ConfocalLaser.X = double.Parse(txt_ConfigEquip_RelPosition_Laser2ConfocalLaser_X.Text);
            _ConfigEquip._RelPosition_Laser2ConfocalLaser.Y = double.Parse(txt_ConfigEquip_RelPosition_Laser2ConfocalLaser_Y.Text);

            string msg = string.Format("Set Laser To ConfocalLaser = ({0:0.####}, {1:0.####})", _ConfigEquip._RelPosition_Laser2ConfocalLaser.X, _ConfigEquip._RelPosition_Laser2ConfocalLaser.Y);
            // Write Event
            writeEvent("UserEvent", msg);
        }

        private void btn_ConfigEquip_Set_Heights_Click(object sender, EventArgs e)
        {
            _ConfigEquip._Height_Equip.Laser = double.Parse(txt_ConfigEquip_Height_Laser.Text);
            _ConfigEquip._Height_Equip.Camera = double.Parse(txt_ConfigEquip_Height_Camera.Text);
            _ConfigEquip._Height_Equip.ConfocalLaser = double.Parse(txt_ConfigEquip_Height_ConfocalLaser.Text);

            string msg = string.Format("Set Heights; Laser = {0:0.####}, Camera = {1:0.####}, ConfocalLaser = {2:0.####}", _ConfigEquip._Height_Equip.Laser, _ConfigEquip._Height_Equip.Camera, _ConfigEquip._Height_Equip.ConfocalLaser);
            // Write Event
            writeEvent("UserEvent", msg);
        }

        private void btn_ConfigEquip_Set_SWLimit_Click(object sender, EventArgs e)
        {
            _ConfigEquip._SWLimit_X.High = double.Parse(txt_ConfigEquip_SWLimit_X_High.Text);
            _ConfigEquip._SWLimit_X.Low = double.Parse(txt_ConfigEquip_SWLimit_X_Low.Text);
            _ConfigEquip._SWLimit_Y.High = double.Parse(txt_ConfigEquip_SWLimit_Y_High.Text);
            _ConfigEquip._SWLimit_Y.Low = double.Parse(txt_ConfigEquip_SWLimit_Y_Low.Text);
            _ConfigEquip._SWLimit_Z.High = double.Parse(txt_ConfigEquip_SWLimit_Z_High.Text);
            _ConfigEquip._SWLimit_Z.Low = double.Parse(txt_ConfigEquip_SWLimit_Z_Low.Text);

            string msg = string.Format("Set SW Limits; X_Hi = {0:0.####}, X_Lo = {1:0.####}, Y_Hi = {2:0.####}, Y_Lo = {3:0.####}, Z_Hi = {4:0.####}, Z_Lo = {5:0.####}", _ConfigEquip._SWLimit_X.High, _ConfigEquip._SWLimit_X.Low, _ConfigEquip._SWLimit_Y.High, _ConfigEquip._SWLimit_Y.Low, _ConfigEquip._SWLimit_Z.High, _ConfigEquip._SWLimit_Z.Low);
            // Write Event
            writeEvent("UserEvent", msg);
        }

        private void btn_Set_ProcessLimit_Click(object sender, EventArgs e)
        {
            _ConfigEquip._ProcessLimit_X.High = double.Parse(txt_ConfigEquip_ProcessLimit_X_High.Text);
            _ConfigEquip._ProcessLimit_X.Low = double.Parse(txt_ConfigEquip_ProcessLimit_X_Low.Text);
            _ConfigEquip._ProcessLimit_Y.High = double.Parse(txt_ConfigEquip_ProcessLimit_Y_High.Text);
            _ConfigEquip._ProcessLimit_Y.Low = double.Parse(txt_ConfigEquip_ProcessLimit_Y_Low.Text);
            _ConfigEquip._ProcessLimit_Z.High = double.Parse(txt_ConfigEquip_ProcessLimit_Z_High.Text);
            _ConfigEquip._ProcessLimit_Z.Low = double.Parse(txt_ConfigEquip_ProcessLimit_Z_Low.Text);

            string msg = string.Format("Set Process Limits; X_Hi = {0:0.####}, X_Lo = {1:0.####}, Y_Hi = {2:0.####}, Y_Lo = {3:0.####}, Z_Hi = {4:0.####}, Z_Lo = {5:0.####}", _ConfigEquip._ProcessLimit_X.High, _ConfigEquip._ProcessLimit_X.Low, _ConfigEquip._ProcessLimit_Y.High, _ConfigEquip._ProcessLimit_Y.Low, _ConfigEquip._ProcessLimit_Z.High, _ConfigEquip._ProcessLimit_Z.Low);
            // Write Event
            writeEvent("UserEvent", msg);
        }

        private void btn_ConfigEquip_Set_Velocity_Click(object sender, EventArgs e)
        {
            _ConfigEquip._Velocity_Default.X = double.Parse(txt_ConfigEquip_Velocity_X.Text);
            _ConfigEquip._Velocity_Default.Y = double.Parse(txt_ConfigEquip_Velocity_Y.Text);
            _ConfigEquip._Velocity_Default.Z = double.Parse(txt_ConfigEquip_Velocity_Z.Text);

            string msg = string.Format("Set Velocities; X = {0:0.####}, Y = {1:0.####}, Z = {2:0.####}", _ConfigEquip._Velocity_Default.X, _ConfigEquip._Velocity_Default.Y, _ConfigEquip._Velocity_Default.Z);
            // Write Event
            writeEvent("UserEvent", msg);
        }

        private void btn_Move_Position_Processing_Click(object sender, EventArgs e)
        {
            // Write Event
            writeEvent("UserEvent", "Move to " + _pointName1);

            this.moveTo(_pointName1, _ConfigEquip._Position_Processing.X, _ConfigEquip._Position_Processing.Y, _ConfigEquip._Position_Processing.Z, _ConfigEquip._Velocity_Default.Z);
        }

        private void btn_Move_Position_Camera_Click(object sender, EventArgs e)
        {
            // Write Event
            writeEvent("UserEvent", "Move to " + _pointName2);

            this.moveTo(_pointName2, _ConfigEquip._Position_Camera.X, _ConfigEquip._Position_Camera.Y, _ConfigEquip._Position_Camera.Z, _ConfigEquip._Velocity_Default.Z);
        }

        private void btn_Move_Position_ConfocalLaser_Click(object sender, EventArgs e)
        {
            // Write Event
            writeEvent("UserEvent", "Move to " + _pointName3);

            this.moveTo(_pointName3, _ConfigEquip._Position_ConfocalLaser.X, _ConfigEquip._Position_ConfocalLaser.Y, _ConfigEquip._Position_ConfocalLaser.Z, _ConfigEquip._Velocity_Default.Z);
        }

        private void btn_Move_Position_FeedIn_Click(object sender, EventArgs e)
        {
            // Write Event
            writeEvent("UserEvent", "Move to " + _pointName4);

            this.moveTo(_pointName4, _ConfigEquip._Position_FeedIn.X, _ConfigEquip._Position_FeedIn.Y, _ConfigEquip._Position_FeedIn.Z, _ConfigEquip._Velocity_Default.Z);
        }

        private void btn_Move_Position_FeedOut_Click(object sender, EventArgs e)
        {
            // Write Event
            writeEvent("UserEvent", "Move to " + _pointName5);

            this.moveTo(_pointName5, _ConfigEquip._Position_FeedOut.X, _ConfigEquip._Position_FeedOut.Y, _ConfigEquip._Position_FeedOut.Z, _ConfigEquip._Velocity_Default.Z);
        }

        private void btn_Move_Position_Reserved1_Click(object sender, EventArgs e)
        {
            // Write Event
            writeEvent("UserEvent", "Move to " + _pointName6);

            this.moveTo(_pointName6, _ConfigEquip._Position_Reserved1.X, _ConfigEquip._Position_Reserved1.Y, _ConfigEquip._Position_Reserved1.Z, _ConfigEquip._Velocity_Default.Z);
        }

        private void btn_Move_Position_Reserved2_Click(object sender, EventArgs e)
        {
            // Write Event
            writeEvent("UserEvent", "Move to " + _pointName7);

            this.moveTo(_pointName7, _ConfigEquip._Position_Reserved2.X, _ConfigEquip._Position_Reserved2.Y, _ConfigEquip._Position_Reserved2.Z, _ConfigEquip._Velocity_Default.Z);
        }

        private void btn_Move_Position_Reserved3_Click(object sender, EventArgs e)
        {
            // Write Event
            writeEvent("UserEvent", "Move to " + _pointName8);

            this.moveTo(_pointName8, _ConfigEquip._Position_Reserved3.X, _ConfigEquip._Position_Reserved3.Y, _ConfigEquip._Position_Reserved3.Z, _ConfigEquip._Velocity_Default.Z);
        }
        /// <summary>
        /// 機台參數頁面-功率量測區-移至設定座標
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btn_Move_Position_PowerMonitor_Click(object sender, EventArgs e)
        {
            // Write Event
            writeEvent("UserEvent", "Move to " + _pointName9);

            this.moveTo(_pointName9, _ConfigEquip._Position_PowerMonitor.X, _ConfigEquip._Position_PowerMonitor.Y, _ConfigEquip._Position_PowerMonitor.Z, _ConfigEquip._Velocity_Default.Z);
        }

        private void c(object sender, EventArgs e)
        {
            // Write Event
            writeEvent("UserEvent", "Move to " + _pointName9);

            this.moveTo(_pointName9, _ConfigEquip._Position_PowerMonitor.X, _ConfigEquip._Position_PowerMonitor.Y, _ConfigEquip._Position_PowerMonitor.Z, _ConfigEquip._Velocity_Default.Z);
        }

        private void btn_ConfigProcess_DistanceZ_Click(object sender, EventArgs e)
        {
            _ConfigProcess._Compensate_DistanceZ = double.Parse(txt_ConfigProcess_DistanceZ.Text);

            string msg = string.Format("Compensate_DistanceZ = {0:0.####}", _ConfigProcess._Compensate_DistanceZ);
            // Write Event
            writeEvent("UserEvent", msg);
        }

        private void btn_ConfigProcess_Set_Speed_Click(object sender, EventArgs e)
        {
            _ConfigProcess._Speed_Fast = double.Parse(txt_ConfigProcess_Fast_Speed.Text);
            _ConfigProcess._Speed_Feature = double.Parse(txt_ConfigProcess_Feature_speed.Text);
            _ConfigProcess._Speed_GuideHole = double.Parse(txt_ConfigProcess_GH_speed.Text);
            _ConfigProcess._Speed_LamGH = double.Parse(txt_ConfigProcess_LamGH_speed.Text);
            _ConfigProcess._Speed_Others = double.Parse(txt_ConfigProcess_Others_Speed.Text);

            string msg = string.Format("Set Speed; Fast_Speed = {0:0.####}, Feature_Speed = {1:0.####}, GuideHole_Speed = {2:0.####}, LamGH_Speed = {3:0.####}, Others_Speed = {4:0.####}", _ConfigProcess._Speed_Fast, _ConfigProcess._Speed_Feature, _ConfigProcess._Speed_GuideHole, _ConfigProcess._Speed_LamGH, _ConfigProcess._Speed_Others);
            // Write Event
            writeEvent("UserEvent", msg);
        }

        private void btn_ConfigProcess_Set_Power_Click(object sender, EventArgs e)
        {
            
            _ConfigProcess._Power_GuideHole = double.Parse(txt_ConfigProcess_Power_GuideHole.Text);
            _ConfigProcess._Power_LamGH = int.Parse(txt_ConfigProcess_Power_LamGH.Text);
            _ConfigProcess._Power_Others = int.Parse(txt_ConfigProcess_Power_Others.Text);
            _ConfigProcess._Power_DeviationThreshold = int.Parse(txt_ConfigProcess_Power_DeviationThreshold.Text);

            string msg = string.Format("Set Power; Power_Feature = {0:0.####}, Power_GuideHole = {1:0.####},Power_LamGH = {2:0.####} , Power_Others = {3:0.####}, Power_DeviationThreshold = {4:0.####}", _ConfigProcess._Power_Feature, _ConfigProcess._Power_GuideHole, _ConfigProcess._Power_LamGH, _ConfigProcess._Power_Others, _ConfigProcess._Power_DeviationThreshold);
            // Write Event
            writeEvent("UserEvent", msg);
        }

        private void btn_ConfigProcess_Sample_Set_Click(object sender, EventArgs e)
        {
            _ConfigProcess._Power_Feature = double.Parse(txt_ConfigProcess_Power_Feature.Text);
            _ConfigProcess._Sample_JobName = txt_ConfigProcess_Sample_JobName.Text;
            _ConfigProcess._Sample_CutLoop = int.Parse(txt_ConfigProcess_Sample_CutLoop.Text);
            _ConfigProcess._Sample_CutWidth = double.Parse(txt_ConfigProcess_Sample_CutWidth.Text);
            _ConfigProcess._Sample_CutLength = double.Parse(txt_ConfigProcess_Sample_CutLength.Text);
            _ConfigProcess._Sample_OffsetX = double.Parse(txt_ConfigProcess_Sample_OffsetX.Text);
            _ConfigProcess._Sample_OffsetY = double.Parse(txt_ConfigProcess_Sample_OffsetY.Text);

            string msg = string.Format("Set Sample; Sample_JobName = {0}, Sample_CutLoop = {1:0}, Sample_CutWidth = {2:0.###}, Sample_CutLength = {3:0.###}, Sample_OffsetX = {4:0.###}, Sample_OffsetY = {5:0.###}, Power_Feature = {6:0.###}", _ConfigProcess._Sample_JobName, _ConfigProcess._Sample_CutLoop, _ConfigProcess._Sample_CutWidth, _ConfigProcess._Sample_CutLength, _ConfigProcess._Sample_OffsetX, _ConfigProcess._Sample_OffsetY, _ConfigProcess._Power_Feature);
            // Write Event
            writeEvent("UserEvent", msg);
        }

        private void btn_ConfigProcess_Set_Warmup_Click(object sender, EventArgs e)
        {
            _ConfigProcess._IsAutoProcessWarmup = chk_ConfigProcess_IsAutoProcessWarmup.Checked;
            _ConfigProcess._Warmup_TimeToWait = int.Parse(txt_ConfigProcess_Warnup_TimeToWait.Text);

            string msg = string.Format("Set Warnup; IsAutoProcessWarnup = {0}, Warnup_TimeToWait = {1}", _ConfigProcess._IsAutoProcessWarmup, _ConfigProcess._Warmup_TimeToWait);
            // Write Event
            writeEvent("UserEvent", msg);
        }
        private void btn_ConfigProcess_Set_LaserSleep_Click(object sender, EventArgs e)
        {
            _ConfigProcess._IsAutoLaserSleep = chk_ConfigProcess_IsAutoLaserSleep.Checked;
            _ConfigProcess._LaserSleep_Count = int.Parse(txt_ConfigProcess_LaserSleep_Count.Text);
            _ConfigProcess._LaserSleep_Time = int.Parse(txt_ConfigProcess_LaserSleep_Time.Text); 

            string msg = string.Format("Set LaserSleep; IsAutoLaserSleep = {0}, LaserSleep_Count = {1}, LaserSleep_Time = {2}", _ConfigProcess._IsAutoLaserSleep, _ConfigProcess._LaserSleep_Count, _ConfigProcess._LaserSleep_Time);
            // Write Event
            writeEvent("UserEvent", msg);
        }
        private void btn_ConfigProcess_Set_Suspend_Click(object sender, EventArgs e)
        {
            _ConfigProcess._IsAutoProcessSuspend = chk_ConfigProcess_IsAutoProcessSuspend.Checked;
            _ConfigProcess._Suspend_IntervalTime = int.Parse(txt_ConfigProcess_Suspend_IntervalTime.Text);
            _ConfigProcess._Suspend_TimeToWait = int.Parse(txt_ConfigProcess_Suspend_TimeToWait.Text);

            string msg = string.Format("Set Susped; IsAutoProcessSuspend = {0}, Suspend_IntervalTime = {1}, Suspend_TimeToWait = {2}", _ConfigProcess._IsAutoProcessSuspend, _ConfigProcess._Suspend_IntervalTime, _ConfigProcess._Suspend_TimeToWait);
            // Write Event
            writeEvent("UserEvent", msg);
        }

        private void btn_ConfigProcess_Set_Hold_Click(object sender, EventArgs e)
        {
            _ConfigProcess._IsAutoProcessHold = chk_ConfigProcess_IsAutoProcessHold.Checked;
            _ConfigProcess._Hold_IntervalTime = int.Parse(txt_ConfigProcess_Hold_IntervalTime.Text);
            _ConfigProcess._Hold_TimeToWait = int.Parse(txt_ConfigProcess_Hold_TimeToWait.Text);

            string msg = string.Format("Set Hold; IsAutoProcessHold = {0}, Hold_IntervalTime = {1}, Hold_TimeToWait = {2}", _ConfigProcess._IsAutoProcessHold, _ConfigProcess._Hold_IntervalTime, _ConfigProcess._Hold_TimeToWait);
            // Write Event
            writeEvent("UserEvent", msg);
        }

        private void btn_Set_PowerCalibration_Click(object sender, EventArgs e)
        {
            _ConfigEquip._PowerCalibration.Gain = double.Parse(txt_ConfigEquip_Power_Gain.Text);
            _ConfigEquip._PowerCalibration.Offset = double.Parse(txt_ConfigEquip_Power_Offset.Text);
            _ConfigEquip._PowerCalibration.Cutoff = double.Parse(txt_ConfigEquip_Power_Cutoff.Text);

            string msg = string.Format("Set PowerCalibration; Gain = {0:0.###}, Offset = {1:0.###}, Cutoff = {2:0.###}", _ConfigEquip._PowerCalibration.Gain, _ConfigEquip._PowerCalibration.Offset, _ConfigEquip._PowerCalibration.Cutoff);
            // Write Event
            writeEvent("UserEvent", msg);
        }

        private void btn_Set_RotationCalibration_Click(object sender, EventArgs e)
        {
            _ConfigEquip._RotationCalibration.Gain = double.Parse(txt_ConfigEquip_Rotation_Gain.Text);
            _ConfigEquip._RotationCalibration.Offset = double.Parse(txt_ConfigEquip_Rotation_Offset.Text);

            string msg = string.Format("Set RotationCalibration; Gain = {0:0.###}, Offset = {1:0.###}", _ConfigEquip._RotationCalibration.Gain, _ConfigEquip._RotationCalibration.Offset);
            // Write Event
            writeEvent("UserEvent", msg);
        }

        private void btn_ConfigProcess_Set_LP_Click(object sender, EventArgs e)
        {
            _ConfigProcess._LaserParam_Convert.Gain = double.Parse(txt_ConfigProcess_LP_Gain.Text);
            _ConfigProcess._LaserParam_Convert.Offset = double.Parse(txt_ConfigProcess_LP_Offset.Text);

            string msg = string.Format("Set LaserParam; Gain = {0:0.###}, Offset = {1:0.###}", _ConfigProcess._LaserParam_Convert.Gain, _ConfigProcess._LaserParam_Convert.Offset);
            // Write Event
            writeEvent("UserEvent", msg);
        }

        private void btn_ConfigProcess_Set_MP_Click(object sender, EventArgs e)
        {
            _ConfigProcess._MotionParam_Convert.Gain = double.Parse(txt_ConfigProcess_MP_Gain.Text);
            _ConfigProcess._MotionParam_Convert.Offset = double.Parse(txt_ConfigProcess_MP_Offset.Text);

            string msg = string.Format("Set MotionParam; Gain = {0:0.###}, Offset = {1:0.###}", _ConfigProcess._MotionParam_Convert.Gain, _ConfigProcess._MotionParam_Convert.Offset);
            // Write Event
            writeEvent("UserEvent", msg);
        }

        private void btn_ConfigProcess_Set_CheckJobxName_Click(object sender, EventArgs e)
        {
            _ConfigProcess._IsAutoProcessCheckJobx = chk_ConfigProcess_IsAutoProcessCheckJobx.Checked;

            string msg = string.Format("Set CheckJobx; IsAutoProcessCheckJobx = {0}", _ConfigProcess._IsAutoProcessCheckJobx);
            // Write Event
            writeEvent("UserEvent", msg);
        }
        private void btn_ConfigProcess_ThickComparison_Click(object sender, EventArgs e)
        {
            _ConfigProcess._IsThickComparison = chk_ConfigProcess_IsThickComparison.Checked;
            _ConfigProcess._ThickComparison = double.Parse(txt_ConfigProcess_ThickComparison.Text);
            _ConfigProcess._Check_ThickLaserX = double.Parse(txt_ConfigProcess_Check_ThickLaserX.Text);
            _ConfigProcess._Check_ThickLaserY = double.Parse(txt_ConfigProcess_Check_ThickLaserY.Text);
            _ConfigProcess._Check_ThickLaserZ = double.Parse(txt_ConfigProcess_Check_ThickLaserZ.Text);


            string msg = string.Format("Set ThickComparison; IsThickComparison = {0},ThickComparison = {1},Check_ThickLaserX = {2},Check_ThickLaserY = {3},Check_ThickLaserZ = {4}", _ConfigProcess._IsThickComparison, _ConfigProcess._ThickComparison, _ConfigProcess._Check_ThickLaserX, _ConfigProcess._Check_ThickLaserY, _ConfigProcess._Check_ThickLaserZ);
            // Write Event
            writeEvent("UserEvent", msg);
        }
        private void btn_ConfigProcess_Check_ThickLaser_Click(object sender, EventArgs e)
        {
            // Write Event
            writeEvent("UserEvent", "Move to Check ThickLaser");

            this.moveTo("Check ThickLaser", _ConfigProcess._Check_ThickLaserX, _ConfigProcess._Check_ThickLaserY, _ConfigProcess._Check_ThickLaserZ, _ConfigEquip._Velocity_Default.Z);

        }
        #endregion
    }
}
