﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;


using Module_Interface;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading;
using System.Windows.Forms;
using System.Management;
using NCScriptParser_Interface;
using System.IO;
using System.Text.RegularExpressions;
using CameraCVX_Interface;

namespace LaserProcess_LCH
{
    public partial class MainForm
    {
        #region 宣告
        /// <summary>
        /// LCH定位孔置中執行續變數
        /// </summary>
        Thread _Alignment_Auto_FindHole;
        /// <summary>
        /// 安全退出LCH定位孔置中執行續bool
        /// </summary>
        bool _is_Alignment_Auto_FindHole = false;
        /// <summary>
        /// LCH定位孔置中流程旗標
        /// </summary>
        int _Alignment_AT_FindHole_flag = 0;
        /// <summary>
        /// 儲存流程正常完成的字串資訊，用於與prog_status資訊進行比對，若是正常流程結束才可執行內容
        /// </summary>
        string process_completion_text;
        /// <summary>
        /// LCH定位控制中-迴圈
        /// </summary>



        //================================================================================================================

        /// <summary>
        /// LCH儲存第1個對位點中心位置的X座標
        /// </summary>
        double AlignmentProcess_Point1_X;
        /// <summary>
        /// LCH儲存第1個對位點中心位置的Y座標
        /// </summary>
        double AlignmentProcess_Point1_Y;
        /// <summary>
        /// LCH儲存第2個對位點中心位置的X座標
        /// </summary>
        double AlignmentProcess_Point2_X;
        /// <summary>
        /// LCH儲存第2個對位點中心位置的Y座標
        /// </summary>
        double AlignmentProcess_Point2_Y;
        /// <summary>
        /// LCH儲存2點之夾角(G84要應用的旋轉角度)
        /// </summary>
        double AlignmentProcess_Angle;

        /// <summary>
        /// 是否為LCH對位加工
        /// </summary>
        bool AlignmentProcess_flag=false;
        #endregion
        #region UI
        /// <summary>
        /// 載入加工檔案
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void bt_AlignmentProcess_SelectFile_Click(object sender, EventArgs e)
        {



           

            //Write Event
            writeEvent("UserEvent", "Select Process File.");

            chk_Distance.Checked = false;
            OpenFileDialog_NC.InitialDirectory = _NCParser._InitialDirectory;
            OpenFileDialog_NC.DefaultExt = "mlproj";
            OpenFileDialog_NC.Filter = "project files (*.mlproj)|*.mlproj";
            if (OpenFileDialog_NC.ShowDialog() == DialogResult.OK)
            {
                try
                {

                    string fileName = OpenFileDialog_NC.FileName;
                    int index1 = fileName.LastIndexOf('\\');
                    int index2 = fileName.LastIndexOf('.');

                    char[] projectDir = new char[index1];
                    // Get project directory
                    fileName.CopyTo(0, projectDir, 0, projectDir.Length);
                    _NCParser._ProjectDirectory = new string(projectDir);
                    _NCParser._InitialDirectory = new string(projectDir);
                    //[BM:刀具檔讀取通解]//=================================================
                    if (_isSysSimulated)
                    {
                        _ConfigSystem._JobxFolderPath = "C:\\Users\\250319\\Desktop\\job\\LCH_job";//10f電腦自看測試用
                    }
                    #region 20260206修改的LD後面只會接一個數字，UD後面只會接 數字-數字
                    //=====
                    string fileName_UDorLD = fileName.Substring(0, index1);

                    // LD 後面只抓一位數字
                    string patternLD = @"LD(\d)";

                    // UD 後面抓一位數字，-後面也只抓一位數字
                    string patternUD = @"UD(\d)(?:-(\d))?";

                    Match matchLD = Regex.Match(fileName_UDorLD, patternLD);
                    Match matchUD = Regex.Match(fileName_UDorLD, patternUD);

                    List<string> extractedKeywords = new List<string>();

                    if (matchLD.Success)
                    {
                        // 只取 LD 後面的那個一位數字
                        extractedKeywords.Add("LD" + matchLD.Groups[1].Value);
                        UD_or_LD = $"LD{matchLD.Groups[1].Value}";
                    }
                    if (matchUD.Success)
                    {
                        // 取 UD 後面的數字
                        string udValue = "UD" + matchUD.Groups[1].Value;
                        // 如果有 -數字，就加上，但只取一位
                        if (matchUD.Groups[2].Success)
                        {
                            udValue += "-" + matchUD.Groups[2].Value;
                        }
                        extractedKeywords.Add(udValue);

                        UD_or_LD = $"{udValue}";
                    }
                    //=====
                    #endregion

                    if (extractedKeywords.Count == 0)
                    {
                        MessageBox.Show("確認Case資料夾名稱內具有單一層之名稱");
                        writeError("NC檔轉檔失敗", "轉檔名稱:" + _NCParser._NCName);
                        return;
                    }
                    else if (extractedKeywords.Count > 1)
                    {
                        MessageBox.Show("確認Case資料夾名稱內只有單一層之名稱");
                        writeError("NC檔轉檔失敗", "轉檔名稱:" + _NCParser._NCName);
                        return;
                    }

                    else
                    {
                        if (_isSysSimulated)
                        {
                            _ConfigSystem._JobxFolderPath = Path.Combine(_ConfigSystem._JobxFolderPath, extractedKeywords[0]);
                            _ConfigSystem.WriteIntoIniFile();
                        }
                        else
                        {
                            _ConfigSystem._JobxFolderPath = Path.Combine(_ConfigSystem._JobxFolderPath1, extractedKeywords[0]);
                            _ConfigSystem.WriteIntoIniFile();
                        }
                        #region 檢查暖機檔是否存在
                        string source = Path.Combine(C_Path, "Warmup_File"); // 來源資料夾(比對刀具資料夾中是否有Warmup_File資料夾中的刀具)
                        string destination = _ConfigSystem._JobxFolderPath;                        // 目標資料夾
                        bool missingFiles = false;                                                 // 用於追蹤是否有缺少的檔案
                        List<string> missingFileList = new List<string>();                         // 儲存缺少的檔案清單
                        int w = 300, h = 100;                                                      //提醒視窗尺寸長寬
                        if (!Directory.Exists(destination))
                        {
                            System.Windows.Forms.Form customMessageBox = new System.Windows.Forms.Form();
                            customMessageBox.Text = "資料夾缺失!!";
                            customMessageBox.Size = new Size(w, h);
                            customMessageBox.FormBorderStyle = FormBorderStyle.FixedDialog;  // 固定視窗大小
                            customMessageBox.TopMost = true;                                 // 確保視窗顯示在最前方
                            customMessageBox.Icon = SystemIcons.Warning;                     // 使用內建警告圖示
                            customMessageBox.StartPosition = FormStartPosition.CenterScreen; // 讓視窗顯示在螢幕中央
                            customMessageBox.MinimumSize = new Size(w, w);                   // 強制視窗不會小於這個大小
                            RichTextBox richTextBox = new RichTextBox();
                            richTextBox.Dock = DockStyle.Fill;
                            richTextBox.ReadOnly = true;
                            richTextBox.BackColor = Color.White;
                            richTextBox.Font = new Font("微軟正黑體", 12);
                            richTextBox.ForeColor = Color.FromArgb(85, 85, 85);
                            richTextBox.Text = $"LCH_job 資料夾內不存在名為：\n{extractedKeywords[0]}\n之資料夾請手動建立。";

                            richTextBox.SelectAll();
                            richTextBox.SelectionAlignment = HorizontalAlignment.Center;     // 文字置中 (適用於 `RichTextBox` 需要使用 RTF 設定)

                            int keywordPosition = richTextBox.Text.IndexOf(extractedKeywords[0]);
                            if (keywordPosition >= 0)
                            {
                                richTextBox.Select(keywordPosition, extractedKeywords[0].Length);
                                richTextBox.SelectionColor = Color.Red;                      // 確保 extractedKeywords[0] 顯示為紅色
                                richTextBox.SelectionLength = 0;
                            }
                            customMessageBox.Controls.Add(richTextBox);
                            customMessageBox.ShowDialog();
                            return;
                        }

                        // 檢查來源資料夾內的所有檔案是否存在於目標資料夾
                        foreach (string file1 in Directory.GetFiles(source))
                        {
                            string destFile = Path.Combine(destination, Path.GetFileName(file1)); // 取得目標完整路徑

                            if (!File.Exists(destFile)) // 如果目標資料夾內沒有該檔案
                            {
                                missingFiles = true;
                                missingFileList.Add(Path.GetFileName(file1)); // 只存檔案名稱
                            }
                        }

                        if (missingFiles)
                        {
                            string missingFilesText = string.Join("\r", missingFileList); // 將缺少的檔案合併成一個字串
                            System.Windows.Forms.Form customMessageBox = new System.Windows.Forms.Form();
                            customMessageBox.Text = "檔案缺失提醒!!";
                            customMessageBox.Size = new Size(w + 600, h + 600);
                            customMessageBox.FormBorderStyle = FormBorderStyle.FixedDialog; // 固定視窗大小
                            customMessageBox.TopMost = true; // 確保視窗顯示在最前方
                            customMessageBox.Icon = SystemIcons.Warning; // 使用內建警告圖示
                            customMessageBox.StartPosition = FormStartPosition.CenterScreen;  //讓視窗顯示在螢幕中央
                            customMessageBox.MinimumSize = new Size(w, w); // 強制視窗不會小於這個大小
                            RichTextBox richTextBox = new RichTextBox();
                            richTextBox.Dock = DockStyle.Fill;
                            richTextBox.ReadOnly = true;
                            richTextBox.BackColor = Color.White;
                            richTextBox.Font = new Font("微軟正黑體", 12);
                            richTextBox.ForeColor = Color.FromArgb(85, 85, 85);
                            richTextBox.Text = $"{extractedKeywords[0]} 資料夾內缺少以下暖機檔案：\n{missingFilesText}\n請手動建立。"; // 文字置中 (適用於 `RichTextBox` 需要使用 RTF 設定)
                            richTextBox.SelectAll();
                            richTextBox.SelectionAlignment = HorizontalAlignment.Center;
                            richTextBox.DeselectAll(); // 取消所有選取狀態
                            customMessageBox.Controls.Add(richTextBox);
                            customMessageBox.ShowDialog();
                            return;
                        }
                        #endregion
                    }
                    //=================================================
                    char[] file = new char[fileName.Length - index1 - 1 - OpenFileDialog_NC.DefaultExt.Length - 1];
                    // Get NC file name
                    fileName.CopyTo(index1 + 1, file, 0, file.Length);
                    _NCParser._NCName = new string(file);

                    // Display NC file name
                    txt_AlignmentProcess_FileName.Text = _NCParser._NCName;

                    // Reset step status
                    _stepFlags[(int)Step.s1] = false;
                    updatePnlStepState(pnl_AutoMode_LoadFile_Status, StepState.inactive);
                    updatePnlStepState(pnl_AutoMode_MoveZ_Status, StepState.inactive);
                    updatePnlStepState(pnl_AutoMode_OrgPoint_Status, StepState.inactive);
                    //[BM:不放開吸附功能，狀態顯示不會放開(所有程式只有UI介面的取消吸附才可以解除吸附)]
                    // updatePnlStepState(pnl_AutoMode_Chuck_Status, StepState.inactive);

                    //解析NC檔為 研發手動NC檔模式 chk_RD_NCfile.Checked
                    _NCParser.RD_NCfile = chk_RD_NCfile.Checked;



                    // Load file and parse parameters
                    _NCParser.ParseData();

                    bool Checked = CheckScanheadFiles(_ConfigSystem._JobxFolderPath, _NCParser._ToolCheckList);//檢查刀具是否齊全

                    if (!Checked)
                    {
                        //[BM:防呆檢查刀具-解除急停後清除載檔顯示框]
                        txt_AutoMode_FileName.Clear(); //清除載入檔案顯示的txtbox
                        return;
                    }

                    UpdateDIPnlBackColor(pnl_AlignmentProcess_SelectFile_Status, true);

                    if (_isSysSimulated)//Path.Combine(Environment.CurrentDirectory, "xuan","Comparing Automation and Cagila"); 
                    {
                        NCScriptParser data = _NCParser;
                        string NCParser_Cagila_CsvPath = Path.Combine(Environment.CurrentDirectory, "xuan", "Comparing Automation and Cagila", "NCParser" + ".csv");   // 組合對應的解析結果CSV儲存路徑
                        using (StreamWriter stream = new StreamWriter(NCParser_Cagila_CsvPath, false))                         // 建立輸出串流並覆寫模式開啟檔案
                        {
                            stream.WriteLine("PropertyName,Value"); // ⇦ 表頭列：屬性名稱與對應值

                            var props = data.GetType().GetProperties(); // ⇦ 取得 data 物件的所有屬性（public）

                            foreach (var prop in props)
                            {
                                object value = prop.GetValue(data); // ⇦ 取出屬性值

                                if (value == null)
                                {
                                    stream.WriteLine($"{prop.Name},null"); // ⇦ 若為 null 則記錄屬性名稱與 null 字串
                                }
                            }

                            var fields = data.GetType().GetFields(System.Reflection.BindingFlags.Instance | System.Reflection.BindingFlags.NonPublic | System.Reflection.BindingFlags.Public); // ⇦ 若你還要抓取欄位（不是屬性）

                            stream.WriteLine("FieldName,Value"); // ⇦ 如果你只抓欄位（Fields）

                            foreach (var field in fields)
                            {
                                object value = field.GetValue(data); // ⇦ 取出欄位值

                                if (value == null)
                                {
                                    stream.WriteLine($"{field.Name},null"); // ⇦ 若欄位為 null 則記錄
                                }
                            }
                        }
                        return;
                    }


                    // Write InitialDirectory back to the .ini file
                    _NCParser.WriteIntoIniFile();

                    // Do Data Parsing
                    _formNCParser = new FormNCParser(_NCParser);


                    //MES LOG批號記錄
                    _CHPT_MES.Batch_Number = txt_AutoMode_LotMumber.Text;
                    _CHPT_MES.Serial_Number = txt_AutoMode_LotMumber.Text;
                    _CHPT_MES.Product_Name = _NCParser._NCName;
                    _CHPT_MES.Laser_Process_File = fileName;
                    _CHPT_MES.Laser_Pos_File = fileName;


                    //Write Event
                    writeEvent("UserEvent", "加工轉檔路徑： " + OpenFileDialog_NC.FileName);

                    // Write Process
                    writeProcess("Step1", "檔案已選擇載入");
                }
                catch (Exception ex)
                {
                    // MessageBox.Show("確認轉檔為研發手動檔或是加工自動檔", "Error！！");
                    MessageBox.Show($"確認轉檔為研發手動檔或是加工自動檔，NC檔轉檔失敗：{ex.Message}", "Error！！");
                    writeError("NC檔轉檔失敗", "轉檔名稱： " + _NCParser._NCName);
                    return;
                }
            }
            else
            {
            }
        }

        /// <summary>
        /// 吸附
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btn_AlignmentProcess_Chuck_ON_Click(object sender, EventArgs e)
        {
            UpdateDIPnlBackColor(pnl_AlignmentProcess_Chuck_Status, true);

            if (_isSysSimulated)
                return;

            _CameraCVX.CamShutterSetting(1, CameraCVX.ShutterSpeed.S15);//設定快門速度，才能做影像對位

            WriteLog("Log", "_Log.ini", $"吸附樣品");

        

            // Enable Chuck vacuum
            enableChuckVacuum(true);




            //LCH2切
            bt_vacuum2.Enabled = false;
            解除2.Enabled = true;
        }
        /// <summary>
        /// 解除
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btn_AlignmentProcess_Chuck_OFF_Click(object sender, EventArgs e)
        {
            UpdateDIPnlBackColor(pnl_AlignmentProcess_Chuck_Status, false);

            if (_isSysSimulated)
                return;
            // Enable Chuck vacuum
            enableChuckVacuum(false);


          //  _stepFlags[(int)Step.s2] = false;

            // Write Process
            writeProcess("Step2", "樣品已解除吸附");

            //[BM:自訂Log紀錄內容-操作設定]
            if (_AutoProcessLog_flag)
                writeEventLog_Automatic_processing($"操作設定", $"人員解除吸附");

        }
        /// <summary>
        /// Z軸移動到預設高度
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btn_AlignmentProcess_MoveZ_Move_Click(object sender, EventArgs e)
        {



            if (_isSysSimulated)
                return;

            btn_Move_Position_Camera_Click("AutoProcess", null);
        }
        /// <summary>
        /// 焦點校正
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btn_AlignmentProcess_MoveZ_Start_Click(object sender, EventArgs e)
        {
            UpdateDIPnlBackColor(pnl_AlignmentProcess_MoveZ_Status, true);

            if (_isSysSimulated)
                return;

            enableUIGroup(false);

         
            // Call BackgroundWorker to do asynchronous operation
            if (!BW_AutoFocus.IsBusy)
            {
                // Start the asynchronous operation.
                BW_AutoFocus.RunWorkerAsync(AutoFocusType.AutoProcess);
            }

            // Update panel

        }

        /// <summary>
        /// 設定此位置為原點
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btn_AlignmentProcess_OrgPoint_Set_Click(object sender, EventArgs e)
        {

        }
        /// <summary>
        /// 返回原點
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btn_AlignmentProcess_OrgPoint_MoveTo_Click(object sender, EventArgs e)
        {

        }

        /// <summary>
        /// LCH定位孔置中按鈕
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btn_AlignmentProcess_Alignment_Hole_Click(object sender, EventArgs e)
        {
            /*先自動對焦 後 再做定位孔置中*/
            if (waitMotionDone(axisIndexXYZ, 10000))
            {
                if (!BW_AutoFocus.IsBusy)  // Call BackgroundWorker to do asynchronous operation
                {
                    _is_Alignment_Auto_FindHole = true;//啟用定位孔置中流程
                    BW_AutoFocus.RunWorkerAsync(AutoFocusType.AutoProcess); // Start the asynchronous operation.
                }
            }
        }

        /// <summary>
        /// LCH儲存第1個對位XY座標
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btn_AlignmentProcess_Point1_Set_Click(object sender, EventArgs e)
        {
            AlignmentProcess_Point1_X = Convert.ToDouble(txt_Motion_Position_X.Text);
            AlignmentProcess_Point1_Y = Convert.ToDouble(txt_Motion_Position_Y.Text);
            lbl_AlignmentProcess_Point1.Text = $"定位點1:{Environment.NewLine}({AlignmentProcess_Point1_X},{AlignmentProcess_Point1_Y})";
            UpdateDIPnlBackColor(pnl_AlignmentProcess_Point1_Status, true);
        }
        /// <summary>
        /// LCH儲存第2個對位XY座標
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btn_AlignmentProcess_Point2_Set_Click(object sender, EventArgs e)
        {
            AlignmentProcess_Point2_X = Convert.ToDouble(txt_Motion_Position_X.Text);
            AlignmentProcess_Point2_Y = Convert.ToDouble(txt_Motion_Position_Y.Text);
            lbl_AlignmentProcess_Point2.Text = $"定位點2:{Environment.NewLine}({AlignmentProcess_Point2_X},{AlignmentProcess_Point2_Y})";
            UpdateDIPnlBackColor(pnl_AlignmentProcess_Point2_Status, true);
        }
        /// <summary>
        /// LCH依據2點對位點計算旋轉角度
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btn_AlignmentProcess_Angle_Calculation_Click(object sender, EventArgs e)
        {
            // 兩個點座標
            double x1 = AlignmentProcess_Point1_X;
            double y1 = AlignmentProcess_Point1_Y;
            double x2 = AlignmentProcess_Point2_X;
            double y2 = AlignmentProcess_Point2_Y;

            // 計算差值
            double dx = x2 - x1;
            double dy = y2 - y1;

            // 判斷差距大小
            double angleDegrees;
            if (Math.Abs(dx) >= Math.Abs(dy))
            {
                // X差距比較大 → 以0度為基準 (x軸) 逆時針旋轉
                angleDegrees = Math.Atan2(dy, dx) * (180.0 / Math.PI);
            }
            else
            {
                // Y差距比較大 → 以90度為基準 (y軸) 逆時針旋轉
                angleDegrees = Math.Atan2(dx, dy) * (180.0 / Math.PI);
            }

            // 確保角度在 0~360 範圍
            if (angleDegrees < 0)
                angleDegrees += 360;

            // 四捨五入到小數點三位
            AlignmentProcess_Angle = Math.Round(angleDegrees, 3);

            lbl_AlignmentProcess_Angle.Text = $"旋轉角度:{AlignmentProcess_Angle}°";

            UpdateDIPnlBackColor(pnl_AlignmentProcess_Angle_Status, true);





            if (!_isSysSimulated)
            {
                string code = $"G84 X Y F{AlignmentProcess_Angle}";
                executeGCode(code);
                Thread.Sleep(100);

            }


            if (_AutoProcessLog_flag)
                writeEventLog_Automatic_processing("LCH對位加工旋轉角度", $"當前角度設為:{AlignmentProcess_Angle}°");
       
        }
        /// <summary>
        /// 鎖門
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btn_AlignmentProcess_LockDoor_ON_Click(object sender, EventArgs e)
        {
            UpdateDIPnlBackColor(pnl_AlignmentProcess_LockDoor_Status, true);

            if (_isSysSimulated)
                return;

            //Write Event
            writeEvent("UserEvent", "Enable Door Lock.");

            this.controlDO(_controlDoorLock, true);


            // Write Process
            writeProcess("Step5", "電子門鎖已上鎖");

        }
        /// <summary>
        /// 開門
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btn_AlignmentProcess_LockDoor_OFF_Click(object sender, EventArgs e)
        {
            UpdateDIPnlBackColor(pnl_AlignmentProcess_LockDoor_Status, false);

            if (_isSysSimulated)
                return;

            //Write Event
            writeEvent("UserEvent", "Disable Door Lock.");

            this.controlDO(_controlDoorLock, false);
          

            // Write Process
            writeProcess("Step5", "電子門鎖已解除");
        }
        /// <summary>
        /// 移動至儲存點1
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btn_AlignmentProcess_Move2Point1_Click(object sender, EventArgs e)
        {
            if (_isSysSimulated)
                return;

            if (waitMotionDone(axisIndexXYZ, 1000))
            {
                this.linearMove(AlignmentProcess_Point1_X, AlignmentProcess_Point1_Y);
            }
        }
        /// <summary>
        /// 移動至儲存點2
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btn_AlignmentProcess_Move2Point2_Click(object sender, EventArgs e)
        {
            if (_isSysSimulated)
                return;

            if (waitMotionDone(axisIndexXYZ, 1000))
            {
                this.linearMove(AlignmentProcess_Point2_X, AlignmentProcess_Point2_Y);
            }
        }
        /// <summary>
        /// 設置原點
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btn_AlignmentProcess_OrgPoint_Offset_Click(object sender, EventArgs e)
        {
            UpdateDIPnlBackColor(pnl_AlignmentProcess_OrgPoint_Status, true);
            AlignmentProcess_flag = true;


            if (_isSysSimulated)
                return;

            // 轉換成 double
            double offsetX = Convert.ToDouble(txt_AlignmentProcess_OrgPoint_Offset_X.Text);
            double offsetY = Convert.ToDouble(txt_AlignmentProcess_OrgPoint_Offset_Y.Text);

            if (!_isSysSimulated)
            {

                string code = $"G92 X{offsetX.ToString("F3")} Y{offsetY.ToString("F3")}";
                executeGCode(code);
                Thread.Sleep(100);
            }


            if (_AutoProcessLog_flag)
                writeEventLog_Automatic_processing("LCH對位加工原點設置", $"當前位置設為:X{offsetX.ToString("F3")},Y{offsetY.ToString("F3")}");

        }
        #endregion

        #region  Thread
        private void _Alignment_AT_FindHole()
        {
            try
            {
                while (_is_Alignment_Auto_FindHole)
                {
                    Alignment_AT_FindHole();
                }
            }
            finally // ← 無論正常結束、還是被外部要求停止，都一定會執行這裡
            {
                _is_Alignment_Auto_FindHole = false;
                _Alignment_AT_FindHole_flag = 0;

                if (!string.Equals(prog_status?.Trim(), process_completion_text, StringComparison.Ordinal))//判斷是否正常完成=case10的內容
                {
                    writeEvent("LCH對位孔置中", $"{prog_status}");
                }
                else
                {
                    writeEvent("LCH對位孔置中", $"定位孔至中異常結束,請確認問題");
                }
            }
        }

        /// <summary>
        /// LCH定位孔置中-動作流程
        /// </summary>
        private void Alignment_AT_FindHole()
        {
            switch (_Alignment_AT_FindHole_flag)
            {
                case 0:
                    _Alignment_AT_FindHole_flag = 0;
                    _is_Alignment_Auto_FindHole = false;
                    break;

                case 1:
                    if (axCVX1.Created)
                    {
                        try
                        {
                            prog_status = "LCH對位孔置中開始";
                            writeEvent("LCH對位孔置中", $"{prog_status}");
                            string response = _CameraCVX.ExternalRead(150);   // 發送並接收回傳值
                            _lastEXRResponse = response;        // ← 記錄下來給 case 2 使用
                            Thread.Sleep(100);
                            _Alignment_AT_FindHole_flag = 2;
                        }
                        catch (Exception ex)
                        {
                            MessageBox.Show($"讀取當前KEYENCE檢測方式錯誤: {ex.Message}", "CV-X 錯誤", MessageBoxButtons.OK, MessageBoxIcon.Error);
                            writeError("LCH對位孔置中錯誤", $"讀取當前KEYENCE檢測方式錯誤{ex.Message}，CV-X 錯誤");
                            _Alignment_AT_FindHole_flag = 0;   // 錯誤時的旗標
                        }
                    }
                    else
                    {
                        MessageBox.Show("視覺系統未連線");
                        writeError("LCH對位孔置中錯誤", $"視覺系統未連線");
                        _Alignment_AT_FindHole_flag = 0;
                    }
                    break;

                case 2:
                    try
                    {
                        if (_lastEXRResponse == "EXR,2" || _lastEXRResponse.Contains("EXR,2"))//檢察當前檢測條件是不是定為LCH孔置中
                        {
                            _Alignment_AT_FindHole_flag = 3;
                        }
                        else
                        {
                            _CameraCVX.ExternalWrite(2, 150);    // 若不是則進行切換切 Scene 
                            _Alignment_AT_FindHole_flag = 1;
                        }
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show($"KEYENCE檢測方式切換失敗: {ex.Message}", "CV-X 錯誤", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        writeError("LCH對位孔置中錯誤", $"KEYENCE檢測方式切換失敗{ex.Message}，CV-X 錯誤");
                        _Alignment_AT_FindHole_flag = 0;
                    }
                    break;

                case 3:
                    try
                    {
                        string response = _CameraCVX.Trigger1(500);   // 2000若timeout太短會收不到第二行資訊
                        _lastTriggerResponse = response;  // 記錄最後一次的回應，給 case 4 使用
                        _Alignment_AT_FindHole_flag = 4;
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show($"讀取當前KEYENCE檢測內容錯誤: {ex.Message}", "CV-X 錯誤", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        writeError("LCH對位孔置中錯誤", $"讀取當前KEYENCE檢測內容錯誤 {ex.Message}，CV-X 錯誤");
                        _Alignment_AT_FindHole_flag = 0;
                    }
                    break;

                case 4:
                    string[] s_im = _lastTriggerResponse.Split(',', '\r');// 一定是單引
                    sub_im[0] = s_im[0];
                    sub_im[1] = s_im[1];
                    sub_im[2] = s_im[2];
                    sub_im[3] = s_im[3];
                    if ((Convert.ToDouble(sub_im[3]) >= 50) && sub_im[0] == "T1")
                    {
                        hole_comp_X = sub_im[1];
                        hole_comp_Y = sub_im[2];
                        _Alignment_AT_FindHole_flag = 5;
                    }
                    else
                    {
                        MessageBox.Show("辨識失敗相似度不符", "CV-X 警告", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                        writeError("LCH對位孔置中錯誤", $"讀取當前KEYENCE檢測內容相似度低於門檻50 {sub_im[3]}，CV-X 錯誤");
                        _Alignment_AT_FindHole_flag = 0;
                        _is_Alignment_Auto_FindHole = false;
                    }
                    break;

                case 5://補償 //移動xy軸
                    if (myController.Commands.Motion.WaitForMotionDone(Aerotech.A3200.Commands.WaitOption.InPosition, 0, 2000) && myController.Commands.Motion.WaitForMotionDone(Aerotech.A3200.Commands.WaitOption.InPosition, 1, 2000) && myController.Commands.Motion.WaitForMotionDone(Aerotech.A3200.Commands.WaitOption.InPosition, 2, 2000))
                    {
                            prog_status = "LCH對位孔置中-補償中";
                            writeEvent("LCH對位孔置中", $"{prog_status}");

                            Distance_X = Convert.ToDouble(hole_comp_X) / 970;
                            Distance_Y = -Convert.ToDouble(hole_comp_Y) / 970;
                            double[] Speed = { 30, 30 };
                            double[] Distance = { Distance_X, Distance_Y };
                            this.moveRel(0, Distance_X, fastspeed);
                            this.moveRel(1, Distance_Y, fastspeed);
                            _Alignment_AT_FindHole_flag = 6;
                        
                    }
                    break;

                case 6:
                    if (waitMotionDone(axisIndexXYZ, 10000))
                    {
                        if (Motion_X && Motion_Y && Motion_Z)
                        {
                            Thread.Sleep(100);
                            _Alignment_AT_FindHole_flag = 100;
                        }
                    }
                    break;

                case 7:
                    break;
                case 8:
                    break;
                case 9:
                    break;
                case 10:
                    break;
                case 11:
                    break;

                case 100:
                    process_completion_text = prog_status = "定位孔至中完成,可以繼續操作";
                    _Alignment_AT_FindHole_flag = 0;
                    _is_Alignment_Auto_FindHole = false;
                    break;
            }
        }

        #endregion
    }
}
