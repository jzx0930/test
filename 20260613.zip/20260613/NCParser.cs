﻿//using System;
//using System.Collections.Generic;
//using System.IO;
//using System.Linq;
//using System.Text;
//using System.Threading.Tasks;

//namespace LaserProcess_LCH
//{
//    public class NCParser : Module_Interface.Module
//    {
//        public enum ExeType
//        {
//            Motion,
//            Laser,
//            LaserScanner,
//            ConfocalLaser
//        }
//        private Dictionary<string, string> _iniDic;
//        public string _InitialDirectory;
//        public string _ProjectDirectory;
//        public string _NCName;
//        private string _NC_FilePath;
//        private string _DrillDataSet_FilePath;
//        private string _MotionParam_FilePath;
//        private string _LaserParam_FilePath;
//        private string _Operation_FilePath;
//        private string _ScannerJob_FilePath;

//        //NC Code
//        public string _NCCode;
//        public int _HashCode;

//        //DrillDataSet
//        public int _DDS_RowCount;
//        public string[] _DDS_FileHeader = { "Index", "LoadData", "FilePath|#S", "ArrayName|#S", "NbrOfFeatures", "ZProbe", "ZprobePositionX", "ZprobePositionY", "ScanheadFilePath|#S", "LaserPowerPct", "LaserDivider" };
//        public bool[] _DDS_LoadData; //DrillDataSet (DDS)
//        public string[] _DDS_FilePath;
//        public string[] _DDS_ArrayName;
//        public int[] _DDS_NbrOfFeature;
//        public bool[] _DDS_ZProbe;
//        public double[] _DDS_ZprobePositionX;
//        public double[] _DDS_ZprobePositionY;
//        public string[] _DDS_ScanheadFilePath;
//        public int[] _DDS_LaserPower;
//        public int[] _DDS_LaserDivider;

//        public int _Op_GH_Index;
//        public int _Op_LamGH_Index;
//        public int _Op_Others_Index;
//        public int _Op_Edge_Index;

//        //DrillFeature
//        public struct Position
//        {
//            public double X;
//            public double Y;
//        }
//        public Position[,] _DrillFeatures;
//        public struct PositionType
//        {
//            public double X;
//            public double Y;
//            public int Type;
//        }
//        public PositionType[] _NewDrillFeatures;

//        public struct CCWCircularPosition
//        {
//            public double X;
//            public double Y;
//            public double I;
//            public double J;
//        }

//        public struct CWCircularPosition
//        {
//            public double X;
//            public double Y;
//            public double I;
//            public double J;
//        }

//        //Operation
//        public int _Op_RowCount;
//        public string[] _Op_FileHeader = { "Index", "Execute", "Status", "LaserParamSet", "MotionParamSet", "Offset", "CutRepeat", "Probe" };
//        public bool[] _Op_Execute;  //Operation (Op)
//        public int[] _Op_Status;
//        public int[] _Op_LaserParamSet;
//        public int[] _Op_MotionParamSet;
//        public int[] _Op_Offset;
//        public int[] _Op_CutRepeat;
//        public bool[] _Op_Probe;
//        private string[,] _Op_Data;
//        public DrillPositions[] _GuideHole_DrillPositionData;
//        public int _GuideHole_NbrOfData;
//        public string _GuideHole_JobName;
//        public LamGHPositions[] _LamGH_PositionData;
//        public int _LamGH_NbrOfData;
//        public string _LamGH_JobName;
//        public CutPositions[] _Others_CutPositionData;
//        public int _Others_NbrOfData_Cut;
//        public DrillPositions[] _Others_DrillPositionData;
//        public int _Others_NbrOfData_Drill;
//        public string _Others_JobName;
//        public EdgePositions _Edge_PositionData;
//        public int _Edge_NbrOfData;
//        public string _Edge_JobName;

//        // MotionParam
//        public int _MP_RowCount;
//        public int[] _MP_CutSpeed;
//        public int[] _MP_FastSpeed;

//        // LaserParam
//        public int _LP_RowCount;
//        public int[] _LP_Divider;
//        public int[] _LP_PowerPct;
//        public int[] _LP_PulseWidth;

//        private enum OpProcess
//        {
//            ProcessPosition,
//            StartCP,
//            LoopCP,
//            EndCP
//        }

//        private enum LamGHProcess
//        {
//            FirstPosition,
//            SecondPosition,
//            ProcessPosition,
//            StartCP,
//            LoopPosition,
//            EndCP,
//            EndParsing
//        }

//        private enum CutProcess
//        {
//            FirstPosition,
//            ProcessPosition,
//            StartCP,
//            LoopPosition,
//            EndCP,
//            EndParsing
//        }

//        private enum EdgeProcess
//        {
//            FirstPosition,
//            ProcessPosition,
//            StartCP,
//            LoopPosition,
//            EndCP,
//            EndParsing
//        }

//        //OperationFeature
//        public struct DrillPositions
//        {
//            public Position ProcessPosition;
//            public CCWCircularPosition StartCP;    //CircularPosition (CP)
//            public CCWCircularPosition LoopCP;
//            public CCWCircularPosition EndCP;
//        }

//        public struct LamGHPositions
//        {
//            public Position FirstPosition;
//            public Position SecondPosition;
//            public Position ProcessPosition;
//            public CWCircularPosition StartCP;
//            public Position[] LoopPosition;
//            public CWCircularPosition EndCP;
//        }

//        public struct CutPositions
//        {
//            public Position FirstPosition;
//            public Position ProcessPosition;
//            public CWCircularPosition StartCP;
//            public Position[] LoopPosition;
//            public CWCircularPosition EndCP;
//        }

//        public struct EdgePositions
//        {
//            public Position FirstPosition;
//            public Position ProcessPosition;
//            public CCWCircularPosition StartCP;
//            public Position[] LoopPosition;
//            public CCWCircularPosition EndCP;
//        }

//        public NCParser(string name) : base(name)
//        {
//            // Update _iniDic and private parameters
//            _iniDic = this.GetIniDic();
//            this.UpdatePublicParams();
//        }

//        ~NCParser()
//        {
//            Destruction();
//        }

//        private void Destruction()
//        {
//            // Write back ini file
//            this.WriteIniFile(_iniDic);
//        }

//        #region Public Method

//        public void UpdatePublicParams()
//        {
//            try
//            {
//                _InitialDirectory = _iniDic["InitialDirectory"];
//            }
//            catch (Exception ex)
//            {
//                throw ex;
//            }
//        }

//        public void WriteIntoIniFile()
//        {
//            try
//            {
//                // Update dictionary list
//                _iniDic["InitialDirectory"] = _InitialDirectory;

//                // Write back ini file
//                this.WriteIniFile(_iniDic);
//            }
//            catch (Exception ex)
//            {
//                throw ex;
//            }
//        }

//        public void ParseData()
//        {
//            this.UpdateFilePath();

//            this.UpdateNCCode();

//            this.UpdateDrillDataSetData();

//            this.UpdateDrillFeaturesData();

//            this.UpdateOperationData();

//            this.UpdateNewDrillFeatureData();

//            this.UpdateMotionParamData();

//            this.UpdateLaserParamData();

//            this.UpdateGuideHoleOperationData();

//            this.UpdateLamGHOperationData();

//            this.UpdateOthersOperationData();

//            this.UpdateEdgeOperationData();
//        }

//        public void UpdateFilePath()
//        {
//            List<string> filePath = new List<string>();
//            filePath.Add(_ProjectDirectory);
//            filePath.Add("Programs");
//            filePath.Add(_NCName + ".nc");
//            _NC_FilePath = Path.Combine(filePath.ToArray());

//            filePath.Clear();
//            filePath.Add(_ProjectDirectory);
//            filePath.Add("ProgramObjects");
//            filePath.Add("Operation.csv");
//            _Operation_FilePath = Path.Combine(filePath.ToArray());

//            filePath.Clear();
//            filePath.Add(_ProjectDirectory);
//            filePath.Add("ProgramObjects");
//            filePath.Add("DrillDataSet.csv");
//            _DrillDataSet_FilePath = Path.Combine(filePath.ToArray());

//            filePath.Clear();
//            filePath.Add(_ProjectDirectory);
//            filePath.Add("ProgramObjects");
//            filePath.Add("MotionParam.csv");
//            _MotionParam_FilePath = Path.Combine(filePath.ToArray());

//            filePath.Clear();
//            filePath.Add(_ProjectDirectory);
//            filePath.Add("ProgramObjects");
//            filePath.Add("LaserParam.csv");
//            _LaserParam_FilePath = Path.Combine(filePath.ToArray());

//            filePath.Clear();
//            filePath.Add(_ProjectDirectory);
//            filePath.Add("Scanhead");
//            filePath.Add("DryRunJob.jobx");
//            _ScannerJob_FilePath = Path.Combine(filePath.ToArray());
//        }

//        public void UpdateNCCode()
//        {
//            // Read NC code from file and generate HashCode
//            _NCCode = File.ReadAllText(_NC_FilePath, Encoding.UTF8);
//            _HashCode = _NCCode.GetHashCode();

//            // Parse Operation number from List of Operations
//            string _NCCode_ListOfOperations_Start = string.Format("// List of Operations:");
//            string _NCCode_ListOfOperations_End = string.Format("//--------- Operation");
//            int indexStart = _NCCode.IndexOf(_NCCode_ListOfOperations_Start);
//            int indexEnd = _NCCode.IndexOf(_NCCode_ListOfOperations_End);
//            string _NCCode_ListOfOperation = _NCCode.Substring(indexStart + _NCCode_ListOfOperations_Start.Length, indexEnd - (indexStart + _NCCode_ListOfOperations_Start.Length));

//            while (_NCCode_ListOfOperation.IndexOf("\"") > 0)
//            {
//                // Parse Key number
//                indexStart = _NCCode_ListOfOperation.IndexOf("//     ");
//                indexEnd = _NCCode_ListOfOperation.IndexOf(") ");
//                string keyNumber = _NCCode_ListOfOperation.Substring(indexStart + 7, indexEnd - (indexStart + 7));

//                // Parse Key name
//                indexStart = _NCCode_ListOfOperation.IndexOf("\"");
//                indexEnd = _NCCode_ListOfOperation.IndexOf("\"", indexStart + 1);
//                string keyName = _NCCode_ListOfOperation.Substring(indexStart + 1, indexEnd - (indexStart + 1));

//                if (keyName == "GH")
//                    _Op_GH_Index = int.Parse(keyNumber);
//                else if (keyName == "LAM_GH")
//                    _Op_LamGH_Index = int.Parse(keyNumber);
//                else if (keyName == "others")
//                    _Op_Others_Index = int.Parse(keyNumber);
//                else if (keyName == "edge")
//                    _Op_Edge_Index = int.Parse(keyNumber);

//                // Cut already parsed string
//                _NCCode_ListOfOperation = _NCCode_ListOfOperation.Substring(indexEnd + 1);
//            }
//        }

//        public void UpdateDrillDataSetData()
//        {
//            _DDS_RowCount = 0;
//            List<bool> listLoadData = new List<bool>();
//            List<string> listFilePath = new List<string>();
//            List<string> listArrayName = new List<string>();
//            List<int> listNbrOfFeature = new List<int>();
//            List<bool> listZProbe = new List<bool>();
//            List<double> listZprobePositionX = new List<double>();
//            List<double> listZprobePositionY = new List<double>();
//            List<string> listScanheadFilePath = new List<string>();
//            List<int> listLaserPower = new List<int>();
//            List<int> listLaserDivider = new List<int>();

//            // Import data and convert Data Type
//            using (var reader = new StreamReader(_DrillDataSet_FilePath))
//            {
//                // skip 1st row
//                string temp = reader.ReadLine();

//                while (!reader.EndOfStream)
//                {
//                    var line = reader.ReadLine();
//                    var values = line.Split(',');
//                    if (values[0] == "1")
//                        listLoadData.Add(true);
//                    else
//                        listLoadData.Add(false);
//                    listFilePath.Add(values[1]);
//                    listArrayName.Add(values[2]);
//                    listNbrOfFeature.Add(Convert.ToInt32(values[3]));
//                    if (values[4] == "1")
//                        listZProbe.Add(true);
//                    else
//                        listZProbe.Add(false);
//                    listZprobePositionX.Add(Convert.ToDouble(values[5]));
//                    listZprobePositionY.Add(Convert.ToDouble(values[6]));
//                    listScanheadFilePath.Add(values[7]);
//                    listLaserPower.Add(Convert.ToInt32(values[8]));
//                    listLaserDivider.Add(Convert.ToInt32(values[9]));

//                    _DDS_RowCount++;
//                }
//            }

//            // Convert List to Array
//            _DDS_LoadData = listLoadData.ToArray();
//            _DDS_FilePath = listFilePath.ToArray();
//            _DDS_ArrayName = listArrayName.ToArray();
//            _DDS_NbrOfFeature = listNbrOfFeature.ToArray();
//            _DDS_ZProbe = listZProbe.ToArray();
//            _DDS_ZprobePositionX = listZprobePositionX.ToArray();
//            _DDS_ZprobePositionY = listZprobePositionY.ToArray();
//            _DDS_ScanheadFilePath = listScanheadFilePath.ToArray();
//            _DDS_LaserPower = listLaserPower.ToArray();
//            _DDS_LaserDivider = listLaserDivider.ToArray();

//            //_Op_GH_Index = _DDS_LoadData.Length;
//            //_Op_Others_Index = _Op_GH_Index + 1;
//            //_Op_Edge_Index = _Op_Others_Index + 1;
//        }

//        public void UpdateDrillFeaturesData()
//        {
//            int featureCount = _DDS_LoadData.Length;
//            int pointCount = _DDS_NbrOfFeature.Max();

//            _DrillFeatures = new Position[featureCount, pointCount];

//            for (int i = 0; i < featureCount; i++)
//            {
//                var values = _DDS_FilePath[i].Split('/');  //ex. "./ProgramObjects/red.csv"
//                List<string> filePath = new List<string>();
//                filePath.Add(_ProjectDirectory);
//                filePath.Add(values[1]);
//                filePath.Add(values[2]);
//                string file = Path.Combine(filePath.ToArray());

//                using (var reader = new StreamReader(file))
//                {
//                    // skip 1st row
//                    reader.ReadLine();

//                    for (int j = 0; j < pointCount; j++)
//                    {
//                        var line = reader.ReadLine();
//                        values = line.Split(',');
//                        _DrillFeatures[i, j].X = Convert.ToDouble(values[0]);
//                        _DrillFeatures[i, j].Y = Convert.ToDouble(values[1]);
//                    }
//                }
//            }
//        }

//        private void UpdateNewDrillFeatureData()
//        {
//            // Create new list for Sorted drill features
//            List<PositionType> _FeatureList = new List<PositionType>();
//            for (int i = 0; i < _DDS_RowCount; i++)
//            {
//                if (_Op_Execute[i])
//                {
//                    if (_DDS_LoadData[i])
//                    {
//                        for (int j = 0; j < _DDS_NbrOfFeature[i]; j++)
//                        {
//                            PositionType position = new PositionType();
//                            position.X = _DrillFeatures[i, j].X;
//                            position.Y = _DrillFeatures[i, j].Y;
//                            position.Type = i;
//                            _FeatureList.Add(position);
//                        }
//                    }
//                }
//            }

//            // Sort order
//            // (Y) Ascending - => +
//            // (X) Descending + => -
//            _NewDrillFeatures = _FeatureList.OrderBy(pos => pos.Y).ThenByDescending(pos => pos.X).ToArray();
//        }

//        public void UpdateOperationData()
//        {
//            string[][] matrix;
//            using (var reader = new StreamReader(_Operation_FilePath))
//            {
//                List<string[]> temp = new List<string[]>();
//                while (!reader.EndOfStream)
//                {
//                    var line = reader.ReadLine();
//                    var values = line.Split(',');
//                    temp.Add(values);
//                }
//                matrix = temp.ToArray();
//            }

//            // Evaluate String array
//            string[] sExecute = getColDataArray(matrix, "Execute");
//            string[] sStatus = getColDataArray(matrix, "Status");
//            string[] sLaserParamSet = getColDataArray(matrix, "LaserParamSet");
//            string[] sMotionParamSet = getColDataArray(matrix, "MotionParamSet");
//            string[] sOffset = getColDataArray(matrix, "Offset");
//            string[] sCutRepeat = getColDataArray(matrix, "CutRepeat");
//            string[] sProbe = getColDataArray(matrix, "Probe");
//            _Op_RowCount = sExecute.Length;

//            // Initialize params
//            _Op_Execute = new bool[_Op_RowCount];
//            _Op_Status = new int[_Op_RowCount];
//            _Op_LaserParamSet = new int[_Op_RowCount];
//            _Op_MotionParamSet = new int[_Op_RowCount];
//            _Op_Offset = new int[_Op_RowCount];
//            _Op_CutRepeat = new int[_Op_RowCount];
//            _Op_Probe = new bool[_Op_RowCount];

//            // Data Type conversion
//            for (int i = 0; i < _Op_RowCount; i++)
//            {
//                if (sExecute[i] == "1")
//                    _Op_Execute[i] = true;
//                else
//                    _Op_Execute[i] = false;
//                _Op_Status[i] = Convert.ToInt32(sStatus[i]);
//                _Op_LaserParamSet[i] = Convert.ToInt32(sLaserParamSet[i]);
//                _Op_MotionParamSet[i] = Convert.ToInt32(sMotionParamSet[i]);
//                _Op_Offset[i] = Convert.ToInt32(sOffset[i]);
//                _Op_CutRepeat[i] = Convert.ToInt32(sCutRepeat[i]);
//                if (sProbe[i] == "1")
//                    _Op_Probe[i] = true;
//                else
//                    _Op_Probe[i] = false;
//            }
//        }

//        public void UpdateMotionParamData()
//        {
//            string[][] matrix;
//            using (var reader = new StreamReader(_MotionParam_FilePath))
//            {
//                List<string[]> temp = new List<string[]>();
//                while (!reader.EndOfStream)
//                {
//                    var line = reader.ReadLine();
//                    var values = line.Split(',');
//                    temp.Add(values);
//                }
//                matrix = temp.ToArray();
//            }

//            // Evaluate String array
//            string[] sCutSpeed = getColDataArray(matrix, "CutSpeed");
//            string[] sFastSpeed = getColDataArray(matrix, "FastSpeed");
//            _MP_RowCount = sCutSpeed.Length;

//            // Initialize params
//            _MP_CutSpeed = new int[_MP_RowCount];
//            _MP_FastSpeed = new int[_MP_RowCount];

//            // Data Type conversion
//            for (int i = 0; i < _MP_RowCount; i++)
//            {
//                _MP_CutSpeed[i] = Convert.ToInt32(sCutSpeed[i]);
//                _MP_FastSpeed[i] = Convert.ToInt32(sFastSpeed[i]);
//            }
//        }

//        public void UpdateLaserParamData()
//        {
//            string[][] matrix;
//            using (var reader = new StreamReader(_LaserParam_FilePath))
//            {
//                List<string[]> temp = new List<string[]>();
//                while (!reader.EndOfStream)
//                {
//                    var line = reader.ReadLine();
//                    var values = line.Split(',');
//                    temp.Add(values);
//                }
//                matrix = temp.ToArray();
//            }

//            // Evaluate String array
//            string[] sDivider = getColDataArray(matrix, "Divider");
//            string[] sPowerPct = getColDataArray(matrix, "PowerPct");
//            string[] sPulseWidth = getColDataArray(matrix, "PulseWidth");
//            _LP_RowCount = sDivider.Length;

//            // Initialize params
//            _LP_Divider = new int[_LP_RowCount];
//            _LP_PowerPct = new int[_LP_RowCount];
//            _LP_PulseWidth = new int[_LP_RowCount];

//            // Data Type conversion
//            for (int i = 0; i < _LP_RowCount; i++)
//            {
//                _LP_Divider[i] = Convert.ToInt32(sDivider[i]);
//                _LP_PowerPct[i] = Convert.ToInt32(sPowerPct[i]);
//                _LP_PulseWidth[i] = Convert.ToInt32(sPulseWidth[i]);
//            }
//        }

//        public void UpdateGuideHoleOperationData()
//        {
//            // Operation => GuideHole application
//            // Substring NC code
//            string _NCCode_GH;
//            string _NCCode_GH_Start = string.Format("//--------- Operation {0} ----------", _Op_GH_Index);
//            string _NCCode_GH_End = string.Format("//--------- Operation {0} ----------", _Op_Others_Index);
//            int indexStart = _NCCode.IndexOf(_NCCode_GH_Start);
//            int indexEnd = _NCCode.IndexOf(_NCCode_GH_End);
//            _NCCode_GH = _NCCode.Substring(indexStart + _NCCode_GH_Start.Length, indexEnd - (indexStart + _NCCode_GH_Start.Length));

//            // Parse JobName
//            string _NCCode_GH_JobName_Start = "call Scanhead.SelectJobByName(\"";
//            string _NCCode_GH_JobName_End = "\",&jobResult)";
//            indexStart = _NCCode_GH.IndexOf(_NCCode_GH_JobName_Start);
//            indexEnd = _NCCode_GH.IndexOf(_NCCode_GH_JobName_End);
//            _GuideHole_JobName = _NCCode_GH.Substring(indexStart + _NCCode_GH_JobName_Start.Length, indexEnd - (indexStart + _NCCode_GH_JobName_Start.Length));

//            string[] splitter = { Environment.NewLine };
//            string[] _Data_GH = _NCCode_GH.Split(splitter, StringSplitOptions.RemoveEmptyEntries);

//            // Proceed GH data parsing
//            int length = _Data_GH.Length;
//            List<DrillPositions> listOpPosition = new List<DrillPositions>();
//            DrillPositions parseOpPosition = new DrillPositions();
//            int i = 0;
//            _GuideHole_NbrOfData = 0;
//            OpProcess state = OpProcess.ProcessPosition;
//            while(i < length)
//            {
//                switch (state)
//                {
//                    case OpProcess.ProcessPosition:
//                        if (_Data_GH[i].IndexOf("G01") < 0)
//                            break;
//                        // Find "G01"
//                        bool isFind1 = false;
//                        string[] tempArray1 = _Data_GH[i].Split();
//                        foreach (var item in tempArray1)
//                        {
//                            searchAndUpdate("X", item, ref parseOpPosition.ProcessPosition.X, ref isFind1);
//                            searchAndUpdate("Y", item, ref parseOpPosition.ProcessPosition.Y, ref isFind1);
//                        }
//                        if (isFind1)
//                            state = OpProcess.StartCP;
//                        break;
//                    case OpProcess.StartCP:
//                        if (_Data_GH[i].IndexOf("G03") < 0)
//                            break;
//                        // Find "G03"
//                        bool isFind2 = false;
//                        string[] tempArray2 = _Data_GH[i].Split();
//                        foreach (var item in tempArray2)
//                        {
//                            searchAndUpdate("X", item, ref parseOpPosition.StartCP.X, ref isFind2);
//                            searchAndUpdate("Y", item, ref parseOpPosition.StartCP.Y, ref isFind2);
//                            searchAndUpdate("I", item, ref parseOpPosition.StartCP.I, ref isFind2);
//                            searchAndUpdate("J", item, ref parseOpPosition.StartCP.J, ref isFind2);
//                        }
//                        if (isFind2)
//                            state = OpProcess.LoopCP;
//                        break;
//                    case OpProcess.LoopCP:
//                        if (_Data_GH[i].IndexOf("G03") < 0)
//                            break;
//                        // Find "G03"
//                        bool isFind3 = false;
//                        string[] tempArray3 = _Data_GH[i].Split();
//                        foreach (var item in tempArray3)
//                        {
//                            searchAndUpdate("X", item, ref parseOpPosition.LoopCP.X, ref isFind3);
//                            searchAndUpdate("Y", item, ref parseOpPosition.LoopCP.Y, ref isFind3);
//                            searchAndUpdate("I", item, ref parseOpPosition.LoopCP.I, ref isFind3);
//                            searchAndUpdate("J", item, ref parseOpPosition.LoopCP.J, ref isFind3);
//                        }
//                        if (isFind3)
//                            state = OpProcess.EndCP;
//                        break;
//                    case OpProcess.EndCP:
//                        if (_Data_GH[i].IndexOf("G03") < 0)
//                            break;
//                        // Find "G03"
//                        bool isFind4 = false;
//                        string[] tempArray4 = _Data_GH[i].Split();
//                        foreach (var item in tempArray4)
//                        {
//                            searchAndUpdate("X", item, ref parseOpPosition.EndCP.X, ref isFind4);
//                            searchAndUpdate("Y", item, ref parseOpPosition.EndCP.Y, ref isFind4);
//                            searchAndUpdate("I", item, ref parseOpPosition.EndCP.I, ref isFind4);
//                            searchAndUpdate("J", item, ref parseOpPosition.EndCP.J, ref isFind4);
//                        }
//                        if (isFind4)
//                        {
//                            state = OpProcess.ProcessPosition;
//                            _GuideHole_NbrOfData++;
//                            listOpPosition.Add(parseOpPosition);
//                        }
//                        break;
//                }
//                i++;
//            }
//            // Convert private data to public data
//            _GuideHole_DrillPositionData = listOpPosition.ToArray();
//        }

//        public void UpdateLamGHOperationData()
//        {
//            // Operation => LamGH application
//            // Substring NC code
//            string _NCCode_LamGH;
//            string _NCCode_LamGH_Start = string.Format("//--------- Operation {0} ----------", _Op_LamGH_Index);
//            string _NCCode_LamGH_End = string.Format("//--------- Operation {0} ----------", _Op_Others_Index);
//            int indexStart = _NCCode.IndexOf(_NCCode_LamGH_Start);
//            int indexEnd = _NCCode.IndexOf(_NCCode_LamGH_End);
//            _LamGH_NbrOfData = 0;

//            if (indexStart < 0)
//            {
//                // Cannot find the LamGH section
//                return;
//            }

//            _NCCode_LamGH = _NCCode.Substring(indexStart + _NCCode_LamGH_Start.Length, indexEnd - (indexStart + _NCCode_LamGH_Start.Length));

//            // Parse JobName
//            string _NCCode_Others_JobName_Start = "call Scanhead.SelectJobByName(\"";
//            string _NCCode_Others_JobName_End = "\",&jobResult)";
//            indexStart = _NCCode_LamGH.IndexOf(_NCCode_Others_JobName_Start);
//            indexEnd = _NCCode_LamGH.IndexOf(_NCCode_Others_JobName_End);
//            _LamGH_JobName = _NCCode_LamGH.Substring(indexStart + _NCCode_Others_JobName_Start.Length, indexEnd - (indexStart + _NCCode_Others_JobName_Start.Length));

//            string[] splitter = { Environment.NewLine };
//            string[] _Data_LamGH = _NCCode_LamGH.Split(splitter, StringSplitOptions.RemoveEmptyEntries);

//            // Proceed Others data parsing
//            int length = _Data_LamGH.Length;
//            Position firstPosition = new Position();
//            Position secondPosition = new Position();
//            Position processPosition = new Position();
//            CWCircularPosition startCP = new CWCircularPosition();
//            List<Position> listLoopPosition = new List<Position>();
//            CWCircularPosition endCP = new CWCircularPosition();
//            List<LamGHPositions> listLamGHPositions = new List<LamGHPositions>();
//            int i = 0;
//            LamGHProcess state = LamGHProcess.FirstPosition;
//            while (i < length)
//            {
//                switch (state)
//                {
//                    case LamGHProcess.FirstPosition:
//                        if (_Data_LamGH[i].IndexOf("G01") < 0)
//                            break;
//                        // Find "G01"
//                        bool isFind1 = false;
//                        string[] tempArray1 = _Data_LamGH[i].Split();
//                        foreach (var item in tempArray1)
//                        {
//                            searchAndUpdate("X", item, ref firstPosition.X, ref isFind1);
//                            searchAndUpdate("Y", item, ref firstPosition.Y, ref isFind1);
//                        }
//                        if (isFind1)
//                        {
//                            _Edge_NbrOfData++;
//                            state = LamGHProcess.SecondPosition;
//                        }
//                        break;
//                    case LamGHProcess.SecondPosition:
//                        if (_Data_LamGH[i].IndexOf("G01") < 0)
//                            break;
//                        // Find "G01"
//                        bool isFind2 = false;
//                        string[] tempArray2 = _Data_LamGH[i].Split();
//                        foreach (var item in tempArray2)
//                        {
//                            searchAndUpdate("X", item, ref secondPosition.X, ref isFind2);
//                            searchAndUpdate("Y", item, ref secondPosition.Y, ref isFind2);
//                        }
//                        if (isFind2)
//                        {
//                            state = LamGHProcess.ProcessPosition;
//                        }
//                        break;
//                    case LamGHProcess.ProcessPosition:
//                        if (_Data_LamGH[i].IndexOf("G01") < 0)
//                            break;
//                        // Find "G01"
//                        bool isFind3 = false;
//                        string[] tempArray3 = _Data_LamGH[i].Split();
//                        foreach (var item in tempArray3)
//                        {
//                            searchAndUpdate("X", item, ref processPosition.X, ref isFind3);
//                            searchAndUpdate("Y", item, ref processPosition.Y, ref isFind3);
//                        }
//                        if (isFind3)
//                        {
//                            _Edge_NbrOfData++;
//                            state = LamGHProcess.StartCP;
//                        }
//                        break;
//                    case LamGHProcess.StartCP:
//                        if (_Data_LamGH[i].IndexOf("G02") < 0)
//                            break;
//                        // Find "G03"
//                        bool isFind4 = false;
//                        string[] tempArray4 = _Data_LamGH[i].Split();
//                        foreach (var item in tempArray4)
//                        {
//                            searchAndUpdate("X", item, ref startCP.X, ref isFind4);
//                            searchAndUpdate("Y", item, ref startCP.Y, ref isFind4);
//                            searchAndUpdate("I", item, ref startCP.I, ref isFind4);
//                            searchAndUpdate("J", item, ref startCP.J, ref isFind4);
//                        }
//                        if (isFind4)
//                        {
//                            _Edge_NbrOfData++;
//                            state = LamGHProcess.LoopPosition;
//                        }
//                        break;
//                    case LamGHProcess.LoopPosition:
//                        // Find "G03"
//                        if (_Data_LamGH[i].IndexOf("G02") >= 0)
//                        {
//                            state = LamGHProcess.EndCP;
//                            i--;    //Keep its index to enter next Switch case EdgeProcess.EndCP (since i-- and i++)
//                            break;
//                        }
//                        if (_Data_LamGH[i].IndexOf("G01") < 0)
//                            break;
//                        // Find "G01"
//                        bool isFind5 = false;
//                        string[] tempArray5 = _Data_LamGH[i].Split();
//                        Position position = new Position();
//                        foreach (var item in tempArray5)
//                        {
//                            searchAndUpdate("X", item, ref position.X, ref isFind5);
//                            searchAndUpdate("Y", item, ref position.Y, ref isFind5);
//                        }
//                        if (isFind5)
//                        {
//                            _Edge_NbrOfData++;
//                            listLoopPosition.Add(position);
//                        }
//                        break;
//                    case LamGHProcess.EndCP:
//                        if (_Data_LamGH[i].IndexOf("G02") < 0)
//                            break;
//                        // Find "G03"
//                        bool isFind6 = false;
//                        string[] tempArray6 = _Data_LamGH[i].Split();
//                        foreach (var item in tempArray6)
//                        {
//                            searchAndUpdate("X", item, ref endCP.X, ref isFind6);
//                            searchAndUpdate("Y", item, ref endCP.Y, ref isFind6);
//                            searchAndUpdate("I", item, ref endCP.I, ref isFind6);
//                            searchAndUpdate("J", item, ref endCP.J, ref isFind6);
//                        }
//                        if (isFind6)
//                        {
//                            state = LamGHProcess.EndParsing;
//                        }
//                        break;
//                    case LamGHProcess.EndParsing:
//                        LamGHPositions temp = new LamGHPositions();
//                        temp.FirstPosition = firstPosition;
//                        temp.SecondPosition = secondPosition;
//                        temp.ProcessPosition = processPosition;
//                        temp.StartCP = startCP;
//                        temp.LoopPosition = listLoopPosition.ToArray();
//                        listLoopPosition.Clear();
//                        temp.EndCP = endCP;
//                        listLamGHPositions.Add(temp);
//                        _LamGH_NbrOfData++;

//                        state = LamGHProcess.FirstPosition;
//                        i--;    //Keep its index to enter next Switch case EdgeProcess.EndCP (since i-- and i++)
//                        break;
//                }
//                i++;
//            }
//            // Convert private data to public data
//            _LamGH_PositionData = listLamGHPositions.ToArray();
//        }

//        public void UpdateOthersOperationData()
//        {
//            // Operation => Others application
//            // Substring NC code
//            string _NCCode_Others;
//            string _NCCode_Others_Start = string.Format("//--------- Operation {0} ----------", _Op_Others_Index);
//            string _NCCode_Others_End = string.Format("//--------- Operation {0} ----------", _Op_Edge_Index);
//            int indexStart = _NCCode.IndexOf(_NCCode_Others_Start);
//            int indexEnd = _NCCode.IndexOf(_NCCode_Others_End);
//            _NCCode_Others = _NCCode.Substring(indexStart + _NCCode_Others_Start.Length, indexEnd - (indexStart + _NCCode_Others_Start.Length));

//            // Parse JobName
//            string _NCCode_Others_JobName_Start = "call Scanhead.SelectJobByName(\"";
//            string _NCCode_Others_JobName_End = "\",&jobResult)";
//            indexStart = _NCCode_Others.IndexOf(_NCCode_Others_JobName_Start);
//            indexEnd = _NCCode_Others.IndexOf(_NCCode_Others_JobName_End);
//            _Others_JobName = _NCCode_Others.Substring(indexStart + _NCCode_Others_JobName_Start.Length, indexEnd - (indexStart + _NCCode_Others_JobName_Start.Length));

//            string _NCCode_Others_Part1;
//            string _NCCode_Others_Start_Part1 = "-------------------- Position setup --------------------";
//            string _NCCode_Others_End_Part1 = "-------------------- Position setup --------------------";
//            int indexStart_Part1 = _NCCode_Others.IndexOf(_NCCode_Others_Start_Part1);
//            int indexEnd_Part1 = _NCCode_Others.IndexOf(_NCCode_Others_End_Part1, indexStart_Part1 + 1);
//            _NCCode_Others_Part1 = _NCCode_Others.Substring(indexStart_Part1 + _NCCode_Others_Start_Part1.Length, indexEnd_Part1 - (indexStart_Part1 + _NCCode_Others_Start_Part1.Length));

//            string _NCCode_Others_Part2;
//            string _NCCode_Others_Start_Part2 = _NCCode_Others_End_Part1;
//            int indexStart_Part2 = indexEnd_Part1;
//            _NCCode_Others_Part2 = _NCCode_Others.Substring(indexStart_Part2 + _NCCode_Others_Start_Part2.Length);

//            string[] splitter = { Environment.NewLine };
//            string[] _Data_Others_Part1 = _NCCode_Others_Part1.Split(splitter, StringSplitOptions.RemoveEmptyEntries);
//            string[] _Data_Others_Part2 = _NCCode_Others_Part2.Split(splitter, StringSplitOptions.RemoveEmptyEntries);

//            // Proceed Others data parsing
//            // Part1 parsing
//            int length_Part1 = _Data_Others_Part1.Length;
//            Position firstPosition = new Position();
//            Position processPosition = new Position();
//            CWCircularPosition startCP = new CWCircularPosition();
//            List<Position> listLoopPosition = new List<Position>();
//            CWCircularPosition endCP = new CWCircularPosition();
//            List<CutPositions> listCutPositions = new List<CutPositions>();
//            int i = 0;
//            _Others_NbrOfData_Cut = 0;
//            CutProcess state = CutProcess.FirstPosition;
//            while (i < length_Part1)
//            {
//                switch (state)
//                {
//                    case CutProcess.FirstPosition:
//                        if (_Data_Others_Part1[i].IndexOf("G01") < 0)
//                            break;
//                        // Find "G01"
//                        bool isFind1 = false;
//                        string[] tempArray1 = _Data_Others_Part1[i].Split();
//                        foreach (var item in tempArray1)
//                        {
//                            searchAndUpdate("X", item, ref firstPosition.X, ref isFind1);
//                            searchAndUpdate("Y", item, ref firstPosition.Y, ref isFind1);
//                        }
//                        if (isFind1)
//                        {
//                            _Edge_NbrOfData++;
//                            state = CutProcess.ProcessPosition;
//                        }
//                        break;
//                    case CutProcess.ProcessPosition:
//                        if (_Data_Others_Part1[i].IndexOf("G01") < 0)
//                            break;
//                        // Find "G01"
//                        bool isFind2 = false;
//                        string[] tempArray2 = _Data_Others_Part1[i].Split();
//                        foreach (var item in tempArray2)
//                        {
//                            searchAndUpdate("X", item, ref processPosition.X, ref isFind2);
//                            searchAndUpdate("Y", item, ref processPosition.Y, ref isFind2);
//                        }
//                        if (isFind2)
//                        {
//                            _Edge_NbrOfData++;
//                            state = CutProcess.StartCP;
//                        }
//                        break;
//                    case CutProcess.StartCP:
//                        if (_Data_Others_Part1[i].IndexOf("G02") < 0)
//                            break;
//                        // Find "G03"
//                        bool isFind3 = false;
//                        string[] tempArray3 = _Data_Others_Part1[i].Split();
//                        foreach (var item in tempArray3)
//                        {
//                            searchAndUpdate("X", item, ref startCP.X, ref isFind3);
//                            searchAndUpdate("Y", item, ref startCP.Y, ref isFind3);
//                            searchAndUpdate("I", item, ref startCP.I, ref isFind3);
//                            searchAndUpdate("J", item, ref startCP.J, ref isFind3);
//                        }
//                        if (isFind3)
//                        {
//                            _Edge_NbrOfData++;
//                            state = CutProcess.LoopPosition;
//                        }
//                        break;
//                    case CutProcess.LoopPosition:
//                        // Find "G03"
//                        if (_Data_Others_Part1[i].IndexOf("G02") >= 0)
//                        {
//                            state = CutProcess.EndCP;
//                            i--;    //Keep its index to enter next Switch case EdgeProcess.EndCP (since i-- and i++)
//                            break;
//                        }
//                        if (_Data_Others_Part1[i].IndexOf("G01") < 0)
//                            break;
//                        // Find "G01"
//                        bool isFind4 = false;
//                        string[] tempArray4 = _Data_Others_Part1[i].Split();
//                        Position position = new Position();
//                        foreach (var item in tempArray4)
//                        {
//                            searchAndUpdate("X", item, ref position.X, ref isFind4);
//                            searchAndUpdate("Y", item, ref position.Y, ref isFind4);
//                        }
//                        if (isFind4)
//                        {
//                            _Edge_NbrOfData++;
//                            listLoopPosition.Add(position);
//                        }
//                        break;
//                    case CutProcess.EndCP:
//                        if (_Data_Others_Part1[i].IndexOf("G02") < 0)
//                            break;
//                        // Find "G03"
//                        bool isFind5 = false;
//                        string[] tempArray5 = _Data_Others_Part1[i].Split();
//                        foreach (var item in tempArray5)
//                        {
//                            searchAndUpdate("X", item, ref endCP.X, ref isFind5);
//                            searchAndUpdate("Y", item, ref endCP.Y, ref isFind5);
//                            searchAndUpdate("I", item, ref endCP.I, ref isFind5);
//                            searchAndUpdate("J", item, ref endCP.J, ref isFind5);
//                        }
//                        if (isFind5)
//                        {
//                            state = CutProcess.EndParsing;
//                        }
//                        break;
//                    case CutProcess.EndParsing:
//                        CutPositions temp = new CutPositions();
//                        temp.FirstPosition = firstPosition;
//                        temp.ProcessPosition = processPosition;
//                        temp.StartCP = startCP;
//                        temp.LoopPosition = listLoopPosition.ToArray();
//                        listLoopPosition.Clear();
//                        temp.EndCP = endCP;
//                        listCutPositions.Add(temp);
//                        _Others_NbrOfData_Cut++;

//                        state = CutProcess.FirstPosition;
//                        i--;    //Keep its index to enter next Switch case EdgeProcess.EndCP (since i-- and i++)
//                        break;
//                }
//                i++;
//            }
//            // Convert private data to public data
//            _Others_CutPositionData = listCutPositions.ToArray();

//            // Part2 Parsing
//            int length_Part2 = _Data_Others_Part2.Length;
//            List<DrillPositions> listOpPosition = new List<DrillPositions>();
//            DrillPositions parseOpPosition = new DrillPositions();
//            int j = 0;
//            _Others_NbrOfData_Drill = 0;
//            OpProcess state_Part2 = OpProcess.ProcessPosition;
//            while (j < length_Part2)
//            {
//                switch (state_Part2)
//                {
//                    case OpProcess.ProcessPosition:
//                        if (_Data_Others_Part2[j].IndexOf("G01") < 0)
//                            break;
//                        // Find "G01"
//                        bool isFind1 = false;
//                        string[] tempArray1 = _Data_Others_Part2[j].Split();
//                        foreach (var item in tempArray1)
//                        {
//                            searchAndUpdate("X", item, ref parseOpPosition.ProcessPosition.X, ref isFind1);
//                            searchAndUpdate("Y", item, ref parseOpPosition.ProcessPosition.Y, ref isFind1);
//                        }
//                        if (isFind1)
//                            state_Part2 = OpProcess.StartCP;
//                        break;
//                    case OpProcess.StartCP:
//                        if (_Data_Others_Part2[j].IndexOf("G03") < 0)
//                            break;
//                        // Find "G03"
//                        bool isFind2 = false;
//                        string[] tempArray2 = _Data_Others_Part2[j].Split();
//                        foreach (var item in tempArray2)
//                        {
//                            searchAndUpdate("X", item, ref parseOpPosition.StartCP.X, ref isFind2);
//                            searchAndUpdate("Y", item, ref parseOpPosition.StartCP.Y, ref isFind2);
//                            searchAndUpdate("I", item, ref parseOpPosition.StartCP.I, ref isFind2);
//                            searchAndUpdate("J", item, ref parseOpPosition.StartCP.J, ref isFind2);
//                        }
//                        if (isFind2)
//                            state_Part2 = OpProcess.LoopCP;
//                        break;
//                    case OpProcess.LoopCP:
//                        if (_Data_Others_Part2[j].IndexOf("G03") < 0)
//                            break;
//                        // Find "G03"
//                        bool isFind3 = false;
//                        string[] tempArray3 = _Data_Others_Part2[j].Split();
//                        foreach (var item in tempArray3)
//                        {
//                            searchAndUpdate("X", item, ref parseOpPosition.LoopCP.X, ref isFind3);
//                            searchAndUpdate("Y", item, ref parseOpPosition.LoopCP.Y, ref isFind3);
//                            searchAndUpdate("I", item, ref parseOpPosition.LoopCP.I, ref isFind3);
//                            searchAndUpdate("J", item, ref parseOpPosition.LoopCP.J, ref isFind3);
//                        }
//                        if (isFind3)
//                            state_Part2 = OpProcess.EndCP;
//                        break;
//                    case OpProcess.EndCP:
//                        if (_Data_Others_Part2[j].IndexOf("G03") < 0)
//                            break;
//                        // Find "G03"
//                        bool isFind4 = false;
//                        string[] tempArray4 = _Data_Others_Part2[j].Split();
//                        foreach (var item in tempArray4)
//                        {
//                            searchAndUpdate("X", item, ref parseOpPosition.EndCP.X, ref isFind4);
//                            searchAndUpdate("Y", item, ref parseOpPosition.EndCP.Y, ref isFind4);
//                            searchAndUpdate("I", item, ref parseOpPosition.EndCP.I, ref isFind4);
//                            searchAndUpdate("J", item, ref parseOpPosition.EndCP.J, ref isFind4);
//                        }
//                        if (isFind4)
//                        {
//                            state_Part2 = OpProcess.ProcessPosition;
//                            _Others_NbrOfData_Drill++;
//                            listOpPosition.Add(parseOpPosition);
//                        }
//                        break;
//                }
//                j++;
//            }
//            // Convert private data to public data
//            _Others_DrillPositionData = listOpPosition.ToArray();
//        }

//        public void UpdateEdgeOperationData()
//        {
//            // Operation => Edge application
//            // Substring NC code
//            string _NCCode_Edge;
//            string _NCCode_Edge_Start = string.Format("//--------- Operation {0} ----------", _Op_Edge_Index);
//            string _NCCode_Edge_End = "call OffsetManager.ClearAllOffsets();";
//            int indexStart = _NCCode.IndexOf(_NCCode_Edge_Start);
//            int indexEnd = _NCCode.LastIndexOf(_NCCode_Edge_End);
//            _NCCode_Edge = _NCCode.Substring(indexStart + _NCCode_Edge_Start.Length, indexEnd - (indexStart + _NCCode_Edge_Start.Length));

//            // Parse JobName
//            string _NCCode_Edge_JobName_Start = "call Scanhead.SelectJobByName(\"";
//            string _NCCode_Edge_JobName_End = "\",&jobResult)";
//            indexStart = _NCCode_Edge.IndexOf(_NCCode_Edge_JobName_Start);
//            indexEnd = _NCCode_Edge.IndexOf(_NCCode_Edge_JobName_End);
//            _Edge_JobName = _NCCode_Edge.Substring(indexStart + _NCCode_Edge_JobName_Start.Length, indexEnd - (indexStart + _NCCode_Edge_JobName_Start.Length));

//            string[] splitter = { Environment.NewLine };
//            string[] _Data_Edge = _NCCode_Edge.Split(splitter, StringSplitOptions.RemoveEmptyEntries);

//            // Proceed data parsing
//            int length = _Data_Edge.Length;
//            Position firstPosition = new Position();
//            Position processPosition = new Position();
//            CCWCircularPosition startCP = new CCWCircularPosition();
//            List<Position> listLoopPosition = new List<Position>();
//            CCWCircularPosition endCP = new CCWCircularPosition();
            
//            int i = 0;
//            _Edge_NbrOfData = 0;
//            EdgeProcess state = EdgeProcess.FirstPosition;
//            while (i < length)
//            {
//                switch (state)
//                {
//                    case EdgeProcess.FirstPosition:
//                        if (_Data_Edge[i].IndexOf("G01") < 0)
//                            break;
//                        // Find "G01"
//                        bool isFind1 = false;
//                        string[] tempArray1 = _Data_Edge[i].Split();
//                        foreach (var item in tempArray1)
//                        {
//                            searchAndUpdate("X", item, ref firstPosition.X, ref isFind1);
//                            searchAndUpdate("Y", item, ref firstPosition.Y, ref isFind1);
//                        }
//                        if (isFind1)
//                        {
//                            _Edge_NbrOfData++;
//                            state = EdgeProcess.ProcessPosition;
//                        }
//                        break;
//                    case EdgeProcess.ProcessPosition:
//                        if (_Data_Edge[i].IndexOf("G01") < 0)
//                            break;
//                        // Find "G01"
//                        bool isFind2 = false;
//                        string[] tempArray2 = _Data_Edge[i].Split();
//                        foreach (var item in tempArray2)
//                        {
//                            searchAndUpdate("X", item, ref processPosition.X, ref isFind2);
//                            searchAndUpdate("Y", item, ref processPosition.Y, ref isFind2);
//                        }
//                        if (isFind2)
//                        {
//                            _Edge_NbrOfData++;
//                            state = EdgeProcess.StartCP;
//                        }
//                        break;
//                    case EdgeProcess.StartCP:
//                        if (_Data_Edge[i].IndexOf("G03") < 0)
//                            break;
//                        // Find "G03"
//                        bool isFind3 = false;
//                        string[] tempArray3 = _Data_Edge[i].Split();
//                        foreach (var item in tempArray3)
//                        {
//                            searchAndUpdate("X", item, ref startCP.X, ref isFind3);
//                            searchAndUpdate("Y", item, ref startCP.Y, ref isFind3);
//                            searchAndUpdate("I", item, ref startCP.I, ref isFind3);
//                            searchAndUpdate("J", item, ref startCP.J, ref isFind3);
//                        }
//                        if (isFind3)
//                        {
//                            _Edge_NbrOfData++;
//                            state = EdgeProcess.LoopPosition;
//                        }
//                        break;
//                    case EdgeProcess.LoopPosition:
//                        // Find "G03"
//                        if (_Data_Edge[i].IndexOf("G03") >= 0)
//                        {
//                            state = EdgeProcess.EndCP;
//                            i--;    //Keep its index to enter next Switch case EdgeProcess.EndCP (since i-- and i++)
//                            break;
//                        }
//                        if (_Data_Edge[i].IndexOf("G01") < 0)
//                            break;
//                        // Find "G01"
//                        bool isFind4 = false;
//                        string[] tempArray4 = _Data_Edge[i].Split();
//                        Position position = new Position();
//                        foreach (var item in tempArray4)
//                        {
//                            searchAndUpdate("X", item, ref position.X, ref isFind4);
//                            searchAndUpdate("Y", item, ref position.Y, ref isFind4);
//                        }
//                        if (isFind4)
//                        {
//                            _Edge_NbrOfData++;
//                            listLoopPosition.Add(position);
//                        }
//                        break;
//                    case EdgeProcess.EndCP:
//                        if (_Data_Edge[i].IndexOf("G03") < 0)
//                            break;
//                        // Find "G03"
//                        bool isFind5 = false;
//                        string[] tempArray5 = _Data_Edge[i].Split();
//                        foreach (var item in tempArray5)
//                        {
//                            searchAndUpdate("X", item, ref endCP.X, ref isFind5);
//                            searchAndUpdate("Y", item, ref endCP.Y, ref isFind5);
//                            searchAndUpdate("I", item, ref endCP.I, ref isFind5);
//                            searchAndUpdate("J", item, ref endCP.J, ref isFind5);
//                        }
//                        if (isFind5)
//                        {
//                            _Edge_NbrOfData++;
//                            state = EdgeProcess.EndParsing;
//                        }
//                        break;
//                    case EdgeProcess.EndParsing:
//                        break;
//                }
//                i++;
//            }
//            // Convert private data to public data
//            _Edge_PositionData.FirstPosition = firstPosition;
//            _Edge_PositionData.ProcessPosition = processPosition;
//            _Edge_PositionData.StartCP = startCP;
//            _Edge_PositionData.LoopPosition = listLoopPosition.ToArray();
//            _Edge_PositionData.EndCP = endCP;
//        }

//        private static void searchAndUpdate(string value, string item, ref double data, ref bool flag)
//        {
//            if (item.IndexOf(value) >= 0)
//            {
//                data = findGetDblValue(item);
//                flag = true;
//            }
//        }

//        private static double findGetDblValue(string item)
//        {
//            int len = item.Length - 1;
//            char[] temp = new char[len];
//            item.CopyTo(1, temp, 0, len);
//            string sTemp = new string(temp);
//            return Convert.ToDouble(sTemp);
//        }

//        #endregion

//        #region Private Method

//        private string[] getColDataArray(string[][] matrix, string header)
//        {
//            int rowLength = matrix.Length;
//            int colLength = matrix[0].Length;
//            int targetIndex = -1;

//            for (int i = 0; i < colLength; i++)
//            {
//                if (matrix[0][i] == header)
//                {
//                    targetIndex = i;
//                    break;
//                }
//            }
//            if (targetIndex < 0)
//                return new string[0];

//            string[] result = new string[rowLength - 1];
//            for (int i = 0; i < result.Length; i++)
//            {
//                result[i] = matrix[i + 1][targetIndex];
//            }
//            return result;
//        }

//        #endregion
//    }
//}
