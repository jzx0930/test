﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Xml;

namespace LaserProcess_LCH
{
   public class CHPT_MES_FilePath
    {
        public MES_FilePath.wsMES mes_filepath = new MES_FilePath.wsMES();

        public MainForm _mainForm = new MainForm();


        //[BM:掃碼載檔-傳送掃碼得到的資訊給MES，並將回傳之XML資訊Decode出各欄位資訊]
        /// <summary>
        /// 傳送掃碼得到的資訊給MES，並將回傳之XML資訊Decode出各欄位資訊
        /// </summary>
        public Dictionary<string, string> SendMES_AndExtractFields(string lotNo, string procseq, string number = "無輸入板號")
        {
            try
            {
              
                    mes_filepath.Timeout = 120000;//120s  設定逾時門檻時間 超過會輸出錯誤訊息

                string inputXml = BuildMesInputXml(lotNo, procseq);//組合傳送資料之格式
                LogMESRequest("GetParameter", inputXml);                        //寫入機台發送給MES之資訊至MES_FilePathLog.txt

                string responseXml = mes_filepath.GetParameter(inputXml);       //發送 並 儲存 回傳結果
                LogMESResponse("GetParameter", responseXml);                    //寫入MES回傳之XML資訊至MES_FilePathLog.txt

                Dictionary<string, string> mesData = ParseMESResponseToDictionary(responseXml);//解析XML格式，讓人員比較好看

                mesData["層數"] = $"{number}";//將人為輸入的層數存入mesData

                string logEntry = string.Join("\n", mesData.Select(kv => $"{kv.Key}: {kv.Value}"));   // 將 Dictionary 轉成格式化字串

                File.AppendAllText(GetDailyLogPath(), logEntry + "\n\n");  // 寫入日誌檔案"⬇⬇⬇⬇⬇⬇⬇⬇⬇⬇⬇⬇⬇⬇⬇⬇⬇⬇⬇⬇"

                return mesData;//此方法傳出MES回傳之資訊
            }
            catch (Exception ex)
            {
                LogMESException("SendMES_AndExtractFields", ex.ToString());         //寫入LOG-錯誤原因
               

                throw;//將錯誤內容外拋給呼叫此方法的地方其catch會承接此拋出之內容
            }
        }
        
        //[BM: 掃碼載檔-組合MES所需之XML格式之方法]
        /// <summary>
        /// 組合 MES 所需的輸入 XML 結構
        /// </summary>
        public string BuildMesInputXml(string lotNo, string procseq)//設備編號、批號、製程序
        {
            return $@"<?xml version='1.0' encoding='utf-8'?>
            <mfdata>
              <lotdata>
                <no>{lotNo}</no>
                <itemno></itemno>
                <itemver></itemver>
                <mfver></mfver>
                <procseq>{procseq}</procseq>
                <proceqp></proceqp>
              </lotdata>
              <procdata></procdata>
              <exception></exception>
            </mfdata>";
        }

        //[BM:掃碼載檔-解析MES回傳之資訊]
        /// <summary>
        /// 從 MES 回應之XML內容解析欄位並組成單一格式化字串
        /// </summary>
        /// <param name="responseXml">MES 回傳的 XML 字串</param>
        /// <returns>格式化後的資訊字串</returns>
        private Dictionary<string, string> ParseMESResponseToDictionary(string responseXml)// 從 MES XML 回應中解析欄位並組成 Dictionary
        {
            var result = new Dictionary<string, string>();// 建立結果容器
            XmlDocument doc = new XmlDocument();// 建立 XML 文件物件
            doc.LoadXml(responseXml);// 載入回傳的 XML 字串

            string errorMsg = doc.SelectSingleNode("//exception/errormsg")?.InnerText.Trim();// 取得錯誤訊息（如果有）
            string lotNo = doc.SelectSingleNode("//lotdata/no")?.InnerText.Trim() ?? "";// 取得批號

            if (!string.IsNullOrEmpty(errorMsg))// 如果有錯誤訊息
            {
                result["LotNo"] = lotNo;// 儲存批號
                result["錯誤訊息"] = errorMsg;// 儲存錯誤訊息
                return result;// 回傳錯誤結果
            }

            //[BM:掃碼載檔-MES回傳資訊解析]
            // 正常欄位解析
            result["設備名"] = _mainForm.EquipmentNo; //equipmentNo;
            result["LotNo<no>"] = lotNo;

            result["料號<itemno>"] = doc.SelectSingleNode("//lotdata/itemno")?.InnerText.Trim() ?? "";
            result["版次<itemver>"] = doc.SelectSingleNode("//lotdata/itemver")?.InnerText.Trim() ?? "";
            result["製造版次<mfver>"] = doc.SelectSingleNode("//lotdata/mfver")?.InnerText.Trim() ?? "";
            result["製程序<procseq>"] = doc.SelectSingleNode("//lotdata/procseq")?.InnerText.Trim() ?? "";
            result["品名<erp_itemdescrip>"] = doc.SelectSingleNode("//lotdata/erp_itemdescrip")?.InnerText.Trim() ?? "";
            result["<serialno>"] = doc.SelectSingleNode("//lotdata/serialno")?.InnerText.Trim() ?? "";
            result["狀態<LotStatus>"] = doc.SelectSingleNode("//lotdata/LotStatus")?.InnerText.Trim() ?? "";
            result["<opno>"] = doc.SelectSingleNode("//lotdata/opno")?.InnerText.Trim() ?? "";
            result["<Brno>"] = doc.SelectSingleNode("//lotdata/Brno")?.InnerText.Trim() ?? "";
            result["案件名"] = doc.SelectSingleNode("//procdata/procprams/procpram[procprammes='CaseName']/procvalue")?.InnerText.Trim() ?? "";


            result["---------------"] = "";
            result[""] = doc.SelectSingleNode("//procdata/procname")?.InnerText.Trim() ?? "";
            result["--------------"] = "";

            return result;// 回傳解析結果
        }

        //[BM:掃碼載檔-MES回傳之資訊正理使LOG內容好閱讀]
        /// <summary>
        /// 將MES回傳的XML資訊，解析成一行一行的給LogMESResponse()寫入MES_FilePathLog.TXT。
        /// </summary>
        /// <param name="xml">MES 回傳的 XML 字串</param>
        /// <returns>整理後的資訊字串</returns>
        private string FormatXml(string xml)//// 將壓縮的 XML 字串格式化為有縮排的可讀格式
        {
            try
            {
                var doc = new XmlDocument();
                doc.LoadXml(xml);

                var stringBuilder = new StringBuilder();
                var settings = new XmlWriterSettings
                {
                    Indent = true,// 啟用縮排
                    IndentChars = "  ", // 每層縮排使用兩個空格
                    NewLineChars = "\r\n",// 換行符號
                    NewLineHandling = NewLineHandling.Replace// 替換原始換行
                };

                using (var writer = XmlWriter.Create(stringBuilder, settings))
                {
                    doc.Save(writer);// 將格式化結果寫入 stringBuilder
                }

                return stringBuilder.ToString();// 回傳格式化後的 XML
            }
            catch
            {
                return xml; // 若格式化失敗，回傳原始字串
            }
        }

        //[BM:掃碼載檔-將掃碼後之資訊傳送給 MES]
        /// <summary>
        /// 將掃碼後之資訊傳送給 MES 的 XML 內容寫入LOG。(LCN->MES)
        /// </summary>
        private void LogMESRequest(string functionName, string xml)
        {
            string entry = $"[{DateTime.Now:yyyy-MM-dd HH:mm:ss}] 傳送 MES 方法: {functionName}\n{xml}\r\n\r\n";
            File.AppendAllText(GetDailyLogPath(), entry);//LCN_V01.35 (20250730 carbide power+GH 旋轉盤)\LaserProcess\LaserProcess\LaserProcess\bin\Debug\MES_FilePathLog
        }

        //[BM:掃碼載檔- 將MES回傳之 XML 資訊內容寫入LOG]
        /// <summary>
        /// 將MES回傳之 XML 資訊內容寫入LOG。(MES->LCN)
        /// </summary>
        private void LogMESResponse(string functionName, string result)
        {
            string formattedXml = FormatXml(result); // 將回傳 XML 格式化
            string entry = $"[{DateTime.Now:yyyy-MM-dd HH:mm:ss}] MES 回應 ({functionName}):\n{formattedXml}\r\n⬇⬇⬇⬇⬇⬇⬇⬇⬇⬇⬇⬇⬇⬇⬇⬇⬇⬇⬇⬇⬇⬇⬇⬇⬇⬇⬇⬇⬇⬇\r\n";
            File.AppendAllText(GetDailyLogPath(), entry);//LCN_V01.35 (20250730 carbide power+GH 旋轉盤)\LaserProcess\LaserProcess\LaserProcess\bin\Debug\MES_FilePathLog
        }

        //[BM:掃碼載檔- 傳送設備編號與批號給 MES，過程中若有錯誤，則將錯誤資訊寫入LOG]
        /// <summary>
        /// 傳送設備編號與批號給 MES，過程中若有錯誤，則將錯誤資訊寫入LOG。
        /// </summary>
        public void LogMESException(string context, string ex)
        {
            string entry = $"[{DateTime.Now:yyyy-MM-dd HH:mm:ss}] 錯誤於 {context}: {ex}\r\n\r\n";
            File.AppendAllText(GetDailyLogPath(), entry);//LCN_V01.35 (20250730 carbide power+GH 旋轉盤)\LaserProcess\LaserProcess\LaserProcess\bin\Debug\MES_FilePathLog
        }

        //[BM:掃碼載檔- 組合 MES_FilePath LOG檔案路徑]
        /// <summary>
        /// MES_FilePath LOG檔案路徑 LCN_V01.35 (20250730 carbide power+GH 旋轉盤)\LaserProcess\LaserProcess\LaserProcess\bin\Debug\MES_FilePathLog
        /// </summary>
        private string GetDailyLogPath()
        {
            string fileName = DateTime.Now.ToString("yyyyMMdd") + "_MES_FilePathLog.txt"; // 例如 20251020_MES_FilePathLog.txt
            return Path.Combine(_mainForm.C_Path, "MES_FilePathLog", fileName); // 組合完整路徑
        }





    }
}
