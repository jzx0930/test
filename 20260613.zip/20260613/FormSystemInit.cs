﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace LaserProcess_LCH
{
    public partial class FormSystemInit : Form
    {
        public int iProgress = 0;
        public string sProgress = "";
        private int count = 0;
        private static int countLimit = 5;

        private enum MainState
        {
            Disconnect,
            Connect,
            OK,
            NO,
            Progress
        };

        public FormSystemInit()
        {
            InitializeComponent();
        }

        private void FormSystemInit_Load(object sender, EventArgs e)
        {
            // Update Status Image
            updateMainStatusImage(MainState.Progress);

            TopMost = true;

            timer250.Start();
        }

        #region GUI Control Method

        private void updateMainStatusImage(MainState state)
        {
            string path = @"C:\LCH_system" + "\\images\\" + state + ".png";
            Image temp = Image.FromFile(path);
            Bitmap bitmap = Module_Interface.ImageHandler.ResizeImage(temp, pnl_Main_Status.Width, pnl_Main_Status.Height);
            pnl_Main_Status.BackgroundImage = bitmap;
        }

        #endregion

        private void timer250_Tick(object sender, EventArgs e)
        {
            string msg = string.Format("Current Progress: {0}...", sProgress);
            lbl_CurrentProgress.Text = msg;
            string dot = ".";
            if (count < countLimit)
            {
                count++;
                for (int i = 0; i < count; i++)
                    dot = dot + ".";
            }
            else
                count = 0;
            msg = string.Format("({0}%) Initializing{1}", iProgress, dot);
            lbl_ProgressPercentage.Text = msg;
            progressBar_SysInit.Value = iProgress;
        }
    }
}
