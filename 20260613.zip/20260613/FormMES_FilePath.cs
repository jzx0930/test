﻿using System;
using System.Collections.Generic;
using System.Xml.Linq;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using CHPT_Server_Interface;
using System.IO;
using System.Text.RegularExpressions;

namespace LaserProcess_LCH
{/// <summary>
/// 傳送批號，紀錄MES回傳之資訊，依據回傳結果帶入參數
/// </summary>
    public partial class FormMES_FilePath : System.Windows.Forms.Form
    {
        /// <summary>
        /// 建立 MES 通訊模組的靜態實例（用於呼叫 WebService）
        /// </summary>
        public static CHPT_MES_FilePath chpt_mes_filepath = new CHPT_MES_FilePath();

        private ConfigSystem _ConfigSystem = new ConfigSystem("ConfigSystem");

        /// <summary>
        /// 儲存 MES 回傳資料的欄位（以鍵值對形式）
        /// </summary>
        public Dictionary<string, string> MesData { get; private set; }// 儲存 MES 回傳資料的欄位（以鍵值對形式）
        /// <summary>
        /// 決定是否能夠執行掃描條碼載檔，若要重新掃馬人員需要關閉視窗後再開啟。
        /// </summary>
        bool ReadBarcode_flag;

        private Timer xmlTimer; // 計時器：用來延遲觸發
        private Timer barcodeTimer; // 計時器：用來延遲觸發
        /// <summary>
        /// 計時器：用來延遲觸發(人員輸入層數使用)
        /// </summary>
        private Timer layer_numberTimer;//計時器：用來延遲觸發(人員輸入層數使用)

        public MainForm _mainForm ;

        public FormMES_FilePath(MainForm mainForm)
        {
            _mainForm = mainForm;


            InitializeComponent();
            this.Text = $"掃碼介面";
            ReadBarcode_flag = true;
            this.Load += MES_FilePath_Form_Load; // 綁定表單載入事件，設定初始焦點

            Complete_or_Return.Text = $"返回主頁面";

            //xml資訊進入RTextBox後計時2秒的計時器(計時完成後解析內容)
            xmlTimer = new Timer();
            xmlTimer.Interval = 500; // 0.5秒
            xmlTimer.Tick += XmlTimer_Tick;

            barcodeTimer = new Timer();
            barcodeTimer.Interval = 2000; // 2秒
            barcodeTimer.Tick += BarcodeTimer_Tick;

            layer_numberTimer = new Timer();
            layer_numberTimer.Interval = 2000; // 2秒
            layer_numberTimer.Tick += LayerNumber_Timer_Tick;

        }
        private void MES_FilePath_Form_Load(object sender, EventArgs e)
        {
            BeginInvoke(new Action(() => LotNo_textBox.Focus())); // 使用 BeginInvoke 確保 UI 完成後再設定焦點到批號欄位，使其進入頁面後讓鼠標出現於，要乘載條碼內容的容器中
        }
        private void XmlTimer_Tick(object sender, EventArgs e)//時間到執行的內容
        {
            xmlTimer.Stop();// 停止計時器，避免重複觸發
            ReadBarcode_flag = false; //表示此表單以載入一次條碼，若要重新掃描需要重新進入表單。
            label2.Visible = true;
            try
            {
                // 載入 XML
                XDocument doc = XDocument.Parse(RTBox_SendData.Text.Trim());
                Complete_or_Return.BackColor = Color.Gold;
                Complete_or_Return.Text = $"返回主頁面";

                //
            }
            catch (Exception ex)
            {
                Complete_or_Return.BackColor = Color.Gold;
                Complete_or_Return.Text = $"返回主頁面";

                chpt_mes_filepath.LogMESException("SendMES_AndExtractFields 發生例外", ex.ToString());

                DateTime currentTime = DateTime.Now;
                using (StreamWriter sw = new StreamWriter(Path.Combine(Application.StartupPath, "MES_FilePathLog", currentTime.ToString("yyyyMMdd") + "_MES_FilePath_ErrorLog.txt"), true))// 寫入 LOG，檔案路徑在 ...\LaserProcess_LCH\bin\Debug\MES_FilePathLog
                {
                    sw.WriteLine("時間: " + DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss"));
                    sw.WriteLine("錯誤訊息: " + ex.Message); sw.WriteLine("來源: " + ex.Source);
                    sw.WriteLine("堆疊追蹤: " + ex.StackTrace);
                    sw.WriteLine("----------------------------------------");
                }
                MessageBox.Show($"詳細錯誤資訊請查看 {currentTime.ToString("yyyyMMdd")}_MES_FilePath_ErrorLog.txt", "系統提示", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }
        }
        private void BarcodeTimer_Tick(object sender, EventArgs e)//時間到執行的內容
        {
            barcodeTimer.Stop();// 停止計時器，避免重複觸發
            LotNo_textBox.Enabled = false;//禁用自己
            label2.Visible = true;

            RTBox_SendData.Text = chpt_mes_filepath.BuildMesInputXml(LotNo_textBox.Text, Procseq_textBox.Text);

        }


        private void LayerNumber_Timer_Tick(object sender, EventArgs e)
        {
            layer_numberTimer.Stop(); // 停止舊的計時
            string lastInput = "";

            string input = TB_Layer_Number.Text.Trim();

            if (input == lastInput) return; // 沒變化就不檢查
            lastInput = input;

            // 同時允許「單一數字」或「數字-數字」
            Regex regex = new Regex(@"^([1-9]|[1-9]-[1-9])$");

            if (regex.IsMatch(input))
            {
                Send2MES.Visible = true;
            }
            else if (!string.IsNullOrEmpty(input)) // 只有在有輸入時才提示
            {
                Send2MES.Visible = false;
                MessageBox.Show("請確認輸入格式: 必須是『單一數字』或『數字-數字』，且範圍在 1~9 之間。\n範例: 1、5、9、1-3、9-5、1-6、6-4");
                TB_Layer_Number.Text = ""; // 在對話框之後清除
            }
        }



        private void Send2MES_Click(object sender, EventArgs e)
        {
            Send2MES.Visible = false;       //按過一次即消失，重開走流程才會出現
            Procseq_textBox.Enabled = false;

            string eqpid = _mainForm.EquipmentNo;//設定要發送的資訊-設備編號
            string lotNo = LotNo_textBox?.Text?.Trim();         //設定要發送的資訊-批號
            string procseq = Procseq_textBox?.Text?.Trim();     //設定要發送的資訊-製程序號

            try
            {
                MesData = chpt_mes_filepath.SendMES_AndExtractFields(lotNo, procseq, TB_Layer_Number.Text);//進入發送資料給MES之流程，並將MES回傳資料儲存。

                string displayText = string.Join("\n", MesData.Select(kv => $"{kv.Key}: {kv.Value}"));//將MES回傳資料拆成單筆
                RTBox_RetunData.Text = displayText;//顯示於UI介面
                string targetPath;
                string basePath;
                string folderName;
                if (_mainForm._isSysSimulated == false)
                {
                     basePath = $"{_ConfigSystem._FilePath}"; // ini檔內的路徑
                     folderName = $"{MesData["案件名"]}"; //mes回的路徑 資料夾名稱 ，
                     targetPath = Path.Combine(basePath, folderName);
                }
                else
                {
                     basePath = $"C:\\Users\\250319\\Desktop\\case"; // ini檔內的路徑
                    folderName = $"{MesData["案件名"]}"; //mes回的路徑 資料夾名稱 ，
                     targetPath = Path.Combine(basePath, folderName);
                }

                if (Directory.Exists(targetPath)) //檢查路徑的資料夾是否存在
                {
                    //LD後面只會有一個數字 UD後面有X-Y
                    string layerValue = MesData["層數"];
                    string LayerName = "";

                    if (Regex.IsMatch(layerValue, @"^\d$")) // 第一種情況：MesData["層數"]只有一位數字
                    {
                        LayerName = "LD" + layerValue;//組合要搜尋的名稱

                        string parentPath = targetPath; // 父路徑
                        string keyword = LayerName;     // 固定要檢查的字串

                        string[] subFolders = Directory.GetDirectories(parentPath);// 取得所有子資料夾名稱
                        var matchedFolders = subFolders.Where(folder => Path.GetFileName(folder).Contains(keyword)).ToList();// 檢查哪些資料夾名稱包含指定字串

                        if (matchedFolders.Count ==1)//具有1個正確的 LD+數字 的完整路徑
                        {
                            string targetFolder = matchedFolders[0];
                            _mainForm.Processing_Path = targetFolder;//將路徑儲存
                            DateTime currentTime = DateTime.Now;
                            using (StreamWriter sw = new StreamWriter(Path.Combine(_mainForm.C_Path, "MES_FilePathLog", currentTime.ToString("yyyyMMdd") + "_MES_FilePath_EventLog.txt"), true))// 寫入 LOG，檔案路徑在 
                            {
                                sw.WriteLine($"時間:{DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss")}，掃碼載檔路徑:{_mainForm.Processing_Path}");
                                sw.WriteLine("----------------------------------------");
                            }
                           // this.Close();
                        }
                        else if (matchedFolders.Count > 1)//具多個相同的 LD+數字 
                        {
                            DateTime currentTime = DateTime.Now;
                            using (StreamWriter sw = new StreamWriter(Path.Combine(_mainForm.C_Path, "MES_FilePathLog", currentTime.ToString("yyyyMMdd") + "_MES_FilePath_EventLog.txt"), true))// 寫入 LOG，檔案路徑在 
                            {
                                sw.WriteLine($"時間:{DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss")}，路徑:{targetPath}中。同時存在多個 名稱內具有:{keyword}的資料夾");
                                sw.WriteLine("----------------------------------------");
                            }
                            this.Close();
                            MessageBox.Show($"路徑:{targetPath}中。\n同時存在多個 名稱內具有:{keyword}的資料夾");
                            return;
                        }
                        else//沒有任何 LD+數字
                        {
                            DateTime currentTime = DateTime.Now;
                            using (StreamWriter sw = new StreamWriter(Path.Combine(_mainForm.C_Path, "MES_FilePathLog", currentTime.ToString("yyyyMMdd") + "_MES_FilePath_EventLog.txt"), true))// 寫入 LOG，檔案路徑在 
                            {
                                sw.WriteLine($"時間:{DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss")}，路徑:{targetPath}中。\n沒有找到 名稱內具有:{keyword}的資料夾");
                                sw.WriteLine("----------------------------------------");
                            }
                            this.Close();
                            MessageBox.Show($"路徑:{targetPath}中。\n沒有找到 名稱內具有:{keyword}的資料夾");
                            return;
                        }
                    }
                    else if (Regex.IsMatch(layerValue, @"^\d-\d$")) // 第二種情況：MesData["層數"]為 x-y，且各為一位數字
                    {
                        // 只取前後各一位數字
                        string[] parts = layerValue.Split('-');
                        LayerName = "UD" + parts[0] + "-" + parts[1];

                        string parentPath = targetPath; // 父路徑
                        string keyword = LayerName;     // 固定要檢查的字串

                        string[] subFolders = Directory.GetDirectories(parentPath);// 取得所有子資料夾名稱
                        var matchedFolders = subFolders.Where(folder => Path.GetFileName(folder).Contains(keyword)).ToList();// 檢查哪些資料夾名稱包含指定字串

                        if (matchedFolders.Count == 1)//具有1個正確的 UD+X-Y 的完整路徑
                        {
                            string targetFolder = matchedFolders[0];
                            _mainForm.Processing_Path = targetFolder;//將路徑儲存
                            DateTime currentTime = DateTime.Now;
                            using (StreamWriter sw = new StreamWriter(Path.Combine(_mainForm.C_Path, "MES_FilePathLog", currentTime.ToString("yyyyMMdd") + "_MES_FilePath_EventLog.txt"), true))// 寫入 LOG，檔案路徑在 
                            {
                                sw.WriteLine($"時間:{DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss")}，掃碼載檔路徑:{_mainForm.Processing_Path}");
                                sw.WriteLine("----------------------------------------");
                            }
                           // this.Close();
                        }
                        else if (matchedFolders.Count > 1)//具多個相同的 UD+X-Y
                        {
                            DateTime currentTime = DateTime.Now;
                            using (StreamWriter sw = new StreamWriter(Path.Combine(_mainForm.C_Path, "MES_FilePathLog", currentTime.ToString("yyyyMMdd") + "_MES_FilePath_EventLog.txt"), true))// 寫入 LOG，檔案路徑在 
                            {
                                sw.WriteLine($"時間:{DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss")}，路徑:{targetPath}中。同時存在多個 名稱內具有:{keyword}的資料夾");
                                sw.WriteLine("----------------------------------------");
                            }
                            this.Close();
                            MessageBox.Show($"路徑:{targetPath}中。\n同時存在多個 名稱內具有:{keyword}的資料夾");
                            return;
                        }
                        else//沒有任何 UD+X-Y
                        {
                            DateTime currentTime = DateTime.Now;
                            using (StreamWriter sw = new StreamWriter(Path.Combine(_mainForm.C_Path, "MES_FilePathLog", currentTime.ToString("yyyyMMdd") + "_MES_FilePath_EventLog.txt"), true))// 寫入 LOG，檔案路徑在 
                            {
                                sw.WriteLine($"時間:{DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss")}，路徑:{targetPath}中。\n沒有找到 名稱內具有:{keyword}的資料夾");
                                sw.WriteLine("----------------------------------------");
                            }
                            this.Close();
                            MessageBox.Show($"路徑:{targetPath}中。\n沒有找到 名稱內具有:{keyword}的資料夾");
                            return;
                        }


                    }
                    else
                    {
                        // 防呆：格式不符合
                        LayerName = "格式錯誤: " + layerValue;

                        DateTime currentTime = DateTime.Now;
                        using (StreamWriter sw = new StreamWriter(Path.Combine(_mainForm.C_Path, "MES_FilePathLog", currentTime.ToString("yyyyMMdd") + "_MES_FilePath_EventLog.txt"), true))// 寫入 LOG，檔案路徑在 
                        {
                            sw.WriteLine($"時間:{DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss")}，格式錯誤");
                            sw.WriteLine("----------------------------------------");
                        }
                        this.Close();
                        MessageBox.Show($"格式錯誤");
                        return;

                    }

                    RTBox_CheckInformation.AppendText($"加工檔路徑:{ _mainForm.Processing_Path}");

                    //更改按鈕資訊
                    Complete_or_Return.BackColor = Color.LightGreen;
                    Complete_or_Return.Text = $"載入完成";
                }

                else 
                {
                    DateTime currentTime = DateTime.Now;
                    using (StreamWriter sw = new StreamWriter(Path.Combine(_mainForm.C_Path, "MES_FilePathLog", currentTime.ToString("yyyyMMdd") + "_MES_FilePath_EventLog.txt"), true))// 寫入 LOG，檔案路徑在 
                    {
                        sw.WriteLine($"時間:{DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss")}，路徑:{basePath}。不存在 名為:{folderName}的資料夾");
                        sw.WriteLine("----------------------------------------");
                    }
                    this.Close();

                    MessageBox.Show($"路徑:{basePath}。\n不存在 名為:{folderName}的資料夾");
                    return;
                }
            }

            catch (Exception ex)
            {
                Complete_or_Return.BackColor = Color.Gold;
                Complete_or_Return.Text = $"返回主頁面";

                chpt_mes_filepath.LogMESException("SendMES_AndExtractFields 發生例外", ex.ToString());

                DateTime currentTime = DateTime.Now;
                using (StreamWriter sw = new StreamWriter(Path.Combine(_mainForm.C_Path, "MES_FilePathLog", currentTime.ToString("yyyyMMdd") + "_ErrorLog.txt"), true))// 寫入 LOG，檔案路徑在 ...\LaserProcess\bin\Debug\Log\當天日期
                {
                    sw.WriteLine("時間: " + DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss"));
                    sw.WriteLine("錯誤訊息: " + ex.Message); sw.WriteLine("來源: " + ex.Source);
                    sw.WriteLine("堆疊追蹤: " + ex.StackTrace);
                    sw.WriteLine("----------------------------------------");
                }
                MessageBox.Show($"錯誤:{ex}。錯誤詳情請查看 ErrorLog.txt。位於 bin->Debug->MES_FilePathLog", "系統提示", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }
        }


        private void Complete_or_Return_Click(object sender, EventArgs e)
        {
            this.Close(); // 關閉目前的表單
        }

        private void FormMES_FilePath_FormClosed(object sender, FormClosedEventArgs e)
        {
            return;
        }

        private void TB_Layer_Number_TextChanged(object sender, EventArgs e)
        {
            layer_numberTimer.Stop(); // 停止舊的計時
            layer_numberTimer.Start(); // 重新啟動計時器
        }

        private void LotNo_textBox_TextChanged(object sender, EventArgs e)
        {
            barcodeTimer.Stop(); // 停止舊的計時
            barcodeTimer.Start(); // 重新啟動計時器
        }

        private void RTBox_SendData_TextChanged(object sender, EventArgs e)
        {
            xmlTimer.Stop(); // 停止舊的計時
            xmlTimer.Start(); // 重新啟動計時器
        }
    }
}
